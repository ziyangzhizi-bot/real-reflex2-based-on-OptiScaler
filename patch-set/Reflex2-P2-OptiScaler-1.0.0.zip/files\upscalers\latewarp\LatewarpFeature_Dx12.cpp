// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#include <pch.h>

#include "LatewarpFeature_Dx12.h"

#include "LatewarpIntercept.h"   // p2::NgxSink / p2::LogPlaneProbe (shared with the intercept path)

#include <Config.h>
#include <proxies/NVNGX_Proxy.h>

// NGX feature id 15 == latewarp (Reflex 2). Evidence: the target's own call
// CreateFeature(featureId=15), and nvngx_latewarp.dll being feature 15
// (see _re/reflex2_mod/spec/LATEWARP_ABI.md).
static const unsigned int kLatewarpFeatureId = 15;

namespace
{
// NgxSink and the plane probe live in LatewarpIntercept.{h,cpp}: the feature-layer intercept and
// this self-create path must write through exactly ONE whitelist gate, not two copies.

// AcquireParameters() is a MEMBER now (defined below the namespace): create and evaluate must
// share one object, and it has to be the kind the kernel accepts.

}   // namespace

// GetCapabilityParameters() comes FIRST: the object that D3D12_AllocateParameters() returned
// answered FAIL_UnsupportedParameter to every Get in a live run (see the header), and the next
// EvaluateFeature failed with FAIL_InvalidParameter as if nothing had been written at all.
NVSDK_NGX_Parameter* LatewarpFeatureDx12::AcquireParameters()
{
    if (_parameters != nullptr)
        return _parameters;

    if (auto fn = NVNGXProxy::D3D12_GetCapabilityParameters(); fn != nullptr)
    {
        const NVSDK_NGX_Result r = fn(&_parameters);
        if (r == NVSDK_NGX_Result_Success && _parameters != nullptr)
        {
            LOG_INFO("latewarp: parameter object = D3D12_GetCapabilityParameters");
            return _parameters;
        }

        LOG_WARN("latewarp: D3D12_GetCapabilityParameters -> 0x{0:X}", static_cast<unsigned int>(r));
        _parameters = nullptr;
    }

    if (auto fn = NVNGXProxy::D3D12_AllocateParameters(); fn != nullptr)
    {
        const NVSDK_NGX_Result r = fn(&_parameters);
        if (r == NVSDK_NGX_Result_Success && _parameters != nullptr)
        {
            LOG_WARN("latewarp: falling back to D3D12_AllocateParameters");
            return _parameters;
        }

        LOG_ERROR("latewarp: D3D12_AllocateParameters -> 0x{0:X}", static_cast<unsigned int>(r));
        _parameters = nullptr;
    }

    return nullptr;
}

bool LatewarpFeatureDx12::Init(ID3D12Device* InDevice, ID3D12GraphicsCommandList* InCmdList, const p2::Inputs& In)
{
    if (In.outputWidth == 0 || In.outputHeight == 0)
    {
        // A zero extent is a hard kernel failure (0xBAD00005), so refuse before we spend a
        // CreateFeature on it.
        LOG_ERROR("latewarp: refusing to init with a zero output extent ({0}x{1})", In.outputWidth, In.outputHeight);
        return false;
    }

    if (_p_latewarpHandle != nullptr)
        return true;

    if (NVNGXProxy::NVNGXModule() == nullptr)
    {
        LOG_ERROR("latewarp: nvngx.dll not loaded!");
        return false;
    }

    if (NVNGXProxy::D3D12_CreateFeature() == nullptr)
    {
        LOG_ERROR("latewarp: D3D12_CreateFeature is nullptr");
        return false;
    }

    if (!_ngxInited)
    {
        _ngxInited = NVNGXProxy::InitDx12(InDevice);
        if (!_ngxInited)
        {
            LOG_ERROR("latewarp: NVNGXProxy::InitDx12 failed");
            return false;
        }
    }

    NVSDK_NGX_Parameter* params = AcquireParameters();
    if (params == nullptr)
    {
        LOG_ERROR("latewarp: could not obtain an NGX parameter object");
        return false;
    }

    p2::LogPlaneProbe(params, "fresh-params/before-fill");

    // The extent is mandatory (Latewarp.Output.Width/.Height) and the two decisive keys are
    // written LAST by p2::Fill; P1 proved these two turn a bit-exact copy into a real warp.
    // The caller's inputs carry the PLANES (Depth / MotionVectors / Output / the frame). Creating
    // the feature without them is exactly what made NGX crash inside CreateFeature(15): a live run
    // logged "keys written 7" with no planes at all, then the process died. So take the caller's
    // set verbatim -- and hand CreateFeature the real command list instead of nullptr.
    p2::Inputs inputs = In;

    p2::NgxSink sink(params);
    p2::Stats stats {};
    const int written = p2::Fill(sink, inputs, &stats);

    LOG_INFO("latewarp: feature 15 create; extent {0}x{1}, keys written {2}, refused {3} (refused keys "
             "are outside the 43-key whitelist and were NOT written)",
             In.outputWidth, In.outputHeight, written, stats.refused);

    // ROUND 90: probe AGAIN now that the 23 keys are in -- this is the run that proves the recovered
    // GetPtr slot works against a real NGX parameter object in-game (and shows what we bound: with
    // UIColorAlpha deliberately null until P3-C, 'MISSING' on that ONE key is the expected reading).
    p2::LogPlaneProbe(params, "after-fill");

    _p_latewarpHandle = &_latewarpHandle;
    const NVSDK_NGX_Result result = NVNGXProxy::D3D12_CreateFeature()(
        InCmdList, static_cast<NVSDK_NGX_Feature>(kLatewarpFeatureId), params, &_p_latewarpHandle);

    if (result != NVSDK_NGX_Result_Success)
    {
        LOG_ERROR("latewarp: CreateFeature(featureId=15) -> 0x{0:X}", static_cast<unsigned int>(result));
        _p_latewarpHandle = nullptr;
        return false;
    }

    LOG_INFO("latewarp: CreateFeature(featureId=15) succeeded");
    return true;
}

bool LatewarpFeatureDx12::Evaluate(ID3D12GraphicsCommandList* InCommandList, const p2::Inputs& In)
{
    if (NVNGXProxy::D3D12_EvaluateFeature() == nullptr)
    {
        LOG_ERROR("latewarp: D3D12_EvaluateFeature is nullptr");
        return false;
    }

    if (_p_latewarpHandle == nullptr)
    {
        LOG_ERROR("latewarp: evaluated before the feature was created");
        return false;
    }

    if (InCommandList == nullptr)
    {
        LOG_ERROR("latewarp: evaluated with a null command list");
        return false;
    }

    NVSDK_NGX_Parameter* params = AcquireParameters();
    if (params == nullptr)
        return false;

    // Per-frame refresh: the frame id advances and the decisive keys are re-asserted every
    // frame, which is exactly what the P1 proxy did on the real target.
    ++_frameId;

    p2::Inputs inputs = In;
    inputs.frameId = _frameId;

    p2::NgxSink sink(params);
    p2::Stats stats {};
    p2::Fill(sink, inputs, &stats);

    const NVSDK_NGX_Result result =
        NVNGXProxy::D3D12_EvaluateFeature()(InCommandList, _p_latewarpHandle, params, nullptr);

    if (result != NVSDK_NGX_Result_Success)
    {
        LOG_ERROR("latewarp: EvaluateFeature -> 0x{0:X}", static_cast<unsigned int>(result));
        return false;
    }

    ++_frameCount;

    // P2/E2c2: every 300 evaluations, not every 1000. The 2026-09-29 14:03 run was ~900 frames long,
    // so the old throttle printed #1-#4 and then NOTHING -- which read as 'the pass stopped' when in
    // fact it had been evaluating on every rendered frame. A log that cannot show a healthy run is
    // worse than no log.
    if (_frameCount <= 4 || _frameCount % 300 == 0)
        LOG_INFO("latewarp: eval #{0} frame {1} (keys written {2}, refused {3})", _frameCount, _frameId,
                 stats.written, stats.refused);

    return true;
}

void LatewarpFeatureDx12::Release()
{
    if (NVNGXProxy::D3D12_ReleaseFeature() != nullptr && _p_latewarpHandle != nullptr)
        NVNGXProxy::D3D12_ReleaseFeature()(_p_latewarpHandle);

    _p_latewarpHandle = nullptr;
}

void LatewarpFeatureDx12::Shutdown(ID3D12Device* InDevice)
{
    if (_ngxInited && NVNGXProxy::D3D12_Shutdown1() != nullptr)
        NVNGXProxy::D3D12_Shutdown1()(InDevice);

    _ngxInited = false;
}
