// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
// Self-contained evaluator for NGX feature 15 (latewarp / Reflex 2).
// Deliberately free of IFeature / IFeature_Dx12 / the Upscaler enum: it is driven by the
// reprojection backend, which owns the device, the command list and the frame resources.
#pragma once

#include "LatewarpFeature.h"
#include "LatewarpParams.h"
#include "LatewarpFrameData.h"   // P2/A1: world->view + view->clip matrices

#include <d3d12.h>

class LatewarpFeatureDx12 : public LatewarpFeature
{
  private:
    // ONE parameter object shared by create and evaluate, and it must be the kind the kernel
    // accepts: a live run showed the D3D12_AllocateParameters object answering
    // FAIL_UnsupportedParameter (0xBAD00010) to every Get, after which EvaluateFeature failed
    // with FAIL_InvalidParameter (0xBAD00005) as if our Set calls had never landed.
    NVSDK_NGX_Parameter* _parameters = nullptr;
    NVSDK_NGX_Parameter* AcquireParameters();

    // Persistent storage for the four matrix parameters (see p2::MatrixRing): the kernel reads them
    // after this frame returns, so they may not live on the caller's stack.
    p2::MatrixRing _matrixRing;

  public:
    // Create NGX feature 15 for the given output extent. Idempotent; returns false (and logs
    // why) when the NGX core, the entry point or the feature itself is unavailable.
    bool Init(ID3D12Device* InDevice, ID3D12GraphicsCommandList* InCmdList, const p2::Inputs& In);

    // One warp attempt. `In` must already carry the planes the caller has; planes that are
    // absent stay unset so that nothing is written as null over a game-supplied plane.
    bool Evaluate(ID3D12GraphicsCommandList* InCommandList, const p2::Inputs& In);

    // Storage for the four matrix parameters; the caller binds pointers returned by this ring.
    p2::MatrixRing& MatrixRingRef() { return _matrixRing; }

    // Release the NGX feature. Safe to call more than once.
    void Release();

    // NGX D3D12 shutdown, called from the device-teardown path.
    static void Shutdown(ID3D12Device* InDevice);
};
