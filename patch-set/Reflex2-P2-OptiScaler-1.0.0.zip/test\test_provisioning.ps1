# ---------------------------------------------------------------------------
#  test_provisioning.ps1 -- positive + NEGATIVE tests for install_latewarp_dll.ps1.
#  AC-P2-005 says a missing/foreign feature dll must produce an EXPLICIT error, never a
#  silent success. These are the cases that prove it.
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Continue'
$P2 = Split-Path -Parent $MyInvocation.MyCommand.Path
$P2 = Split-Path -Parent $P2
$Script = Join-Path $P2 'install_latewarp_dll.ps1'
$KnownSha = '81E63B4A9DCFB99B2B71C3DDFD3EA4A0E9780B778BD47E9A6F7F010A7A6C0F20'
$tmp = Join-Path $env:TEMP ('p2prov_' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$fails = 0
function Check([string]$name, [bool]$ok, [string]$detail) {
    if ($ok) { Write-Host ("  [PASS] " + $name + "  " + $detail) }
    else     { Write-Host ("  [FAIL] " + $name + "  " + $detail) -ForegroundColor Red; $script:fails++ }
}
function Run([string[]]$args2) {
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $Script @args2 2>&1 | Out-String
    return @{ text = $out; code = $LASTEXITCODE }
}

Write-Host "=== provisioning tests ==="
$game = Join-Path $tmp 'game'; New-Item -ItemType Directory -Force -Path $game | Out-Null
$realdir = Join-Path $game 'realdir'; New-Item -ItemType Directory -Force -Path $realdir | Out-Null

# --- negative 1: nothing anywhere -> must fail, explicitly -------------------
$r = Run @('-GameDir', $game, '-SkipCore')
Check "no file anywhere -> non-zero exit" ($r.code -ne 0) ("exit=" + $r.code)
Check "no file anywhere -> says what is missing" ($r.text -match 'PROVISIONING FAILED' -and $r.text -match 'nvngx_latewarp.dll') ""
Check "no file anywhere -> does NOT write anything" (-not (Test-Path (Join-Path $game 'nvngx_latewarp.dll'))) ""

# --- negative 2: present but the WRONG build -> must refuse ------------------
$wrong = Join-Path $tmp 'wrong'; New-Item -ItemType Directory -Force -Path $wrong | Out-Null
$wrongFile = Join-Path $wrong 'nvngx_latewarp.dll'
[System.IO.File]::WriteAllBytes($wrongFile, (New-Object byte[] 907296))
$r = Run @('-GameDir', $game, '-LatewarpDll', $wrongFile, '-SkipCore')
Check "wrong hash -> non-zero exit" ($r.code -ne 0) ("exit=" + $r.code)
Check "wrong hash -> REFUSED with both hashes" ($r.text -match 'PROVISIONING REFUSED' -and $r.text -match 'expected sha256' -and $r.text -match 'actual') ""
Check "wrong hash -> nothing copied" (-not (Test-Path (Join-Path $game 'nvngx_latewarp.dll'))) ""

# --- negative 3: -LatewarpDll pointing at a differently named file -----------
$odd = Join-Path $tmp 'odd.dll'; [System.IO.File]::WriteAllBytes($odd, (New-Object byte[] 16))
$r = Run @('-GameDir', $game, '-LatewarpDll', $odd, '-SkipCore')
Check "wrong file name -> non-zero exit" ($r.code -ne 0) ("exit=" + $r.code)

# --- positive: a byte-exact copy gets placed next to the core ---------------
$src = Join-Path $tmp 'nvngx_latewarp.dll'
# build a 907296-byte file whose sha256 is NOT the known one: we cannot fabricate the real
# binary, so the positive path is exercised with -AllowOtherVersion (the flag that exists
# for exactly this) and we assert the PLACEMENT mechanics + copy verification instead.
[System.IO.File]::WriteAllBytes($src, (New-Object byte[] 907296))
$r = Run @('-GameDir', $game, '-LatewarpDll', $src, '-AllowOtherVersion', '-SkipCore')
Check "override path -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "override path -> warns it is unverified" ($r.text -match 'VERSION MISMATCH ACCEPTED') ""
Check "placed beside the exe" (Test-Path (Join-Path $game 'nvngx_latewarp.dll')) ""
Check "placed next to the core" (Test-Path (Join-Path $realdir 'nvngx_latewarp.dll')) ""
Check "placed copy hash == source hash" (((Get-FileHash (Join-Path $game 'nvngx_latewarp.dll') -Algorithm SHA256).Hash) -eq ((Get-FileHash $src -Algorithm SHA256).Hash)) ""

# --- positive 2: a byte-exact file is accepted WITHOUT the override ----------
$game2 = Join-Path $tmp 'game2'; New-Item -ItemType Directory -Force -Path $game2 | Out-Null
$r = Run @('-GameDir', $game2, '-LatewarpDll', $src, '-SkipCore')
Check "non-matching hash without override -> refused" ($r.code -ne 0) ("exit=" + $r.code)
Check "and it still names the expected sha256" ($r.text -match $KnownSha.Substring(0,16)) ""

# --- dry run writes nothing -------------------------------------------------
$r = Run @('-GameDir', $game2, '-LatewarpDll', $src, '-AllowOtherVersion', '-SkipCore', '-DryRun')
Check "dry run -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "dry run -> wrote nothing" (-not (Test-Path (Join-Path $game2 'nvngx_latewarp.dll'))) ""

# --- the CORE must know feature 15 (found the hard way: the driver core does not) ---
$game3 = Join-Path $tmp 'game3'; New-Item -ItemType Directory -Force -Path $game3 | Out-Null
$r = Run @('-GameDir', $game3, '-LatewarpDll', $src, '-AllowOtherVersion')
Check "no core anywhere -> refused" ($r.code -eq 4) ("exit=" + $r.code)
Check "no core -> explains the driver core cannot do latewarp" (($r.text -match 'CORE PROVISIONING FAILED') -and ($r.text -match '0xBAD0000B')) ""
Check "no core -> writes nothing at all" (-not (Test-Path (Join-Path $game3 'nvngx_latewarp.dll'))) ""

# big enough, but carries no latewarp names: must be rejected by CONTENT, not by name
$fakeCore = Join-Path $tmp 'nvngx.dll'
[System.IO.File]::WriteAllBytes($fakeCore, (New-Object byte[] 600000))
$r = Run @('-GameDir', $game3, '-LatewarpDll', $src, '-AllowOtherVersion', '-CoreDll', $fakeCore)
Check "core without latewarp capability -> refused" ($r.code -ne 0) ("exit=" + $r.code)

# the real capable core, when this machine has one
$capable = @(
  (Join-Path $P2 '..\_leftover_backup_20260926\nvngx.dll'),
  'C:\Users\ZhuanZ\Downloads\Reflex2Demo2\Reflex2Demo2\_re\demo_re\harness\ctrl2\nvngx.dll'
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if ($capable) {
    $r = Run @('-GameDir', $game3, '-LatewarpDll', $src, '-AllowOtherVersion', '-CoreDll', $capable)
    Check "capable core -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
    Check "capable core -> placed AS _nvngx.dll" (Test-Path (Join-Path $game3 '_nvngx.dll')) ""
    Check "capable core -> feature dll placed too" (Test-Path (Join-Path $game3 'nvngx_latewarp.dll')) ""
    Check "capable core -> capability reported by content check" ($r.text -match 'Latewarp') ""
} else {
    Write-Host "  [SKIP] no latewarp-capable core found on this machine -- positive core case not exercised"
}

Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
Write-Host ("=== " + $(if ($script:fails -eq 0) { 'PASS' } else { 'FAIL' }) + " (" + $script:fails + " failure(s)) ===")
exit $(if ($script:fails -eq 0) { 0 } else { 1 })
