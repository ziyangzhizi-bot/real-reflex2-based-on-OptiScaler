// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#pragma once
#include "LatewarpUi_Common.h"

#include "SysUtils.h"

#include <d3d12.h>
#include <d3dx/d3dx12.h>
#include <dxgi1_6.h>
#include <shaders/Shader_Dx12Utils.h>
#include <shaders/Shader_Dx12.h>

#define LatewarpUi_NUM_OF_HEAPS 2

// Everything the pass needs besides the five resources. Mirrors the built-in reprojection mask:
// the UI half uses UiDiffThreshold, the static-viewmodel half uses DepthCutoff/CutoffExpandPx, and
// the result is dithered to one bit with the validated blue-noise table before it is handed to the
// kernel as Latewarp.NoWarpMask.
struct LatewarpUiDispatchParams
{
    float UiDiffThreshold = 0.01f;
    float ShowMask = 0.0f;
    float DepthCutoff = 0.0f;
    float CutoffExpandPx = 0.0f;
    uint32_t InvertedDepth = 0;
    float InvScreenWidth = 0.0f;
    float InvScreenHeight = 0.0f;

    // P3-3: 1 = the depth buffer's v axis is flipped vs the pixels (the diagnostic's raycaster needs
    // it). P3-1/P3-2 were withdrawn on 2026-09-28 -- no lead-fill band, no hole-fill gain.
    float DepthFlipY = 0.0f;
    // P3-3: the diagnostic. 1 = paint the reprojection offset as a heat map AND accumulate the
    // 20-word block Dispatch() reads back and logs. 0 (the default) leaves the pass byte-identical
    // to the build before P3-3: nothing is cleared, copied or mapped.
    float DiagMap = 0.0f;
    // The host's PREDICTED centre shift in px (focal * tan(pose angle)) for a distant point. It
    // only travels in the constant buffer so the logged measurement has a reference next to it.
    float DiagRefPx = 0.0f;
    // P2/E2c6: 0..1, how much of the warp the composite applies (1 = the old behaviour, 0 = none).
    float WarpStrength = 1.0f;
    // P2/E2c26: the highlight protection (see the shader): freeze ISOLATED bright points so the
    // reprojection cannot re-sample a 1-2 px specular highlight into the dark surround.
    float HighlightProtect = 0.0f;
    float HighlightThreshold = 1.5f;
    const float* invVPCur = nullptr;   // 16 floats, row-vector convention
    const float* vpPrev = nullptr;
};

class LatewarpUi_Dx12 : public Shader_Dx12, public LatewarpUi_Common
{
  private:
    FrameDescriptorHeap _frameHeaps[LatewarpUi_NUM_OF_HEAPS];

    ID3D12Resource* _buffer = nullptr;

    // The PREVIOUS composite (same desc as `present`), updated at the end of every dispatch with a
    // CopyResource of the composite we just wrote. P3-3's diagnostic samples it where the maths says
    // this pixel came from -- the semantic-free convention check. (P3-2's fill, which also used it,
    // was withdrawn on 2026-09-28.)
    ID3D12Resource* _history = nullptr;

    // Two R8 mask textures: the pass writes one while the kernel reads the other (its mask is one
    // frame old, which is fine for UI/viewmodel masks and avoids a same-frame dependency).
    ID3D12Resource* _maskRing[2] = { nullptr, nullptr };
    int _maskNext = 0;
    bool _maskReady = false;

    // P3-3: the diagnostic. `_diag` is the UAV the shader accumulates into, `_diagRead` its
    // READBACK companion, `_diagZero` an upload buffer of zeros used to clear it (a
    // CopyBufferRegion, so no descriptor heap is needed for the clear). All three are inert unless
    // the panel's diag slider is on.
    ID3D12Resource* _diag = nullptr;
    ID3D12Resource* _diagRead = nullptr;
    ID3D12Resource* _diagZero = nullptr;
    uint32_t _diagFrames = 0;
    float _diagPeakShiftPx = 0.0f;

    uint32_t InNumThreadsX = 16;
    uint32_t InNumThreadsY = 16;

    // Maps `_diagRead`, decodes it and logs it (every 30th diag frame, plus the first three).
    void LogDiagStats(uint32_t width, uint32_t height, float refPx);

    static void ResourceBarrier(ID3D12GraphicsCommandList* InCommandList, ID3D12Resource* InResource,
                                D3D12_RESOURCE_STATES InBeforeState, D3D12_RESOURCE_STATES InAfterState);

  public:
    // The mask to hand the kernel THIS frame: whatever the previous composite wrote. Only valid once
    // HasMask() is true (before the first composite the texture is uninitialised, and binding that
    // could exclude every pixel).
    bool HasMask() const { return _maskReady && _maskRing[0] != nullptr && _maskRing[1] != nullptr; }
    ID3D12Resource* MaskForKernel() const { return HasMask() ? _maskRing[1 - _maskNext] : nullptr; }

    // warped = the kernel output, hudless = the SAME frame without UI (fed to the kernel),
    // present = the backbuffer / game frame (world + UI + viewmodel), depth = the game depth.
    // Writes the composite into `present` and the no-warp mask into the ring slot the kernel will
    // read next frame. Returns false on the first call: like HudCopy it only allocates then, so the
    // caller must keep its own plain-copy fallback for that frame.
    bool Dispatch(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* warped, ID3D12Resource* hudless,
                  ID3D12Resource* present, ID3D12Resource* depth, D3D12_RESOURCE_STATES warpedState,
                  D3D12_RESOURCE_STATES hudlessState, D3D12_RESOURCE_STATES presentState,
                  D3D12_RESOURCE_STATES depthState, const LatewarpUiDispatchParams& params,
                  // P2/E2c32 (T89): the SOURCE may be a different resource than the target the
                  // pass writes. That turns this pass into a FORMAT-CONVERTING copy -- needed
                  // because ScalingOutputColor is R16G16B16A16_FLOAT while the composited
                  // backbuffer is R10G10B10A2_UNORM, so CopyResource between them is illegal.
                  // Defaults keep every existing caller bit-identical.
                  ID3D12Resource* presentSource = nullptr,
                  D3D12_RESOURCE_STATES presentSourceState = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

    // P2/E2c37: THE PEAK BOOST PASS (see the ShowMask > 200 mode branch in LatewarpUi.hlsl).
    // src = the kernel output (its resample has damped the specular peaks), dst = a texture of
    // OURS that receives the lifted copy; the caller then copies THAT into the game texture.
    // No game resource is touched here and every barrier state below is one we set ourselves.
    bool Boost(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* src, ID3D12Resource* dst,
               float amount, float threshold);

    // P2/E2c37c: the boost owns its constant buffer. Sharing _constantBuffer with Dispatch put a
    // second write into the same buffer in the same frame, i.e. a hazard that can hand the boost
    // dispatch the UI pass's constants for a frame.
    ID3D12Resource* _boostConstantBuffer = nullptr;   // same type the base uses for _constantBuffer

    LatewarpUi_Dx12(std::string InName, ID3D12Device* InDevice);

    ~LatewarpUi_Dx12();
};