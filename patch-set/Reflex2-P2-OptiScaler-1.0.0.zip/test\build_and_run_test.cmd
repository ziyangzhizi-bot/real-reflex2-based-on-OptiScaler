@echo off
rem Build + run the offline unit test for the P2 parameter assembly.
rem usage: build_and_run_test.cmd  [<path to LATEWARP_KEYS.tsv>]
setlocal
set TSV=%~1
rem works in the workspace (<mod>\p2\test) and in the released package (<pkg>\test):
if "%TSV%"=="" if exist "%~dp0..\spec\LATEWARP_KEYS.tsv" set TSV=%~dp0..\spec\LATEWARP_KEYS.tsv
if "%TSV%"=="" if exist "%~dp0..\..\spec\LATEWARP_KEYS.tsv" set TSV=%~dp0..\..\spec\LATEWARP_KEYS.tsv
if "%TSV%"=="" set TSV=%~dp0..\..\spec\LATEWARP_KEYS.tsv
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cd /d "%~dp0"
cl /nologo /EHsc /O2 /std:c++17 LatewarpParams_test.cpp "..\files\upscalers\latewarp\LatewarpParams.cpp" "..\files\upscalers\latewarp\LatewarpFrameData.cpp" /Fe:LatewarpParams_test.exe || exit /b 1
echo RUN
LatewarpParams_test.exe "%TSV%"
echo exit=%ERRORLEVEL%
