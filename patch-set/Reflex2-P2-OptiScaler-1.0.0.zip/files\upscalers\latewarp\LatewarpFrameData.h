// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#pragma once

#include <stdint.h>
#include <vector>

// NOTE: SetStreamlineViewToClip / GetFrameData are internally synchronised (see the .cpp);
// callers do not need their own locking.

// Per-frame camera data for latewarp, captured from Streamline's constants hook.
//
// Deliberately dependency-free (no sl::, no D3D12) so it can be unit-tested offline:
// the hook extracts 16 contiguous floats from sl::Constants (sl::float4x4 is
// "float4 row[4]", row major -- sl_consts.h L131/L183) and hands them to us.
//
// Why a double buffer: latewarp wants both the current and the PREVIOUS projection.
// P1 measured on the real target that the pose differs by a frame while the projection
// is identical between frames, so the natural PrevRenderedViewToClip is simply the
// matrix captured on the previous frame index.
namespace p2
{

struct FrameData
{
    float viewToClip[16] = {};
    float prevViewToClip[16] = {};

    // P3-5b: the TAA/DLSS subpixel jitter Streamline carried for this frame, and for the frame
    // before it. The kernel reprojects the PREVIOUS frame (our hudless is `validity != ValidNow`),
    // so `prevJitter` is the one that belongs to the image being warped.
    float jitter[2] = {};
    float prevJitter[2] = {};
    bool hasPrevJitter = false;
    uint32_t frameIndex = 0;
    bool hasCurrent = false;
    bool hasPrevious = false;
    uint32_t updateCount = 0;

    // P3-B (round 88): LATE-LATCH TIMING. `sampleMs` is when THIS frame's camera constants were
    // sampled (the slSetConstants hook); the previous pair is kept too, because the warp can be for a
    // frame while a NEWER sample already exists. All of this is instrumentation: nothing reads it
    // except the log.
    double sampleMs = 0.0;
    double prevSampleMs = 0.0;
    uint32_t prevSampleFrameIndex = 0;
};

// Called from the Streamline slSetConstants hook. A new frameIndex rotates
// current -> previous; repeated calls within the same frame only refresh the current
// matrix (Streamline calls it once per viewport).
void SetStreamlineViewToClip(const float* m16, uint32_t frameIndex);

// Called from the SAME hook, right after SetStreamlineViewToClip and with the same frame: the
// rotation current -> previous is owned by SetStreamlineViewToClip (it is the one that sees the
// frame index change), so this only ever writes the CURRENT value. A NaN or an absurd magnitude
// (|v| > 4 px) is rejected rather than passed to the kernel -- a wrong jitter would shift the
// whole warp.
void SetStreamlineJitter(float x, float y);

// ---------------------------------------------------------------------------
// P2/E2c9 (P0, round 133): THE PRESENT-BOUNDARY CAMERA DOUBLE BUFFER.
//
// WHY. The FG camera ring (_cameraPosition/Up/Right/Forward) is indexed by GetIndex() ==
// _frameCount % 4, and _frameCount advances on EVERY slSetConstants call. The 2026-09-29 22:02
// run MEASURED that cadence: 35783 StartNewFrame calls while the composite ran ~7530 times --
// 4.7 camera samples per PRESENT. A four-slot ring written 4.7 times per present is rewritten
// INSIDE one present interval, so _cameraX[fIndex] and _cameraX[fIndex - 1] are two samples of
// the SAME rendered frame. The matrices handed to the kernel therefore came out near-identical
// (translation differed by ~0.07 units, orientation by 1e-4) and NGX early-outed into a bit-exact
// copy -- the composite itself measured a centre shift of 0.0 px while the camera turned 5.15 deg
// in that same frame. That is why the picture never changed.
//
// WHAT. A strict two-entry history that rotates ONLY at the present boundary:
//   cur  = newest sample at THIS present (the pose the presented image is being held at)
//   prev = newest sample at the PREVIOUS present (the pose the previously presented image was
//          rendered with)
// Camera basis AND clip matrix come from the SAME sl::Constants struct, so the four matrices the
// kernel gets stay from one generation instead of being mixed across the 4.7-sample burst.
struct LwCameraPose
{
    float pos[3] = {};
    float up[3] = {};
    float right[3] = {};
    float fwd[3] = {};
    float viewToClip[16] = {};
    bool valid = false;
};

// Writer: the slSetConstants hook (Streamline's thread). Never blocks longer than a copy.
void SetStreamlineCameraPose(const float pos[3], const float up[3], const float right[3], const float fwd[3],
                             const float viewToClip[16]);

// Reader: the PRESENT path. Returns false until the first sample exists. The writer and the reader
// are different threads, so both outputs are COPIES (S10 F-03 rule).
bool AdvanceStreamlineCameraPose(LwCameraPose& outCur, LwCameraPose& outPrev);

// Instrumentation only: how many samples arrived / how many the presenter has adopted.
uint32_t CameraPoseSerial();
uint32_t CameraPoseConsumed();

// P2/E2c11b (round 139): THE TAG DRIVE. The warp has to happen BEFORE the frame generator reads
// the frame, and the only point that is both "the frame is final" and "the generator has not looked
// at it yet" is the moment the game TAGS its frame-generation inputs (measured: slSetTag carries
// type 0=Depth / 1=Velocity / 2=HudlessColor once per frame, right before it presents).
// At that instant the frame resources ARE the current ones, i.e. validity == ValidNow -- which the
// present-time gate rejected ON PURPOSE -- so the drive point has to be visible to the gate, and the
// near-duplicate suppression may only kick in when the tag drive ACTUALLY did the work, otherwise it
// eats the present-chain fallback as well (that is exactly what the 14:12 run measured: zero passes).
// P2/E2c12: the tag path warps the frame the GENERATOR eats, and the present chain then warps the
// DISPLAYED frame. If the second call advanced the pose pair again, the two would disagree by a
// sub-frame of motion (~1 deg at 4 deg/frame) and leave a residual offset ghost. Pinning the pair at
// the tag keeps the real and the generated frames on the SAME pose.
void PinLatewarpPosePair();
bool LatewarpPosePinned();
bool CurrentLatewarpPosePair(LwCameraPose& outCur, LwCameraPose& outPrev);

void SetLatewarpAtTag(bool on);
bool LatewarpAtTag();
void SetLatewarpTagDriveOk();
bool LatewarpTagDriveRecent();

// Returns a COPY: the writer is Streamline's slSetConstants thread while the reader is the
// render thread, so handing out a reference would be a data race on a 16-float matrix
// (S10 F-03).
FrameData GetFrameData();

// ---------------------------------------------------------------------------
// P3-B: late-latch instrumentation (LOGGING ONLY -- no behaviour anywhere depends on it).
//
// `NowMs()` is a monotonic millisecond clock (std::chrono::steady_clock -- this TU is also
// compiled by the offline unit test WITHOUT the Windows headers).
// `NewestSampleAgeMs(now)` is the age of the newest camera sample: the gap between the moment the
// game's slSetConstants handed us that frame's camera and the moment we are about to warp with it.
// That is the number the late-input idea lives or dies on: if it is a large fraction of the present
// gap, a later sample would still have bought something; if it is near zero there is nothing left to
// squeeze at this layer. Returns -1 when nothing has been sampled yet.
double NowMs();
double NewestSampleAgeMs(double nowMs);

// CONVENTION (and the bug this comment exists to prevent): our W2V is built the way
// XMMatrixLookAtLH/DirectXMath store it, i.e. the basis vectors live in the ROWS and a position is
// multiplied on the LEFT (`v' = v * M`); Streamline's float4x4 is stored the same way. So the
// composed world->clip is `W2V * V2C`, NOT `V2C * W2V`. Mixing that up silently drops the camera
// translation and flips the rotation sign (found by the old P3-2 unit test on 2026-09-27).
//
// P3-3: the two matrices the DIAGNOSTIC reprojects with, so the shader never has to invert anything:
//   outInvVPCur = inverse(W2V_cur * V2C_cur)   -- clip -> world for the CURRENT frame
//   outVPPPrev  = W2V_prev * V2C_prev          -- world -> clip for the PREVIOUS frame
// (row-vector convention, same as everything else here). Returns false on a singular pose.
bool BuildReprojectionMatrices(const float curWorldToView[16], const float curViewToClip[16],
                               const float prevWorldToView[16], const float prevViewToClip[16],
                               float outInvVPCur[16], float outVPPPrev[16]);



// ---------------------------------------------------------------------------
// P3-3: the reprojection DIAGNOSTIC. (P3-2's history fill was WITHDRAWN on 2026-09-28 -- the kernel
// repairs its own holes -- so what is left is the measurement: a wrong depth / v-axis / scale
// convention is INVISIBLE in the picture, so the GPU pass accumulates a small word block per frame,
// the host reads it back and logs it, and the shader can paint the reprojection OFFSET as a heat map.
//
// The word layout is shared by THREE places and must stay in step: the shader (LatewarpUi.hlsl and
// its runtime twin LatewarpUi_Common.h), the readback in LatewarpUi_Dx12.cpp, and this table (which
// the unit test pins).
static constexpr int kDiagWords = 29;


static constexpr int kDiagMaxShiftPx   = 0;    // atomicMax, asuint(float): max |shift| of the frame, px
static constexpr int kDiagOutsideCount = 1;    // atomicAdd: pixels landing outside the previous frame
static constexpr int kDiagMaxOutsidePx = 2;    // atomicMax, asuint(float): how far outside, in px
static constexpr int kDiagMmSumQ       = 3;    // atomicAdd: sum of |history(uvPrev)-present| * 1024
static constexpr int kDiagMmCount      = 4;    // atomicAdd: sampled pixels in that sum
static constexpr int kDiagMmOutSumQ    = 5;    // atomicAdd: the same mismatch, outside pixels only
static constexpr int kDiagMmOutCount   = 6;
static constexpr int kDiagBehindCount  = 7;    // atomicAdd: w <= 0 => 'behind the previous camera'
static constexpr int kDiagPixels       = 8;    // plain store: pixels the pass covered
static constexpr int kDiagDepthW       = 9;    // plain store: the DEPTH TEXTURE's own size. It is NOT
static constexpr int kDiagDepthH       = 10;   //   necessarily the composite's size: if it differs,
                                               //   Depth.Load(pixelCoord) samples the wrong pixel.
static constexpr int kDiagCentreCurX   = 11;   // plain store: the centre pixel's NDC in THIS frame
static constexpr int kDiagCentreCurY   = 12;
static constexpr int kDiagCentrePrevX  = 13;   //   ... and where that point was in the PREVIOUS one
static constexpr int kDiagCentrePrevY  = 14;
static constexpr int kDiagCentreDepth  = 15;   // plain store: the depth value the centre pixel used
static constexpr int kDiagCentreValid  = 16;   // plain store: 1 = the centre sample was written
// P3-3b: the UI MASK, quantified. The user's one concrete observation from the first live run with
// the diagnostic built was 'objects inside the smart-weapon aiming frame are treated as UI and get
// masked'. These three words turn that into numbers: how much of the frame is masked at all, how
// much of it comes from the DEPTH cutout (the viewmodel predicate) rather than the colour diff, and
// how strong that colour diff is. A big cutout share means the depth predicate (or
// InvertedDepth/DepthCutoff) is wrong; a low diff strength means the mask is latching onto a subtle
// screen-space TINT that should have been warped with the world.
static constexpr int kDiagMaskCount    = 17;   // atomicAdd: pixels whose uiMask ended up 1
static constexpr int kDiagMaskCutout   = 18;   // atomicAdd: of those, the ones the DEPTH predicate selected
static constexpr int kDiagMaskDiffQ    = 19;   // atomicAdd: their |present-hudless| * 1024 (mean over the mask)
// P2/E2c25 (T82): WHAT THE WARP COSTS THIN BRIGHT CONTENT -- the "the lamp highlights vanish when I
// turn" report, turned into numbers. `hudless` is the image the kernel was HANDED and `warped` is what
// it returned, so the comparison is one image against itself before/after the reprojection: no
// brightness-space assumption, no mask, no UI. Four luminance bins carry the INPUT energy and the
// (same pixels') OUTPUT energy, quantised to 1/32 and clamped at 8.0 (a bin can never overflow: the
// bins only sum pixels above 0.5 and at most 4M * 256 fits in uint32).
//   kept% = outQ / inQ per bin. A reprojection that destroys specular highlights shows up as a bright
//   bin whose kept collapses while the dark bins stay near 100% -- and the frame max lum tells us
//   which bins are reachable in this game at all.
static constexpr int kDiagBin0InQ      = 20;   // luminance 0.5 - 1.0: input energy  * 32
static constexpr int kDiagBin0OutQ     = 21;   //                  same pixels, warped * 32
static constexpr int kDiagBin1InQ      = 22;   // 1.0 - 2.0
static constexpr int kDiagBin1OutQ     = 23;
static constexpr int kDiagBin2InQ      = 24;   // 2.0 - 4.0
static constexpr int kDiagBin2OutQ     = 25;
static constexpr int kDiagBin3InQ      = 26;   // 4.0 and up
static constexpr int kDiagBin3OutQ     = 27;
static constexpr int kDiagMaxLumQ      = 28;   // atomicMax: the frame''s max luminance * 32 (clamped 256)

// The decoded, human-readable form of one readback. 'valid' is false when the block was never
// written (the first diag frame) or when the pass covered no pixel at all.
struct DiagReadout
{
    bool valid = false;
    float maxShiftPx = 0.f;
    float maxOutsidePx = 0.f;
    float outsidePercent = 0.f;
    float meanMismatch = 0.f;          // 0..1, over the sampled pixels
    float meanMismatchOutside = 0.f;   // 0..1, over the outside pixels only
    uint32_t outsideCount = 0;
    uint32_t behindCount = 0;
    uint32_t pixels = 0;
    int depthWidth = 0;
    int depthHeight = 0;
    float centreCur[2] = {};
    float centrePrev[2] = {};
    float centreDepth = 0.f;
    float centreShiftPx = 0.f;         // |shift| at the centre pixel, px
    bool centreValid = false;          // false = the centre pixel never got that far (w <= 0)
    // P3-3b: the mask
    uint32_t maskCount = 0;
    uint32_t maskCutoutCount = 0;
    float maskPercent = 0.f;
    float maskCutoutPercent = 0.f;     // of the MASK (how much of it is the depth predicate)
    float meanMaskDiff = 0.f;          // 0..1, |present - hudless| averaged over the masked pixels
    // P2/E2c25 (T82): the warp cost to bright content, per luminance bin. A bin with a non-zero
    // input energy and (almost) no output energy is content the reprojection destroyed.
    uint32_t binInQ[4] = {};           // input energy  * 32, per bin
    uint32_t binOutQ[4] = {};          // output energy * 32, over the same pixels
    float maxLum = 0.f;                // the brightest luminance the frame contained (diag only)
};

// Decodes one readback block. `screenWidth/Height` are the composite's size (the pass runs over
// the whole backbuffer), used to turn the NDC shift into pixels. Pure integer/float math so the
// unit test can drive every branch, including the all-zero (never written) block.
bool DecodeDiagStats(const uint32_t words[kDiagWords], int screenWidth, int screenHeight,
                     DiagReadout* out);

// P3-3: the angle between two camera forward vectors, in degrees. MAGNITUDE ONLY, on purpose: the
// live log proved the host's Forward slot is (0.64, -0.77, 0.00), i.e. the slot names are not
// trustworthy, so nothing here interprets which axis the rotation was about. It exists so the log
// can put 'the pose moved N degrees' next to 'the shader measured M px' -- if the two disagree by
// orders of magnitude, the reprojection convention is wrong, which is exactly the failure this
// round is built to make visible. Returns false for a null or degenerate input.
bool ForwardAngleDeg(const float curFwd[3], const float prevFwd[3], float* outDeg);

// P3-3: what a DISTANT point at the frame centre should move by, in pixels, when the camera goes from
// `prevFwd` to `curFwd`: focal * tan(angle). It is the REFERENCE the diag log prints next to the
// shader's per-pixel measurement -- a reference that disagrees with it by orders of magnitude is what
// exposes a wrong reprojection convention. Returns false when the angle or the focal is unusable.
bool PredictCentreShiftPx(const float curFwd[3], const float prevFwd[3], float focalPx, float* outPx);

// Builds the row-major world->view matrix latewarp wants (Latewarp.WorldToViewMatrix) out of the
// FG layer camera vectors. Layout = XMMatrixLookAtLH (verified against the two real captures in
// spec/LATEWARP_ABI.md):
//   row0 = (right.x, up.x, fwd.x, 0)
//   row1 = (right.y, up.y, fwd.y, 0)
//   row2 = (right.z, up.z, fwd.z, 0)
//   row3 = (-dot(right,pos), -dot(up,pos), -dot(fwd,pos), 1)
// Returns false when the basis is degenerate (all three vectors zero), in which case out is
// left zeroed and the caller must NOT bind the key: NGX answers 0xBAD00005 for a matrix that is
// simply absent, and a zero matrix would silently early-out the kernel instead.
// P2/E2c27 (T84): WARP SCALE. The kernel treats the input frame as rendered at prevWorldToView and
// warps it FORWARD to worldToView (P3-DIR measured 1 deg yaw -> f*tan(1deg) px), so scaling the
// DELTA between the two poses scales the shift. alpha = 1 keeps the current behaviour, alpha = 0
// hands the kernel an IDENTICAL pair -- which the offline suite measured to early-out BIT-EXACT
// (dx = 0, 0.000000% pixels changed). It exists because the residual highlight loss is suspected to
// grow with the shift, so the shift has to be a dial before that can be tested.
// Returns false for a null / invalid / out-of-range input; the caller then keeps the pair it has --
// never a half-scaled one. `out` receives cur scaled toward prev on success.
bool ScaleLatewarpWarpDelta(const LwCameraPose& prev, const LwCameraPose& cur, float alpha, LwCameraPose* out);

bool BuildWorldToView(const float right[3], const float up[3], const float fwd[3], const float pos[3],
                      float out[16]);
// ---------------------------------------------------------------------------
//  P3-D: the LATE-INPUT delta (rotation-only late warp).
//
//  The host hands us raw mouse counts that arrived AFTER the game sampled the camera for
//  the frame we are about to warp. With a non-zero gain the counts become a camera
//  rotation which is ADDED to the WorldToView we give the kernel, so the kernel warps
//  toward a NEWER pose than the game had -- the late-input-sampling idea, with the delta
//  CLAMPED, because this host can never feed engine state back.
//
//  gain == 0 makes the pair a bit-exact no-op and gain SHIPS at 0: the sign is validated
//  in the same run that measures the sensitivity (P3-D1).
// ---------------------------------------------------------------------------
// dx > 0 (cursor right)  -> yaw   > 0 (turn right)
// dy > 0 (cursor down)   -> pitch < 0 (look down)
// The dead zone removes hand-resting jitter and is SUBTRACTED from the magnitude, so a slow
// pan is not rescaled; the result is scaled by gain and hard-clamped to +/-maxDeg.
void LateInputYawPitchDeg(int32_t dx, int32_t dy, float yawDegPerCount, float pitchDegPerCount,
                          float deadZoneCounts, float gain, float maxDeg, float* yawDeg, float* pitchDeg);

// Rotates the camera IN PLACE inside a row-major WorldToView built by BuildWorldToView:
//   yaw   > 0 turns RIGHT  (forward moves toward the right axis)
//   pitch > 0 looks UP     (forward moves toward the up axis)
// The camera position is recovered from row 3 and re-encoded with the ROTATED basis, so the
// camera stays exactly where it was -- a pure rotation, which is all a late input delta is.
// yaw == pitch == 0 returns without touching w2v.
void ApplyYawPitchToWorldToViewDeg(float w2v[16], float yawDeg, float pitchDeg);


// The driver stores the POINTER we hand it and dereferences it LATER (the game itself rotates 5
// slots, stride 0x100 = four 4x4 matrices, i.e. one element per frame-in-flight). Handing it the
// address of a stack local would let the GPU read a dead frame, so the matrices live in this ring
// and a new slot is filled once per evaluated frame.
//
// Slot layout (matches the game): +0 current world->view, +16 current view->clip,
// +32 previous world->view, +48 previous view->clip. A null source leaves its block zeroed and
// the caller must ALSO keep the corresponding Inputs pointer null, so the key is not written.
struct MatrixRing
{
    static constexpr int kSlots = 5;
    float slot[kSlots][64] = {};
    uint32_t next = 0;
    uint32_t binds = 0;

    // Fills the next slot (copies what is non-null, zeroes what is not) and returns a pointer to
    // its 64 floats. Never returns nullptr: the caller decides per source whether to bind it.
    const float* Bind(const float* worldToView, const float* viewToClip, const float* prevWorldToView,
                      const float* prevViewToClip);
};

// --- takeover ARMED vs STARTED ---------------------------------------------------------------
// A user asked for an in-game hot start: the takeover owns the presented frame, so start-up and
// loading screens must stay native. The ini/menu switch ARMS the takeover, the hotkey STARTS it.
// Starting STOPPED also keeps OptiScaler's built-in reprojection path skipped -- that path is
// broken in this configuration: on 2026-09-27 15:38 the hotkey flipped the ini switch instead, the
// built-in path went live and died in Reproject_Dx12::Dispatch ("Failed to create a constants
// buffer" -> DXGI_ERROR_INVALID_CALL -> device removed -> the game exited).
void SetRuntimeEnabled(bool on);
bool IsRuntimeEnabled();

// ---------------------------------------------------------------------------
// P3-4a: the Chinese panel rows. The user reads Chinese, and OptiScaler has NO translation layer (its
// menu is hard-coded English), so the rows that matter -- this project's knobs, the takeover switch
// and the depth cutoff -- carry a Chinese label in FRONT of the English one (the English token stays,
// so the gate's markers, the logs and this doc keep matching).
//
// kChinesePanelGlyphs is exactly those labels' CJK characters, as UTF-8. It is spelled with byte
// escapes in the .cpp so this source stays pure ASCII and compiles identically whatever code page the
// compiler assumes (a literal Chinese string in a .cpp compiled without /utf-8 is mojibake soup). The
// panel feeds it to ImFontGlyphRangesBuilder, which grows the font atlas by ~57 glyphs instead of the
// ~20k a full Chinese range would add -- and those glyphs only render if the menu uses a CJK-capable
// TTF (see [Menu] TTFFontPath in the RUNBOOK).
extern const char kChinesePanelGlyphs[];


// ---------------------------------------------------------------------------
//  P3-E: the (M+1)-PRESENTED-FRAME PLAN for one rendered frame.
//
//  With M generated frames inserted after a rendered frame R, the present chain shows
//  M+1 images. Two rules come straight out of the offline experiments and are pinned
//  here so the GPU side cannot quietly break them:
//
//   1. E1 measured that evaluating the SAME source frame with ADVANCING poses is not
//      equivalent to an independent single warp (1.805% of pixels, against a 0.0027%
//      repeat noise band): the kernel keeps state across evaluations inside one rendered
//      frame. Every presented frame must therefore be evaluated into its OWN output.
//   2. A generated frame has no depth, and the kernel skips the matrix composition when
//      the frame is not the rendered one, so generated frames can only get our
//      rotation-only 2D warp while the rendered frame keeps the kernel matrix path.
//
//  The interpolation factor of generated frame k is k/(M+1) toward the NEXT rendered frame
//  (DLSS-G semantics: R, G1..GM, nextR). The plan encodes all of that, so the GPU side is
//  a table walk rather than a decision.
// ---------------------------------------------------------------------------
struct PresentedFrame
{
    int presentedIndex = 0;      // 0 = the rendered frame itself, 1..M = generated frames
    int outputSlot = 0;          // presentedIndex % slots -- one output per presented frame
    float interpolationT = 0.f;  // 0 for the rendered frame, k/(M+1) for generated frame k
    bool isRenderedFrame = true; // true = kernel matrix path, false = our 2D rotation path
};

// Fills plan[0 .. framesToGenerate] (framesToGenerate + 1 entries: the rendered frame plus
// M generated ones) and returns the entry count, or 0 when the arguments are out of range
// (framesToGenerate < 1, slots < 1, plan == nullptr, or planCapacity too small). Nothing is
// written unless the whole plan fits.
int BuildPresentedFramePlan(int framesToGenerate, int slots, PresentedFrame* plan, int planCapacity);

// Test/reinit hook.
void ResetFrameData();

}   // namespace p2
