# ---------------------------------------------------------------------------
#  make_patch_review.ps1 -- turn the applied patch set into a REVIEWABLE artifact.
#
#  INV-P4 requires the changes to be traceable as a patch set AND the diff list to be delivered.
#  Until now the only trace was p2\APPLIED_DIFF.txt: a per-patch line-count summary written into the
#  BUILD tree, not shipped. This script produces two files that ARE shipped in the package:
#
#    PATCH_REVIEW.diff -- a real unified diff (git-style, 3 lines of context) of the pristine tree
#                         versus the applied tree, for every modified source file.
#    PATCH_REVIEW.md   -- the manifest: line deltas, sha256 of both sides, the added backend files,
#                         and an independent whole-tree check of the patch set BLAST RADIUS (it must
#                         touch exactly the 6 modified + 2 generated files and add exactly 8).
#
#  Read-only with respect to both trees. Refuses to run if the target tree is not actually patched.
#  git is used only as a diff engine (no repository is required, it is --no-index).
#
#  usage: .\make_patch_review.ps1 [-Tree <applied tree>] [-Pristine <delivered tree>] [-Out <dir>]
# ---------------------------------------------------------------------------
param(
    [string]$Tree = '',
    [string]$Pristine = '',
    [string]$Out = ''
)
$ErrorActionPreference = 'Stop'
$q    = [char]96   # markdown code span, built without a literal backtick
$P2   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
if (-not $Tree)     { $Tree     = Join-Path $Repo '_re\repro_src' }
if (-not $Pristine) { $Pristine = Join-Path $Repo 'OptiScaler_20260923_154112\OptiScaler_source_5b6bc822\OptiScaler' }
if (-not $Out)      { $Out      = $P2 }
$Src = Join-Path $Tree 'OptiScaler'
if (-not (Test-Path -LiteralPath $Src))      { throw ("applied source tree not found: " + $Src) }
if (-not (Test-Path -LiteralPath $Pristine)) { throw ("pristine tree not found: " + $Pristine) }
$git = (Get-Command git -ErrorAction SilentlyContinue).Source
if (-not $git) { throw 'git is required for a real unified diff' }

if (-not (Select-String -LiteralPath (Join-Path $Src 'Config.h') -Pattern 'ReprojectionUseNvidiaLatewarp' -Quiet)) {
    throw 'the target tree is NOT patched (no ReprojectionUseNvidiaLatewarp in Config.h) -- apply first, then review'
}

$modified  = @('Config.h','Config.cpp','framegen\reprojection\Reprojection_Dx12.h','framegen\reprojection\Reprojection_Dx12.cpp','inputs\NVNGX_DLSS_Dx12.cpp','hooks\Streamline_Hooks.cpp','menu\menu_common.cpp','OptiScaler.vcxproj','wrapped\wrapped_swapchain.cpp','dllmain.cpp','framegen\IFGFeature_Dx12.h','resource_tracking\ResTrack_dx12.h','resource_tracking\ResTrack_dx12.cpp','inputs\FG\Upscaler_Inputs_Dx12.cpp')   # P3-E2c: the present-chain presenter (T49-T51/T57); framegen\IFGFeature_Dx12.h added in round 142 by T73a; resource_tracking\ResTrack_dx12.{h,cpp} added by T90 (P2/E2c34) -- the record-only swap-chain state probe: the ResourceBarrier hook lives there, and the list has to name every file the patch set touches or the gate fails on the run after the change
$generated = @('resource_build_date.h','resource_build_commit.h')
$added     = @('upscalers\latewarp\LatewarpFeature.h','upscalers\latewarp\LatewarpFeature.cpp',
               'upscalers\latewarp\LatewarpFeature_Dx12.h','upscalers\latewarp\LatewarpFeature_Dx12.cpp',
               'upscalers\latewarp\LatewarpParams.h','upscalers\latewarp\LatewarpParams.cpp',
               'upscalers\latewarp\LatewarpFrameData.h','upscalers\latewarp\LatewarpFrameData.cpp',
               'upscalers\latewarp\LatewarpIntercept.h','upscalers\latewarp\LatewarpIntercept.cpp',
               'shaders\latewarp\LatewarpUi_Common.h','shaders\latewarp\LatewarpUi_Dx12.h',
               'shaders\latewarp\LatewarpUi_Dx12.cpp','shaders\latewarp\LatewarpUi_Shader.h',
               'shaders\latewarp\LatewarpUi.hlsl','shaders\latewarp\LatewarpBlueNoise32.h')
$fails = 0
function Check([string]$n, [bool]$ok, [string]$d) {
    if ($ok) { Write-Host ("  [PASS] " + $n + "  " + $d) }
    else { Write-Host ("  [FAIL] " + $n + "  " + $d) -ForegroundColor Red; $script:fails++ }
}
function Sha([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash }
function Git-Diff([string]$a, [string]$b, [string]$rel) {
    # Do NOT parse git's own header: with absolute Windows paths git quotes them and C-escapes
    # the backslashes, so a path substitution silently does nothing. We keep only the hunks and
    # write our own machine-independent header.
    $raw = & $git -c core.safecrlf=false -c core.quotePath=false diff --no-index --no-color -U3 -- $a $b 2>&1
    $body = @()
    $seenHunk = $false
    foreach ($ln in $raw) {
        if (-not $seenHunk) {
            if ($ln -match '^@@') { $seenHunk = $true }
            elseif ($ln -match '^(diff --git|index |--- |\+\+\+ |new file mode|deleted file mode|similarity index)') { continue }
        }
        $body += $ln
    }
    # parentheses around each concatenation: without them PowerShell's comma binds first and
    # silently merges the two header lines into one
    $hdr = @(('--- a/' + $rel), ('+++ b/' + $rel))
    return (@($hdr) + $body) -join [char]10
}

Write-Host '=== patch review ==='
$parts = @()
$parts += '# PATCH REVIEW -- P2 latewarp integration for OptiScaler'
$parts += '# generated ' + (Get-Date).ToString('s') + ' by make_patch_review.ps1'
$parts += '# pristine: OptiScaler source as delivered (0 latewarp traces)'
$parts += '# applied : the same tree after apply_to_optiscaler.ps1'
$parts += '# unified diff, 3 lines of context -- review this instead of trusting the patch script.'
$parts += ''
foreach ($rel in $modified) {
    $a = Join-Path $Pristine $rel
    $b = Join-Path $Src $rel
    Check ("modified file present: " + $rel) ((Test-Path -LiteralPath $a) -and (Test-Path -LiteralPath $b)) ''
    $parts += Git-Diff $a $b $rel
}
$diffPath = Join-Path $Out 'PATCH_REVIEW.diff'
[System.IO.File]::WriteAllLines($diffPath, $parts)
Write-Host ("  wrote " + $diffPath + "  (" + (Get-Item $diffPath).Length + " bytes)")

$addedLines = @(Get-Content -LiteralPath $diffPath -Encoding UTF8 | Where-Object { $_ -match '^\+[^+]' })
$delLines   = @(Get-Content -LiteralPath $diffPath -Encoding UTF8 | Where-Object { $_ -match '^-[^-]' })
Check 'the diff contains our additions' ($addedLines.Count -ge 13) ('+' + $addedLines.Count + ' lines')
# T7 REPLACES two build-event commands, so deletions are expected -- but only as replacements,
# and no modified file may end up shorter than it was.
$netNegative = @()
foreach ($rel in $modified) {
    $la = (Get-Content -LiteralPath (Join-Path $Pristine $rel) -Encoding UTF8).Count
    $lb = (Get-Content -LiteralPath (Join-Path $Src $rel) -Encoding UTF8).Count
    if ($lb -lt $la) { $netNegative += ($rel + ' ' + $la + '->' + $lb) }
}
Check 'no modified file got shorter (deletions are replacements)' ($netNegative.Count -eq 0) $(if ($netNegative.Count) { $netNegative -join '; ' } else { ('-' + $delLines.Count + ' replaced lines, all paired') })

# --- independent blast radius: walk BOTH trees and compare hashes ----------------------------
# (not parsed out of git's output: --stat abbreviates long paths and quotes them, which produced
#  a false failure the first time this check was written.)
$srcExt = @('.h','.hpp','.cpp','.c','.cc','.vcxproj','.props','.targets','.def','.ini','.filters','.rc','.hlsl')
function Get-TreeMap([string]$root) {
    $m = @{}
    foreach ($f in (Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue)) {
        $m[$f.FullName.Substring($root.Length + 1)] = (Sha $f.FullName)
    }
    return $m
}
$pm = Get-TreeMap $Pristine
$sm = Get-TreeMap $Src
$modSrc = @($sm.Keys | Where-Object { $pm.ContainsKey($_) -and ($pm[$_] -ne $sm[$_]) -and ($srcExt -contains ([System.IO.Path]::GetExtension($_).ToLower())) })
$addAll = @($sm.Keys | Where-Object { -not $pm.ContainsKey($_) })
$addSrc = @($addAll | Where-Object { $srcExt -contains ([System.IO.Path]::GetExtension($_).ToLower()) })
$outAll = @($addAll | Where-Object { -not ($srcExt -contains ([System.IO.Path]::GetExtension($_).ToLower())) })
$delAll = @($pm.Keys | Where-Object { -not $sm.ContainsKey($_) })
$dMod = @(Compare-Object $modSrc @($modified))
$dAdd = @(Compare-Object $addSrc @($generated + $added))
Check 'blast radius: exactly the expected SOURCE files were modified' ($dMod.Count -eq 0) $(if ($dMod.Count) { 'differs: ' + (($dMod | ForEach-Object { $_.InputObject }) -join ', ') } else { $modified.Count.ToString() + '/' + $modified.Count })
Check ('blast radius: exactly the ' + $added.Count + ' expected files were added') ($dAdd.Count -eq 0) $(if ($dAdd.Count) { 'differs: ' + (($dAdd | ForEach-Object { $_.InputObject }) -join ', ') } else { $added.Count.ToString() + ' added files match' })
Check 'no source file was deleted' ($delAll.Count -eq 0) $(if ($delAll.Count) { 'DELETED: ' + ($delAll -join ', ') } else { '0' })
$unexplained = @($outAll | Where-Object { $_ -notmatch '(^|\\)x64\\' -and $_ -notmatch '\.tlog$' -and $_ -notmatch '\.recipe$' })
Check 'the only non-source differences are build outputs' ($unexplained.Count -eq 0) $(if ($unexplained.Count) { 'UNEXPLAINED: ' + ($unexplained -join ', ') } else { $outAll.Count.ToString() + ' build outputs (x64\\, *.tlog, *.recipe)' })

$md = @()
$md += '# P2 patch review manifest'
$md += ''
$md += ('Generated by ' + $q + 'make_patch_review.ps1' + $q + ' (read-only; refuses an unpatched tree). The machine-readable')
$md += ('counterpart is ' + $q + 'PATCH_REVIEW.diff' + $q + ' (real unified diff, 3 lines of context).')
$md += ''
$md += '## Modified (6)'
$md += ''
$md += '| file | lines (pristine -> applied) | sha256 pristine | sha256 applied |'
$md += '|---|---|---|---|'
foreach ($rel in $modified) {
    $a = Join-Path $Pristine $rel; $b = Join-Path $Src $rel
    $la = (Get-Content -LiteralPath $a -Encoding UTF8).Count
    $lb = (Get-Content -LiteralPath $b -Encoding UTF8).Count
    $md += ('| ' + $q + $rel + $q + ' | ' + $la + ' -> ' + $lb + ' | ' + $q + (Sha $a).Substring(0,16) + $q + ' | ' + $q + (Sha $b).Substring(0,16) + $q + ' |')
}
$md += ''
$md += '## Generated during apply (2)'
$md += ''
foreach ($rel in $generated) {
    $md += ('* ' + $q + $rel + $q + ' -- pinned value so the build is reproducible; -Action Revert removes it again.')
}
$md += ''
$md += '## Added (8, new backend)'
$md += ''
$md += '| file | bytes | sha256 |'
$md += '|---|---|---|'
foreach ($rel in $added) {
    $b = Join-Path $Src $rel
    if (Test-Path -LiteralPath $b) { $md += ('| ' + $q + $rel + $q + ' | ' + (Get-Item $b).Length + ' | ' + $q + (Sha $b).Substring(0,16) + $q + ' |') }
    else { $md += ('| ' + $q + $rel + $q + ' | MISSING | |') }
}
$md += ''
$md += '## What this does NOT claim'
$md += ''
$md += '* The diff proves WHAT changed, not that it works. Functional acceptance is verify_p2.ps1'
$md += '  (L1-L7) plus a run in a real game.'
$md += '* The pristine column is the delivered source tree, which must itself contain 0 latewarp traces.'
$mdPath = Join-Path $Out 'PATCH_REVIEW.md'
[System.IO.File]::WriteAllLines($mdPath, $md)
Write-Host ("  wrote " + $mdPath)

Write-Host ("=== " + $(if ($script:fails -eq 0) { 'PASS' } else { 'FAIL' }) + " (" + $script:fails + " failure(s)) ===")
exit $(if ($script:fails -eq 0) { 0 } else { 1 })
