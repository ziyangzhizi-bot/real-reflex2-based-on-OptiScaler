# P2 S10 — adversarial review disposition

Reviewer file: `docs/REVIEW_P2_S10.md` (16 findings, F-01..F-16).
This is the response. Every verdict below is either backed by a **re-run** or by a
**re-measurement of the current file**, never by a claim.

Verifier used for all "FIXED" lines:

    _re\reflex2_mod\p2\verify_p2.ps1 -Full          -> VERIFY-P2: PASS
    -Full now implies the L6 rollback round-trip (F-10), and the build gate was MOVED
    after the re-apply, so it blesses a build of the freshly re-applied tree.
    Measured: L1 2/2, L2 2/2, L3 17/17, L4 3/3, L5 unit+provisioning 2/2,
              L6 8/8 (6/6 files byte-identical), build gate msbuild exit=0 elapsed=0.64 min.

## Two findings are REFUTED (measured against the current revision)

| # | Finding| Verdict |
|---|---|---|
| F-06 | "make_p2_release.ps1 can no longer reproduce the shipped package; line 32 omits install_p2_into_game.ps1 and line 40 omits test_game_install.ps1" | **REFUTED (stale observation).** `make_p2_release.ps1:32` lists `install_p2_into_game.ps1`; `:40` lists `test_game_install.ps1`; `:46` lists all three `LATEWARP_*` spec files. A fresh run produced **34** files containing both, and zip member set == folder member set. The reviewer was reading a revision from before those lists were completed. |
| F-07 | "spec\LATEWARP_KEYS.tsv is not packaged, and the test's default TSV path is two levels up" | **REFUTED as stated / FIXED in the revision.** `:46` copies it, and `build_and_run_test.cmd:7` tries `%~dp0..\spec` **first** (line 8 is only a fallback). Decisive re-measure: the zip was extracted to a temp dir **outside the workspace** and ran its own `test\build_and_run_test.cmd` -> **28 PASS / 0 failure**, fixture resolved from inside the package. The package is self-verifying. |

F-06's *constructive* half was adopted anyway, because the underlying worry — silent
divergence between the explicit lists and the package — was legitimate:
`make_p2_release.ps1` now records every copied destination and **throws** unless the
on-disk file set is exactly the copied+generated set. Measured: `34 files == 34
explicitly listed/generated`. An omission or an accidental wildcard leak can no longer pass.

## Fixed (with the evidence)

| # | Sev | Finding | Fix + evidence |
|---|---|---|---|
| F-01 | major | `-DryRun` wrote the two build-metadata headers into the target tree | Generated headers now go through the same file-state writer as every other patch (registered first, flushed only by the write phase, which `-DryRun` never reaches). **New assertion**: "dry run leaves the pristine tree untouched / no files created" PASS. |
| F-02 | major | `-Revert` left the two generated headers behind | They are backed up if present and deleted if we created them. **L6**: "revert removes the generated metadata headers too" PASS, alongside 6/6 byte-identical files. |
| F-03 | major | T2's early `return true` bypassed `ModuleLoaded()`, the FSR fallback and the config commit | T2 is now `case Upscaler::Latewarp:` **inside** the switch. L3 counts it exactly once in the touched file. |
| F-04 | major | the feature ctor never called `SetInitParameters`, so the mandatory output extent stayed 0 (`0xBAD00005`) | ctor calls `SetInitParameters(InParameters)`; `InitLatewarp` additionally calls `UpdateOutputResolution(InParameters)`. Unit test "output extent written" PASS. |
| F-05 | major | `Fill` overwrote game-supplied `Depth`/`MotionVectors`/`Output` with null | Plane keys are written **only when non-null** (`LatewarpParams.cpp:118-123`); `Latewarp.UIColorAlpha` is still nulled. Unit test "no planes given -> plane keys left alone" PASS. |
| F-08 | minor | README/DESIGN stale; assertion count said 16 where RUNBOOK said 22 | One count everywhere: **28** (`README.md:79`). T4 is documented as applied/selectable, DESIGN line numbers corrected. |
| F-10 | minor | the rollback half of AC-P2-001 never ran in the default/`-Full` gate | `-Full` now implies the L6 round-trip, **and** the build gate moved after the re-apply so it gates the freshly re-applied tree. Measured in one run: L6 8/8 then `msbuild exit=0 elapsed=0.64 min`. |
| F-13a | minor | frame data shared between the Streamline hook and the render thread without synchronisation | `std::mutex` + `GetFrameData()` returns a copy. |
| F-15a | minor | `refusedLogged` is dead | Field and both increments removed; grep for it in `p2\` returns **0**. |

## Accepted, with the reason (deliberately not changed)

| # | Sev | Finding | Why accepted |
|---|---|---|---|
| F-09 | minor | T1/T7 anchors depend on textual ordering/adjacency | Every anchor must match **exactly once** or the whole apply aborts, and the pre-flight refuses a non-pristine tree, so the failure mode is a loud abort, never a silent mis-patch. This patch set is pinned to OptiScaler `5b6bc822`; a tree refresh requires re-validation anyway. Tracked as a robustness item, not a defect. |
| F-11 | minor | L4 cannot see the real selection paths (menu/config) | It can only be decided by a **differential host run**, which is the same unproven step as AC-P2-002/003 (there is no host log yet). Faking it statically would be worse than naming the limit. Now stated in the README's unverified list. |
| F-12 | minor | only `D3D12_Shutdown1` is handled | The added backend is D3D12-only by design; no D3D11/Vulkan path is added because there is no carrier to test one, which is the plan's stop-loss. |
| F-13b | minor | multi-viewport is last-writer-wins | Same reason: needs a multi-viewport host. Stated in the README's unverified list. |
| F-14 | minor | `cameraViewToClip` goes into `Latewarp.ViewToClipMatrix`; `WorldToView` is never written | **Accepted as the #1 open risk, with new evidence.** `sl::Constants` provides `cameraViewToClip`, `clipToCameraView`, `clipToLensClip`, `clipToPrevClip`, `prevClipToClip` — and **no worldToView**, so `Latewarp.WorldToViewMatrix` has no direct source at the integration point (it would have to be derived from the camera basis vectors, `sl_consts.h:208-214`). The key-name mismatch is real and the code says `NOT VALIDATED YET`. Pinning it needs the host run — i.e. the same event as AC-P2-002/003. Mitigation: the backend is off by default (L4 `assignments=0`, ini default `Reset`), so nobody reaches this path without opting in. Listed as item 2 of the README's unverified list. **RESOLVED 2026-09-27 — this WAS the root cause of the 7792 `0xBAD00005`:** the NGX core itself logged `NGXLatewarp::EvaluateFeature:589 error: could not find Latewarp.WorldToViewMatrix parameter` right before every failure, i.e. the accepted risk materialised exactly as written. Fix: `p2::BuildWorldToView()` derives it from the FG camera basis, and the row-major layout was pinned against two real game captures (`ngxproxy.camrun.log:25`, `routeA\frame_4042.txt`; maxErr 0 and 6e-6). See the README's new "P2 输入清单与证据表". |
| F-16 | minor | "the feature DLL is not on this machine" is contradicted by the workspace | The claim was always scoped to `DriverStore` (zero hits there), and `spec\NVIDIA_BINARY_POLICY.md:11` already lists the owner's own copies. `NOTICE.md` §2 now says so explicitly. The packaging guard is an explicit list, now additionally set-asserted, and a fresh package has **0** forbidden files. |

## F-15b: `Latewarp.EvalFlags` — CLOSED WITH EVIDENCE (was an open question)

The finding left "if EvalFlags is required to make the kernel warp, the assembly layer
cannot produce it" unresolved. It is resolved, by P1's already-live-verified run:

* P1's whitelist (`src\reflex2_nvngx.cpp:10-84`) is used **only** by `Whitelisted()`
  (`:87-91`) — it is a **gate**, not an iterate-and-write loop. Grep for
  `EvalFlags` across the whole mod tree finds the string **only inside the whitelist
  tables**; there is no write site in P1 or P2.
* That same P1 build was **live-verified** on `bin\StreamlineSample.exe` at the same
  feature id: the output went from a bit-exact copy (0.000000% of pixels differing) to a
  real warp (**81.0888%**), with `IsRenderedFrame := 0` and `UIColorAlpha := nullptr`.

So `EvalFlags` is whitelisted but **not required** for a warp. It stays whitelisted
(so a future need can set it without a new patch) and is deliberately not written, because
writing a guessed value into a parameter the kernel already defaults correctly is exactly
the kind of unforced change INV-P7 forbids.

## Note on the FIRST review round (18 findings)

Two adversarial reviews were run for S10. The first reviewer's findings arrived in the
session, while the second reviewer's file (``docs\REVIEW_P2_S10.md``) overwrote the first one on disk — so only the
second is preserved as a file. That is a process defect worth recording: **the two reviews
shared one output path**.

The first round's substantive findings all map onto the second round's: missing
``SetInitParameters`` (F-04), T2's early return (F-03), the unsynchronised frame data (F-13a),
``-Revert`` leaving the generated headers (F-02), the package omitting ``LATEWARP_KEYS.tsv`` (F-07),
README/DESIGN drift (F-08), the untested refusal path (F-09/F-15a), the assertion count,
only-``D3D12_Shutdown1`` (F-12), multi-viewport (F-13b) and ``cameraViewToClip`` (F-14).
Its verdicts are therefore the same as the table above; nothing it raised is unaddressed.

Also recorded: the first round pinned findings to SHA-256 prefixes, and several were already
fixed by the time they arrived. The same hazard bit this round (F-06/F-07 were stale
observations). **Lesson: re-measure every finding against the current file before acting on it.**

## What is still not demonstrated

Nothing in this disposition changes the AC status: **AC-P2-002/003 need a host game** and
no host log exists yet. That is not a finding of this review and cannot be closed from here.