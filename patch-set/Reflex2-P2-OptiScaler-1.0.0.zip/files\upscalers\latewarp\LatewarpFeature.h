// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
// B1: latewarp is NOT an upscaler. This is the shared state of NGX feature 15
// (Reflex 2 "frame warp") as used by OptiScaler's REPROJECTION backend.
//
// An earlier design put a Latewarp entry into the Upscaler enum. It was rejected after a
// live run on a real host printed
//     init failed with Latewarp (Reflex 2) feature
// because that path (FeatureProvider_Dx12) expects a backend that produces an UPSCALED
// image, and latewarp does not upscale -- it reprojects. The reprojection layer is the only
// layer whose inputs (Velocity/Depth/Hudless plus a reprojection target) match what
// feature 15 actually consumes. See p2/DESIGN_B1.md.
#pragma once

#include <stdint.h>
#include <proxies/NVNGX_Proxy.h>   // NVSDK_NGX_Handle / the NGX types
#include "LatewarpParams.h"

class LatewarpFeature
{
  protected:
    NVSDK_NGX_Handle _latewarpHandle {};
    NVSDK_NGX_Handle* _p_latewarpHandle = nullptr;

    // One NGX D3D12 init per process: NVNGXProxy::InitDx12 is not re-entrant.
    inline static bool _ngxInited = false;

    uint32_t _frameId = 0;
    uint32_t _frameCount = 0;

  public:
    bool IsCreated() const { return _p_latewarpHandle != nullptr; }
    uint32_t FrameCount() const { return _frameCount; }

    LatewarpFeature();
    virtual ~LatewarpFeature();
};
