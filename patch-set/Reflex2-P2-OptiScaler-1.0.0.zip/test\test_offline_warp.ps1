# ---------------------------------------------------------------------------
#  test_offline_warp.ps1 -- does the REAL latewarp kernel actually warp, offline?
#
#  AC-P2-002 is "every frame evaluates AND the picture really warps". The host half needs a game,
#  but the kernel half does not: _re\demo_re\harness\fwtest.exe drives the real feature DLL with a
#  real captured frame and reports the pixel difference of the warp. This test pins three facts:
#
#    A) NEGATIVE CONTROL: remove the four matrix parameters -> EvaluateFeature 0xBAD00005, i.e. the
#       exact failure a live host showed 7792 times. This is why the matrices must be supplied.
#    B) POSITIVE: with the matrices + UIColorAlpha=null the kernel returns Success AND warps
#       (P1 measured 81.0888% of pixels changed; a bit-exact copy would be 0.000000%).
#    C) ABLATION: the Subrect keys are NOT required (the self-create path does not write them).
#
#  The harness and both NVIDIA binaries are the USER'S OWN and are never shipped, so this suite
#  SKIPs cleanly when they are absent (e.g. inside the released package).
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Continue'
$P2   = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
$Harness = Join-Path $Repo '_re\demo_re\harness'
$Exe  = Join-Path $Harness 'fwtest.exe'
$Core = Join-Path $Harness 'cubintest\nvngx.dll'
$Feat = Join-Path $Harness 'cubintest\nvngx_latewarp.dll'
$In   = Join-Path $Repo '_re\routeA\demo_run\cap1\demo_in_f4042.raw'
$Mat  = Join-Path $Repo '_re\routeA\frame_4042.txt'

$missing = @()
foreach ($f in @($Exe, $Core, $Feat, $In, $Mat)) { if (-not (Test-Path -LiteralPath $f)) { $missing += $f } }
if ($missing.Count -gt 0) {
    Write-Host ("=== SKIP (no offline harness / no user-supplied kernel): " + ($missing -join ', ') + " ===")
    Write-Host "    This suite is a WORKSPACE test: it needs the user's own nvngx.dll + nvngx_latewarp.dll,"
    Write-Host "    which never ship with the package. Nothing is wrong with the build."
    exit 0
}

$fails = 0
function Check([string]$n, [bool]$ok, [string]$d) {
    if ($ok) { Write-Host ("  [PASS] " + $n + "  " + $d) }
    else { Write-Host ("  [FAIL] " + $n + "  " + $d) -ForegroundColor Red; $script:fails++ }
}

$ngxDir = Join-Path $Harness 'cubintest'
function RunHarness([string]$extra, [string]$tag, [string]$outFmt = 'bgra8') {
    $out = Join-Path $env:TEMP ("p2warp_" + $tag + ".out.txt")
    # NOTE: none of these paths contain spaces, so each argument can be passed as its own element
    # without any quoting game (which Start-Process would otherwise mangle).
    $argList = @('--in', $In, '--matseq', $Mat, '--infmt', 'bgra8', '--outfmt', $outFmt,
                 '--depthfmt', 'r24g8', '--inflags', 'uav', '--irf', '0', '--uialpha', 'null',
                 '--loops', '2', '--ngxdir', $ngxDir, '--tag', $tag)
    if ($extra -ne '') { $argList += $extra.Split(' ') }
    $p = Start-Process -FilePath $Exe -ArgumentList $argList -WorkingDirectory $Harness -NoNewWindow -Wait -PassThru -RedirectStandardOutput $out
    # Read the harness's OWN log file when it exists: with a format the dump/compare path cannot
    # handle the process can die AFTER the evaluations (seen with --outfmt r10g10b10a2, 0xC0000005),
    # and a crashed process loses its redirected stdout while the log file keeps what was written.
    $logPath = Join-Path $Harness ("fwtest." + $tag + ".log")
    $text = if (Test-Path -LiteralPath $logPath) { [System.IO.File]::ReadAllText($logPath) }
            else { [System.IO.File]::ReadAllText($out) }
    return @{ text = $text; code = $p.ExitCode }
}

Write-Host "=== offline latewarp kernel acceptance (real feature DLL, captured frame) ==="
Write-Host ("  harness : " + $Exe)
Write-Host ("  core    : " + $Core)

$A = RunHarness '--nomats 1' 'offwarp_nomats'
Check "control: matrices removed -> CreateFeature still succeeds" ($A.text -match 'CreateFeature\(featureId=15\) ret=0x00000001') ""
Check "control: matrices removed -> EvaluateFeature 0xBAD00005 (the live-host failure)" ($A.text -match 'EvaluateFeature #0 FrameID=\d+ ret=0xBAD00005') ""

$B = RunHarness '' 'offwarp_positive'
Check "positive: CreateFeature(featureId=15) succeeds" ($B.text -match 'CreateFeature\(featureId=15\) ret=0x00000001') ""
Check "positive: every EvaluateFeature succeeds" (([regex]::Matches($B.text, 'EvaluateFeature #\d+ FrameID=\d+ ret=0x00000001')).Count -ge 2) ""
$m = [regex]::Match($B.text, 'diffPixels=(\d+)/\d+ \(([0-9.]+)%\)')
$pct = if ($m.Success) { [double]$m.Groups[2].Value } else { -1 }
Check "positive: the kernel REALLY warps (pixel change >= 50%)" ($pct -ge 50) ("diffPixels=" + $(if ($m.Success) { $m.Groups[1].Value } else { '?' }) + "  " + $pct + "%")

$C = RunHarness '--nosubrect 1' 'offwarp_nosubrect'
Check "ablation: no Subrect keys -> EvaluateFeature still succeeds" ($C.text -match 'EvaluateFeature #0 FrameID=\d+ ret=0x00000001') ""

# The self-create path models its warp target on the BACKBUFFER desc so that CopyResource back is
# valid. That only works if the kernel accepts the swapchain format (24 = R10G10B10A2) as Output.
#
# 2026-10-01: this case used to pass on a run that DIED. The dump/compare path read every 32-bit
# non-BGRA8 output as 8 bytes/pixel, so it over-read the readback buffer and killed the process
# right after the IN dump -- the two lines below were satisfied by the log up to that point. The
# reader is fixed (see section H), so the assertion is now that the run COMPLETES.
$D = RunHarness '' 'offwarp_fmt24' 'r10g10b10a2'
Check "format 24 (swapchain R10G10B10A2) accepted as Output" (($D.text -match 'out=\S*\(24\)') -or ($D.text -match 'out=24/4bpp')) ""
Check "format 24: CreateFeature + EvaluateFeature both succeed" (($D.text -match 'CreateFeature\(featureId=15\) ret=0x00000001') -and ($D.text -match 'EvaluateFeature #0 FrameID=\d+ ret=0x00000001')) ""
Check "format 24: the run REACHES THE END (no readback access violation)" (($D.code -eq 0) -and ($D.text -match 'done\. run:')) ("exit=" + $D.code)


# ---------------------------------------------------------------------------
#  E) P3-DIR: WHICH WAY does the kernel move the image, and by how much?
#
#  Everything downstream depends on this and it had never been measured:
#    * P3-1b (the edge-fill knob) must know WHICH border gets the hole;
#    * P3-0a (pose extrapolation) must know WHICH matrix slot is the target.
#
#  The experiment: keep the demo's real projection, make the camera yaw by a KNOWN angle between
#  the two poses, and locate the output against the input by a global shift search. A pure yaw
#  moves content OPPOSITE to the turn by f*tan(theta) at the frame centre, where f = V2C[0]*W/2.
#  MEASURED 2026-09-27 (1.0 deg, f = 935.9 px, predicted 16.34 px):
#      yaw +1.0  ->  diffPixels 94.81%  dx = +16 px   (content moved LEFT: hole on the RIGHT)
#      yaw -1.0  ->  diffPixels 94.94%  dx = -16 px
#      slots swapped (equivalent to -1.0) -> dx = -16 px   <- the contract closes
#      identical pair -> diffPixels 0.000000%, dx = 0      <- bit-exact early-out
#  => the input frame is treated as rendered at PrevRenderedWorldToView and warped FORWARD to
#     WorldToView. Our T21 pairing (hudless = previous frame) is therefore the contract's pairing.
# ---------------------------------------------------------------------------
$p3gen = Join-Path $Harness 'p3dir_make.py'
$p3sh  = Join-Path $Harness 'p3dir_shift.py'
$py    = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $py) { $p3local = 'C:\Users\ZhuanZ\local\Python\python.exe'; if (Test-Path $p3local) { $py = $p3local } }
if ((-not $py) -or (-not (Test-Path $p3gen)) -or (-not (Test-Path $p3sh))) {
    Write-Host "  [SKIP] P3-DIR needs python + p3dir_make.py + p3dir_shift.py next to the harness"
} else {
    $p3dir = Join-Path $Harness 'p3dir_gate'
    New-Item -ItemType Directory -Force -Path $p3dir | Out-Null
    $gen = & $py $p3gen $Mat $p3dir 1.0 2>&1 | Out-String
    $fpx = [double]([regex]::Match($gen, 'f_x = ([0-9.]+)').Groups[1].Value)
    $pred = [double]([regex]::Match($gen, 'f\*tan\(t\) = ([0-9.]+) px').Groups[1].Value)
    Check 'P3-DIR: generator produced a prediction' (($fpx -gt 100) -and ($pred -gt 1)) ("f_x=" + $fpx + "  predicted |dx|=" + $pred + " px")

    function RunP3([string]$matFile, [string]$tag) {
        $outDir = Join-Path $p3dir $tag
        New-Item -ItemType Directory -Force -Path $outDir | Out-Null
        $argList = @('--in', $In, '--matseq', $matFile, '--infmt', 'bgra8', '--outfmt', 'bgra8',
                     '--depthfmt', 'r24g8', '--inflags', 'uav', '--irf', '0', '--uialpha', 'null',
                     '--loops', '2', '--ngxdir', $ngxDir, '--tag', $tag, '--outdir', $outDir)
        $tmp = Join-Path $env:TEMP ('p3dir_' + $tag + '.txt')
        $pr = Start-Process -FilePath $Exe -ArgumentList $argList -WorkingDirectory $Harness -NoNewWindow -Wait -PassThru -RedirectStandardOutput $tmp
        $lg = Join-Path $outDir ('fwtest.' + $tag + '.log')
        $txt = if (Test-Path -LiteralPath $lg) { [System.IO.File]::ReadAllText($lg) } else { '' }
        $pct = [double]([regex]::Match($txt, 'diffPixels=\d+/\d+ \(([0-9.]+)%\)').Groups[1].Value)
        $loaded = [regex]::Match($txt, 'matseq: loaded (\d+) frames').Groups[1].Value
        $dx = 0
        $inD = Join-Path $outDir 'framewarp_dump_r99_f100_in.raw'
        $outD = Join-Path $outDir 'framewarp_dump_r99_f100_out.raw'
        if ((Test-Path -LiteralPath $inD) -and (Test-Path -LiteralPath $outD)) {
            $sh = & $py $p3sh $inD $outD 0.10 64 2>&1 | Out-String
            $dx = [int]([regex]::Match($sh, 'dx=\s*([+-]?\d+)').Groups[1].Value)
        }
        return @{ pct = $pct; dx = $dx; loaded = $loaded }
    }

    $Z = RunP3 (Join-Path $p3dir 'yaw_zero.txt') 'p3dir_zero'
    Check 'P3-DIR control: identical matrix pair -> bit-exact passthrough' (($Z.pct -eq 0) -and ($Z.dx -eq 0)) ('pct=' + $Z.pct + '  dx=' + $Z.dx)

    $P = RunP3 (Join-Path $p3dir 'yaw_pos.txt') 'p3dir_pos'
    Check 'P3-DIR: the matrix pair is actually used (matseq loaded 1 frame)' ($P.loaded -eq '1') ('loaded=' + $P.loaded)
    Check 'P3-DIR: +1 deg yaw moves the content LEFT by ~f*tan(theta)' (($P.pct -gt 50) -and ($P.dx -gt 0) -and ([Math]::Abs($P.dx - $pred) -le 12)) ('dx=' + $P.dx + ' px  predicted=' + [Math]::Round($pred,2) + '  diffPixels=' + $P.pct + '%')

    $N = RunP3 (Join-Path $p3dir 'yaw_neg.txt') 'p3dir_neg'
    Check 'P3-DIR: -1 deg yaw moves the content RIGHT (opposite sign)' (($N.dx -lt 0) -and ([Math]::Abs($N.dx + $pred) -le 12)) ('dx=' + $N.dx + ' px')

    $S = RunP3 (Join-Path $p3dir 'yaw_swap.txt') 'p3dir_swap'
    Check 'P3-DIR: swapping the slots equals the opposite turn (forward-warp contract)' ([Math]::Abs($S.dx - $N.dx) -le 8) ('swap dx=' + $S.dx + '  neg dx=' + $N.dx)
    Write-Host ('  => the kernel warps the frame from PrevRenderedWorldToView FORWARD to WorldToView;')
    Write-Host ('     a right turn puts the hole on the RIGHT border (P3-1b) and the target slot is WorldToView (P3-0a).')
}
# ---------------------------------------------------------------------------
#  F) P3-E1: does (M+1)-per-rendered-frame warping behave the way the present chain
#  needs? Repeating a pose is bit-exact, but ADVANCING the pose across the passes is
#  NOT equivalent to an independent single warp (the kernel keeps state inside one
#  rendered frame) -- that is the constraint the P3-E filter design rests on.
#  The probe lives in the harness (workspace-only) and SKIPs cleanly when absent.
# ---------------------------------------------------------------------------
Write-Host "=== F) P3-E1: (M+1)-per-rendered-frame protocol model ==="
$p3eProbe = Join-Path $Harness 'p3e_mfg.ps1'
if (-not (Test-Path -LiteralPath $p3eProbe)) {
    Write-Host ("  [SKIP] P3-E1 needs " + $p3eProbe + " (workspace-only probe)")
} else {
    $p3eOut = & $p3eProbe *>&1 | Out-String   # Write-Host is the information stream: *>&1 captures it
    $verdict = [regex]::Match($p3eOut, 'P3E-MFG:\s*(PASS|FAIL)').Groups[1].Value
    Check 'P3-E1: the (M+1) protocol model passes its tolerance assertions' ($verdict -eq 'PASS') ("verdict=" + $verdict)
}


# ---------------------------------------------------------------------------
#  G) H2: DOES THE WARP EAT THIN BRIGHT FEATURES?   (measured 2026-09-30: NO)
#
#  The live report was that lamp highlights vanish when the camera turns, and H2 read that as
#  the reprojection re-sampling a 1-2 px highlight into the dark surround. The user own kernel
#  answers it offline: paint N isolated bright dots (a white pixel whose four neighbours are
#  forced dark) plus 32x32 white control patches into the captured frame, warp it, and COUNT
#  the isolated bright pixels again. The predicate is LOCAL, so it does not care where the warp
#  moves the content.
#
#  MEASURED (2880x1620 bgra8, 200 injected dots, maskval -1 / 255):
#      injected input : dots 153  dotLum 39015  bright 15275  patchPeak 255
#      warp everything: dots 349  dotLum 79822  bright 22048  patchPeak 255
#      freeze all     : dots 153  dotLum 39015  bright 15275  patchPeak 255  (BIT-EXACT)
#  => the kernel does NOT destroy thin bright features; it CREATES extra local maxima by
#     resampling. H2 is refuted as the cause, so the in-game highlight loss lives in the HOST
#     integration (composition order / temporal history), not in the resampling of the kernel.
#
#  The case is a REGRESSION GUARD: it asserts the two facts that must not change (freeze-all is
#  bit-exact, warp-all really warps) and PRINTS the three statistics for the record.
# ---------------------------------------------------------------------------
Write-Host "=== G) H2: does the warp eat thin bright features? ==="
$DotTool = Join-Path $P2 "test\dot_survival.ps1"
$CapIn = Join-Path $Repo "_re\routeA\demo_run\cap1\demo_in_f4042.raw"
if ((-not (Test-Path -LiteralPath $DotTool)) -or (-not (Test-Path -LiteralPath $CapIn))) {
    Write-Host "  [SKIP] needs test\dot_survival.ps1 + the captured frame"
} else {
    $dsDir = Join-Path $Harness "dot_survival_gate"
    New-Item -ItemType Directory -Force -Path $dsDir | Out-Null
    $inj = Join-Path $dsDir "injected.raw"
    & $DotTool -Mode inject -File $CapIn -OutFile $inj -Dots 200 -Patches 4 2>&1 | Out-Null

    function RunDot([string]$extra, [string]$tag) {
        $d = Join-Path $dsDir $tag
        New-Item -ItemType Directory -Force -Path $d | Out-Null
        $argList = @("--in", $inj, "--matseq", $Mat, "--infmt", "bgra8", "--outfmt", "bgra8", "--depthfmt", "r24g8",
                     "--inflags", "uav", "--irf", "0", "--uialpha", "null", "--loops", "2", "--ngxdir", $ngxDir,
                     "--tag", $tag, "--outdir", $d)
        if ($extra -ne "") { $argList += $extra.Split(" ") }
        $o = Join-Path $env:TEMP ("p2dot_" + $tag + ".out.txt")
        $p2dot = Start-Process -FilePath $Exe -ArgumentList $argList -WorkingDirectory $Harness -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o
        $lp = Join-Path $Harness ("fwtest." + $tag + ".log")
        $t = if (Test-Path -LiteralPath $lp) { [System.IO.File]::ReadAllText($lp) } else { [System.IO.File]::ReadAllText($o) }
        return @{ text = $t; outFile = (Join-Path $d "framewarp_dump_r99_f100_out.raw") }
    }

    $DA = RunDot "--maskval -1" "dotsurv_warp"
    $DB = RunDot "--maskval 255" "dotsurv_froz"
    Check "dot survival: freeze-all (maskval 255) reproduces the input BIT-EXACT" ($DB.text -match "diffPixels=0/\d+ \(0\.000000%\)") ""
    $dm = [regex]::Match($DA.text, "diffPixels=(\d+)/\d+ \(([0-9.]+)%\)")
    Check "dot survival: warp-all (maskval -1) really warps (>= 50%)" ($dm.Success -and ([double]$dm.Groups[2].Value -ge 50)) ("diffPixels=" + $dm.Groups[2].Value + "%")
    $sIn = (& $DotTool -Mode analyse -File $inj *>&1 | Out-String).Trim()
    $sW  = if (Test-Path -LiteralPath $DA.outFile) { (& $DotTool -Mode analyse -File $DA.outFile *>&1 | Out-String).Trim() } else { "" }
    $sF  = if (Test-Path -LiteralPath $DB.outFile) { (& $DotTool -Mode analyse -File $DB.outFile *>&1 | Out-String).Trim() } else { "" }
    Write-Host ("    in   : " + $sIn)
    Write-Host ("    warp : " + $sW)
    Write-Host ("    frozen: " + $sF)
    Check "dot survival: the local-predicate meter runs on all three frames" (($sIn -match "RESULT dots=") -and ($sW -match "RESULT dots=") -and ($sF -match "RESULT dots=")) ""
}
# ---------------------------------------------------------------------------
#  H) WHICH COLOUR FORMATS CAN THE KERNEL BE HANDED?   (measured 2026-10-01)
#
#  The live crash under investigation is a write-back into the game's swap-chain image, and the
#  two formats that image was measured at are 24 (R10G10B10A2_UNORM) and 28 (R8G8B8A8_UNORM) --
#  neither is the 87 (B8G8R8A8_UNORM) this harness has always used. Neither direction had ever
#  actually completed: ScoreAndDumpTexture computed the output bytes-per-pixel as "BGRA8 ? 4 : 8",
#  so EVERY 32-bit non-BGRA8 output was read as 8 bytes/pixel, the per-row memcpy over-read the
#  mapped readback buffer by W*4 bytes, and the process died with 0xC0000005 right after the IN
#  dump. The earlier "format 24 accepted as Output" reading came from exactly such a log.
#  Fixed in fwtest.cpp (the bpp now comes from the texture's own DXGI format).
#
#  MEASURED (2880x1620, --loops 2, real nvngx_latewarp):
#      bgra8 -> bgra8 : 81.0908% pixels, PSNR 24.2995 dB   <- the proven baseline, unchanged
#      fmt 24 as INPUT: EvaluateFeature Success, writes=2 nonzero=1.000000
#      fmt 28 as INPUT: EvaluateFeature Success, writes=2 nonzero=1.000000
#      bgra8 -> fmt 24 / fmt 28: now run to completion (were access violations)
#      fmt 24 -> fmt 24: 81.0903% pixels changed
#      fmt 28 -> fmt 28: 81.0907% pixels changed, PSNR 24.2998 dB == the baseline
#  => the kernel honours the DECLARED colour format in BOTH directions, and a fmt-28 round trip is
#     numerically identical to the proven BGRA8 path. The game-side device removal is therefore NOT
#     a format problem -- it is the back buffer's resource state / write TIMING (handoff 5). It also
#     means a same-format write-back (28 -> 28) needs no converting copy at all: a plain
#     CopyResource is enough, which is the cheapest possible version of the feed-composite route.
# ---------------------------------------------------------------------------
Write-Host "=== H) the swap-chain colour formats as kernel input AND output ==="

function RunFmt([string]$inf, [string]$outf, [string]$tag) {
    $d = Join-Path $Harness ("fmtgate\" + $tag)
    New-Item -ItemType Directory -Force -Path $d | Out-Null
    $o = Join-Path $env:TEMP ("p2fmt_" + $tag + ".out.txt")
    $argList = @('--in', $In, '--matseq', $Mat, '--infmt', $inf, '--outfmt', $outf, '--depthfmt', 'r24g8',
                 '--inflags', 'uav', '--irf', '0', '--uialpha', 'null', '--loops', '2',
                 '--ngxdir', $ngxDir, '--tag', $tag, '--outdir', $d)
    $p = Start-Process -FilePath $Exe -ArgumentList $argList -WorkingDirectory $Harness -NoNewWindow -Wait -PassThru -RedirectStandardOutput $o
    $lp = Join-Path $Harness ("fwtest." + $tag + ".log")
    $t = if (Test-Path -LiteralPath $lp) { [System.IO.File]::ReadAllText($lp) } else { [System.IO.File]::ReadAllText($o) }
    return @{ text = $t; code = $p.ExitCode; outFile = (Join-Path $d "framewarp_dump_r99_f100_out.raw") }
}

$H1 = RunFmt 'r10g10b10a2' 'bgra8' 'fmt_in24'
Check 'H: fmt 24 (R10G10B10A2) is accepted as COLOUR INPUT' (($H1.code -eq 0) -and ($H1.text -match 'EvaluateFeature #0 FrameID=\d+ ret=0x00000001') -and ($H1.text -match 'writes=2 nonzero=1\.000000')) ("exit=" + $H1.code)

$H2 = RunFmt 'r8g8b8a8' 'bgra8' 'fmt_in28'
Check 'H: fmt 28 (R8G8B8A8) is accepted as COLOUR INPUT' (($H2.code -eq 0) -and ($H2.text -match 'EvaluateFeature #0 FrameID=\d+ ret=0x00000001') -and ($H2.text -match 'writes=2 nonzero=1\.000000')) ("exit=" + $H2.code)

$H3 = RunFmt 'r10g10b10a2' 'r10g10b10a2' 'fmt_24_24'
Check 'H: a fmt-24 round trip COMPLETES and writes the OUT dump' (($H3.code -eq 0) -and (Test-Path -LiteralPath $H3.outFile)) ("exit=" + $H3.code)
$m3 = [regex]::Match($H3.text, 'diffPixels=(\d+)/\d+ \(([0-9.]+)%\)')
Check 'H: fmt 24 -> 24 really warps (>= 50% of pixels changed)' ($m3.Success -and ([double]$m3.Groups[2].Value -ge 50)) ("diffPixels=" + $(if ($m3.Success) { $m3.Groups[2].Value } else { '?' }) + "%")

$H4 = RunFmt 'r8g8b8a8' 'r8g8b8a8' 'fmt_28_28'
Check 'H: a fmt-28 round trip COMPLETES and writes the OUT dump' (($H4.code -eq 0) -and (Test-Path -LiteralPath $H4.outFile)) ("exit=" + $H4.code)
$m4 = [regex]::Match($H4.text, 'diffPixels=(\d+)/\d+ \(([0-9.]+)%\)')
Check 'H: fmt 28 -> 28 really warps (>= 50% of pixels changed)' ($m4.Success -and ([double]$m4.Groups[2].Value -ge 50)) ("diffPixels=" + $(if ($m4.Success) { $m4.Groups[2].Value } else { '?' }) + "%")
Check 'H: the fmt-28 path is numerically the SAME as the proven BGRA8 path' ($m4.Success -and ([Math]::Abs([double]$m4.Groups[2].Value - $pct) -le 0.05)) ("fmt28=" + $(if ($m4.Success) { $m4.Groups[2].Value } else { '?' }) + "%  baseline=" + $pct + "%")
Write-Host "  => a same-format write-back (28 -> 28) needs NO converting copy; the crash is state/timing."

Write-Host ("=== " + $(if ($fails -eq 0) { "PASS" } else { "FAIL" }) + " (" + $fails + " failure(s)) ===")
exit $(if ($fails -eq 0) { 0 } else { 1 })