# ---------------------------------------------------------------------------
#  build_verify.ps1 -- build the PATCHED OptiScaler and actually GATE on the result.
#
#  Why this exists: _re\optiscaler_verify\repro_build2.ps1 prints the output DLL and its
#  hash even when msbuild FAILED (it reports the stale DLL from the previous build), so
#  "BUILT ..." there is NOT evidence of a successful build. This wrapper:
#    1. records the DLL's hash/bytes before,
#    2. runs msbuild,
#    3. FAILS unless msbuild exited 0 AND the DLL was actually rewritten.
#
#  usage: .\build_verify.ps1 [-ExpectFail]   (ExpectFail = negative test of this gate)
# ---------------------------------------------------------------------------
param([switch]$ExpectFail)
$ErrorActionPreference = 'Stop'
$P2   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
$REPRO = Join-Path $Repo '_re\repro_src'
$sln  = Join-Path $REPRO 'OptiScaler.sln'
$dll  = Join-Path $REPRO 'x64\ReleaseDebug\OptiScaler.dll'
if (-not (Test-Path -LiteralPath $sln)) { throw "solution not found: $sln" }

# ---------------------------------------------------------------------------
#  SAFETY (added 2026-09-28 after the incident): this script starts a PARALLEL
#  msbuild (/m = every core). At 21:40 on 2026-09-28 that ran while Cyberpunk 2077
#  was being played, and the machine hard-reset one second later (Kernel-Power 41,
#  BugcheckCode 0 = no bugcheck, i.e. the box lost power / was cut out under load).
#  A heavy build must never race a game: refuse while the game process is alive.
#  There is deliberately NO bypass switch -- wait for the game to exit.
# ---------------------------------------------------------------------------
$gameProc = @(Get-Process -Name Cyberpunk2077 -ErrorAction SilentlyContinue)
if ($gameProc.Count -gt 0) {
    Write-Host ('[build] REFUSED: Cyberpunk2077.exe is running (pid ' + $gameProc[0].Id + ').') -ForegroundColor Red
    Write-Host '        A parallel msbuild must not race the game (2026-09-28 hard-reset). Close the game first.'
    exit 2
}

$before = if (Test-Path -LiteralPath $dll) { (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash } else { '<none>' }
$beforeLen = if (Test-Path -LiteralPath $dll) { (Get-Item -LiteralPath $dll).Length } else { 0 }
Write-Host ("[build] before : " + $before.Substring(0, [Math]::Min(24, $before.Length)) + "  " + $beforeLen + " bytes")

$vcvars = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$sw = [Diagnostics.Stopwatch]::StartNew()
cmd.exe /c ('call "' + $vcvars + '" >nul 2>&1 && msbuild /m /p:Configuration=ReleaseDebug /p:Platform=x64 "' + $sln + '" /verbosity:minimal /nologo') 2>&1 |
    Tee-Object -FilePath (Join-Path $P2 'build_verify.log') | Out-Null
$code = $LASTEXITCODE
$sw.Stop()

if (-not (Test-Path -LiteralPath $dll)) { Write-Host "[build] FAIL: no output DLL"; exit 1 }
$after = (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash
$afterLen = (Get-Item -LiteralPath $dll).Length

Write-Host ("[build] msbuild exit=" + $code + "  elapsed=" + [Math]::Round($sw.Elapsed.TotalMinutes, 2) + " min")
Write-Host ("[build] after  : " + $after.Substring(0, 24) + "  " + $afterLen + " bytes")

if ($ExpectFail) {
    if ($code -ne 0) { Write-Host "[build] PASS (negative test: the gate did see the failure)"; exit 0 }
    Write-Host "[build] FAIL (negative test: expected a failing build)"; exit 1
}

# A repeat invocation legitimately finds everything up to date: msbuild exits 0 and does not
# touch the DLL (it prints nothing and finishes in seconds). Requiring "the DLL must change"
# made that case look like a FAIL, so accept it when the DLL is newer than every build input.
$rewritten = ($after -ne $before)
$upToDate = $false
if (($code -eq 0) -and (-not $rewritten)) {
    $newest = Get-ChildItem (Join-Path $REPRO 'OptiScaler') -Recurse -File -Include *.cpp,*.h,*.vcxproj -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $upToDate = ($null -ne $newest) -and ((Get-Item -LiteralPath $dll).LastWriteTime -ge $newest.LastWriteTime)
    Write-Host ("[build] nothing rebuilt; newest input: " + $(if ($newest) { $newest.Name } else { '<none>' }) + "  up-to-date=" + $upToDate)
}

if (($code -eq 0) -and ($rewritten -or $upToDate)) {
    Write-Host ("[build] PASS (msbuild ok; " + $(if ($rewritten) { 'DLL rewritten' } else { 'DLL already up to date' }) + ")")
    exit 0
}
Write-Host "[build] FAIL: msbuild exit=" + $code + ", dll changed=" + $rewritten + ", up-to-date=" + $upToDate
Write-Host "[build] (see build_verify.log for the compiler errors)"
exit 1
