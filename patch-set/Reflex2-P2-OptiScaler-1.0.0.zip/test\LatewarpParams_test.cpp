// ---------------------------------------------------------------------------
//  LatewarpParams_test.cpp -- offline unit test for the P2 parameter assembly.
//  SPDX-License-Identifier: GPL-3.0-or-later
//
//  This is how S3 gets verified WITHOUT a game: the assembly layer is pure logic, so
//  we drive it with a recording sink and assert the exact key set, the values of the
//  two decisive keys, and that a key outside the whitelist is REFUSED.
//
//  usage: LatewarpParams_test.exe <path to spec\LATEWARP_KEYS.tsv>
// ---------------------------------------------------------------------------
#include "../files/upscalers/latewarp/LatewarpParams.h"
#include <math.h>

#include "../files/upscalers/latewarp/LatewarpFrameData.h"

#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <map>
#include <set>

static int g_fail = 0;
static void Check(const char* what, bool ok, const char* detail)
{
    printf("  [%s] %-46s %s\n", ok ? "PASS" : "FAIL", what, detail ? detail : "");
    if (!ok) ++g_fail;
}

// --- a sink that records everything and re-validates the whitelist itself -----
struct RecSink : p2::ISink
{
    std::vector<std::string> order;
    std::map<std::string, std::string> values;

    bool Set(const char* key, p2::ValueType t, const void* v) override
    {
        if (!p2::IsLatewarpKey(key)) { printf("  !! sink got a NON-whitelisted key: %s\n", key); ++g_fail; }
        char buf[128];
        switch (t)
        {
            case p2::ValueType::Pointer:
            {
                void* p = v ? *(void* const*) v : nullptr;
                if (p == nullptr) snprintf(buf, sizeof(buf), "ptr 0");
                else              snprintf(buf, sizeof(buf), "ptr %p", p);
                break;
            }
            case p2::ValueType::Int32:   snprintf(buf, sizeof(buf), "i32 %d", v ? *(const int32_t*) v : 0); break;
            case p2::ValueType::UInt32:  snprintf(buf, sizeof(buf), "u32 %u", v ? *(const uint32_t*) v : 0u); break;
            case p2::ValueType::Float:   snprintf(buf, sizeof(buf), "f32 %.3f", v ? *(const float*) v : 0.f); break;
            default:                     snprintf(buf, sizeof(buf), "?"); break;
        }
        order.push_back(key);
        values[key] = buf;
        return true;
    }
};

static std::set<std::string> ReadTsvKeys(const char* path, int* keyRows)
{
    std::set<std::string> keys;
    FILE* f = fopen(path, "rb");
    *keyRows = 0;
    if (!f) return keys;
    char line[512];
    while (fgets(line, sizeof(line), f))
    {
        if (line[0] == '#') continue;
        char* tab = strchr(line, '\t');
        if (!tab) continue;
        std::string k(tab + 1);
        while (!k.empty() && (k.back() == '\n' || k.back() == '\r' || k.back() == ' ')) k.pop_back();
        if (k.empty() || k == "key") continue;
        keys.insert(k);
        ++(*keyRows);
    }
    fclose(f);
    return keys;
}

int main(int argc, char** argv)
{
    printf("=== LatewarpParams assembly test ===\n");

    // ---- 1. the embedded whitelist -------------------------------------------------
    Check("embedded whitelist has 43 Latewarp keys", p2::LatewarpKeyCount() == 43, "");
    Check("3 unprefixed plane keys are allowed", p2::PlaneKeyCount() == 3, "Depth / MotionVectors / Output");
    Check("2 NGX-generic extra keys are allowed", p2::ExtraKeyCount() == 2, "Jitter.Offset.X / Jitter.Offset.Y");
    Check("Jitter.Offset.X (unprefixed, the real name) is accepted", p2::IsLatewarpKey("Jitter.Offset.X"), "");

    if (argc > 1)
    {
        int rows = 0;
        std::set<std::string> tsv = ReadTsvKeys(argv[1], &rows);
        Check("TSV has 43 key rows", rows == 43, argv[1]);
        bool same = (tsv.size() == (size_t) p2::LatewarpKeyCount());
        for (int i = 0; i < p2::LatewarpKeyCount(); ++i)
            if (tsv.find(p2::LatewarpKeyAt(i)) == tsv.end()) { same = false; printf("  missing from TSV: %s\n", p2::LatewarpKeyAt(i)); }
        for (const auto& k : tsv)
        {
            bool found = false;
            for (int i = 0; i < p2::LatewarpKeyCount(); ++i) if (k == p2::LatewarpKeyAt(i)) { found = true; break; }
            if (!found) { same = false; printf("  extra in TSV, not embedded: %s\n", k.c_str()); }
        }
        Check("embedded list == TSV list (both directions)", same, "");
    }
    else { Check("TSV path given", false, "pass spec/LATEWARP_KEYS.tsv as argv[1]"); }

    // ---- 2. whitelist gate ----------------------------------------------------------
    Check("a real key is accepted", p2::IsLatewarpKey("Latewarp.IsRenderedFrame"), "");
    Check("a made-up key is REFUSED", !p2::IsLatewarpKey("Latewarp.ThisKeyDoesNotExist"), "");
    Check("a jitter guess is REFUSED (not in the 43)", !p2::IsLatewarpKey("Latewarp.Jitter.Offset.X"), "");

    // S10 F-09: exercise the gate that Fill itself uses, not just the predicate. Without this
    // the refusal path was unreachable code and stats.refused was never observed.
    {
        RecSink gs; p2::Stats gst {};
        int32_t one = 1;
        bool accepted = p2::TryWriteKey(gs, &gst, "Latewarp.Output.Width", p2::ValueType::Int32, &one);
        Check("gate ACCEPTS a real key", accepted && gst.refused == 0 && gst.written == 1, "");
        bool refused = p2::TryWriteKey(gs, &gst, "Latewarp.NotAKey", p2::ValueType::Int32, &one);
        Check("gate REFUSES a fake key and counts it", !refused && gst.refused == 1, "");
        bool refused2 = p2::TryWriteKey(gs, &gst, "NotEvenLatewarp", p2::ValueType::Int32, &one);
        Check("gate refuses a non-latewarp key too", !refused2 && gst.refused == 2, "");
        bool sawBad = false;
        for (size_t i = 0; i < gs.order.size(); ++i) if (gs.order[i] == "Latewarp.NotAKey" || gs.order[i] == "NotEvenLatewarp") sawBad = true;
        Check("refused keys NEVER reach the sink", !sawBad && gst.written == 1, "");
    }

    // ---- 3. a full fill ------------------------------------------------------------
    p2::Inputs in {};
    in.outputWidth = 2880; in.outputHeight = 1620;
    in.backbuffer = (void*) 0x1000; in.hudlessColor = (void*) 0x2000; in.depth = (void*) 0x3000;
    in.motionVectors = (void*) 0x4000; in.output = (void*) 0x5000;
    in.subrect[0][2] = 2880; in.subrect[0][3] = 1620;         // Backbuffer = full frame
    in.subrect[1][2] = 2880; in.subrect[1][3] = 1620;         // HudlessColor = full frame
    in.subrect[2][2] = 2880; in.subrect[2][3] = 1620;         // UIColorAlpha = full frame
    in.subrect[3][2] = 2880; in.subrect[3][3] = 1620;         // Depth
    in.subrect[4][2] = 2880; in.subrect[4][3] = 1620;         // MV
    in.subrect[5][2] = 2880; in.subrect[5][3] = 1620;         // Output
    in.frameId = 4042;
    in.jitterX = 0.25f; in.jitterY = -0.5f;   // P3-5a: values must reach the sink unchanged
    static float w2v[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    static float v2c[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    in.worldToView = w2v; in.viewToClip = v2c;
    in.prevWorldToView = w2v; in.prevViewToClip = v2c;

    RecSink sink;
    p2::Stats st;
    int n = p2::Fill(sink, in, &st);

    Check("fill reported no refusals", st.refused == 0, "");
    Check("writes > 20", n > 20, "");
    Check("two decisive keys were written LAST",
          sink.order.size() >= 2 &&
          sink.order[sink.order.size() - 2] == "Latewarp.UIColorAlpha" &&
          sink.order[sink.order.size() - 1] == "Latewarp.IsRenderedFrame", "");
    Check("Latewarp.IsRenderedFrame == 0",
          sink.values["Latewarp.IsRenderedFrame"] == "i32 0", sink.values["Latewarp.IsRenderedFrame"].c_str());
    Check("Latewarp.UIColorAlpha == nullptr",
          sink.values["Latewarp.UIColorAlpha"] == "ptr 0", sink.values["Latewarp.UIColorAlpha"].c_str());
    Check("output extent written", sink.values.count("Latewarp.Output.Width") && sink.values.count("Latewarp.Output.Height"), "");
    Check("planes bound via the 3 unprefixed keys",
          sink.values.count("Depth") && sink.values.count("MotionVectors") && sink.values.count("Output"), "");
    // P3-5a: parity with the official FrameWarp sample, which writes all three of these explicitly.
    Check("jitter reaches the sink through the NGX-generic keys",
          sink.values.count("Jitter.Offset.X") == 1 && sink.values.count("Jitter.Offset.Y") == 1, "");
    Check("EvalFlags written explicitly", sink.values.count("Latewarp.EvalFlags") == 1, "");
    Check("no key outside the whitelist reached the sink", true, "(sink itself asserts this)");

    // ---- 3b. S10 F-05: with no planes supplied, Fill must NOT touch the plane keys --------
    {
        p2::Inputs none = in;
        none.backbuffer = nullptr; none.hudlessColor = nullptr; none.noWarpMask = nullptr;
        none.depth = nullptr; none.motionVectors = nullptr; none.output = nullptr;
        RecSink ns; p2::Stats nst {};
        p2::Fill(ns, none, &nst);
        bool touchedAPlane = ns.values.count("Depth") || ns.values.count("MotionVectors") ||
                             ns.values.count("Output") || ns.values.count("Latewarp.Backbuffer") ||
                             ns.values.count("Latewarp.HudlessColor") || ns.values.count("Latewarp.NoWarpMask");
        Check("no planes given -> plane keys left alone", !touchedAPlane, "(a null write would clobber the game's input)");
        Check("no planes given -> UIColorAlpha is still nulled", ns.values["Latewarp.UIColorAlpha"] == "ptr 0", ns.values["Latewarp.UIColorAlpha"].c_str());
    }

    // ---- 4. the decisive key can be forced wrong, proving it is really the one we set
    p2::Inputs bad = in; bad.isRenderedFrame = 1;
    RecSink sink2; p2::Stats st2;
    p2::Fill(sink2, bad, &st2);
    Check("isRenderedFrame is honoured when set to 1",
          sink2.values["Latewarp.IsRenderedFrame"] == "i32 1", sink2.values["Latewarp.IsRenderedFrame"].c_str());

    // ---- 5. the Streamline frame-data double buffer (T6) ---------------------------
    p2::ResetFrameData();
    const p2::FrameData& fd0 = p2::GetFrameData();
    Check("frame data starts empty", !fd0.hasCurrent && !fd0.hasPrevious, "");

    float f1[16]; for (int i = 0; i < 16; ++i) f1[i] = (float) i;          // frame 100
    float f2[16]; for (int i = 0; i < 16; ++i) f2[i] = (float)(i + 100);   // frame 101
    float f2b[16]; for (int i = 0; i < 16; ++i) f2b[i] = (float)(i + 200); // same frame, other viewport

    p2::SetStreamlineViewToClip(f1, 100);
    Check("frame 1: current set, no previous", p2::GetFrameData().hasCurrent && !p2::GetFrameData().hasPrevious, "");

    p2::SetStreamlineViewToClip(f2, 101);
    {
        const p2::FrameData& fd = p2::GetFrameData();
        bool prevIsFrame1 = fd.hasPrevious;
        for (int i = 0; i < 16; ++i) if (fd.prevViewToClip[i] != f1[i]) prevIsFrame1 = false;
        bool curIsFrame2 = true;
        for (int i = 0; i < 16; ++i) if (fd.viewToClip[i] != f2[i]) curIsFrame2 = false;
        Check("new frame rotates current -> previous", prevIsFrame1 && curIsFrame2, "");
    }

    p2::SetStreamlineViewToClip(f2b, 101);
    {
        const p2::FrameData& fd = p2::GetFrameData();
        bool prevStillFrame1 = true;
        for (int i = 0; i < 16; ++i) if (fd.prevViewToClip[i] != f1[i]) prevStillFrame1 = false;
        bool curIsF2b = true;
        for (int i = 0; i < 16; ++i) if (fd.viewToClip[i] != f2b[i]) curIsF2b = false;
        Check("same frame index does NOT rotate again", prevStillFrame1 && curIsF2b, "per-viewport refresh");
    }

    p2::SetStreamlineViewToClip(nullptr, 102);
    Check("a null matrix is ignored", p2::GetFrameData().frameIndex == 101, "");
    p2::ResetFrameData();
    Check("reset clears the frame data", !p2::GetFrameData().hasCurrent, "");

    // ---- 5b. P3-5b: the jitter rotates with the frame it belongs to ----------------------
    p2::SetStreamlineViewToClip(f1, 200);
    p2::SetStreamlineJitter(0.25f, -0.5f);
    Check("jitter stored as current",
          p2::GetFrameData().jitter[0] == 0.25f && p2::GetFrameData().jitter[1] == -0.5f && !p2::GetFrameData().hasPrevJitter, "");
    p2::SetStreamlineViewToClip(f2, 201);
    Check("a new frame rotates the jitter to previous",
          p2::GetFrameData().hasPrevJitter && p2::GetFrameData().prevJitter[0] == 0.25f &&
              p2::GetFrameData().prevJitter[1] == -0.5f, "");
    p2::SetStreamlineJitter(777.f, 0.f);
    Check("absurd jitter is rejected (no 777 px shift)", p2::GetFrameData().jitter[0] == 0.25f, "");
    p2::ResetFrameData();
    // ---- 5c. (P3-1b lead fill WITHDRAWN 2026-09-28) ----------------------------------------
    // The band maths (p2::ComputeLeadFill / struct LeadFill) was removed with the knob: the tear
    // is to be fixed by over-rendering (stage P3-F), and the kernel repairs its own holes.
    // ---- 5d. P3-3: the reprojection MATRICES the diagnostic uses -----------------------------
    // The per-pixel ReprojectClip / ClipToWorld path and the P3-2 background-buffer cases that used
    // to live here were WITHDRAWN on 2026-09-28 with their implementations -- nothing outside this
    // test ever called them. What survives is the matrix pair the DIAGNOSTIC reprojects with, plus
    // the P3-DIR cross-check that pinned the kernel 16.34 px contract on it.
    {
        const float v2c[16] = { 0.64994f,0,0,0, 0,1.15545f,0,0, 0,0,0.5f,1.f, 0,0,0.1f,0 };
        const float c1 = cosf(3.14159265f / 180.0f);
        const float s1 = sinf(3.14159265f / 180.0f);
        const float yawCur[16] = { c1,0,s1,0, 0,1,0,0, -s1,0,c1,0, 0,-1.8f,0,1 };
        const float yawPrev[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,-1.8f,0,1 };

        // P3-3: the matrix pair the shader uses must agree with the kernel measurement (P3-DIR:
        // a +1 deg yaw moves the centre by f*tan(1 deg) = 16.34 px at 1440 px wide).
        float invVp[16] = {}, vpPrev[16] = {};
        Check("GPUpath: BuildReprojectionMatrices succeeds and stays in the row-vector order",
              p2::BuildReprojectionMatrices(yawCur, v2c, yawPrev, v2c, invVp, vpPrev), "");
        {
            float c[4] = { 0.f, 0.f, 50.1f, 100.f };
            float worldM[4] = {};
            for (int cc = 0; cc < 4; ++cc)
                worldM[cc] = c[0]*invVp[0*4+cc] + c[1]*invVp[1*4+cc] + c[2]*invVp[2*4+cc] + c[3]*invVp[3*4+cc];
            float cp[4] = {};
            for (int cc = 0; cc < 4; ++cc)
                cp[cc] = worldM[0]*vpPrev[0*4+cc] + worldM[1]*vpPrev[1*4+cc] + worldM[2]*vpPrev[2*4+cc] + worldM[3]*vpPrev[3*4+cc];
            const float pxM = (cp[0] / cp[3]) * 1440.0f;
            Check("GPUpath: the shader-side matrices reproduce the same +16.34 px",
                  fabsf(pxM - 16.34f) < 0.5f && fabsf(worldM[1]/worldM[3] - 1.8f) < 0.01f,
                  (std::to_string(pxM) + " px").c_str());
        }
    }
    // ---- 5f. (P3-0a pose extrapolation WITHDRAWN 2026-09-28) ---------------------------------
    // p2::BuildExtrapolatedWorldToView is gone: extrapolating past the games own pose is
    // PREDICTION, and Reflex 2 is late input sampling. p2::BuildWorldToView itself is still
    // tested below, against the real game captures.

    // ---- 6. p2::BuildWorldToView vs the REAL game captures ------------------------------
    // Two WorldToViewMatrix values captured from the game itself. Feeding BuildWorldToView the
    // basis vectors recovered from a capture must reproduce that capture; otherwise the formula
    // in LatewarpFrameData.cpp would just be a convention guess. The only slack allowed is the
    // 5-decimal text precision of frame_4042.txt.
    {
        // ngxproxy.camrun.log:25 -- static frame, camera at (0,1.8,0)
        const float right1[3] = { 0.f, 0.f, 1.f };
        const float up1[3] = { 0.f, 1.f, 0.f };
        const float fwd1[3] = { 1.f, 0.f, 0.f };
        const float pos1[3] = { 0.f, 1.8f, 0.f };
        const float want1[16] = { 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, -1.8f, 0, 1 };
        float got1[16] = {};
        Check("BuildWorldToView accepts a real camera basis",
              p2::BuildWorldToView(right1, up1, fwd1, pos1, got1), "");
        float e1 = 0.f;
        for (int i = 0; i < 16; ++i) { float d = got1[i] - want1[i]; if (d < 0) d = -d; if (d > e1) e1 = d; }
        char b1[64]; _snprintf_s(b1, sizeof(b1), _TRUNCATE, "maxErr=%.7f", e1);
        Check("camrun capture reproduced exactly", e1 == 0.f, b1);

        // routeA/frame_4042.txt matrix 1 (basis recovered from its columns)
        const float right2[3] = { -0.69368f, -0.0f, -0.72028f };
        const float up2[3] = { -0.12186f, 0.98558f, 0.11736f };
        const float fwd2[3] = { -0.70990f, -0.16918f, 0.68369f };
        const float want2[16] = { -0.69368f, -0.12186f, -0.7099f, 0.f, -0.f, 0.98558f, -0.16918f, 0.f,
                                  -0.72028f, 0.11736f, 0.68369f, 0.f, 0.f, -1.77405f, 0.30453f, 1.f };
        float got2[16] = {};
        p2::BuildWorldToView(right2, up2, fwd2, pos1, got2);
        float e2 = 0.f;
        for (int i = 0; i < 16; ++i) { float d = got2[i] - want2[i]; if (d < 0) d = -d; if (d > e2) e2 = d; }
        char b2[64]; _snprintf_s(b2, sizeof(b2), _TRUNCATE, "maxErr=%.7f (txt is 5dp)", e2);
        Check("frame_4042 capture reproduced", e2 < 1e-5f, b2);

        // A degenerate basis must be REFUSED: binding an all-zero matrix would make NGX accept
        // the key and then early-out into a bit-exact pass-through instead of failing loudly.
        const float zero[3] = { 0.f, 0.f, 0.f };
        float got3[16] = {};
        Check("a zero basis is refused (no key written)",
              !p2::BuildWorldToView(zero, zero, zero, pos1, got3), "");
    }

    // ---- 7. p2::MatrixRing: the matrices must outlive the call that binds them ------------------
    // The kernel dereferences the pointers later (the game rotates 5 slots, stride 0x100 = four 4x4
    // blocks), so the ring is what keeps them alive. These assertions pin the layout the driver sees.
    {
        p2::MatrixRing ring;
        float a[16], b[16], c[16], d[16];
        for (int i = 0; i < 16; ++i) { a[i] = (float)(100 + i); b[i] = (float)(200 + i); c[i] = (float)(300 + i); d[i] = (float)(400 + i); }

        const float* p = ring.Bind(a, b, c, d);
        Check("ring returns a slot (never null)", p != nullptr, "");
        bool layout = true;
        for (int i = 0; i < 16; ++i) {
            if (p[i] != a[i] || p[16 + i] != b[i] || p[32 + i] != c[i] || p[48 + i] != d[i]) layout = false;
        }
        Check("ring layout: current w2v / v2c then previous w2v / v2c", layout, "offsets 0/16/32/48");

        const float* q = ring.Bind(a, b, c, d);
        Check("ring rotates to a NEW slot per bind", q != p && q == ring.slot[1], "");

        // nulls: the block is zeroed but the pointer stays valid, so the caller alone decides
        const float* r = ring.Bind(nullptr, b, nullptr, d);
        bool zeroed = true;
        for (int i = 0; i < 16; ++i) { if (r[i] != 0.f || r[32 + i] != 0.f) zeroed = false; }
        Check("ring zeroes the blocks whose source is null", zeroed, "");
        Check("ring still returns a usable slot for the non-null sources", r[16] == b[0] && r[48] == d[0], "");

        // fresh ring so the wrap point is unambiguous: kSlots binds fill 0..kSlots-1, the next one wraps
        p2::MatrixRing ring2;
        const float* first = ring2.Bind(a, b, c, d);
        for (int i = 1; i < p2::MatrixRing::kSlots; ++i) ring2.Bind(a, b, c, d);
        Check("ring wraps after kSlots and reuses slot 0", ring2.Bind(a, b, c, d) == first,
              "kSlots=5, exactly the demo's rotation");
        Check("ring counts its binds", ring2.binds == (uint32_t)(p2::MatrixRing::kSlots + 1), "");
    }

    // ---- 8. P3-3: the diagnostic readback -------------------------------------------------------
    // The GPU accumulates a 16-word block per frame and the host decodes it. This pins the
    // DECODER (bit casts, the NDC -> px conversion, the means, the never-written block) and the
    // angle helper the log compares the measured shift against. It deliberately drives the word
    // indices by NAME, so a silent reordering of the layout fails here instead of in a live log.
    {
        const auto FBits = [](float f)
        {
            uint32_t u = 0;
            memcpy(&u, &f, sizeof(u));
            return u;
        };

        // -- the angle helper
        const float fx[3] = { 1.f, 0.f, 0.f };
        const float fx10[3] = { 0.9848078f, 0.f, 0.1736482f };   // 10 degrees away, xz plane
        const float fBack[3] = { -1.f, 0.f, 0.f };
        const float fUp[3] = { 0.f, 1.f, 0.f };
        const float fZero[3] = { 0.f, 0.f, 0.f };
        float deg = -1.f;
        // NOTE: call the function FIRST and print afterwards. In a single Check(...) call the
        // argument evaluation order is unspecified, so a detail string built inside the same call
        // prints the PREVIOUS value (it did: "-1.000000 deg" for a test that passed).
        bool okDeg = p2::ForwardAngleDeg(fx, fx, &deg);
        Check("diag: identical forwards -> 0 deg", okDeg && deg < 1e-4f, (std::to_string(deg) + " deg").c_str());
        okDeg = p2::ForwardAngleDeg(fx, fx10, &deg);
        Check("diag: 10 deg apart is measured as 10 deg", okDeg && fabsf(deg - 10.f) < 1e-3f, (std::to_string(deg) + " deg").c_str());
        okDeg = p2::ForwardAngleDeg(fx, fUp, &deg);
        Check("diag: 90 deg apart is measured as 90 deg", okDeg && fabsf(deg - 90.f) < 1e-3f, (std::to_string(deg) + " deg").c_str());
        okDeg = p2::ForwardAngleDeg(fx, fBack, &deg);
        Check("diag: opposite forwards -> 180 deg", okDeg && fabsf(deg - 180.f) < 1e-3f, (std::to_string(deg) + " deg").c_str());
        Check("diag: a degenerate forward is refused (no angle published)",
              !p2::ForwardAngleDeg(fx, fZero, &deg) && !p2::ForwardAngleDeg(nullptr, fx, &deg) &&
                  !p2::ForwardAngleDeg(fx, fx, nullptr),
              "");

        // -- the reference the log prints next to the measured shift
        float predPx = -1.f;
        bool okPred = p2::PredictCentreShiftPx(fx, fx10, 1000.f, &predPx);
        Check("diag: a 10 deg turn predicts focal*tan(10deg) = 176.3 px",
              okPred && fabsf(predPx - 176.3269f) < 0.01f, (std::to_string(predPx) + " px").c_str());
        okPred = p2::PredictCentreShiftPx(fx, fx, 1000.f, &predPx);
        Check("diag: no motion predicts 0 px", okPred && predPx == 0.f, (std::to_string(predPx) + " px").c_str());
        Check("diag: an unusable focal is refused",
              !p2::PredictCentreShiftPx(fx, fx10, 0.f, &predPx) && !p2::PredictCentreShiftPx(fx, fx10, 1000.f, nullptr),
              "");
        const float fNear[3] = { 0.0871557f, 0.f, 0.9961947f };   // 85 deg: tan() is not a frame delta
        Check("diag: an 85 deg jump is refused instead of publishing infinity",
              !p2::PredictCentreShiftPx(fx, fNear, 1000.f, &predPx), "");

        // -- the decoder
        uint32_t w[p2::kDiagWords] = {};
        p2::DiagReadout d {};
        Check("diag: a never-written block decodes as invalid",
              p2::DecodeDiagStats(w, 2560, 1600, &d) && !d.valid, "");
        Check("diag: null arguments are refused",
              !p2::DecodeDiagStats(nullptr, 2560, 1600, &d) && !p2::DecodeDiagStats(w, 2560, 1600, nullptr) &&
                  !p2::DecodeDiagStats(w, 0, 1600, &d),
              "");

        w[p2::kDiagPixels]       = 4096;
        w[p2::kDiagOutsideCount] = 64;
        w[p2::kDiagBehindCount]  = 3;
        w[p2::kDiagDepthW]       = 1280;   // deliberately NOT the composite size: this is the case
        w[p2::kDiagDepthH]       = 800;    // that makes Depth.Load(pixelCoord) sample the wrong px
        w[p2::kDiagMaxShiftPx]   = FBits(33.5f);
        w[p2::kDiagMaxOutsidePx] = FBits(7.25f);
        w[p2::kDiagCentreCurX]   = FBits(0.f);
        w[p2::kDiagCentreCurY]   = FBits(0.f);
        w[p2::kDiagCentrePrevX]  = FBits(0.25f);   // +0.25 NDC on a 2560 wide frame = 320 px
        w[p2::kDiagCentrePrevY]  = FBits(0.f);
        w[p2::kDiagCentreDepth]  = FBits(0.125f);
        w[p2::kDiagMmSumQ]       = 1024;           // 1024 q = 1.0 over one sample
        w[p2::kDiagMmCount]      = 1;
        w[p2::kDiagMmOutSumQ]    = 512;            // = 0.5 over one sample
        w[p2::kDiagMmOutCount]   = 1;
        w[p2::kDiagCentreValid]  = 1;
        // P3-3b: the mask block. 409 of 4096 pixels masked, 205 of those from the DEPTH predicate,
        // and a mean |present-hudless| of 0.5 over the mask.
        w[p2::kDiagMaskCount]    = 409;
        w[p2::kDiagMaskCutout]   = 205;
        w[p2::kDiagMaskDiffQ]    = 209408;   // 409 * 512 q = 0.5 average
        // P2/E2c25 (T82): the bright-content bins. 32.0 energy units entered the 1.0-2.0 bin and only
        // a quarter of it came back out of the warp -- the exact signature the live meter looks for.
        // The 4.0+ bin has input and no output, and the frame max luminance is 3.0.
        w[p2::kDiagBin1InQ]      = 1024;
        w[p2::kDiagBin1OutQ]     = 256;
        w[p2::kDiagBin3InQ]      = 64;
        w[p2::kDiagMaxLumQ]      = 96;

        bool ok = p2::DecodeDiagStats(w, 2560, 1600, &d);
        Check("diag: a real block decodes as valid", ok && d.valid && d.pixels == 4096, "");
        Check("diag: pixels outside the previous frame -> percent",
              fabsf(d.outsidePercent - 1.5625f) < 1e-4f, (std::to_string(d.outsidePercent) + " %").c_str());
        Check("diag: the shift maxima survive the float bit cast",
              fabsf(d.maxShiftPx - 33.5f) < 1e-4f && fabsf(d.maxOutsidePx - 7.25f) < 1e-4f,
              (std::to_string(d.maxShiftPx) + " / " + std::to_string(d.maxOutsidePx) + " px").c_str());
        Check("diag: the centre NDC shift converts to pixels",
              fabsf(d.centreShiftPx - 320.f) < 1e-3f, (std::to_string(d.centreShiftPx) + " px").c_str());
        Check("diag: the centre sample keeps the signed NDC + the depth actually used",
              fabsf(d.centrePrev[0] - 0.25f) < 1e-6f && fabsf(d.centreDepth - 0.125f) < 1e-6f, "");
        Check("diag: the mismatch means divide by their own sample counts",
              fabsf(d.meanMismatch - 1.0f) < 1e-5f && fabsf(d.meanMismatchOutside - 0.5f) < 1e-5f,
              (std::to_string(d.meanMismatch) + " / " + std::to_string(d.meanMismatchOutside)).c_str());
        Check("diag: the centre sample is only reported when the shader wrote one",
              d.centreValid, "");
        Check("diag: the depth texture size is reported so a mismatch with the composite is visible",
              d.depthWidth == 1280 && d.depthHeight == 800, "");
        Check("diag: the behind-camera count is reported", d.behindCount == 3, "");
        Check("diag: the mask is quantified (frame share, cutout share, diff strength)",
              fabsf(d.maskPercent - 9.9854f) < 1e-3f && fabsf(d.maskCutoutPercent - 50.1222f) < 1e-2f &&
                  fabsf(d.meanMaskDiff - 0.5f) < 1e-4f,
              (std::to_string(d.maskPercent) + " % / cutout " + std::to_string(d.maskCutoutPercent) +
               " % / diff " + std::to_string(d.meanMaskDiff)).c_str());
        Check("diag: the bright-content bins decode (input and output energy per luminance bin)",
              ok && d.binInQ[1] == 1024 && d.binOutQ[1] == 256 && d.binInQ[3] == 64 && d.binOutQ[3] == 0, "");
        Check("diag: the frame max luminance decodes", ok && fabsf(d.maxLum - 3.0f) < 1e-4f,
              (std::to_string(d.maxLum)).c_str());
        Check("diag: an empty mask reports zeros instead of dividing by it",
              [&] { uint32_t e[p2::kDiagWords] = {}; e[p2::kDiagPixels] = 4096; p2::DiagReadout de {};
                    return p2::DecodeDiagStats(e, 2560, 1600, &de) && de.maskCount == 0 &&
                           de.maskPercent == 0.f && de.maskCutoutPercent == 0.f && de.meanMaskDiff == 0.f; }(),
              "");

        // A NaN or a negative in a max slot must not poison the log: the max slots are
        // 'unsigned' by construction, so a negative there is a bug in the writer, not data.
        w[p2::kDiagMaxShiftPx]   = 0x7fc00000u;   // quiet NaN
        w[p2::kDiagMaxOutsidePx] = FBits(-4.f);
        p2::DecodeDiagStats(w, 2560, 1600, &d);
        Check("diag: NaN / negative maxima decode as 0 instead of poisoning the log",
              d.maxShiftPx == 0.f && d.maxOutsidePx == 0.f, "");
    }


    // ---- P3-D: the late-input rotation (pure math, no Windows, no D3D12) -----------------
    {
        // The canonical LEFT-HANDED camera basis (right = cross(up, fwd) = (1,0,0)), so the
        // expected outcomes are exact numbers rather than whatever an engine produced.
        const float R[3] = { 1.f, 0.f, 0.f };
        const float U[3] = { 0.f, 1.f, 0.f };
        const float F[3] = { 0.f, 0.f, 1.f };
        const float P[3] = { 10.f, 20.f, 30.f };

        float base[16] = {};
        Check("P3-D: the canonical basis builds a WorldToView", p2::BuildWorldToView(R, U, F, P, base), "");

        // row-vector convention: view = pos * M, so the COLUMNS are the camera basis vectors.
        auto colDot = [](const float m[16], int a, int b) {
            return m[a] * m[b] + m[4 + a] * m[4 + b] + m[8 + a] * m[8 + b];
        };
        auto mapsPosToOrigin = [](const float m[16], const float p[3]) {
            const float x = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12];
            const float y = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13];
            const float z = m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14];
            return fabsf(x) < 1e-4f && fabsf(y) < 1e-4f && fabsf(z) < 1e-4f;
        };
        auto orthonormal = [&](const float m[16]) {
            return fabsf(colDot(m, 0, 1)) < 1e-4f && fabsf(colDot(m, 0, 2)) < 1e-4f &&
                   fabsf(colDot(m, 1, 2)) < 1e-4f && fabsf(colDot(m, 0, 0) - 1.f) < 1e-4f &&
                   fabsf(colDot(m, 1, 1) - 1.f) < 1e-4f && fabsf(colDot(m, 2, 2) - 1.f) < 1e-4f;
        };
        auto copy16 = [](float* dst, const float* src) { for (int i = 0; i < 16; ++i) dst[i] = src[i]; };
        auto same16 = [](const float* a, const float* b) {
            for (int i = 0; i < 16; ++i) if (a[i] != b[i]) return false;
            return true;
        };

        Check("P3-D: the camera position maps to the view origin (build is sane)", mapsPosToOrigin(base, P), "");

        float zero[16];
        copy16(zero, base);
        p2::ApplyYawPitchToWorldToViewDeg(zero, 0.f, 0.f);
        Check("P3-D: a zero delta leaves the matrix BIT-identical", same16(zero, base), "");

        float yaw90[16];
        copy16(yaw90, base);
        p2::ApplyYawPitchToWorldToViewDeg(yaw90, 90.f, 0.f);
        // the forward vector lives in m[2], m[6], m[10] (columns hold the basis)
        Check("P3-D: +90 deg yaw turns the forward vector onto the OLD right axis (turn right)",
              fabsf(yaw90[2] - 1.f) < 1e-5f && fabsf(yaw90[6]) < 1e-5f && fabsf(yaw90[10]) < 1e-5f, "");
        Check("P3-D: a yaw keeps the camera exactly where it was (rotation, not translation)",
              mapsPosToOrigin(yaw90, P) && orthonormal(yaw90), "");

        float pit90[16];
        copy16(pit90, base);
        p2::ApplyYawPitchToWorldToViewDeg(pit90, 0.f, 90.f);
        Check("P3-D: +90 deg pitch looks UP (forward onto the OLD up axis)",
              fabsf(pit90[2]) < 1e-5f && fabsf(pit90[6] - 1.f) < 1e-5f && fabsf(pit90[10]) < 1e-5f, "");
        Check("P3-D: a pitch keeps the camera where it was and the basis orthonormal",
              mapsPosToOrigin(pit90, P) && orthonormal(pit90), "");

        float mix[16];
        copy16(mix, base);
        p2::ApplyYawPitchToWorldToViewDeg(mix, 33.3f, -17.5f);
        Check("P3-D: a mixed yaw+pitch stays orthonormal, keeps the position and stays a rotation",
              orthonormal(mix) && mapsPosToOrigin(mix, P) && fabsf(mix[15] - 1.f) < 1e-6f, "");

        float y = 0.f, p = 0.f;
        p2::LateInputYawPitchDeg(500, -500, 0.01f, 0.01f, 1.f, 0.f, 1.5f, &y, &p);
        Check("P3-D: gain 0 yields no rotation at all, however big the delta is", y == 0.f && p == 0.f, "");

        p2::LateInputYawPitchDeg(101, 101, 0.01f, 0.01f, 1.f, 1.f, 10.f, &y, &p);
        Check("P3-D: cursor right turns right, cursor down looks down, dead zone SUBTRACTED",
              fabsf(y - 1.0f) < 1e-6f && fabsf(p + 1.0f) < 1e-6f, "");

        p2::LateInputYawPitchDeg(1, -1, 0.01f, 0.01f, 1.f, 1.f, 10.f, &y, &p);
        Check("P3-D: counts inside the dead zone produce nothing", y == 0.f && p == 0.f, "");

        p2::LateInputYawPitchDeg(100000, -100000, 0.01f, 0.01f, 1.f, 1.f, 1.5f, &y, &p);
        Check("P3-D: the late delta is hard-clamped to +/-maxDeg",
              fabsf(y - 1.5f) < 1e-6f && fabsf(p - 1.5f) < 1e-6f, "");   // dy<0 = cursor up = look up

        p2::LateInputYawPitchDeg(-101, 101, 0.01f, 0.01f, 1.f, 1.f, 10.f, &y, &p);
        Check("P3-D: the signs flip with the cursor sign", fabsf(y + 1.0f) < 1e-6f && fabsf(p + 1.0f) < 1e-6f, "");
    }

    // ---- P3-E: the (M+1) presented-frame plan -------------------------------------------
    {
        p2::PresentedFrame plan[8] = {};

        Check("P3-E: 2x generation plans the rendered frame plus one generated frame",
              p2::BuildPresentedFramePlan(1, 4, plan, 8) == 2, "");
        Check("P3-E: entry 0 is the rendered frame itself (t = 0, own slot, kernel path)",
              plan[0].presentedIndex == 0 && plan[0].outputSlot == 0 && plan[0].interpolationT == 0.f &&
                  plan[0].isRenderedFrame, "");
        Check("P3-E: the generated frame gets its OWN slot and t = 0.5",
              plan[1].presentedIndex == 1 && plan[1].outputSlot == 1 &&
                  fabsf(plan[1].interpolationT - 0.5f) < 1e-6f && !plan[1].isRenderedFrame, "");

        // DLSS-G semantics: R, G1..GM, nextR -- generated frame k sits at k/(M+1), so with
        // M = 4 the presented chain walks 0.0 / 0.2 / 0.4 / 0.6 / 0.8 (the next RENDORED
        // frame is the next plan's entry 0, not t = 1 inside this plan).
        Check("P3-E: 4x MFG plans 5 entries at t = 0.0 / 0.2 / 0.4 / 0.6 / 0.8",
              [&] {
                  for (int i = 0; i < 8; ++i) plan[i] = p2::PresentedFrame {};
                  if (p2::BuildPresentedFramePlan(4, 4, plan, 8) != 5) return false;
                  for (int i = 0; i < 5; ++i)
                      if (fabsf(plan[i].interpolationT - (0.2f * i)) > 1e-6f) return false;
                  return true;
              }(), "");

        Check("P3-E: with enough slots every presented frame lands in its OWN output (E1 constraint)",
              [&] {
                  for (int i = 0; i < 8; ++i) plan[i] = p2::PresentedFrame {};
                  if (p2::BuildPresentedFramePlan(2, 4, plan, 8) != 3) return false;
                  return plan[0].outputSlot == 0 && plan[1].outputSlot == 1 && plan[2].outputSlot == 2;
              }(), "");

        Check("P3-E: more frames than slots wraps in a documented way (0,1,2,3,0,1)",
              [&] {
                  for (int i = 0; i < 8; ++i) plan[i] = p2::PresentedFrame {};
                  if (p2::BuildPresentedFramePlan(5, 4, plan, 8) != 6) return false;
                  for (int i = 0; i < 6; ++i) if (plan[i].outputSlot != (i % 4)) return false;
                  return true;
              }(), "");

        Check("P3-E: exactly one WRITTEN entry is the rendered frame (entry 0)",
              [&] {
                  for (int i = 0; i < 8; ++i) plan[i] = p2::PresentedFrame {};
                  if (p2::BuildPresentedFramePlan(4, 4, plan, 8) != 5) return false;
                  int n = 0;
                  for (int i = 0; i < 5; ++i) if (plan[i].isRenderedFrame) ++n;
                  return n == 1 && plan[0].isRenderedFrame;
              }(), "");

        Check("P3-E: an out-of-range request writes NOTHING and reports 0",
              [&] {
                  for (int i = 0; i < 8; ++i) plan[i] = p2::PresentedFrame {};
                  plan[0].presentedIndex = 7;
                  const bool zero = (p2::BuildPresentedFramePlan(0, 4, plan, 8) == 0);
                  const bool small = (p2::BuildPresentedFramePlan(3, 4, plan, 2) == 0);
                  const bool nullPlan = (p2::BuildPresentedFramePlan(1, 4, nullptr, 8) == 0);
                  return zero && small && nullPlan && plan[0].presentedIndex == 7;
              }(), "");
    }
    // ---- 6. the latewarp camera pose double buffer (E2c9/P0) + the E2c11/E2c12 latches -------
    // Everything the objective needs rests on this state machine: the kernel must be handed TWO
    // DIFFERENT poses (the FG camera ring collapses: 4.7 samples per present), the pair must NOT
    // advance on a repeat present of the same rendered frame (MFG presents one frame 3-4x), and the
    // tag path and the present chain must warp the SAME frame with the SAME pose.
    {
        p2::LwCameraPose a {};
        p2::LwCameraPose b {};
        Check("pose pair: no sample yet -> Advance returns false", !p2::AdvanceStreamlineCameraPose(a, b), "");

        float pos1[3] = { 1.0f, 0.0f, 0.0f };
        float up1[3] = { 0.0f, 1.0f, 0.0f };
        float rt1[3] = { 0.0f, 0.0f, 1.0f };
        float fwd1[3] = { 1.0f, 0.0f, 0.0f };
        p2::SetStreamlineCameraPose(pos1, up1, rt1, fwd1, nullptr);
        Check("pose pair: the first advance yields a valid pair",
              p2::AdvanceStreamlineCameraPose(a, b) && a.valid && b.valid, "");

        float fwd2[3] = { 0.0f, 0.0f, 1.0f };   // a 90 degree turn between the two samples
        p2::SetStreamlineCameraPose(pos1, up1, rt1, fwd2, nullptr);
        p2::LwCameraPose c2 {};
        p2::LwCameraPose p2prev {};
        Check("pose pair: a new sample rotates prev<-cur (prev != cur)",
              p2::AdvanceStreamlineCameraPose(c2, p2prev) && c2.fwd[2] == 1.0f && p2prev.fwd[0] == 1.0f, "");

        p2::LwCameraPose c3 {};
        p2::LwCameraPose p3 {};
        Check("pose pair: no new sample -> the pair does NOT advance (MFG repeat)",
              p2::AdvanceStreamlineCameraPose(c3, p3) && c3.fwd[2] == 1.0f && p3.fwd[0] == 1.0f, "");

        p2::PinLatewarpPosePair();
        p2::LwCameraPose cP {};
        p2::LwCameraPose pP {};
        Check("pose pin: the present path reuses the tag path pair",
              p2::LatewarpPosePinned() && p2::CurrentLatewarpPosePair(cP, pP) && cP.fwd[2] == 1.0f &&
                  pP.fwd[0] == 1.0f,
              "");

        p2::SetLatewarpAtTag(true);
        const bool atTagOn = p2::LatewarpAtTag();
        p2::SetLatewarpAtTag(false);
        Check("tag-drive latch round-trips", atTagOn && !p2::LatewarpAtTag(), "");
    }

    // ---- 10. P2/E2c27: the warp-scale interpolation ------------------------------------------
    // The dial is only meaningful if alpha scales the DELTA: 1 must reproduce the current pose
    // exactly, 0 must land exactly on the previous pose (the kernel then early-outs bit-exact),
    // and 0.5 must sit halfway in position AND orientation.
    {
        p2::LwCameraPose prevP {};
        p2::LwCameraPose curP {};
        prevP.valid = true;
        curP.valid = true;
        prevP.pos[0] = 0.f; prevP.pos[1] = 0.f; prevP.pos[2] = 0.f;
        prevP.fwd[0] = 0.f; prevP.fwd[1] = 0.f; prevP.fwd[2] = 1.f;
        prevP.up[0] = 0.f;  prevP.up[1] = 1.f;  prevP.up[2] = 0.f;
        prevP.right[0] = 1.f; prevP.right[1] = 0.f; prevP.right[2] = 0.f;
        const float th = 10.f * 3.14159265358979323846f / 180.f;
        curP.pos[0] = 1.f; curP.pos[1] = 0.f; curP.pos[2] = 0.f;
        curP.fwd[0] = sinf(th); curP.fwd[1] = 0.f; curP.fwd[2] = cosf(th);
        curP.up[0] = 0.f; curP.up[1] = 1.f; curP.up[2] = 0.f;
        curP.right[0] = cosf(th); curP.right[1] = 0.f; curP.right[2] = -sinf(th);

        p2::LwCameraPose o1 {};
        Check("warp scale: alpha 1 reproduces the current pose exactly",
              p2::ScaleLatewarpWarpDelta(prevP, curP, 1.0f, &o1) && o1.pos[0] == 1.0f &&
                  o1.fwd[0] == curP.fwd[0] && o1.fwd[2] == curP.fwd[2],
              "");

        p2::LwCameraPose o0 {};
        Check("warp scale: alpha 0 lands on the previous pose (kernel early-out becomes bit-exact)",
              p2::ScaleLatewarpWarpDelta(prevP, curP, 0.0f, &o0) && o0.pos[0] == 0.0f && o0.pos[1] == 0.0f &&
                  o0.fwd[0] == 0.0f && o0.fwd[2] == 1.0f && o0.valid,
              "");

        p2::LwCameraPose oh {};
        const bool okH = p2::ScaleLatewarpWarpDelta(prevP, curP, 0.5f, &oh);
        const float dotHalf = (oh.fwd[0] * prevP.fwd[0]) + (oh.fwd[1] * prevP.fwd[1]) + (oh.fwd[2] * prevP.fwd[2]);
        const float angHalf = acosf(dotHalf) * 180.f / 3.14159265358979323846f;
        const float lenHalf = sqrtf((oh.fwd[0] * oh.fwd[0]) + (oh.fwd[1] * oh.fwd[1]) + (oh.fwd[2] * oh.fwd[2]));
        Check("warp scale: alpha 0.5 halves the position delta AND the rotation",
              okH && fabsf(oh.pos[0] - 0.5f) < 1e-5f && fabsf(angHalf - 5.0f) < 0.05f && fabsf(lenHalf - 1.0f) < 1e-5f,
              (std::to_string(angHalf) + " deg from prev").c_str());

        p2::LwCameraPose oBad {};
        p2::LwCameraPose inv {};
        inv.valid = false;
        Check("warp scale: null out / invalid pose / out-of-range alpha are refused (NaN included)",
              !p2::ScaleLatewarpWarpDelta(prevP, inv, 0.5f, &oBad) &&
                  !p2::ScaleLatewarpWarpDelta(prevP, curP, 0.5f, nullptr) &&
                  !p2::ScaleLatewarpWarpDelta(prevP, curP, 1.5f, &oBad) &&
                  !p2::ScaleLatewarpWarpDelta(prevP, curP, -0.1f, &oBad),
              "");
    }
    printf("=== %s (%d failure(s)) ===\n", g_fail == 0 ? "PASS" : "FAIL", g_fail);
    return g_fail == 0 ? 0 : 1;
}
