# NOTICE — licensing of this patch set

## 1. Our added code is GPL-3.0-or-later

Everything under `files\`, `test\`, and the scripts `apply_to_optiscaler.ps1`,
`build_verify.ps1`, `verify_p2.ps1`, `install_latewarp_dll.ps1`, `make_p2_release.ps1`
is licensed **GPL-3.0-or-later**.

Reason: it is meant to be compiled into **OptiScaler**, which is licensed **GNU GPL v3**
(the `LICENSE` file in this package is the one that ships with OptiScaler). Linking our
code into it produces a combined work, so the added code carries the same licence.

## 2. What is NOT in this package

* **No NVIDIA binary of any kind.** Not the NGX core, not `nvngx_latewarp.dll`, nothing.
  The *driver* does not provide the latewarp feature DLL (verified: zero hits anywhere under
  `DriverStore`), so it must be supplied by whoever runs this. This statement is about
  `DriverStore` only: the owner's own working copy does exist on the development machine
  (e.g. a game's `bin\` directory), which is exactly the copy `install_latewarp_dll.ps1` is
  meant to find and verify. Nothing of it is ever packaged.
  **Two files are needed, not one**: the feature dll AND an NGX core that knows feature 15.
  The core that ships with the display driver does NOT (on the development machine it carries
  zero `Latewarp.*` names, so the feature dll alone still ends in `0xBAD0000B`).
  `install_latewarp_dll.ps1` takes both from you, verifies them, and places the capable core
  as `_nvngx.dll` (the name OptiScaler loads first). `install_latewarp_dll.ps1` locates **your own** copy, verifies its SHA-256 and
  either places it or fails with an explicit error. It never downloads anything and never
  reconstructs NVIDIA code.
* **No game files.**
* **No reverse-engineering material** (no decompiler output, no disassembly listings).
* **No build artefacts** (no .exe/.obj/.dll/.lib/.pdb). The release script refuses to package
  them.

## 3. About the parameter names in the code

`files\upscalers\latewarp\LatewarpParams.cpp` contains the string names of the parameters
that NGX accepts for this feature (for example `Latewarp.Output.Width`). Those names are
part of the **parameter interface** that the driver's own modules read at run time; they were
recovered by inspecting the files already present on the development machine. No NVIDIA code
is copied or redistributed — only the interface names are used, which is what the API
requires in order to call it at all.

## 4. Third-party components

None bundled. This package does not contain OptiScaler itself: it is a patch set that is
applied to a copy of the OptiScaler source you already have.

## 5. Scope and risk

* Single-player / no kernel-level anti-cheat only. OptiScaler is an injecting mod; do not put
  it in front of a game whose anti-cheat forbids that. This is **enforced, not just advised**:
  `install_p2_into_game.ps1` refuses to install into a game tree that contains a known
  kernel-level anti-cheat (EAC/BattlEye/Vanguard/ACE/mhyprot/...) or any `*.sys` driver, and it
  has no override switch. Uninstalling is deliberately not gated.
* latewarp depends on driver-internal behaviour. A driver or game update can invalidate it.
  The integration logs the real core's version at load (`core version: ...`) so a change is
  visible rather than silent.
