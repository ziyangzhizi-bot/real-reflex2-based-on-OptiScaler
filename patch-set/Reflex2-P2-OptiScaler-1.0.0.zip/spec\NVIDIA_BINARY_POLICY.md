# SPEC: NVIDIA 二进制策略 (用户口径: 有助于兼容性就要, 没用就免谈)

## 1. 实测: 驱动**不**提供 latewarp 特征 DLL [T2]

在本机全盘核查:

| 位置 | 结果 |
|---|---|
| `C:\Windows\System32\DriverStore\FileRepository\nvlti.inf_amd64_7566d6b2a7331e4e\` (NGX 核所在目录) | 只有 `nvngx.dll`(488824) / `nvngx_dlssg.dll`(9299632) / `nvngx_update.exe` —— **没有 `nvngx_latewarp.dll`** |
| `C:\Windows\System32\DriverStore` 全树搜 `nvngx_latewarp*` | **0 命中** |
| 实际存在的位置 | 游戏目录 `Cyberpunk 2077\bin\x64\`、用户备份 `Downloads\Cyberpunk_Reflex2Mod_Backup\`(2026-08-20 创建, 注明"开发前的安全备份")、本项目 `bin\` |

文件身份: `FileVersion 310,2,0,0`, `FileDescription = "NVIDIA Latewarp - DVS PRODUCTION"`, `CompanyName = NVIDIA`,
`InternalName = Latewarp`, `OriginalFilename = CL 35818615`, 907296 B, sha256 前缀 **81E63B4A9DCFB99B**。

## 2. 为什么它是**兼容性必需品**而不是可选项 [T2]

* NGX 要求特征 DLL 与核**同目录**(或应用目录)。已实测: 缺了它 `CreateFeature(featureId=15)` 返回 **`0xBAD0000B`**
  (见 `docs\REVIEW_S12_response.md` / 本轮 verify 的 probe 目录事故)。
* 也就是说: **即使有东西愿意创建 feature 15, 没有这个 DLL 也无法创建**。
* 驱动不给它 ⇒ 在没有这个文件的机器上, latewarp 链路**从根上不存在**。

⇒ 按用户口径"如果有助于兼容性就要": **结论是有用, 而且是必需的**。

## 3. 但"有用"不等于"必须打包": 三种供给方式

| 方式 | 兼容性收益 | 代价 |
|---|---|---|
| **A. 安装器就地取用用户自己的那份**(游戏目录 / 备份 / `-LatewarpDll` 指定) | 同样得到"文件到位"的全部收益 | **零法律风险**; 仅需用户机器上本来就有 |
| **B. 随包分发** | 用户机器上没有时也能用 | **NVIDIA 专有二进制**(DVS PRODUCTION 构建), 再分发属授权问题; 且与核版本耦合(核 32.0.15.7652 / feature 310.2.0) |
| **C. 只用驱动提供的** | 无 | 本机实测**不存在**, 等于放弃这条链路 |

**建议采用 A**: 把"找文件 + 放到核旁边"做成安装器的一步(`install.ps1` 的 `-LatewarpDll <path>`, 缺省自动在
游戏目录/常见备份位置里搜), 并**校验哈希**. 这样兼容性收益拿满, 不碰再分发。
若用户明确要 B, 需要在 `THIRD_PARTY_NOTICES.md` 与 README 里如实写明, 并由用户承担授权责任。

## 4. 与 P1 现状的关系

当前 P1 代理**不包含也不需要**任何 NVIDIA 二进制(交付包已实测 0 个), 它在 demo 上能跑通是因为那里的文件已经就位。
整合进 OptiScaler 后, 供给方式 A 仍然是正确做法。
