# SPEC: LATEWARP ABI (S2 交付) — 开发时唯一需要的参数规范

来源: 本项目已定稿的逆向结论 (证据索引见文末)。**开发阶段只引用本文件, 不重推。**
证据等级: T0 二进制本体 / T1 自算 / T2 独立复算 / T3 他人未复核。本文件内的数字均为 T0/T1, 关键项已 T2。

## 1. 对象布局
- 载荷 `LatewarpParamsStruct` = **408 字节 (0x198)**。
- 位于 **Latewarp 实例 + 0x258**; 包装体虚表在 **实例 + 0x250**, vtable RVA **0x71BD8** (`NGXCubinParameterStruct<LatewarpParamsStruct>::vftable`)。
- 包装体虚表槽: `vt[2]() = lea rax,[rcx+8]`(取载荷地址) / `vt[3]() = mov eax,0x198`(取大小)。
- 构造: `FUN_180024f80` 写虚表到 +0x250 并 `memset(实例+0x258, 0, 0x198)`。

## 2. 必守规则 (来自实测, 违反会白忙)
- **R1 [修订 2026-09-26] `[0,0x40)` 的 7 个"平面资源句柄"槽与参数键一一对应**:
  `+0` Backbuffer / `+8` HudlessColor / `+16` UIColorAlpha / `+24` Depth / `+32` MV / `+40` Output / `+48` NoWarpMask。
  T2 证据: `_re\nvngx_latewarp_re\docs\PARAM_ABI.md:80` =
  `/* +016 */ uint64_t uiColorAlpha; /* 纹理句柄 ... [Latewarp.UIColorAlpha 中] */`。
  **旧表述"绝对不要写 [0,0x40)"是错的** —— 它把唯一的修复手段也一起禁掉了。
  仍然成立的部分: **feature DLL 自己的代码从不写该区间**(污点扫描 + 直接位移扫描双证 0 条);
  写这些槽的是**参数设置路径**(应用 -> `Set("Latewarp.<平面>", ptr)`), 不是 feature DLL。
- **R1' 只允许"把 `Latewarp.UIColorAlpha` 这一个槽置空"**: 即 `Latewarp.UIColorAlpha := nullptr`
  (= 解绑该平面)。**绝不**写入指向具体资源的指针, **绝不**动另外 6 个槽。理由(T2):
  把 UIColorAlpha 置空是内核真正重投影的两个必要条件之一(`0.000000%` -> `81.088820%`), 这不是副作用而是修复本身。
  运行期实测值(四个进程完全一致, 跨帧稳定): `0xC020C800, 0xC020C800, 0xC020C800, 0xC020C801, 0xC020C802, 0xC803, 0xC804, 0x0`。
  内核把它们当纹理/表面句柄读, **0 = 未绑定**(PTX 里 `selp.b64 %rd41, 0, 句柄, %p1` 直证)。
- **R2 `+0x40` 之后的字段按需写**; 与 R1' 合起来的完整规则是:
  `[0,0x40)` 里**只碰 +16 且只置空**, `+0x40` 之后随便写(我们目前只写 +16 这一个键, 其余靠游戏自己设)。
- **R3 参数键必须命中 43 键白名单**(见 §4)。白名单外的键**不会被识别**: 部分键缺失会**硬失败**, 其余**静默无效**。
  实例: `Latewarp.Output.Width/.Height` 缺失 => `EvaluateFeature` 返回 **0xBAD00005**(硬失败); `Latewarp.Reserved1` 从不被查询(静默)。
  两条路径都失败 => **0xBAD00002**。

## 3. 逐字段偏移表 (写参数时照这张表)
| 偏移 | 宽 | 语义 | 内核读点 |
|---|---|---|---|
| +0x00..0x3F | 64B | 7 个平面资源句柄: +0 Backbuffer / +8 HudlessColor / +16 UIColorAlpha / +24 Depth / +32 MV / +40 Output / +48 NoWarpMask —— **只允许把 +16 置空 (R1')** | fb0 {0,8,16,40,48,56} / fb1 {32,40,56} / fb2 {0,8,16,48} |
| +0x40 | v2.u32 | Output 资源 extent {Width, Height} | fb2 @64 (越界判据 + UV 分母) |
| +0x48 | 4xu32 | Output.Subrect {X,Y,W,H} | fb0 @72/@80/@84 |
| +0x58 | 4xu32 | Backbuffer.Subrect | fb0 @88/@96 |
| +0x68 | 4xu32 | HudlessColor.Subrect | fb0 @104/@112 |
| +0x78 | 4xu32 | UIColorAlpha.Subrect | fb0 @120/@128 |
| +0x88 | 4xu32 | Depth.Subrect | fb1 @136/@144 |
| +0x98 | 4xu32 | MV.Subrect | (无内核读点) |
| +0xA8 | 4xu32 | NoWarpMask.Subrect | fb0 @168/@176, fb1 @168 |
| +0xB8 / +0xBC | u32 | Depth.Subrect.Width / .Height 的副本 | fb0 @184(读 6 次) |
| +0xC0 | u32 | 帧计数器 (写后 `add [实例+0xC], 0x101`) | fb0 @192 |
| +0xC4 | f32 | `f32(Output.Subrect.Width) * 2^(2+[r15+0xB8]) / 2160.0` | fb0 @196 |
| +0xC8..0x107 | 64B | 矩阵1 = transpose(FUN_180025180 结果) | **无任何内核读点 (负结果)** |
| +0x108..0x147 | 64B | 矩阵2 = transpose(同上) | **fb1 读 (8xv2.f32 @264..320)** |
| +0x148..0x14B / +0x164..0x167 | 4B / 4B | 模板零区 | 无 |
| +0x14C | u32 | 0 | 无 |
| +0x150 | u32 | 常量 1 | 无 |
| +0x154 | u32 | Latewarp.FrameID | 无 |
| +0x158 / +0x15C | f32 | Jitter.Offset.X / .Y | 无 |
| +0x160 | u8 | (Latewarp.DepthInverted != 0) | fb1 @352 |
| +0x161 | u8 | (Backbuffer 非空 && [r15+0xBD]!=0) | fb0 @353; fb2 @353 |
| +0x168 | u32 | (Jitter.X==0 && Jitter.Y==0) ? 0 : 1 | fb0 @360 |
| +0x16C..0x17D | 18B | 模板零区 | fb1 @364 未机器确认 |

## 4. 43 个有效参数键 (完整清单见 docs\LATEWARP_KEYS.tsv, 含 .rdata 偏移)
Output.Width / Output.Height; 7 组 Subrect{Base.X,Base.Y,Width,Height}: Output / HudlessColor / Depth / Backbuffer / UIColorAlpha / MV / NoWarpMask;
组级开关键: Backbuffer / HudlessColor / UIColorAlpha / NoWarpMask;
EvalFlags / DepthInverted / IsRenderedFrame / FrameID / UsePremultiplyUIAlpha;
WorldToViewMatrix / ViewToClipMatrix / PrevRenderedWorldToViewMatrix / PrevRenderedViewToClipMatrix。
**不存在** `Latewarp.Output`、`Latewarp.Reserved1`; **不存在** `Latewarp.Enabled` 之类总开关。

## 5. 内核侧摘要 (为什么只能这样写)
- 8 个 fatbin: PTX sm_120/89/86/75 + cubin sm_89/86/75 (56 条目); launch 主内核 13 阶段。
- 7 个句柄槽在四个目标 PTX 里都被 `tex.base/tex.level/sust.p/sured.p` 当句柄操作数使用。
- 各内核最大读偏移: fb0 392 / fb1 364 / fb2 382 / font,mv_dilate 88 / exposure 48 / capture 40 / clear_view 32。
- SASS 层未直证(本机无 nvdisasm), PTX 四目标互证是当前最强证据。

## 6. 启动链 (只作背景, 开发不需要碰)
feature DLL -> `nvapi_QueryInterface(0x5C52BB86)` -> `nvapi64_impl!0x362820` -> 运行期装配的 thunk 表 -> 驱动。
写指令拿不到的原因是**结构性**的(全是运行期取指针的转发桩); 见 driver_side\GOAL4_FINAL.md §5d。

## 7. 证据索引 (可复算)
- _re\nvngx_latewarp_re\HANDOFF_OVERVIEW.md — 全局总览
- _re\nvngx_latewarp_re\docs\LATEWARP_KEYS.tsv / PAYLOAD_OFFSET_MAP.tsv / PARAM_FILL.md
- _re\nvngx_latewarp_re\core_ngx\KERNEL_SLOT_USAGE.md / SASS_FALLBACK.md
- _re\nvngx_latewarp_re\driver_side\GOAL4_FINAL.md (含 4 次运行期实测) / PROBE_RESULT_1.md
- 探针: _re\nvngx_latewarp_re\driver_side\probe\FindLatewarpRuntime.ps1
