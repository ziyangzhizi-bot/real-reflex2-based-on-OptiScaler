# ---------------------------------------------------------------------------
#  test_collect.ps1 -- positive + NEGATIVE tests for collect_p2_run.ps1.
#  A report tool that cannot say FAIL is worthless, so each failure mode gets a case.
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Continue'
$P2 = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Script = Join-Path $P2 'collect_p2_run.ps1'
$tmp = Join-Path $env:TEMP ('p2coll_' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$fails = 0
function Check([string]$n, [bool]$ok, [string]$d) {
    if ($ok) { Write-Host ("  [PASS] " + $n + "  " + $d) } else { Write-Host ("  [FAIL] " + $n + "  " + $d) -ForegroundColor Red; $script:fails++ }
}
function Run([string]$content) {
    $p = Join-Path $tmp ([guid]::NewGuid().ToString('N').Substring(0,8) + '.log')
    [System.IO.File]::WriteAllText($p, $content)
    $o = & powershell -NoProfile -ExecutionPolicy Bypass -File $Script -Log $p 2>&1 | Out-String
    return @{ text = $o; code = $LASTEXITCODE }
}

$good = @(
  "latewarp: plane 'Depth' -> ret 0x1 value 0x1234",
  "latewarp: plane 'MotionVectors' -> ret 0x1 value 0x5678",
  "latewarp: plane 'Latewarp.UIColorAlpha' -> ret 0x1 value 0x9ABC",
  "latewarp: feature 15 create; keys written 26, refused 0",
  "latewarp: CreateFeature(featureId=15) succeeded",
  "latewarp: eval #1 frame 2 (keys written 26, refused 0)",
  "latewarp: eval #1000 frame 1001 (keys written 26, refused 0)",
  "latewarp-mat: w2v True pw2v True v2c True pv2c True cam True framedata cur True prev True upd 1200",
  "latewarp-mat row: w2v -0.6937 -0.1219 -0.7099 | 0.0000 1.8000 0.0000",
  "latewarp-mat row: pw2v -0.5783 -0.1741 -0.7971 | 0.0000 1.8000 0.0000"
) -join [char]10
$r = Run $good
Check "good run -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "good run -> QUALIFIED" ($r.text -match 'VERDICT: QUALIFIED') ""
Check "good run -> names the supplied planes" ($r.text -match 'planes already supplied : .*Depth' -and $r.text -match 'MotionVectors') ""
Check "good run -> reports the four matrices" ($r.text -match 'world->view current=True previous=True' -and $r.text -match 'view->clip current=True previous=True') ""
Check "good run -> echoes the matrix values" ($r.text -match 'value row w2v  : -0.6937') ""

# the core oracle must be REPORTED, not just counted: the missing key IS the fix
$r = Run (@(
  "latewarp: CreateFeature(featureId=15) succeeded",
  "latewarp: EvaluateFeature -> 0xBAD00005",
  "[NGXLatewarp::EvaluateFeature:589] error: could not find Latewarp.WorldToViewMatrix parameter",
  "[NGXLatewarp::EvaluateFeature:589] error: could not find Latewarp.WorldToViewMatrix parameter",
  "[NGXLatewarp::EvaluateFeature:589] error: could not find Latewarp.PrevRenderedViewToClipMatrix parameter"
) -join [char]10)
Check "missing param -> exit 13" ($r.code -eq 13) ("exit=" + $r.code)
Check "missing param -> the verdict NAMES the key" ($r.text -match 'could not find: .*Latewarp.PrevRenderedViewToClipMatrix') ""
Check "missing param -> lists each key with its count" ($r.text -match 'MISSING Latewarp.WorldToViewMatrix\s+x2') ""

# a run that evaluates but never bound a matrix must not be reportable as QUALIFIED
$r = Run (@(
  "latewarp: feature 15 create; keys written 46, refused 0",
  "latewarp: CreateFeature(featureId=15) succeeded",
  "latewarp: eval #1 frame 2 (keys written 46, refused 0)",
  "latewarp-mat: w2v False pw2v True v2c True pv2c True cam False framedata cur True prev True upd 0"
) -join [char]10)
Check "matrices incomplete -> exit 20" ($r.code -eq 20) ("exit=" + $r.code)
Check "matrices incomplete -> MATRIX_INPUTS_MISSING" ($r.text -match 'VERDICT: MATRIX_INPUTS_MISSING') ""

$r = Run ("latewarp: feature 15 create; keys written 26, refused 0" + [char]10 + "latewarp: CreateFeature(featureId=15) -> 0xBAD0000B")
Check "CreateFeature failure -> exit 12" ($r.code -eq 12) ("exit=" + $r.code)
Check "CreateFeature failure -> CREATE_FAILED" ($r.text -match 'VERDICT: CREATE_FAILED') ""

$r = Run ("latewarp: feature 15 create; keys written 26, refused 3" + [char]10 + "latewarp: CreateFeature(featureId=15) succeeded" + [char]10 + "latewarp: eval #1 frame 2 (keys written 26, refused 0)")
Check "whitelist refusal -> exit 11" ($r.code -eq 11) ("exit=" + $r.code)
Check "whitelist refusal -> WHITELIST_VIOLATION" ($r.text -match 'VERDICT: WHITELIST_VIOLATION') ""

$r = Run ("latewarp: feature 15 create; keys written 26, refused 0" + [char]10 + "latewarp: CreateFeature(featureId=15) succeeded" + [char]10 + "latewarp: eval #1 frame 2 (keys written 26, refused 0)" + [char]10 + "latewarp: EvaluateFeature -> 0xBAD00005")
Check "eval error -> exit 13" ($r.code -eq 13) ("exit=" + $r.code)
Check "eval error -> EVAL_ERROR" ($r.text -match 'VERDICT: EVAL_ERROR') ""

$r = Run "no latewarp lines at all"
Check "no lines -> exit 14" ($r.code -eq 14) ("exit=" + $r.code)
Check "no lines -> NO_LATEWARP_LINES" ($r.text -match 'VERDICT: NO_LATEWARP_LINES') ""

# --- branch 1: feature-layer intercept -------------------------------------
$r = Run (@(
  "latewarp: plane 'Depth' -> ret 0x1 value 0x1234",
  "Passthrough to native NGX CreateFeature for feature 15",
  "latewarp: intercept asserted the 2 decisive keys (frame 0)"
) -join [char]10)
Check "intercept -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "intercept -> INTERCEPT_ACTIVE" ($r.text -match 'VERDICT: INTERCEPT_ACTIVE') ""
Check "intercept -> reports the app itself created f15" ($r.text -match 'app itself created f15  : True') ""

$r = Run ("Passthrough to native NGX CreateFeature for feature 15" + [char]10 + "latewarp: intercept wrote 1 of 2 decisive keys (refused 1)")
Check "intercept short write -> exit 19" ($r.code -eq 19) ("exit=" + $r.code)
Check "intercept short write -> INTERCEPT_INCOMPLETE" ($r.text -match 'VERDICT: INTERCEPT_INCOMPLETE') ""

$r = Run "latewarp: intercept got a null parameter object"
Check "intercept null params -> exit 18" ($r.code -eq 18) ("exit=" + $r.code)
Check "intercept null params -> INTERCEPT_BAD_PARAMS" ($r.text -match 'VERDICT: INTERCEPT_BAD_PARAMS') ""

# forwarded, but the intercept never logged: the verdict must point at the SWITCH, not at branch 2
$r = Run "Passthrough to native NGX CreateFeature for feature 15"
Check "forwarded without intercept -> exit 14" ($r.code -eq 14) ("exit=" + $r.code)
Check "forwarded without intercept -> points at [Latewarp] Rewrite=true" ($r.text -match 'Rewrite=true') ""

# app never created it and branch 2 did not run: the verdict must point at BRANCH 2
$r = Run "nothing relevant here"
Check "app never created f15 -> exit 14" ($r.code -eq 14) ("exit=" + $r.code)
Check "app never created f15 -> points at branch 2 (FG Output = Reprojection)" ($r.text -match 'FG Output') ""

Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
Write-Host ("=== " + $(if ($script:fails -eq 0) { 'PASS' } else { 'FAIL' }) + " (" + $script:fails + " failure(s)) ===")
exit $(if ($script:fails -eq 0) { 0 } else { 1 })
