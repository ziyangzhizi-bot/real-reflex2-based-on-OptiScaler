# PLAN: P2 — 把 latewarp 接进 OptiScaler (让"从不创建 feature 15"的游戏也能用)

> 生成依据: skill `blueprint`(每步可冷启动 / 含验证命令 / 含退出判据 / 末尾对抗评审) +
> `intent-driven-development`(AC-NNN 验收)。
> 本仓库**不是 git** ⇒ blueprint 的 **direct 模式**: 不建分支/PR, 产出直接落盘 + MANIFEST 哈希。
> 前置: `spec\OPTISCALER_INTEGRATION.md`(S3 勘察, 逐条带文件:行号)、`spec\NVIDIA_BINARY_POLICY.md`、
> `docs\ADR-001-architecture.md` §8(P2 已升为主方向)。

## 0. 目标 (用户裁定)

**把 P2 做出来**: 在 OptiScaler 里加一个 latewarp 后端, 使得
① 对**已经**创建 feature 15 的游戏, 让那次评估真正产生重投影;
② 对**从不**创建 feature 15 的游戏, **由我们自己创建并驱动** feature 15 —— 这才是"通用"。

**范围(用户裁定)**: 有内核级反作弊的游戏**直接排除**(在那类游戏上装 mod 本身就是违规)。
⇒ "通用" = 无内核级反作弊的游戏(单机为主)。

**交付物**: 可复核的补丁集(我们的新文件 + 应用脚本) + 安装器(含特征 DLL 供给) + 验证脚本 + 文档。

## 1. 不变量 (每一步结束都必须成立)

- **INV-P1** 与既有 INV-1..6 一致: 不改 `bin\` 原件; 卸载/还原后哈希一致; 结论分 T0-T3 并指得到地址或哈希。
- **INV-P2 [用户裁定]** **不把 NVIDIA 专有二进制放进交付包**。特征 DLL 由**使用者自备**, 安装器负责
  "自动搜索 + `-LatewarpDll` 指定 + 哈希校验 + 缺失时明确报错"。理由与证据见 `spec\NVIDIA_BINARY_POLICY.md`。
- **INV-P3 [用户裁定]** 反作弊目标不注入、不调试、不宣传支持。
- **INV-P4** 所有对 OptiScaler 的改动**以可复核形式留痕**: 新文件放 `_re\reflex2_mod\p2\`,
  `apply_to_optiscaler.ps1` 落到那棵源码树, 并产出 diff 清单。**不直接改那棵树**。
- **INV-P5 [GPL-3]** OptiScaler 是 GPL-3 ⇒ 我们的新增代码按 GPL-3 提供, 交付物带 `LICENSE`/`NOTICE` 说明。
  因为 INV-P2 不打包专有二进制, 组合问题自然避开。
- **INV-P6** 不重复推导已定稿的 RE 结论(见 `HANDOFF.md` §5); 引用必须能指到地址或哈希。
- **INV-P7** 一次只改一个变量, 追加运行日志; 每步结束自评。

## 2. 步骤 (10 步; 每步可冷启动; 标 [并行] 的写范围不重叠)

### P2-S1 接口事实定稿 (read-only, 无副作用)
- 上下文简报: 勘察已完成(`spec\OPTISCALER_INTEGRATION.md`), 但 §3 有 5 项**待验证**。这 5 项决定后面能不能写。
- 任务: 逐项查证并落 `spec\OPTISCALER_INTERFACE_FACTS.md`(每条带 `文件:行号`):
  ① `hudfix\` 抓到的无 UI 帧能否直接当 `Latewarp.HudlessColor`/`UIColorAlpha`;
  ② `hooks\Streamline_Hooks.cpp` 的 `slSetConstants` 是否能拿到 latewarp 要的**四个矩阵 + jitter**;
  ③ 深度/MV 的格式·极性·缩放约定与 latewarp 内核是否一致;
  ④ 自建实例时命令列表/资源状态是否安全;
  ⑤ latewarp 输出接到呈现链的哪一步。
- 验证: 每条给出文件:行号; 无法查证的**必须标"未知"**, 不许推断。
- 退出: 5 项都有明确结论或"未知"。  止损: 若 ①③ 判定不兼容 ⇒ 转 P2-S1b(只做"游戏已创建时接管", 放弃自建)。

### P2-S2 最小接入骨架 (编译级)
- 任务: 加 `LatewarpFeature`(Dx12) 空实现 + 在 `upscalers\FeatureProvider_Dx12.cpp` 注册 + `OptiTypes.h` 的 `Upscaler` 加值 + 菜单项(默认关)。
- 验证: 源码树能编译通过; 默认关时**行为与改动前一致**。
- 退出: 编译通过 + 默认关无行为变化。  回滚: 删除新文件 + 还原 3 个触点。

### P2-S3 参数装配 (43 键白名单 + 两个决定键)
- 任务: 用 `IFeature` 已有的 color/depth/MV/jitter/尺寸填参数; 写 `Latewarp.IsRenderedFrame:=0`、`Latewarp.UIColorAlpha:=nullptr`;
  所有键过 43 键白名单, 越界显式报错(搬 P1 的 `Whitelisted()`)。
- 验证: 日志能打出每帧装配; 离线 harness(`fwtest --ngxdir`)可复用做差分。
- 退出: 装配出的参数能让内核真的 warp。  止损: 3 轮无进展 ⇒ 退回 P2-S2 只留骨架。

### P2-S4 **自建实例** (本阶段的关键一步)
- 任务: 当宿主帧从未调用 `CreateFeature(15)` 时, 由我们创建 feature 15 并在每帧评估(用 OptiScaler 的管线)。
- 验证: 在**从不创建** feature 15 的目标上(如 CP2077), 日志出现我们自己创建的实例 + 每帧评估 + 真 warp。
- 退出: AC-P2-003。  止损: 若导致宿主崩溃(路线 A 曾因热路径装钩子崩过) ⇒ 停止自建, 只保留接管模式并记录。

### P2-S5 无 UI 帧 / UI 遮罩接法
- 任务: 按 P2-S1 ①的结论, 把 `hudfix` 的无 UI 帧接到 `HudlessColor`/`UIColorAlpha`; 接不上时退回 P1 的"置空 UIColorAlpha"。
- 验证: 实机画面里世界被扭、UI 不被扭(或按文档说明的折中)。
- 退出: AC-P2-004。

### P2-S6 特征 DLL 供给 (安装器侧) [可与 S2-S5 并行]
- 任务: `install.ps1` 增加 `-LatewarpDll <path>` 与自动搜索(游戏目录/备份/当前目录) + SHA256 校验 + 缺失时**明确报错**。
- 验证: 正例(有文件)放到位且哈希吻合; **负例(删掉文件)必须以非零退出并打印缺什么**。
- 退出: 正负例都符合。  止损: 无。

### P2-S7 开关与配置
- 任务: 菜单项 + INI 键(默认关), 与 OptiScaler 现有配置风格一致; 一键禁用。
- 验证: 关掉后行为回到改动前。
- 退出: 可不改代码切换。

### P2-S8 验证脚本 (P2 版)
- 任务: 扩展 `verify.ps1` 或新增 `verify_p2.ps1`: 静态(补丁是否落位/编译产物) + 离线(harness 差分) + 日志(自建实例/每帧评估/无 `0xBAD000xx`)。
- 验证: 负例必须 FAIL(例: 关掉开关、或把某个键改成白名单外)。
- 退出: 正负例都符合。  参照 P1 的三级结构。

### P2-S9 打包与文档
- 任务: `p2\` 补丁集 + `apply_to_optiscaler.ps1` + diff 清单 + README/ADR 更新 + **GPL-3 声明** + 明确写"不含 NVIDIA 二进制"。
- 验证: 包里 0 个 NVIDIA 二进制(沿用 `make_release.ps1` 的硬门禁); 按 README 冷启动能复现。
- 退出: 交付物可复现。

### P2-S10 对抗评审 (blueprint 要求)
- 任务: 派**不带本项目上下文**的 subagent, 按 blueprint 反模式目录 + AC-P2 逐条挑刺; 我逐条修或驳回并记理由。
- 验证: 每条 findings 都有结论。
- 退出: 无未处理 critical。

## 3. 验收 (AC-P2)

- **AC-P2-001** 补丁可落位可回滚: 应用后源码树能编译; 撤销后与原树逐字节一致(记哈希)。
- **AC-P2-002** 已创建 feature 15 的目标: 每帧评估成功且画面真的 warp(实机或离线差分)。
- **AC-P2-003** **从不创建** feature 15 的目标: 我们自己创建的实例出现 + 每帧评估 + 无 `0xBAD000xx`。
- **AC-P2-004** UI 处理有明确结论(接无 UI 帧 或 置空 UIColorAlpha), 且实机可见。
- **AC-P2-005** 缺失特征 DLL 时**明确报错**, 不静默失败。
- **AC-P2-006** 一个开关可完全禁用, 行为回到改动前。
- **AC-P2-007** 交付包内 **0 个 NVIDIA 二进制**; 含 GPL-3 声明。
- **AC-P2-008** 反作弊目标不被注入/调试/宣传支持。
### 验收现状(逐条, 证据在括号里) — 第 37 轮更新

| AC | 状态 | 证据 |
|---|---|---|
| AC-P2-001 | **PASS** | `verify_p2.ps1 -Full`: 20 补丁 / 10 文件落位 / 10 新增文件; 回滚后 **11/11** 文件逐字节 == 交付树, 两个生成的版本头一并删除; `-DryRun` 不落地; 预检拒绝二次 apply |
| AC-P2-002 | **离线已证并入闸, 差实机画面** | `verify_p2.ps1 -Full` 新增闸层 **`offline kernel acceptance (real feature DLL)`**(`test\test_offline_warp.ps1`, 6 例): 负对照去掉四个矩阵 ⇒ `EvaluateFeature -> 0xBAD00005`(与实机同码); 正例 ⇒ `CreateFeature/EvaluateFeature Success` 且像素差异 **81.09%**(P1 实测 81.0888%); 消融 `--nosubrect` ⇒ 仍 Success。缺用户自备的 NVIDIA 二进制时该层 `SKIP` 且不计失败。宿主"每帧真的出画"仍需一次实机日志 |
| AC-P2-003 | **部分, 根因已定并已修** | 自建 f15 的代码路径就绪(`CreateFeature(15) succeeded` 已在实机出现); 缺的是四个矩阵 ⇒ 已由 `p2::BuildWorldToView()` 供上(两份真实抓取回归 maxErr 0 / 6e-6); 采集器新增 `MATRIX_INPUTS_MISSING` 与"内核缺失参数神谕"(在真实的 7792 次失败日志上实测点名 `Latewarp.WorldToViewMatrix`); 待实机确认 `latewarp: eval #N` |
| AC-P2-004 | **部分** | 机制已实现: `Latewarp.UIColorAlpha:=nullptr` + 只在有平面时才写其它平面(不覆盖宿主输入); 离线台架 `--uialpha null` ⇒ 真 warp(81.09% 像素变化)⇒ 机制对真内核有效; "实机可见" 需宿主 |
| AC-P2-005 | **PASS(工具侧)** | `install_latewarp_dll.ps1`: 缺失/校验失败都**明确报错**并回显两个哈希(`test_provisioning.ps1` 24/24); 运行期由 CreateFeature 的 LOG_ERROR + 采集器 `CORE_UNAVAILABLE` 兜住 |
| AC-P2-006 | **部分(静态)** | L4: 两个开关都 `assignments=0`(无程序化赋值) + ini 默认 `Reset`/关; 差分运行需宿主 |
| AC-P2-007 | **PASS** | 包 **40** 文件 sha256 每次注册、**0** 个 NVIDIA 二进制/构建产物/超 2 MB 文件(make_p2_release 自检); `NOTICE.md` + `LICENSE` 声明 GPL-3 |
| AC-P2-008 | **PASS** | 安装器**强制拒绝**内核级反作弊(标记名 + 游戏树里任意 `*.sys`), 无 `-Force` 后门(行为化证明), `-DryRun` 也拒; `test_game_install.ps1` 32/32 |

> 测试计数(第 38 轮): 离线单测 32 断言 / provisioning 24 / collector 29 / game-install 32 / **offline kernel acceptance 6**, 全部 0 失败; `verify_p2.ps1 -Full` = PASS。


## 4. 并行与依赖

- 可并行: P2-S6(安装器, 不碰源码树) 与 P2-S2..S5(源码树)。
- 串行: S1 → S2 → S3 → S4 → S5 → S7 → S8 → S9 → S10; S6 可随时插入。
- 团队纪律: teammate 只做零碎并行线; 主线(接口/后端/自建实例)由 Lead 接手。**用户未要求 teammate 时一律自己干。**

## 5. 上下文预算与交接

- 每步按"一次上下文能做完"切; 做不完就拆子步并写进 `HANDOFF.md`。
- **上下文接近极限时, 先更新 `HANDOFF.md` 再继续任何动作**。
- 每步结束把"产物路径 + 哈希 + 验证结论"追加进 `LOG.md`(append-only)。

## 6. 止损总则

- 同一目标**连续 3 轮无可测进展** ⇒ 停下、写 HANDOFF、换方案。
- 任何"零命中/零效果"的结论**必须同时证明跑完了**(有结束标记)。
- 违反 INV-P2(打包专有二进制) 或 INV-P3(碰反作弊目标) 的提议一律不执行。
