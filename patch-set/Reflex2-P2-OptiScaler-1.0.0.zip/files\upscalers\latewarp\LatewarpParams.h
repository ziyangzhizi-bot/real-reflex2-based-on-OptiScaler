// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#pragma once

#include <stdint.h>
#include <stddef.h>

// Parameter assembly for NGX feature 15 (latewarp / Reflex 2), kept FREE of any
// OptiScaler or D3D12 dependency on purpose: it is unit-testable on its own
// (p2\test\LatewarpParams_test.cpp) and the Dx12 backend just feeds it.
namespace p2
{

// The keys NGX recognises for latewarp. Evidence (T1):
//   * 43  "Latewarp.*" keys   -> _re/reflex2_mod/spec/LATEWARP_KEYS.tsv (all in the payload map)
//   * 3   unprefixed plane keys Depth / MotionVectors / Output
//         -> _re/00_必读_入口.md, the "planar names" table (measured on the real core)
// Anything else is REFUSED and counted; NGX would otherwise ignore it silently.
int          LatewarpKeyCount();          // 43
int          PlaneKeyCount();             // 3
bool         IsLatewarpKey(const char* key);
const char*  LatewarpKeyAt(int index);
const char*  PlaneKeyAt(int index);

// Two NGX-GENERIC keys latewarp also consumes, and which the official FrameWarp sample
// (NVIDIA-RTX/Streamline_Sample, NGXWrapper::EvaluateLatewarp) writes explicitly every frame.
// They carry no "Latewarp." prefix, exactly like Depth / MotionVectors / Output, which is why they
// are not part of the 43 Latewarp.* literals -- but both literals ARE present in the real feature
// DLL (verified by string search), so writing them is not a guess.
int          ExtraKeyCount();             // 2
const char*  ExtraKeyAt(int index);

enum class ValueType { Pointer, Int32, UInt32, Float };

// The caller owns the real NGX parameter object; this is the narrow seam we test.
struct ISink
{
    virtual ~ISink() {}
    virtual bool Set(const char* key, ValueType type, const void* value) = 0;
};

struct Inputs
{
    uint32_t outputWidth = 0;
    uint32_t outputHeight = 0;

    void* backbuffer = nullptr;
    void* hudlessColor = nullptr;
    void* uiColorAlpha = nullptr;
    void* noWarpMask = nullptr;
    void* depth = nullptr;
    void* motionVectors = nullptr;
    void* output = nullptr;

    // per plane, in this order: Backbuffer, HudlessColor, UIColorAlpha, Depth, MV, Output, NoWarpMask
    int32_t subrect[7][4] = {};   // {baseX, baseY, width, height}; width/height 0 => leave unset

    uint32_t frameId = 0;
    int32_t  depthInverted = 1;
    int32_t  usePremultiplyUIAlpha = 1;
    int32_t  evalFlags = 0;

    // The TAA/DLSS subpixel jitter the host applied to THIS frame's projection. The official
    // sample passes its own jitter here; leaving it at 0 while the host did jitter costs a
    // sub-pixel error, which is why the value is wired from Streamline's constants in P3-5b.
    float    jitterX = 0.f;
    float    jitterY = 0.f;

    // THE TWO DECISIVE KEYS (P1 proved: these two alone turn a bit-exact copy into a
    // real warp; see README section 1).
    int32_t isRenderedFrame = 0;   // must be 0
    bool    nullOutUIColorAlpha = true;

    const float* worldToView = nullptr;
    const float* viewToClip = nullptr;
    const float* prevWorldToView = nullptr;
    const float* prevViewToClip = nullptr;
};

struct Stats
{
    int written = 0;
    int refused = 0;              // keys outside the whitelist
};

// Writes everything derivable from Inputs. The two decisive keys are written LAST,
// so a failure in the middle can never leave the feature "half enabled".
// Returns the number of accepted writes.
int Fill(ISink& sink, const Inputs& in, Stats* stats);

// Test-only hook: routes ONE arbitrary key through the very same whitelist gate that Fill
// uses, so a unit test can prove the gate refuses and reports. Production code never calls
// this -- without it, stats.refused was unreachable and the refusal path was untested
// (S10 F-09). Returns true when the key was accepted and handed to the sink.
bool TryWriteKey(ISink& sink, Stats* stats, const char* key, ValueType type, const void* value);

}   // namespace p2
