# ---------------------------------------------------------------------------
#  apply_to_optiscaler.ps1 -- apply / preview / revert the P2 latewarp patch set.
#  Default target = the BUILD WORKSPACE (_re\repro_src), never the delivered source
#  tree, so INV-P4 holds. Every patch is anchored: the anchor must match EXACTLY
#  ONCE or the whole apply aborts before writing anything.
#
#  Patches to the SAME file COMPOSE: each one is computed from the text as it stands
#  after the previous patch (a lost-update bug in the first version silently dropped
#  T6a's include when T6b also touched Streamline_Hooks.cpp -- the per-patch line
#  counts in APPLIED_DIFF.txt are what exposed it).
#
#  usage:  .\apply_to_optiscaler.ps1 [-DryRun] [-Revert] [-Tree <tree>]
# ---------------------------------------------------------------------------
param(
    [ValidateSet('Apply','Revert')][string]$Action = 'Apply',
    [string]$Tree = '',
    [switch]$DryRun,
    # convenience alias: both "-Revert" and "-Action Revert" work. (The docs shipped
    # with "-Revert" while the script only accepted "-Action Revert"; L6 of verify_p2.ps1
    # caught the mismatch -- a real user following README would have failed.)
    [switch]$Revert
)
$ErrorActionPreference = 'Stop'
if ($Revert) { $Action = 'Revert' }
$nl = [string][char]10

$P2   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
if (-not $Tree) { $Tree = Join-Path $Repo '_re\repro_src' }
if (-not (Test-Path -LiteralPath $Tree)) { throw "target tree not found: $Tree" }
$Tree = (Resolve-Path -LiteralPath $Tree).Path
$Src  = Join-Path $Tree 'OptiScaler'
if (-not (Test-Path -LiteralPath (Join-Path $Src 'OptiScaler.vcxproj'))) { throw "not an OptiScaler source tree: $Tree" }

$NewFiles = @('upscalers\latewarp\LatewarpFeature.h','upscalers\latewarp\LatewarpFeature.cpp','upscalers\latewarp\LatewarpFeature_Dx12.h','upscalers\latewarp\LatewarpFeature_Dx12.cpp','upscalers\latewarp\LatewarpParams.h','upscalers\latewarp\LatewarpParams.cpp','upscalers\latewarp\LatewarpFrameData.h','upscalers\latewarp\LatewarpFrameData.cpp','upscalers\latewarp\LatewarpIntercept.h','upscalers\latewarp\LatewarpIntercept.cpp','shaders\latewarp\LatewarpUi_Common.h','shaders\latewarp\LatewarpUi_Dx12.h','shaders\latewarp\LatewarpUi_Dx12.cpp','shaders\latewarp\LatewarpUi_Shader.h','shaders\latewarp\LatewarpUi.hlsl','shaders\latewarp\LatewarpBlueNoise32.h')
$stamp    = Get-Date -Format 'yyyyMMdd_HHmmss'
$BakDir   = Join-Path $P2 ('backup\' + $stamp)
$DiffFile = Join-Path $P2 'APPLIED_DIFF.txt'
$StateFile= Join-Path $P2 'APPLY_STATE.txt'

function Read-Text([string]$p) { [System.IO.File]::ReadAllText($p) }
function Write-Text([string]$p, [string]$t) { [System.IO.File]::WriteAllText($p, $t) }
function LineCount([string]$t) { if ($t.Length -eq 0) { return 0 }; return ([regex]::Matches($t, [string][char]10)).Count + 1 }

if ($Action -eq 'Revert') {
    if (-not (Test-Path -LiteralPath $StateFile)) { throw "no APPLY_STATE.txt -- nothing to revert" }
    $st    = Get-Content -LiteralPath $StateFile
    $bak   = ($st | Where-Object { $_ -like 'backup=*' })  -replace '^backup=', ''
    $added = ($st | Where-Object { $_ -like 'added=*' })   -replace '^added=', ''
    if ($bak -and (Test-Path -LiteralPath $bak)) {
        foreach ($f in Get-ChildItem -LiteralPath $bak -Recurse -File) {
            $rel = $f.FullName.Substring($bak.Length + 1)
            $dst = Join-Path $Src $rel
            if ($DryRun) { Write-Host ("[dry] restore " + $rel) } else { Copy-Item -LiteralPath $f.FullName -Destination $dst -Force; Write-Host ("[revert] restored " + $rel) }
        }
    }
    foreach ($a in $added) {
        if (-not $a) { continue }
        $p = Join-Path $Src $a
        if ($DryRun) { Write-Host ("[dry] delete " + $a) }
        elseif (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force; Write-Host ("[revert] deleted " + $a) }
    }
    $dir = Join-Path $Src 'upscalers\latewarp'
    if ((-not $DryRun) -and (Test-Path -LiteralPath $dir) -and (@(Get-ChildItem -LiteralPath $dir -File).Count -eq 0)) {
        Remove-Item -LiteralPath $dir -Force
        Write-Host "[revert] removed empty upscalers\latewarp"
    }
    if (-not $DryRun) { Remove-Item -LiteralPath $StateFile -Force }
    Write-Host "[revert] done"
    return
}

# --- pre-flight: the tree must be PRISTINE ---------------------------------
# A half-applied run once left a duplicated include, after which re-applying added a
# second copy. Refuse to patch a tree that already mentions latewarp.
foreach ($rel in @('OptiTypes.h','OptiTypes.cpp','upscalers\FeatureProvider_Dx12.cpp','hooks\Streamline_Hooks.cpp','menu\menu_common.cpp','OptiScaler.vcxproj')) {
    $absPre = Join-Path $Src $rel
    if (Test-Path -LiteralPath $absPre) {
        if ((Read-Text $absPre) -match '(?i)latewarp') {
            throw ("tree is not pristine: " + $rel + " already mentions latewarp -- run '-Action Revert', or point -Tree at a fresh copy")
        }
    }
}

# --- composed, anchored patching -------------------------------------------
$script:fileState    = @{}   # abs path -> current (patched) text
$script:fileOriginal = @{}   # abs path -> text as first seen (for the backup / line counts)
$script:fileRel      = @{}   # abs path -> path relative to $Src
$script:fileOrder    = @()   # first-touch order
$script:notes        = @()
$script:genAdded     = @()   # generated headers we created (revert deletes them)

function Get-Current([string]$abs, [string]$rel) {
    if (-not $script:fileState.ContainsKey($abs)) {
        # tolerate a file that does not exist yet (generated metadata): its "original" is empty
        $t = if (Test-Path -LiteralPath $abs) { Read-Text $abs } else { '' }
        $script:fileState[$abs]    = $t
        $script:fileOriginal[$abs] = $t
        $script:fileRel[$abs]      = $rel
        $script:fileOrder         += $abs
    }
    return $script:fileState[$abs]
}

function Queue-Patch([string]$rel, [string]$anchorRegex, [string]$replacement, [string]$note) {
    $abs = Join-Path $Src $rel
    if (-not (Test-Path -LiteralPath $abs)) { throw ("patch target missing: " + $rel) }
    $t = Get-Current $abs $rel
    $n = ([regex]::Matches($t, $anchorRegex)).Count
    if ($n -ne 1) { throw ("anchor for " + $rel + " matched " + $n + " times (must be 1)") }
    $new = [regex]::Replace($t, $anchorRegex, $replacement)
    if ($new -eq $t) { throw ("patch for " + $rel + " produced no change") }
    $script:fileState[$abs] = $new
    $script:notes += @{ rel = $rel; note = $note; before = (LineCount $t); after = (LineCount $new) }
}

function Queue-ReplaceLiteral([string]$rel, [string]$old, [string]$new, [string]$note) {
    $abs = Join-Path $Src $rel
    if (-not (Test-Path -LiteralPath $abs)) { throw ("patch target missing: " + $rel) }
    $t = Get-Current $abs $rel
    $n = ([regex]::Matches($t, [regex]::Escape($old))).Count
    if ($n -ne 1) { throw ("literal anchor for " + $rel + " matched " + $n + " times (must be 1)") }
    $t2 = $t.Replace($old, $new)
    if ($t2 -eq $t) { throw ("patch for " + $rel + " produced no change") }
    $script:fileState[$abs] = $t2
    $script:notes += @{ rel = $rel; note = $note; before = (LineCount $t); after = (LineCount $t2) }
}

function Queue-InsertAfter([string]$rel, [string]$anchor, [string]$insertText, [string]$note) {
    $abs = Join-Path $Src $rel
    if (-not (Test-Path -LiteralPath $abs)) { throw ("patch target missing: " + $rel) }
    $t = Get-Current $abs $rel
    $n = ([regex]::Matches($t, [regex]::Escape($anchor))).Count
    if ($n -ne 1) { throw ("anchor for " + $rel + " matched " + $n + " times (must be 1): " + $anchor) }
    $new = $t.Replace($anchor, $anchor + $nl + $insertText)
    if ($new -eq $t) { throw ("patch for " + $rel + " produced no change") }
    $script:fileState[$abs] = $new
    $script:notes += @{ rel = $rel; note = $note; before = (LineCount $t); after = (LineCount $new) }
}

# ---------------------------------------------------------------------------
# REVERTED, do not resurrect: T1 used to add "Latewarp" to enum class Upscaler and T2 used to
# add a case to FeatureProvider_Dx12::GetFeature. That is the UPSCALER path, and a live run on
# a real host answered
#     init failed with Latewarp (Reflex 2) feature
# because FeatureProvider_Dx12 expects a backend that produces an UPSCALED image, while
# latewarp does not upscale -- it reprojects. The backend now lives in the reprojection layer
# (T8-T13 below). See p2/DESIGN_B1.md.
# ---------------------------------------------------------------------------

# T6: capture Streamline's per-frame constants for latewarp (2 literal insertions)
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' '#include <hooks/Reflex_Hooks.h>' '#include <upscalers/latewarp/LatewarpFrameData.h>' 'T6a Streamline_Hooks.cpp += include for the latewarp frame data'
$t6b = 'p2::SetStreamlineViewToClip(&values.cameraViewToClip.row[0].x, (uint32_t) frame);   // P2 latewarp: cache current/previous projection' + $nl + 'p2::SetStreamlineJitter(values.jitterOffset.x, values.jitterOffset.y);   // P3-5b: TAA/DLSS jitter of the SAME frame' + $nl + ''
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' 'State::Instance().slFGInputs.setConstants(values, (uint32_t) frame);' $t6b 'T6b slSetConstants caches cameraViewToClip for latewarp'


# ---------------------------------------------------------------------------
# T8-T13 (B1): attach native latewarp to the REPROJECTION backend instead of the upscaler list.
# OptiScaler's frame generation is a pluggable layer (hooks/FG_Hooks.cpp picks XeFG / DLSSG /
# Reprojection), and Reprojection_Dx12 already collects exactly what NGX feature 15 consumes:
# FG_ResourceType::Velocity is the game's MotionVectors, plus Depth and HudlessColor.
# The switch defaults to FALSE, so behaviour is identical to an unmodified OptiScaler build
# (AC-P2-006) and the built-in reprojection shader stays the only thing that runs.
# ---------------------------------------------------------------------------
$t8anchor = '    CustomOptional<uint32_t> ReprojectionCutoffExpand { 0 };'
$t8insert = '    CustomOptional<bool> ReprojectionUseNvidiaLatewarp { false };   // P2/B1: warp with NGX feature 15 instead of the built-in shader'
Queue-InsertAfter 'Config.h' $t8anchor $t8insert 'T8 Config.h += Reprojection.UseNvidiaLatewarp (default false)'

Queue-InsertAfter 'Config.cpp' '            ReprojectionCutoffExpand.set_from_config(readUInt("Reprojection", "CutoffExpand"));' '            ReprojectionUseNvidiaLatewarp.set_from_config(readBool("Reprojection", "UseNvidiaLatewarp"));' 'T9 Config.cpp += read Reprojection.UseNvidiaLatewarp'

$t10anchor = '        ini.SetValue("Reprojection", "CutoffExpand",' + $nl + '                     GetIntValue(Instance()->ReprojectionCutoffExpand.value_for_config()).c_str());'
$t10insert = '        ini.SetValue("Reprojection", "UseNvidiaLatewarp",' + $nl + '                     GetBoolValue(Instance()->ReprojectionUseNvidiaLatewarp.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t10anchor $t10insert 'T10 Config.cpp += save Reprojection.UseNvidiaLatewarp'

$t11anchor = '            PopulateCombo("Edge fill mode", config->ReprojectionFillMode, fillModes);'
$t11insert = '            ImGui::TableNextColumn();' + $nl + '            bool useNvidiaLatewarp = config->ReprojectionUseNvidiaLatewarp.value_or_default();' + $nl + '            if (ImGui::Checkbox("Use NVIDIA latewarp (Reflex 2)", &useNvidiaLatewarp))' + $nl + '            {' + $nl + '                config->ReprojectionUseNvidiaLatewarp = useNvidiaLatewarp;' + $nl + '                p2::SetRuntimeEnabled(useNvidiaLatewarp);   // the checkbox both arms and starts' + $nl + '                LOG_DEBUG("Reprojection use NVIDIA latewarp: {}", useNvidiaLatewarp);' + $nl + '            }' + $nl + '            ImGui::TableNextColumn();' + $nl + '            bool latewarpRunning = p2::IsRuntimeEnabled();' + $nl      + $nl + '            if (ImGui::Checkbox("latewarp takeover: running", &latewarpRunning))' + $nl      + $nl + '            {' + $nl      + $nl + '                p2::SetRuntimeEnabled(latewarpRunning);' + $nl      + $nl + '                LOG_INFO("latewarp panel: takeover {}", latewarpRunning ? "STARTED" : "PAUSED");' + $nl      + $nl + '            }' + $nl      + $nl + '            ShowHelpMarker("Start/stop the takeover FROM THE PANEL (no hotkey needed). The switch above only ARMS it; the optional keybind is UNBOUND by default, because a bound key reaches the game too.");'
Queue-InsertAfter 'menu\menu_common.cpp' $t11anchor $t11insert 'T11 menu_common.cpp += the latewarp switch inside the Reprojection block'

# ---------------------------------------------------------------------------
# T22-T28: START/STOP the takeover from the OptiScaler panel, plus an OPTIONAL keybind.
# The takeover owns the presented frame, so it must be controllable without leaving the game, and
# start-up/loading screens must stay native. Controls:
#   * the existing "Use NVIDIA latewarp (Reflex 2)" checkbox ARMS it (ini switch, default false);
#   * a new "latewarp takeover: running" checkbox in the same panel row STARTS/STOPS it (runtime
#     flag, default stopped) -- this is the primary control;
#   * the keybind is OPTIONAL and ships UNBOUND: a bound key reaches the game as well, and the user
#     hit exactly that (F9 = the game's own action -> they were thrown back into a save).
# ---------------------------------------------------------------------------
$t22insert = '    CustomOptional<int> LatewarpShortcutKey { UnboundKey };   // P2: OPTIONAL hotkey, UNBOUND by default -- the panel checkbox is the primary control and an unbound key never collides with the game''s own binds'
Queue-InsertAfter 'Config.h' $t8insert $t22insert 'T22 Config.h += [Latewarp] ShortcutKey (OPTIONAL, unbound by default)'

Queue-InsertAfter 'menu\menu_common.cpp' '#include <hooks/Reflex_Hooks.h>' '#include <upscalers/latewarp/LatewarpFrameData.h>   // P2: takeover armed/started state' 'T26 menu_common.cpp += include for the runtime flag'
Queue-InsertAfter 'menu\menu_common.cpp' 'static bool inputFG = false;' 'static bool inputLatewarp = false;   // P2: in-game toggle for the latewarp takeover' 'T25a menu_common.cpp += the flag'
Queue-InsertAfter 'menu\menu_common.cpp' '    inputFG = vKey == Config::Instance()->FGShortcutKey.value_or_default();' '    inputLatewarp = vKey == Config::Instance()->LatewarpShortcutKey.value_or_default();' 'T25b menu_common.cpp: KeyUp sets it'
# T27a/b: the hotkey belongs in the OptiScaler Keybinds section, next to Menu / FPS / Frame Generation,
# so it is discoverable and rebindable from the UI instead of only via the ini.
$t27a = '        static auto latewarp = Keybind("Latewarp takeover", 14);   // P2: in-game start/stop'
Queue-InsertAfter 'menu\menu_common.cpp' '        static auto fgEnable = Keybind("Frame Generation", 13);' $t27a 'T27a menu_common.cpp: Keybind row for the latewarp hotkey'
Queue-InsertAfter 'menu\menu_common.cpp' '        fgEnable.Render(config->FGShortcutKey);' '        latewarp.Render(config->LatewarpShortcutKey);' 'T27b menu_common.cpp: render the latewarp keybind'
Queue-InsertAfter 'menu\menu_common.cpp' '        CheckShortcut(config->FGShortcutKey.value_or_default(), inputFG, "Menu key pressed, will be switching FG mode");' '        CheckShortcut(config->LatewarpShortcutKey.value_or_default(), inputLatewarp, "Menu key pressed, will be toggling the NVIDIA latewarp takeover");' 'T25c menu_common.cpp: CheckShortcut polls it'
$t25dold = '        if (inputFps)' + $nl + '        {' + $nl + '            inputFps = false;' + $nl + '            config->ShowFps = !config->ShowFps.value_or_default();' + $nl + '        }'
$t25dnew = '        if (inputLatewarp)' + $nl + '        {' + $nl + '            inputLatewarp = false;' + $nl + '            const bool latewarpOn = !p2::IsRuntimeEnabled();' + $nl + '            p2::SetRuntimeEnabled(latewarpOn);' + $nl + '            // Deliberately NOT touching ReprojectionUseNvidiaLatewarp: flipping that switch put' + $nl + '            // the broken built-in reprojection path back on screen and killed the device.' + $nl + '            LOG_INFO("latewarp hotkey: takeover {} (armed {}, built-in path stays skipped)",' + $nl + '                     latewarpOn ? "STARTED" : "PAUSED",' + $nl + '                     config->ReprojectionUseNvidiaLatewarp.value_or_default());' + $nl + '        }' + $nl + $nl + $t25dold
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t25dold $t25dnew 'T25d menu_common.cpp: consume the hotkey (toggles Reprojection.UseNvidiaLatewarp)'
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' '#include <framegen/IFGFeature_Dx12.h>' '#include <upscalers/latewarp/LatewarpFeature_Dx12.h>   // P2/B1: NGX feature 15 evaluator' 'T12a Reprojection_Dx12.h += include'
$t12binsert = '    LatewarpFeatureDx12 _latewarp;   // P2/B1: used instead of _reproject when the switch is on' + $nl + '    // Our OWN texture is the warp target -- never the swapchain resource. Its desc is modelled on' + $nl + '    // the backbuffer (CopyResource needs identical format+size); format 24 is accepted by the' + $nl + '    // kernel (offline: fwtest --outfmt r10g10b10a2 => Success), format 87 stays as the fallback.' + $nl + '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwOut;' + $nl + '    UINT _lwW = 0;' + $nl + '    UINT _lwH = 0;' + $nl + '    DXGI_FORMAT _lwFmt = DXGI_FORMAT_UNKNOWN;'
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' '    std::unique_ptr<Reproject_Dx12> _reproject;' $t12binsert 'T12b Reprojection_Dx12.h += evaluator member + the format-87 warp target'
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' '#include <upscalers/latewarp/LatewarpFeature_Dx12.h>   // P2/B1: NGX feature 15 evaluator' '#include <shaders/latewarp/LatewarpUi_Dx12.h>   // P2: 3-input UI composite (warp + UI)' 'T29a Reprojection_Dx12.h += UI composite include'
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' '    DXGI_FORMAT _lwFmt = DXGI_FORMAT_UNKNOWN;' '    std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;   // P2: re-composites the game UI over the warp' 'T29b Reprojection_Dx12.h += UI composite member'


$t13anchor = '                _reproject->Dispatch((IDXGISwapChain3*) _swapChain, commandList, params, hudless->GetResource(),' + $nl + '                                     hudless->state, depth->GetResource(), depth->state);'
$t13repl = @'
                if (Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default())
                {
                    // P2/B1: native NVIDIA latewarp (NGX feature 15) instead of the built-in
                    // reprojection shader. This layer already has every plane it needs.
                    auto velocity = GetResource(FG_ResourceType::Velocity, fIndex);

                    // The built-in shader renders into the swapchain's current backbuffer, so
                    // that is the target latewarp projects into as well.
                    ID3D12Resource* target = nullptr;
                    if (_swapChain != nullptr)
                    {
                        auto sc3 = (IDXGISwapChain3*) _swapChain;
                        if (FAILED(sc3->GetBuffer(sc3->GetCurrentBackBufferIndex(), IID_PPV_ARGS(&target))))
                            target = nullptr;
                    }

                    p2::Inputs latewarpIn {};
                    latewarpIn.outputWidth = (uint32_t) _interpolationWidth[fIndex];
                    latewarpIn.outputHeight = (uint32_t) _interpolationHeight[fIndex];
                    latewarpIn.hudlessColor = hudless->GetResource();
                    latewarpIn.backbuffer = hudless->GetResource();
                    latewarpIn.depth = depth->GetResource();
                    latewarpIn.output = target;
                    // GetResource() returns a LockedDx12Resource BY VALUE (a lock holder), so it
                    // is tested with operator bool -- not against nullptr.
                    if (velocity && velocity->GetResource() != nullptr)
                        latewarpIn.motionVectors = velocity->GetResource();

                    // The two decisive keys. p2::Fill writes them LAST on purpose.
                    latewarpIn.isRenderedFrame = 0;
                    latewarpIn.nullOutUIColorAlpha = true;

                    if (_latewarp.Init(_device, latewarpIn.outputWidth, latewarpIn.outputHeight))
                        _latewarp.Evaluate(commandList, latewarpIn);

                    if (target != nullptr)
                        target->Release();
                }
                else
                {
                    _reproject->Dispatch((IDXGISwapChain3*) _swapChain, commandList, params, hudless->GetResource(),
                                         hudless->state, depth->GetResource(), depth->state);
                }
'@
# T13 is DISABLED: its branch lived inside the built-in reprojector's readiness guard, and a live
# CP2077 run proved that guard never passes (0 "Reprojection GPU time" lines while Present() ran
# 1057 times) => our branch never got a chance. T21 below places it independently of _reproject.
# $t13anchor / $t13repl are kept only as the historical in-guard version.
# Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t13anchor $t13repl 'T13 (disabled, see T21)'
# ---------------------------------------------------------------------------
# T21 (P2, restructure): the native-latewarp branch must NOT depend on the built-in reprojector.
# A live run showed `_reproject` was never constructed (0 "Reprojection GPU time" lines) although
# Present() ran 1057 times -- the guard below never passed, so our branch never executed.
# This replaces the whole guard: one-shot diagnostics, then our branch gated only on what latewarp
# needs, then the ORIGINAL guard prefixed with "native path is off" so stock behaviour is
# untouched when the switch is false (AC-P2-006).
# ---------------------------------------------------------------------------
$t21anchor = '        if (hudless && (hudless->validity != FG_ResourceValidity::ValidNow) && depth &&' + $nl + '            (depth->validity != FG_ResourceValidity::ValidNow))'
$t21repl = @'
        // ---- P2: which input is missing? logged once (first 5 Present calls), never per frame --
        {
            static int p2diag = 0;
            if (p2diag < 5)
            {
                auto velDiag = GetResource(FG_ResourceType::Velocity, fIndex);
                LOG_INFO("latewarp-diag: active {} paused {} hudless {} depth {} velocity {} extent {}x{} switch {} "
                         "(armed; started = runtime)",
                         IsActive(), IsPaused(),
                         hudless ? (int) hudless->validity : -1,
                         depth ? (int) depth->validity : -1,
                         (velDiag && velDiag->GetResource() != nullptr),
                         (uint32_t) _interpolationWidth[fIndex], (uint32_t) _interpolationHeight[fIndex],
                         Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default(),
                         p2::IsRuntimeEnabled());
                ++p2diag;
            }
        }

        // ---- P2 branch 2: self-created latewarp (NGX feature 15), independent of _reproject ---
        if (IsActive() && !IsPaused() &&
            Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() && p2::IsRuntimeEnabled() &&
            hudless &&
            (hudless->validity != FG_ResourceValidity::ValidNow) && depth &&
            (depth->validity != FG_ResourceValidity::ValidNow))
        {
            auto velocity = GetResource(FG_ResourceType::Velocity, fIndex);
            auto latewarpList = GetSCCommandList(fIndex);

            // The blit DESTINATION is the swapchain buffer; the WARP TARGET is our own texture -- we
            // never hand the kernel the swapchain resource itself. CopyResource requires IDENTICAL
            // format and size, so the target is modelled on the backbuffer desc: a plain format-87
            // target could not be copied into a 24-format backbuffer at all (that call is invalid).
            // Format 24 is accepted by the kernel -- measured offline with the harness:
            // `fwtest --outfmt r10g10b10a2` => CreateFeature + EvaluateFeature Success. Audit item 2
            // ("87/10 only") is what the audit could prove then; the observable constraints are that
            // the plane must be OUR texture and must match the copy destination.
            ID3D12Resource* lwBack = nullptr;
            if (_swapChain != nullptr)
            {
                auto sc3 = (IDXGISwapChain3*) _swapChain;
                if (FAILED(sc3->GetBuffer(sc3->GetCurrentBackBufferIndex(), IID_PPV_ARGS(&lwBack))))
                    lwBack = nullptr;
            }

            UINT lwW = 0;
            UINT lwH = 0;
            DXGI_FORMAT lwFmt = DXGI_FORMAT_B8G8R8A8_UNORM;   // only used when there is no backbuffer
            if (lwBack != nullptr)
            {
                const auto lwBackDesc = lwBack->GetDesc();
                lwW = (UINT) lwBackDesc.Width;
                lwH = (UINT) lwBackDesc.Height;
                lwFmt = lwBackDesc.Format;
            }
            else
            {
                lwW = (UINT) (_interpolationWidth[fIndex] != 0 ? _interpolationWidth[fIndex]
                                                               : State::Instance().currentSwapchainDesc.BufferDesc.Width);
                lwH = (UINT) (_interpolationHeight[fIndex] != 0 ? _interpolationHeight[fIndex]
                                                                : State::Instance().currentSwapchainDesc.BufferDesc.Height);
            }

            if (lwW != 0 && lwH != 0 && (_lwOut == nullptr || _lwW != lwW || _lwH != lwH || _lwFmt != lwFmt))
            {
                _lwOut.Reset();
                auto lwHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
                auto lwDesc = CD3DX12_RESOURCE_DESC::Tex2D(lwFmt, lwW, lwH, 1, 1, 1, 0,
                                                           D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS |
                                                               D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET);
                HRESULT lwHr = _device->CreateCommittedResource(&lwHeap, D3D12_HEAP_FLAG_NONE, &lwDesc,
                                                                D3D12_RESOURCE_STATE_COMMON, nullptr,
                                                                IID_PPV_ARGS(&_lwOut));
                if (FAILED(lwHr) && lwFmt != DXGI_FORMAT_B8G8R8A8_UNORM)
                {
                    LOG_WARN("latewarp: output texture in format {} failed (0x{:X}); retrying with "
                             "B8G8R8A8_UNORM (the copy-back is then skipped, see below)",
                             (int) lwFmt, (unsigned) lwHr);
                    lwFmt = DXGI_FORMAT_B8G8R8A8_UNORM;
                    lwDesc = CD3DX12_RESOURCE_DESC::Tex2D(lwFmt, lwW, lwH, 1, 1, 1, 0,
                                                          D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS |
                                                              D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET);
                    lwHr = _device->CreateCommittedResource(&lwHeap, D3D12_HEAP_FLAG_NONE, &lwDesc,
                                                            D3D12_RESOURCE_STATE_COMMON, nullptr,
                                                            IID_PPV_ARGS(&_lwOut));
                }
                if (FAILED(lwHr))
                {
                    LOG_ERROR("latewarp: could not create the {}x{} output texture (format {})", lwW, lwH,
                              (int) lwFmt);
                    _lwOut.Reset();
                }
                else
                {
                    _lwW = lwW; _lwH = lwH; _lwFmt = lwFmt;
                    LOG_INFO("latewarp: warp target {}x{} format {} created (same desc as the backbuffer, "
                             "so CopyResource back is valid)", lwW, lwH, (int) lwFmt);
                }
            }

            p2::Inputs latewarpIn {};
            // The declared output extent must be the extent of the plane we actually bind -- not the
            // (possibly still zero) interpolation extent, which is what NGX validates against.
            latewarpIn.outputWidth = (uint32_t) lwW;
            latewarpIn.outputHeight = (uint32_t) lwH;
            latewarpIn.hudlessColor = hudless->GetResource();
            latewarpIn.backbuffer = hudless->GetResource();
            latewarpIn.depth = depth->GetResource();
            latewarpIn.output = _lwOut.Get();
            // Hand the kernel the NoWarpMask written by the previous composite: NON-ZERO means
            // "do not warp this pixel". Measured offline on the harness (fwtest --maskval): 0 =>
            // warp everywhere (81.09% of pixels changed), 128 and 255 => the frame comes back
            // bit-exact, i.e. non-zero excludes the pixel. This is the reflex2-native way to keep
            // the viewmodel/UI still, instead of fighting the warp afterwards in the composite.
            if (_latewarpUi != nullptr && _latewarpUi->HasMask())
            {
                latewarpIn.noWarpMask = _latewarpUi->MaskForKernel();
                latewarpIn.subrect[6][0] = 0;
                latewarpIn.subrect[6][1] = 0;
                latewarpIn.subrect[6][2] = (int32_t) lwW;
                latewarpIn.subrect[6][3] = (int32_t) lwH;
            }
            // ---- the four matrices (RE LATEWARP_DLL_EARLYOUTS) ----------------------------
            // Without them the NGX core itself says why: "NGXLatewarp::EvaluateFeature:
            // error: could not find Latewarp.WorldToViewMatrix parameter" -> 0xBAD00005, 7792
            // times in one live run. With them, the kernel also needs current != previous or it
            // early-outs into a bit-exact pass-through. Current and previous camera bases come
            // from the FG layer ring, the clip matrices from the slSetConstants cache.
            const int lwPrevIndex = (fIndex == 0) ? (BUFFER_COUNT - 1) : (fIndex - 1);
            float lwW2V[16] = {};
            float lwPW2V[16] = {};
            // BuildWorldToView refuses a degenerate basis, so bind each matrix only when its OWN
            // build succeeded: a zero-filled 16-float block bound to the key would make NGX accept
            // the parameter and then early-out silently instead of failing loudly.
            const bool lwCamCur = p2::BuildWorldToView(_cameraRight[fIndex], _cameraUp[fIndex],
                                                      _cameraForward[fIndex], _cameraPosition[fIndex], lwW2V);
            const bool lwCamPrev = p2::BuildWorldToView(_cameraRight[lwPrevIndex], _cameraUp[lwPrevIndex],
                                                       _cameraForward[lwPrevIndex], _cameraPosition[lwPrevIndex],
                                                       lwPW2V);

            const p2::FrameData lwFrame = p2::GetFrameData();
            const float* lwW2Vp = lwCamCur ? lwW2V : nullptr;
            const float* lwPW2Vp = lwCamPrev ? lwPW2V : nullptr;
            const float* lwV2Cp = lwFrame.hasCurrent ? lwFrame.viewToClip : nullptr;
            const float* lwPV2Cp = lwFrame.hasPrevious ? lwFrame.prevViewToClip : nullptr;

            // The kernel dereferences these POINTERS after this frame returns (the game rotates 5
            // matrix slots for exactly that reason), so the values must outlive the call: put them in
            // the feature's persistent ring instead of the stack arrays they were built into.
            const float* lwMat = _latewarp.MatrixRingRef().Bind(lwW2Vp, lwV2Cp, lwPW2Vp, lwPV2Cp);
            latewarpIn.worldToView     = lwW2Vp ? (lwMat +  0) : nullptr;
            latewarpIn.viewToClip      = lwV2Cp ? (lwMat + 16) : nullptr;
            latewarpIn.prevWorldToView = lwPW2Vp ? (lwMat + 32) : nullptr;
            latewarpIn.prevViewToClip  = lwPV2Cp ? (lwMat + 48) : nullptr;

            {
                static int p2matdiag = 0;
                if (p2matdiag < 5)
                {
                    LOG_INFO("latewarp-mat: w2v {} pw2v {} v2c {} pv2c {} cam {} framedata cur {} prev {} upd {}",
                             latewarpIn.worldToView != nullptr, latewarpIn.prevWorldToView != nullptr,
                             latewarpIn.viewToClip != nullptr, latewarpIn.prevViewToClip != nullptr,
                             (lwCamCur && lwCamPrev), lwFrame.hasCurrent, lwFrame.hasPrevious,
                             lwFrame.updateCount);
                    // the values themselves: row0 + the translation row are enough to tell a real
                    // camera apart from a zero/garbage matrix when reading a host log.
                    LOG_INFO("latewarp-mat row: w2v {:.4f} {:.4f} {:.4f} | {:.4f} {:.4f} {:.4f}",
                             lwW2V[0], lwW2V[1], lwW2V[2], lwW2V[12], lwW2V[13], lwW2V[14]);
                    LOG_INFO("latewarp-mat row: pw2v {:.4f} {:.4f} {:.4f} | {:.4f} {:.4f} {:.4f}",
                             lwPW2V[0], lwPW2V[1], lwPW2V[2], lwPW2V[12], lwPW2V[13], lwPW2V[14]);
                    // The plane formats decide whether the kernel accepts the planes at all, so a
                    // format rejection must be readable straight off the log (colour/depth/mv/out/back).
                    const auto lwFmtOf = [](ID3D12Resource* r) { return (r != nullptr) ? (int) r->GetDesc().Format : -1; };
                    // Is there a UI plane to composite back over the warp? Without one the takeover can
                    // only ever show the UI-less frame (the game composites UI BEFORE Present).
                    auto lwUi = GetResource(FG_ResourceType::UIColor, fIndex);
                    auto lwDist = GetResource(FG_ResourceType::Distortion, fIndex);
                    LOG_INFO("latewarp-ui: game UIColor {} distortion {}",
                             (lwUi && lwUi->GetResource() != nullptr),
                             (lwDist && lwDist->GetResource() != nullptr));
                    LOG_INFO("latewarp-fmt: colour {} depth {} mv {} out {} back {} extent {}x{}",
                             lwFmtOf(hudless->GetResource()), lwFmtOf(depth->GetResource()),
                             lwFmtOf((ID3D12Resource*) latewarpIn.motionVectors),
                             lwFmtOf((ID3D12Resource*) latewarpIn.output), lwFmtOf(lwBack),
                             lwW, lwH);
                    ++p2matdiag;
                }
            }

            // The two decisive keys; p2::Fill writes them LAST on purpose.
            latewarpIn.isRenderedFrame = 0;
            latewarpIn.nullOutUIColorAlpha = true;

            // latewarp mandatory inputs. NGX does NOT return an error when they are missing:
            // a live run proved it CRASHES inside CreateFeature(15) -- the log stopped right at
            // the feature-15-create line with 7 keys written and no planes at all. So refuse to
            // create until the planes exist, and name the missing one (first 5 frames only).
            // Route A's black-frame lesson: a pass that owns the presentation path with nothing
            // valid bound shows a BLACK screen. So the copy-back below happens ONLY when this frame
            // actually evaluated; motion vectors are OPTIONAL -- a null-MV run in the offline harness
            // evaluates fine (`fwtest --mvnull 1` => Success), and the NGX core names the parameter
            // if it ever insists on it.
            const bool planesReady = latewarpIn.depth != nullptr && latewarpIn.output != nullptr;
            if (latewarpIn.motionVectors == nullptr)
            {
                static int p2nomv = 0;
                if (p2nomv < 3)
                {
                    LOG_WARN("latewarp: no motion-vector plane this frame; evaluating WITHOUT it "
                             "(the core is the judge -- it names a missing parameter if it needs one)");
                    ++p2nomv;
                }
            }
            if (!planesReady)
            {
                static int p2wait = 0;
                if (p2wait < 5)
                {
                    LOG_WARN("latewarp: waiting for inputs (depth {} mv {} output {})",
                             latewarpIn.depth != nullptr, latewarpIn.motionVectors != nullptr,
                             latewarpIn.output != nullptr);
                    ++p2wait;
                }
            }
            bool lwEvaluated = false;
            if (planesReady && latewarpList != nullptr && _latewarp.Init(_device, latewarpList, latewarpIn))
                lwEvaluated = _latewarp.Evaluate(latewarpList, latewarpIn);

            // Blit the warped texture into the swapchain buffer: ours is COPY_SOURCE, the
            // backbuffer COPY_DEST, then both return to their normal states.
            // CopyResource demands IDENTICAL formats. The target is modelled on the backbuffer, so
            // this normally holds; the guard makes the fallback path (format 87) skip the copy
            // LOUDLY instead of issuing an invalid call.
            const DXGI_FORMAT lwBackFmt = (lwBack != nullptr) ? lwBack->GetDesc().Format : DXGI_FORMAT_UNKNOWN;
            if (lwEvaluated && _lwOut != nullptr && lwBack != nullptr && latewarpList != nullptr &&
                lwFmt == lwBackFmt)
            {
                D3D12_RESOURCE_BARRIER lwBar[2];
                lwBar[0] = CD3DX12_RESOURCE_BARRIER::Transition(_lwOut.Get(),
                                                                D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                                                                D3D12_RESOURCE_STATE_COPY_SOURCE);
                lwBar[1] = CD3DX12_RESOURCE_BARRIER::Transition(lwBack, D3D12_RESOURCE_STATE_PRESENT,
                                                                D3D12_RESOURCE_STATE_COPY_DEST);
                latewarpList->ResourceBarrier(2, lwBar);
                latewarpList->CopyResource(lwBack, _lwOut.Get());
                lwBar[0] = CD3DX12_RESOURCE_BARRIER::Transition(_lwOut.Get(),
                                                                D3D12_RESOURCE_STATE_COPY_SOURCE,
                                                                D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
                lwBar[1] = CD3DX12_RESOURCE_BARRIER::Transition(lwBack, D3D12_RESOURCE_STATE_COPY_DEST,
                                                                D3D12_RESOURCE_STATE_PRESENT);
                latewarpList->ResourceBarrier(2, lwBar);
            }

            if (lwEvaluated && _lwOut != nullptr && lwBack != nullptr && lwFmt != lwBackFmt)
            {
                static int p2nofmt = 0;
                if (p2nofmt < 3)
                {
                    LOG_WARN("latewarp: NOT copied back -- warp target format {} vs backbuffer {} "
                             "(CopyResource needs identical formats)",
                             (int) lwFmt, (int) lwBackFmt);
                    ++p2nofmt;
                }
            }

            if (lwBack != nullptr)
                lwBack->Release();
        }

        // ---- stock path: only when the native switch is OFF (identical to upstream) ----------
        if (!Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() && hudless &&
            (hudless->validity != FG_ResourceValidity::ValidNow) && depth &&
            (depth->validity != FG_ResourceValidity::ValidNow))
'@
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t21anchor $t21repl 'T21 Reprojection_Dx12.cpp: latewarp moved out of the built-in guard (+ one-shot diagnostics)'
# T28c: T21 states WHY the 2-input HudCopy composite was rejected (its diff mask degenerates when
# the `hudless` input is a warped frame), and keeps the plain copy until a 3-input pass exists.
# The inserted text: try the built-in UI-mask composite first (before the plain-copy fallback).
$t28c = '            // HudCopy was tried here and it is WRONG for this job: its mask comes from' + $nl + '            // |hudless - present|, and with a WARPED frame as `hudless` that difference is large' + $nl + '            // everywhere => uiMask = 1 => output = present, i.e. the warp became INVISIBLE (the user' + $nl + '            // reported exactly that). Keep the plain copy (visible warp, no UI) until a proper' + $nl + '            // 3-input composite exists: warped base + game frame + the SAME-FRAME UI-free frame.'  + $nl + '            // ---- P2: put the game UI back on top of the warp ------------------------------------' + $nl + '            // out = warp + (present - gameHudless) * mask, with mask = smoothstep(T, 2T, |present -' + $nl + '            // gameHudless|). `gameHudless` is the SAME frame without UI that the kernel ate, so that' + $nl + '            // difference IS the UI layer -- which is exactly what makes this valid where the 2-input' + $nl + '            // HudCopy mask degenerated (its `hudless` input is the frame it ADDS the UI to; feeding' + $nl + '            // it a warped frame made |diff| large everywhere -> mask 1 -> out = present -> invisible).' + $nl + '            bool lwComposited = false;' + $nl + '            if (lwEvaluated && _lwOut != nullptr && lwBack != nullptr && latewarpList != nullptr && _device != nullptr &&' + $nl + '                hudless->GetResource() != nullptr)' + $nl + '            {' + $nl + '                if (_latewarpUi == nullptr)' + $nl + '                    _latewarpUi = std::make_unique<LatewarpUi_Dx12>("LatewarpUi", _device);' + $nl + '' + $nl + '                // t0 = our warp, t1 = the game frame (world + UI), t2 = the same frame without UI.' + $nl + '                if (_latewarpUi != nullptr)'+ $nl + '                {'+ $nl + '                    // The panel''s existing sliders drive the SAME mask the built-in reprojection uses:'+ $nl + '                    // "Depth cutoff" (+ "Cutoff expand") keeps the static viewmodel (arms/weapon) unwarped.'+ $nl + '                    LatewarpUiDispatchParams lwUiParams {};'+ $nl + '                    lwUiParams.UiDiffThreshold = 0.01f;   // built-in: Reprojection_Dx12.cpp:498'+ $nl + '                    lwUiParams.ShowMask = State::Instance().fgHudlessCompare ? 1.0f : 0.0f;'+ $nl + '                    lwUiParams.DepthCutoff = Config::Instance()->ReprojectionDepthCutoff.value_or_default();'+ $nl + '                    lwUiParams.CutoffExpandPx = (float) Config::Instance()->ReprojectionCutoffExpand.value_or_default();'+ $nl + '                    lwUiParams.InvertedDepth = _constants.flags[FG_Flags::InvertedDepth] ? 1u : 0u;'+ $nl + '                    lwUiParams.InvScreenWidth = 1.0f / (float) lwW;'+ $nl + '                    lwUiParams.InvScreenHeight = 1.0f / (float) lwH;' + $nl + '                    lwComposited = _latewarpUi->Dispatch(latewarpList, _lwOut.Get(), hudless->GetResource(), lwBack,'+ $nl + '                                                        depth->GetResource(),' + $nl + '                                                         D3D12_RESOURCE_STATE_UNORDERED_ACCESS, hudless->state,' + $nl + '                                                         D3D12_RESOURCE_STATE_PRESENT, depth->state, lwUiParams);' + $nl + '                }'  + $nl + '' + $nl + '                if (!lwComposited)' + $nl + '                    LOG_WARN("latewarp: UI composite failed; falling back to a plain copy (no UI)");' + $nl + '            }' + $nl + ''
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' '            const DXGI_FORMAT lwBackFmt = (lwBack != nullptr) ? lwBack->GetDesc().Format : DXGI_FORMAT_UNKNOWN;' $t28c 'T28c T21: composite the UI back with OptiScaler''s own HudCopy pass'
$t28dold = '            if (lwEvaluated && _lwOut != nullptr && lwBack != nullptr && latewarpList != nullptr &&' + $nl + '                lwFmt == lwBackFmt)'
$t28dnew = '            if (lwEvaluated && !lwComposited && _lwOut != nullptr && lwBack != nullptr && latewarpList != nullptr &&' + $nl + '                lwFmt == lwBackFmt)'
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t28dold $t28dnew 'T28d T21: the plain copy is now only the fallback'
# ---------------------------------------------------------------------------
# T14-T19 (feature-layer intercept = strategy branch 1). OptiScaler implements and exports
# NVSDK_NGX_D3D12_CreateFeature/EvaluateFeature itself (inputs/NVNGX_DLSS_Dx12.cpp), so when it is
# deployed as nvngx.dll every NGX call -- from the game or from Streamline -- lands in its code,
# feature 15 included. For an app that ALREADY creates latewarp we assert the two decisive keys
# before forwarding and touch nothing else. Default FALSE => stock behaviour (AC-P2-006).
# ---------------------------------------------------------------------------
Queue-InsertAfter 'inputs\NVNGX_DLSS_Dx12.cpp' '#include "pch.h"' '#include <upscalers/latewarp/LatewarpIntercept.h>   // P2: feature-15 intercept (rewrite / probe)' 'T14 NVNGX_DLSS_Dx12.cpp += include for the intercept'

$t15anchor = '    CustomOptional<uint32_t> ReprojectionCutoffExpand { 0 };'
$t15insert = '    CustomOptional<bool> LatewarpRewrite { false };   // P2: rewrite the decisive keys of an EXISTING feature 15'
Queue-InsertAfter 'Config.h' $t15anchor $t15insert 'T15 Config.h += Latewarp.Rewrite (default false)'

Queue-InsertAfter 'Config.cpp' '            ReprojectionUseNvidiaLatewarp.set_from_config(readBool("Reprojection", "UseNvidiaLatewarp"));' '            LatewarpRewrite.set_from_config(readBool("Latewarp", "Rewrite"));' 'T16 Config.cpp += read Latewarp.Rewrite'

$t17anchor = '        ini.SetValue("Reprojection", "UseNvidiaLatewarp",' + $nl + '                     GetBoolValue(Instance()->ReprojectionUseNvidiaLatewarp.value_for_config()).c_str());'
$t17insert = '        ini.SetValue("Latewarp", "Rewrite",' + $nl + '                     GetBoolValue(Instance()->LatewarpRewrite.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t17anchor $t17insert 'T17 Config.cpp += save Latewarp.Rewrite'

Queue-InsertAfter 'Config.cpp' '            LatewarpRewrite.set_from_config(readBool("Latewarp", "Rewrite"));' '            LatewarpShortcutKey.set_from_config(readInt("Latewarp", "ShortcutKey"));' 'T23 Config.cpp += read Latewarp.ShortcutKey'

$t24anchor = '        ini.SetValue("Latewarp", "Rewrite",' + $nl + '                     GetBoolValue(Instance()->LatewarpRewrite.value_for_config()).c_str());'
$t24insert = '        ini.SetValue("Latewarp", "ShortcutKey",' + $nl + '                     GetIntValue(Instance()->LatewarpShortcutKey.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t24anchor $t24insert 'T24 Config.cpp += save Latewarp.ShortcutKey'
# ---------------------------------------------------------------------------
# T30 (P3-1): the edge / disocclusion fill. The warp is temporal, so whatever the camera motion
# pulls into the frame along the screen borders has no source content -- the kernel can only stretch
# it or leave it empty. The composite DOES hold that content (the current, unwarped game frame), so
# the outer N pixels ramp from the warp to it. This is a KNOB, not a behaviour change: the default is
# 0, which is byte-identical to the build shipped before P3-1, and one slider in the same
# reprojection block drives it. See p2/DESIGN_P3_reflex2_artifacts.md section 2/3.
# ---------------------------------------------------------------------------
# T30 (P3-1 edge fill) WITHDRAWN 2026-09-28. The user's ruling: the tear is to be fixed by
# OVER-RENDERING (raise the FOV, crop the centre -- stage P3-F), not by ramping the outer band back
# to the unwarped frame; and the kernel already repairs its own holes. What survives here is only the
# ANCHOR the diagnostic (T37) still hangs on, so the patch order stays readable.
$t30anchor = '    CustomOptional<int> LatewarpShortcutKey { UnboundKey };   // P2: OPTIONAL hotkey, UNBOUND by default -- the panel checkbox is the primary control and an unbound key never collides with the game''s own binds'

$t30canchor = '        ini.SetValue("Latewarp", "ShortcutKey",' + $nl + '                     GetIntValue(Instance()->LatewarpShortcutKey.value_for_config()).c_str());'

$t30danchor = '        float cutoff = config->ReprojectionDepthCutoff.value_or_default();' + $nl + '        if (ImGui::SliderFloat("Depth cutoff", &cutoff, 0.0f, 1.0f, "%.3f", ImGuiSliderFlags_Logarithmic))' + $nl + '            config->ReprojectionDepthCutoff = cutoff;'


# ---------------------------------------------------------------------------
# T35 (P3-3): the reprojection MATRICES the diagnostic needs. The disocclusion FILL this block used
# to feed (P3-2) was WITHDRAWN 2026-09-28: the kernel repairs its own holes, so a second
# history-based fill only fights it. What remains is the matrix build the diagnostic reprojects with:
# p2::BuildReprojectionMatrices is unit-tested, so the shader only multiplies.
# NOTE ON ANCHORING: this block is inserted after a WHOLE statement, never inside one -- inserting
# into the middle of a statement is what broke the script on 2026-09-27.
# ---------------------------------------------------------------------------

$t35elines = @(
    '                        // P3-3: the diagnostic reprojects with these two host-built matrices, so the'
    '                        // shader never inverts anything. A missing pose leaves both pointers null and the'
    '                        // shader branch simply never runs. The focal length comes from the SAME viewToClip'
    '                        // the matrices use (P3-DIR: 1.0 deg -> f*tan(1deg) px at f = 935.9).'
    '                        const float lwFocalX = (lwFrame.hasCurrent && lwFrame.viewToClip[0] != 0.0f)'
    '                                                   ? lwFrame.viewToClip[0] * 0.5f * (float) lwW : 0.0f;'
    '                        {'
    '                            float lwInvVP[16] = {};'
    '                            float lwVPP[16] = {};'
    '                            const bool lwMatOk = lwCamCur && lwCamPrev && lwFrame.hasCurrent && lwFrame.hasPrevious &&'
    '                                p2::BuildReprojectionMatrices(lwW2V, lwFrame.viewToClip, lwPW2V,'
    '                                                              lwFrame.prevViewToClip, lwInvVP, lwVPP);'
    '                            if (lwMatOk)'
    '                            {'
    '                                lwUiParams.invVPCur = lwInvVP;'
    '                                lwUiParams.vpPrev = lwVPP;'
    '                            }'
    '                        }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' '                    lwUiParams.InvScreenHeight = 1.0f / (float) lwH;' ($t35elines -join $nl) 'T35e T21: build the reprojection matrices the P3-3 diagnostic needs'
# T36 (P3-0a) WITHDRAWN 2026-09-28. It advanced the TARGET pose by `gain` frame deltas -- but that is
# PREDICTION, and Reflex 2 is not prediction: it is a LATE INPUT SAMPLE (the newest input is taken as
# late as possible and the ALREADY RENDERED frame is warped to it). Extrapolating past the game's own
# pose injects error instead of removing latency (first live run: any non-zero gain inverted the
# picture). What we may still need is the opposite pole: knowing WHEN the game sampled the camera, so
# stage P3-B can measure the pose age before anything else is built on it.

# ---------------------------------------------------------------------------
# T37 (P3-3): the DIAGNOSTIC. The first live run proved that an invisible convention error and a
# working-but-weak fill look IDENTICAL in the picture ('the yellow band never appears'). So the pass
# gets a measurement mode: it paints the reprojection OFFSET as a heat map, accumulates a 20-word
# statistics block, and the host reads it back and logs it (max shift px, how many pixels land
# outside the previous frame, how well the history matches where the maths says the content came
# from, and the depth texture's own size). Ships at 0 = off: a diagnostic must not change the
# default picture, and the readback costs a map per frame while it is on.
# NOTE ON ANCHORING: T37e is anchored on the WHOLE T35e insertion (a unique, self-contained block of
# whole statements), never on a line prefix -- inserting into the middle of a statement is what broke
# this script on 2026-09-27.
# ---------------------------------------------------------------------------
$t37a = '    CustomOptional<float> LatewarpDiagMap { 0.0f };   // P3-3: 1 = reprojection-offset heat map + per-frame stats (0 = off)'
Queue-InsertAfter 'Config.h' $t30anchor $t37a 'T37a Config.h += Latewarp.DiagMap (P3-3, default 0 = off)'

Queue-InsertAfter 'Config.cpp' '            LatewarpShortcutKey.set_from_config(readInt("Latewarp", "ShortcutKey"));' '            LatewarpDiagMap.set_from_config(readFloat("Latewarp", "DiagMap"));' 'T37b Config.cpp += read Latewarp.DiagMap'

$t37c = '        ini.SetValue("Latewarp", "DiagMap",' + $nl + '                     GetFloatValue(Instance()->LatewarpDiagMap.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t30canchor $t37c 'T37c Config.cpp += save Latewarp.DiagMap'

$t37d = '        // P3-3: the DIAGNOSTIC. 1 = LOG the numbers the P3-2 fill is based on; combine it with' + $nl + '        // "Show static elements" to also SEE the offset field as a heat map. It is a measurement mode,' + $nl + '        // not an effect: it ships at 0, and it costs one small readback per frame while it is on.' + $nl + '        float lwDiagMap = config->LatewarpDiagMap.value_or_default();' + $nl + '        if (ImGui::SliderFloat("latewarp diag offset map", &lwDiagMap, 0.0f, 1.0f, "%.0f"))' + $nl + '            config->LatewarpDiagMap = lwDiagMap;' + $nl + '        ShowHelpMarker("P3-3: logs the reprojection numbers (max shift px, pixels outside the previous frame, history mismatch, depth texture size, UI mask share) every 30 frames. The picture stays normal -- add \"Show static elements\" to also paint the offset field as a heat map. Feed the camera some motion. 0 = off.");'
Queue-InsertAfter 'menu\menu_common.cpp' $t30danchor $t37d 'T37d menu_common.cpp: the P3-3 diagnostic slider'

$t37elines = @(
    '                        // P3-3: the diagnostic. 1 = the composite paints the reprojection OFFSET as a'
    '                        // heat map and accumulates the block LatewarpUi_Dx12 reads back and logs. That'
    '                        // is the only way to tell a wrong depth / v-axis convention (which looks'
    '                        // exactly like "the fill does nothing") from a fill that is merely weak. The'
    '                        // reference is what a DISTANT centre pixel SHOULD move by: focal * tan(angle).'
    '                        {'
    '                            const float lwDiagOn = Config::Instance()->LatewarpDiagMap.value_or_default();'
    '                            float lwRefPx = 0.0f;'
    '                            if (lwDiagOn > 0.5f)'
    '                            {'
    '                                p2::PredictCentreShiftPx(_cameraForward[fIndex], _cameraForward[lwPrevIndex],'
    '                                                         lwFocalX, &lwRefPx);'
    '                                lwUiParams.DiagMap = 1.0f;'
    '                                lwUiParams.DiagRefPx = lwRefPx;'
    '                                static int p2diagon = 0;'
    '                                if (p2diagon < 5)'
    '                                {'
    '                                    LOG_INFO("latewarp-diag-on: reference {:.1f} px (focal {:.1f}); the measured numbers come from the composite", lwRefPx, lwFocalX);'
    '                                    ++p2diagon;'
    '                                }'
    '                            }'
    '                        }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' ($t35elines -join $nl) ($t37elines -join $nl) 'T37e T21: pass the P3-3 diagnostic switch + its reference shift (P3-3)'

# ---------------------------------------------------------------------------
# T38 (P3-3b): make a live run SELF-DESCRIBING. Every P3 log so far was a one-shot ('first 5 frames'),
# but the switches get moved minutes into a session -- so a run's log never showed what was actually in
# use, and the first real run's report was uninterpretable ('I can't describe what I saw'). This logs
# one line whenever the DIAGNOSTIC switch changes, with the depth predicate's inputs next to it
# (cutoff / expand / inverted), because that predicate is the prime suspect for a mask that freezes
# the wrong things. (P3-1/P3-2/P3-0a's knobs are withdrawn, so this used to watch four values.)
# ---------------------------------------------------------------------------
$t38lines = @(
    '                        // P3-3b: one line whenever the DIAGNOSTIC switch changes (the old one-shot'
    '                        // "first 5 frames" logs were useless: the switch gets moved minutes-in, so a run'
    '                        // never recorded what was actually in use). The depth PREDICATE is printed too --'
    '                        // it is the prime suspect for a mask that freezes the wrong things.'
    '                        {'
    '                            static float p2knobDiag = -1.0f;'
    '                            const float p2DiagNow = Config::Instance()->LatewarpDiagMap.value_or_default();'
    '                            if (p2DiagNow != p2knobDiag)'
    '                            {'
    '                                p2knobDiag = p2DiagNow;'
    '                                LOG_INFO("latewarp-knob: diag {:.0f} | depth cutoff {:.4f} expand {:.0f} inverted {}",'
    '                                         p2DiagNow,'
    '                                         Config::Instance()->ReprojectionDepthCutoff.value_or_default(),'
    '                                         (float) Config::Instance()->ReprojectionCutoffExpand.value_or_default(),'
    '                                         (int) lwUiParams.InvertedDepth);'
    '                            }'
    '                        }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' ($t37elines -join $nl) ($t38lines -join $nl) 'T38 T21: log every P3 knob change + the depth predicate (P3-3b)'

# ---------------------------------------------------------------------------
# T40 (P3-B): LATE-LATCH INSTRUMENTATION. Logging only -- no behaviour depends on it, and it is the
# measurement the whole late-input direction rests on: how old is the pose we warp with (camera
# sample -> present), what fraction of the present gap is that, and how much camera turn happened
# inside that window. (The game raw mouse accumulator would need a hook into its input system; the
# camera turn is the observable that already contains the same player input.)
# ---------------------------------------------------------------------------
$t40anchor = '            const p2::FrameData lwFrame = p2::GetFrameData();'
$t40lines = @(
    '            // P3-B: LATE-LATCH INSTRUMENTATION. Logging only -- nothing downstream reads these numbers.'
    '            // The question it answers is the one the whole late-input direction rests on: when we hand the'
    '            // kernel a pose, how old IS that pose (camera sample -> present), and how much camera motion'
    '            // happened inside the window it is that old for? `camera turn` is the observable that contains'
    '            // the same player input; `sampled frame` vs the FrameID says whether a NEWER sample already'
    '            // exists. Logged for the first 5 frames and then every 30th.'
    '            {'
    '                static double p2LastPresentMs = 0.0;'
    '                static int p2LateCount = 0;'
    '                const double p2NowMs = p2::NowMs();'
    '                const double p2AgeMs = p2::NewestSampleAgeMs(p2NowMs);'
    '                const double p2GapMs = (p2LastPresentMs > 0.0) ? (p2NowMs - p2LastPresentMs) : 0.0;'
    '                p2LastPresentMs = p2NowMs;'
    '                float p2TurnDeg = 0.0f;'
    '                if (lwCamCur && lwCamPrev)'
    '                    p2::ForwardAngleDeg(_cameraForward[fIndex], _cameraForward[lwPrevIndex], &p2TurnDeg);'
    '                const double p2LateFrac = (p2GapMs > 0.01 && p2AgeMs >= 0.0) ? (p2AgeMs / p2GapMs) : 0.0;'
    '                if (p2LateCount < 5 || (p2LateCount % 30) == 0)'
    '                {'
    '                    LOG_INFO("latewarp-latelatch: pose age {:.2f} ms | present gap {:.2f} ms | age/gap {:.2f} "'
    '                             "| camera turn {:.2f} deg | sampled frame {} | fps {:.1f}",'
    '                             p2AgeMs, p2GapMs, p2LateFrac, p2TurnDeg,'
    '                             lwFrame.frameIndex, (p2GapMs > 0.01) ? (1000.0 / p2GapMs) : 0.0);'
    '                    const long long p2FgId = (long long) _frameCount;'
    '                    const long long p2RfxId = (long long) State::Instance().reflexFrameId;'
    '                    const InputDelta p2SimD = InputCollection::getInstance().readSimDelta((uint32_t) p2FgId);'
    '                    const InputDelta p2SinceFg = InputCollection::getInstance().readDelta((uint32_t) p2FgId);'
    '                    const InputDelta p2SinceRfx = InputCollection::getInstance().readDelta((uint32_t) p2RfxId);'
    '                    const float p2CosPrev = _cameraForward[fIndex][0] * _cameraForward[lwPrevIndex][0] +'
    '                                           _cameraForward[fIndex][1] * _cameraForward[lwPrevIndex][1] +'
    '                                           _cameraForward[fIndex][2] * _cameraForward[lwPrevIndex][2];'
    '                    const float p2CosRight = _cameraForward[fIndex][0] * _cameraRight[lwPrevIndex][0] +'
    '                                            _cameraForward[fIndex][1] * _cameraRight[lwPrevIndex][1] +'
    '                                            _cameraForward[fIndex][2] * _cameraRight[lwPrevIndex][2];'
    '                    const float p2CosUp = _cameraForward[fIndex][0] * _cameraUp[lwPrevIndex][0] +'
    '                                         _cameraForward[fIndex][1] * _cameraUp[lwPrevIndex][1] +'
    '                                         _cameraForward[fIndex][2] * _cameraUp[lwPrevIndex][2];'
    '                    LOG_INFO("latewarp-lateinput: fgid {} rfxid {} | simD {}/{} sinceFg {}/{} sinceRfx {}/{} "'
    '                             "| cosPrev {:.6f} cosRight {:.6f} cosUp {:.6f} | turn {:.2f} deg | fps {:.1f}",'
    '                             p2FgId, p2RfxId, p2SimD.x, p2SimD.y, p2SinceFg.x, p2SinceFg.y,'
    '                             p2SinceRfx.x, p2SinceRfx.y, p2CosPrev, p2CosRight, p2CosUp, p2TurnDeg,'
    '                             (p2GapMs > 0.01) ? (1000.0 / p2GapMs) : 0.0);'
    '                }'
    '                ++p2LateCount;'
    '            }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t40anchor ($t40lines -join $nl) 'T40 T21: P3-B late-latch instrumentation (logging only)'
# ---------------------------------------------------------------------------
# T42 (P3-E): the GAME's own DLSS-G must be allowed to run -- and to be SEEN.
# With FGOutput=DLSSG + FGNvngxReplacement=None the host (the game itself, or RenoDX
# MFGUnlock) needs the REAL feature version and the REAL slDLSSGSetOptions/GetState;
# the spoofed version + dummies are exactly what hides multi-frame generation. Every
# other mode keeps today's behaviour byte for byte.
# ---------------------------------------------------------------------------
$t42gate = @(
    '    // P3-E / MFG compatibility: we hide the real DLSS-G entry points ONLY while WE',
    '    // produce the frames -- Reprojection owns the present chain, and FSR-FG / XeFG / a',
    '    // VNGX replacement own the backend. With FGOutput=NoFG the GAME (and the ReShade',
    '    // MFG-Unlock addon) owns frame generation and must get the REAL feature version and',
    '    // the REAL slDLSSGSetOptions/GetState, otherwise multi-frame generation can never be',
    '    // configured at all.',
    '    //',
    '    // FGOutput=DLSSG is deliberately NOT in this list: the 2026-09-28 run showed',
    '    // OptiScaler cannot initialise that backend in this deployment at all',
    '    // ("Can''t init StreamlineProxy, disabling FGOutput" + multi-second stalls).',
    '    const bool lwGameOwnsDlssg = (State::Instance().activeFgOutput == FGOutput::NoFG) &&',
    '                                 (State::Instance().activeFgNvngx == FGNvngxReplacement::None);',
    ''
) -join $nl

$t42verOld = @(
    '    if (feature == sl::kFeatureDLSS_G)',
    '    {',
    '        version.versionSL = { State::Instance().streamlineVersion.major, State::Instance().streamlineVersion.minor,',
    '                              State::Instance().streamlineVersion.patch };',
    '        version.versionNGX = { 4, 2, 0 };'
) -join $nl
$t42verNew = $t42gate + '    if (feature == sl::kFeatureDLSS_G && !lwGameOwnsDlssg)' + $nl + '    {' + $nl + '        version.versionSL = { State::Instance().streamlineVersion.major, State::Instance().streamlineVersion.minor,' + $nl + '                              State::Instance().streamlineVersion.patch };' + $nl + '        version.versionNGX = { 4, 2, 0 };'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t42verOld $t42verNew 'T42a Streamline_Hooks.cpp: real DLSS-G feature version when the game owns it (P3-E)'

$t42fnOld = @(
    '    if (feature == sl::kFeatureDLSS_G)',
    '    {',
    '        if (strcmp(functionName, "slDLSSGSetOptions") == 0)'
) -join $nl
$t42fnNew = $t42gate + '    if (feature == sl::kFeatureDLSS_G && !lwGameOwnsDlssg)' + $nl + '    {' + $nl + '        if (strcmp(functionName, "slDLSSGSetOptions") == 0)'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t42fnOld $t42fnNew 'T42b Streamline_Hooks.cpp: real SetOptions/GetState when the game owns DLSS-G (P3-E)'
# ---------------------------------------------------------------------------
# T43/T44 (P3-D2): the LATE-INPUT gain. A pure, offline-tested rotation is added to the
# WorldToView we hand the kernel, so it warps toward a pose NEWER than the one the game
# sampled. The gain SHIPS AT 0: with it at 0 the apply site is dead code and the matrix is
# bit-identical to the previous build. The sensitivity constants are placeholders until the
# P3-D1 calibration run (analyze_lateinput.ps1) pins them.
# ---------------------------------------------------------------------------
$t43a = '    CustomOptional<float> LatewarpLateDeltaGain { 0.0f };   // P3-D: late-input rotation gain (0 = off, bit-identical to the old build)'
Queue-InsertAfter 'Config.h' $t30anchor $t43a 'T43a Config.h += Latewarp.LateDeltaGain (P3-D, default 0 = off)'

Queue-InsertAfter 'Config.cpp' '            LatewarpDiagMap.set_from_config(readFloat("Latewarp", "DiagMap"));' '            LatewarpLateDeltaGain.set_from_config(readFloat("Latewarp", "LateDeltaGain"));' 'T43b Config.cpp += read Latewarp.LateDeltaGain'

$t43c = '        ini.SetValue("Latewarp", "LateDeltaGain",' + $nl + '                     GetFloatValue(Instance()->LatewarpLateDeltaGain.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t30canchor $t43c 'T43c Config.cpp += save Latewarp.LateDeltaGain'

$t44anchor = '            const p2::FrameData lwFrame = p2::GetFrameData();'
$t44lines = @(
    '            // P3-D: the LATE-INPUT rotation. The gain ships at 0, so by default this whole block is',
    '            // dead and the matrix handed to the kernel is bit-identical to the pre-P3-D build.',
    '            static int p2LatePoseCount = 0;',
    '            const float p2LateGain = Config::Instance()->LatewarpLateDeltaGain.value_or_default();',
    '            if (p2LateGain > 0.0f && lwCamCur)',
    '            {',
    '                // Calibration PLACEHOLDERS: deg per raw count is a GUESS until the P3-D1 run',
    '                // (analyze_lateinput.ps1) pins it. The clamp keeps a wrong sensitivity from',
    '                // overshooting: this host can never feed engine state back.',
    '                static const float kYawPerCount   = 0.0100f;',
    '                static const float kPitchPerCount = 0.0100f;',
    '                static const float kDeadZone      = 1.0f;',
    '                static const float kMaxDeg        = 1.5f;',
    '',
    '                const InputDelta p2LateD = InputCollection::getInstance().readDelta((uint32_t) _frameCount);',
    '                float p2LateYaw = 0.0f;',
    '                float p2LatePitch = 0.0f;',
    '                p2::LateInputYawPitchDeg(p2LateD.x, p2LateD.y, kYawPerCount, kPitchPerCount, kDeadZone,',
    '                                         p2LateGain, kMaxDeg, &p2LateYaw, &p2LatePitch);',
    '                p2::ApplyYawPitchToWorldToViewDeg(lwW2V, p2LateYaw, p2LatePitch);',
    '',
    '                if (p2LatePoseCount < 5 || (p2LatePoseCount % 30) == 0)',
    '                    LOG_INFO("latewarp-pose: late delta {}/{} counts -> yaw {:.3f} pitch {:.3f} deg ",'
    '                             "(gain {:.2f}, clamp {:.2f} deg)", p2LateD.x, p2LateD.y, p2LateYaw, p2LatePitch,'
    '                             p2LateGain, kMaxDeg);',
    '                ++p2LatePoseCount;',
    '            }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t44anchor ($t44lines -join $nl) 'T44 T21: P3-D late-input rotation (gain 0 = off, bit-identical)'
# ---------------------------------------------------------------------------
# T45 (MFG compatibility): with FGOutput=NoFG and no VNGX replacement, NOTHING of ours
# belongs in the DLSS-G path -- the game's own frame generation must work. Until this was
# added, the DLSS-G plugin's OWN swapchain hooks were stripped whenever FGInput==DLSSG
# (this game's default), which is exactly why the game showed 'Frame Generation: on' while
# no frame was ever generated and the ReShade MFG-Unlock addon read the state as off.
# ---------------------------------------------------------------------------
$t45helper = @(
    '// MFG compatibility: true while we stay completely out of the DLSS-G path. With'
    '// FGOutput=NoFG (and no VNGX replacement) the game -- and the ReShade MFG-Unlock addon --'
    '// own frame generation, so the plugin must load with its ORIGINAL config and the game must'
    '// see the plugin''s REAL options/state. Anything else stalls it or hides it.'
    'static bool lwHandsOffDlssg()'
    '{'
    '    return State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '           State::Instance().activeFgNvngx == FGNvngxReplacement::None;'
    '}'
    ''
) -join $nl
$t45sigOld = 'bool StreamlineHooks::hkdlssg_slOnPluginLoad(sl::param::IParameters* params, const char* loaderJSON,'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t45sigOld ($t45helper + $t45sigOld) 'T45 helper: lwHandsOffDlssg() + keep it in scope for the DLSS-G hooks'

$t45aOld = '    auto result = o_dlssg_slOnPluginLoad(params, loaderJSON, pluginJSON);'
$t45aNew = $t45aOld + $nl + '    ' + $nl + '    // MFG compatibility: hand the plugin its ORIGINAL json -- no stripped hooks, no' + $nl + '    // rewritten tags. Everything below this line exists to take DLSS-G over, which is' + $nl + '    // exactly what must NOT happen while the game owns frame generation.' + $nl + '    if (lwHandsOffDlssg())' + $nl + '        return result;'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t45aOld $t45aNew 'T45a Streamline_Hooks.cpp: do not strip the DLSS-G plugin hooks in NoFG mode (MFG compat)'

$t45bOld = @(
    'sl::Result StreamlineHooks::hkslDLSSGSetOptions(const sl::ViewportHandle& viewport, const sl::DLSSGOptions& options)'
    '{'
) -join $nl
$t45bNew = $t45bOld + $nl + '    // MFG compatibility: the game owns frame generation here, so its options are not ours to' + $nl + '    // rewrite (auto->on, dynamic overrides, Vulkan menu handling, ...).' + $nl + '    if (lwHandsOffDlssg())' + $nl + '        return o_slDLSSGSetOptions(viewport, options);'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t45bOld $t45bNew 'T45b Streamline_Hooks.cpp: pass slDLSSGSetOptions through untouched in NoFG mode'

$t45cOld = @(
    'sl::Result StreamlineHooks::hkslDLSSGGetState(const sl::ViewportHandle& viewport, sl::DLSSGState& state,'
    '                                              const sl::DLSSGOptions* options)'
    '{'
) -join $nl
$t45cNew = $t45cOld + $nl + '    // MFG compatibility: report the plugin''s REAL state -- a lying GetState was how the' + $nl + '    // host concluded frame generation was unavailable.' + $nl + '    if (lwHandsOffDlssg())' + $nl + '        return o_slDLSSGGetState(viewport, state, options);'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t45cOld $t45cNew 'T45c Streamline_Hooks.cpp: report the REAL DLSS-G state in NoFG mode'
# ---------------------------------------------------------------------------
# T47-T57 (E2c): LATEWARP DECOUPLED FROM FGOutput.
#
# The MFG working configuration is [FrameGen] FGInput=nofg + FGOutput=nofg: OptiScaler is out of the
# frame-generation business entirely and the ReShade MFG-Unlock addon owns it. In that configuration
# FGOutput != Reprojection, FGHooks::CreateSwapChain* refuses to create an FG swapchain, and the
# latewarp -- which lived on Reprojection_Dx12 -- never ran at all. E2c moves the SAME pass onto the
# real present chain:
#   T47/T48  Reprojection_Dx12::AdoptExistingSwapchain(queue, swapchain, hwnd): those three members
#            are otherwise written ONLY inside CreateSwapchain*(), i.e. only when WE made the
#            swapchain. Adopting the game's is what makes 'no FG swapchain' possible.
#   T49-T51  WrappedIDXGISwapChain4::LocalPresent -- the present path NoFG mode actually uses --
#            lazily bootstraps the feature once and then drives Present() every frame.
#   T52-T56  the hudless/depth/MV tag pump is keyed on FGInput::DLSSG while FGInput is nofg here.
#            Measured in the 2026-09-28 log: the game calls slSetTag (13 hits) and our
#            'Reporting SL resource type' line NEVER appears. Without these the pass starves.
#   T57      the presenter is dropped together with the swapchain it adopted, so a re-created
#            swapchain cannot leave the pass pointing at released backbuffers.
# Arming stays the existing [Reprojection] UseNvidiaLatewarp -- no new ini key. The runtime
# START/STOP switch (the Chinese quick panel) still gates the work inside Present().
# ---------------------------------------------------------------------------
$t47anchor = '    bool ReleaseSwapchain(HWND hwnd) override final;'
@(
    '    // P2/E2c: bind this pass to the swapchain the GAME already owns. The three members it fills'
    '    // are otherwise written only by CreateSwapchain*(). With FGOutput=NoFG no FG swapchain'
    '    // exists at all, and adopting the game''s is what lets the latewarp pass run anyway.'
    '    void AdoptExistingSwapchain(ID3D12CommandQueue* queue, IDXGISwapChain* swapChain, HWND hwnd);'
) -join $nl | Set-Variable -Name t47lines
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' $t47anchor ($t47lines -join $nl) 'T47 (E2c) Reprojection_Dx12.h += AdoptExistingSwapchain'

$t48anchor = 'bool Reprojection_Dx12::ReleaseSwapchain(HWND hwnd)'
@(
    '// P2/E2c: adopt the swapchain the game already owns instead of creating an FG one.'
    '// CreateSwapchain*() was the ONLY place that filled _gameCommandQueue/_swapChain/_hwnd, which is'
    '// why the latewarp could only ever run while OptiScaler owned the frame-generation backend.'
    'void Reprojection_Dx12::AdoptExistingSwapchain(ID3D12CommandQueue* queue, IDXGISwapChain* swapChain, HWND hwnd)'
    '{'
    '    _gameCommandQueue = queue;'
    '    _swapChain = swapChain;'
    '    _hwnd = hwnd;'
    ''
    '    LOG_INFO("latewarp-e2c: adopted the game swapchain {:X} (queue {:X}, hwnd {:X}), no FG swapchain",'
    '             (size_t) swapChain, (size_t) queue, (size_t) hwnd);'
    '}'
    ''
    ''
) -join $nl | Set-Variable -Name t48lines
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t48anchor (($t48lines -join $nl) + $t48anchor) 'T48 (E2c) Reprojection_Dx12.cpp += AdoptExistingSwapchain (no FG swapchain)'

Queue-InsertAfter 'wrapped\wrapped_swapchain.cpp' '#include <hooks/Reflex_Hooks.h>' '#include <framegen/reprojection/Reprojection_Dx12.h>   // P2/E2c: the latewarp-only presenter' 'T49 (E2c) wrapped_swapchain.cpp += include for the latewarp-only presenter'

$t50aAnchor = 'static HRESULT LocalPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags,'
@(
    '// P2/E2c: the latewarp-only configuration -- OptiScaler stays completely out of frame generation'
    '// ([FrameGen] FGOutput=nofg, the ReShade MFG-Unlock addon owns it) while the native latewarp still'
    '// runs as its own pass on the real present chain. [Reprojection] UseNvidiaLatewarp is the arming'
    '// switch; the runtime START/STOP switch inside the pass is unchanged.'
    'static bool lwLatewarpOnly()'
    '{'
    '    return State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '           Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();'
    '}'
    ''
) -join $nl | Set-Variable -Name t50aHelper
Queue-ReplaceLiteral 'wrapped\wrapped_swapchain.cpp' $t50aAnchor (($t50aHelper -join $nl) + $t50aAnchor) 'T50a (E2c) wrapped_swapchain.cpp += lwLatewarpOnly() helper'

$t50bOld = @(
    '    auto fg = State::Instance().currentFG;'
    '    if (willPresent && fg != nullptr)'
    '        ReflexHooks::update(fg->IsActive(), false);'
) -join $nl
$t50bNew = @(
    '    // P2/E2c: LATEWARP WITHOUT AN FG SWAPCHAIN. Until this existed the pass ran only when'
    '    // OptiScaler owned the frame-generation backend (FGOutput=Reprojection), so the one'
    '    // configuration that makes multi-frame generation work had no latewarp at all. The pass'
    '    // itself is unchanged -- it is bootstrapped lazily here, on the present path NoFG mode'
    '    // actually uses, and it ADOPTS the game swapchain instead of creating one.'
    '    if (willPresent && lwLatewarpOnly() && State::Instance().currentFG == nullptr &&'
    '        State::Instance().currentD3D12Device != nullptr && cq != nullptr && pSwapChain != nullptr)'
    '    {'
    '        auto* lw = new Reprojection_Dx12();'
    '        FG_Constants lwConsts {};'
    '        lw->CreateContext(State::Instance().currentD3D12Device, lwConsts);'
    '        lw->AdoptExistingSwapchain(cq, pSwapChain, hWnd);'
    '        State::Instance().currentFG = lw;'
    '        lw->Activate();'
    ''
    '        LOG_INFO("latewarp-e2c: presenter bootstrapped on the present chain (FGOutput=NoFG): "'
    '                 "device {:X}, queue {:X}, swapchain {:X}, hwnd {:X}",'
    '                 (size_t) State::Instance().currentD3D12Device, (size_t) cq, (size_t) pSwapChain,'
    '                 (size_t) hWnd);'
    '    }'
    ''
    '    auto fg = State::Instance().currentFG;'
    '    if (willPresent && fg != nullptr)'
    '        ReflexHooks::update(fg->IsActive(), false);'
) -join $nl
Queue-ReplaceLiteral 'wrapped\wrapped_swapchain.cpp' ($t50bOld -join $nl) ($t50bNew -join $nl) 'T50b (E2c) wrapped_swapchain.cpp: lazy bootstrap of the latewarp-only presenter'

$t51Old = @(
    '    if (willPresent)'
    '    {'
    '        // Tick feature to let it know if it is frozen'
) -join $nl
$t51Old = $t51Old.Replace('it is frozen', 'it''s frozen')
$t51New = @(
    '    // P2/E2c: drive the latewarp-only pass BEFORE the overlay and the real present, exactly where'
    '    // the FG-owned path called it (before o_FGSCPresent). The pass writes its result into the'
    '    // current backbuffer; the present itself stays with the game swapchain.'
    '    if (willPresent && fg != nullptr && fg->IsActive() && !fg->IsPaused() &&'
    '        State::Instance().activeFgOutput == FGOutput::NoFG)'
    '        fg->Present();'
    ''
    '    if (willPresent)'
    '    {'
    '        // Tick feature to let it know if it''s frozen'
) -join $nl
Queue-ReplaceLiteral 'wrapped\wrapped_swapchain.cpp' ($t51Old -join $nl) ($t51New -join $nl) 'T51 (E2c) wrapped_swapchain.cpp: drive Present() on the real present chain'

$t52Anchor = '    return state.streamlineVersion.major == 1 && state.activeFgInput == FGInput::DLSSG;' + $nl + '}'
@(
    '// P2/E2c: true while OUR latewarp runs as a present-chain pass without OptiScaler owning frame'
    '// generation. The tag pump below is keyed on FGInput::DLSSG and the working MFG configuration is'
    '// FGInput=nofg -- measured on 2026-09-28: the game does call slSetTag while our'
    '// Reporting SL resource type line never appears, i.e. the pass would starve for hudless/depth.'
    'static bool lwLatewarpOnlyTags()'
    '{'
    '    return State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '           State::Instance().currentFG != nullptr &&'
    '           Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();'
    '}'
    ''
) -join $nl | Set-Variable -Name t52Helper
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t52Anchor ($t52Anchor + $nl + ($t52Helper -join $nl)) 'T52 (E2c) Streamline_Hooks.cpp += lwLatewarpOnlyTags() helper'

$t53Old = @(
    '        if (State::Instance().activeFgInput == FGInput::DLSSG &&'
    '            (tags[i].type == sl::kBufferTypeHUDLessColor || tags[i].type == sl::kBufferTypeDepth ||'
) -join $nl
$t53New = @(
    '        if ((State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpOnlyTags()) &&'
    '            (tags[i].type == sl::kBufferTypeHUDLessColor || tags[i].type == sl::kBufferTypeDepth ||'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' ($t53Old -join $nl) ($t53New -join $nl) 'T53 (E2c) Streamline_Hooks.cpp: pump tags for the latewarp-only pass (slSetTag)'

$t54Old = @(
    '        if (State::Instance().activeFgInput == FGInput::DLSSG &&'
    '            (resources[i].type == sl::kBufferTypeHUDLessColor || resources[i].type == sl::kBufferTypeDepth ||'
) -join $nl
$t54New = @(
    '        if ((State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpOnlyTags()) &&'
    '            (resources[i].type == sl::kBufferTypeHUDLessColor || resources[i].type == sl::kBufferTypeDepth ||'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' ($t54Old -join $nl) ($t54New -join $nl) 'T54 (E2c) Streamline_Hooks.cpp: pump tags for the latewarp-only pass (slSetTagForFrame)'

$t55Old = '    if (State::Instance().activeFgInput == FGInput::DLSSG && numInputs > 0 && inputs != nullptr)'
$t55New = '    if ((State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpOnlyTags()) && numInputs > 0 && inputs != nullptr)'
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t55Old $t55New 'T55 (E2c) Streamline_Hooks.cpp: pump tags for the latewarp-only pass (slEvaluateFeature)'

$t56Old = @(
    '    if (State::Instance().activeFgInput == FGInput::DLSSG)'
    '    {'
    '        if (State::Instance().streamlineVersion.major == 1)'
) -join $nl
$t56New = @(
    '    if (State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpOnlyTags())'
    '    {'
    '        if (State::Instance().streamlineVersion.major == 1)'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' ($t56Old -join $nl) ($t56New -join $nl) 'T56 (E2c) Streamline_Hooks.cpp: markPresent/evaluateState for the latewarp-only pass'

$t57Old = @(
    '        auto fg = State::Instance().currentFG;'
    '        if (fg != nullptr && fg->Mutex.getOwner() != 1 && fg->SwapchainContext() != nullptr)'
) -join $nl
$t57New = @(
    '        // P2/E2c: the latewarp-only presenter ADOPTED this swapchain (its SwapchainContext() is'
    '        // null and no FG swapchain is registered), so nothing else would ever drop it. Without'
    '        // this, a re-created swapchain would leave the pass pointing at released backbuffers.'
    '        // The condition is the MODE, not the arming flag: in NoFG mode nothing else can have'
    '        // created a currentFG (CheckForFGStatus refuses to), so anything here is ours.'
    '        if (auto* lwFg = State::Instance().currentFG;'
    '            lwFg != nullptr && State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '                lwFg->SwapchainContext() == nullptr)'
    '        {'
    '            State::Instance().currentFG = nullptr;'
    '            lwFg->Deactivate();'
    '            lwFg->DestroyFGContext();'
    '            delete lwFg;'
    ''
    '            LOG_INFO("latewarp-e2c: presenter released with the swapchain");'
    '        }'
    ''
    '        auto fg = State::Instance().currentFG;'
    '        if (fg != nullptr && fg->Mutex.getOwner() != 1 && fg->SwapchainContext() != nullptr)'
) -join $nl
Queue-ReplaceLiteral 'wrapped\wrapped_swapchain.cpp' ($t57Old -join $nl) ($t57New -join $nl) 'T57 (E2c) wrapped_swapchain.cpp: drop the presenter with the swapchain it adopted'
# ---------------------------------------------------------------------------
# T58-T60 (E2c, 第二轮): THE HOOKS THEMSELVES. The 23:53 live run showed the bootstrap working
# ('latewarp-e2c: presenter bootstrapped' + 'adopted the game swapchain') and then NOTHING:
# zero 'CheckForFrame', zero 'Reporting SL resource type', zero 'latewarp: eval', zero
# 'latewarp-diag'. Cause: slSetTag / slSetTagForFrame / slSetConstants are only detoured when
# activeFgInput is NvngxFG or DLSSG (Streamline_Hooks.cpp:1944), and slPCLSetMarker is only
# rerouted when the FixSlSimulationMarkers quirk is set or FGInput is DLSSG (:1671). The MFG
# working configuration is FGInput=nofg, so none of them were ever installed: no camera constants
# (no p2::SetStreamlineViewToClip), no hudless/depth, no frame count advance -- the pass sat in
# its 10-frame warm-up pause forever. T52-T56 widened the CALL SITES, these widen the INSTALL.
# ---------------------------------------------------------------------------
$t58Anchor = '           State::Instance().currentFG != nullptr &&' + $nl + '           Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();' + $nl + '}'
@(
    '// P2/E2c: the same configuration, evaluated at HOOK TIME. hookInterposer() runs while the'
    '// swapchain is being created, i.e. BEFORE the lazy bootstrap in LocalPresent has created the'
    '// presenter, so this variant must NOT test currentFG: it only decides whether the slSetTag /'
    '// slSetTagForFrame / slSetConstants hooks are installed at all.'
    'static bool lwLatewarpPlanned()'
    '{'
    '    return State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '           Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();'
    '}'
    ''
) -join $nl | Set-Variable -Name t58Helper
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t58Anchor ($t58Anchor + $nl + ($t58Helper -join $nl)) 'T58 (E2c) Streamline_Hooks.cpp += lwLatewarpPlanned() (hook-time predicate)'

$t59Old = @(
    '                if (State::Instance().activeFgInput == FGInput::NvngxFG ||'
    '                    State::Instance().activeFgInput == FGInput::DLSSG)'
    '                {'
    '                    if (o_slSetTag != nullptr)'
) -join $nl
$t59New = @(
    '                // P2/E2c: in the MFG working configuration (FGInput=nofg) nothing else installs'
    '                // these, and without them the latewarp-only presenter gets no camera constants'
    '                // and no hudless/depth tags at all (measured on 2026-09-28 23:53: bootstrap OK,'
    '                // then zero CheckForFrame and zero Reporting SL resource lines).'
    '                if (State::Instance().activeFgInput == FGInput::NvngxFG ||'
    '                    State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpPlanned())'
    '                {'
    '                    if (o_slSetTag != nullptr)'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' ($t59Old -join $nl) ($t59New -join $nl) 'T59 (E2c) Streamline_Hooks.cpp: install slSetTag/slSetTagForFrame/slSetConstants hooks in NoFG latewarp mode'

$t60Old = @(
    '    if (strcmp(functionName, "slPCLSetMarker") == 0 &&'
    '        (State::Instance().gameQuirks & GameQuirk::FixSlSimulationMarkers ||'
    '         State::Instance().activeFgInput == FGInput::DLSSG))'
) -join $nl
$t60New = @(
    '    // P2/E2c: the latewarp-only presenter needs slPCLSetMarker too -- markPresent() is what'
    '    // hands the game Streamline frame id to the pass (and clears the warm-up pause).'
    '    if (strcmp(functionName, "slPCLSetMarker") == 0 &&'
    '        (State::Instance().gameQuirks & GameQuirk::FixSlSimulationMarkers ||'
    '         State::Instance().activeFgInput == FGInput::DLSSG || lwLatewarpPlanned()))'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' ($t60Old -join $nl) ($t60New -join $nl) 'T60 (E2c) Streamline_Hooks.cpp: route slPCLSetMarker through our hook in NoFG latewarp mode'

# ---------------------------------------------------------------------------
# T61-T62 (E2c2): the 2026-09-29 13:12 live run. The pass finally RAN (latewarp: eval #1-#4,
# 'Reporting SL resource type' 3798x, 60 fps) and then WEDGED THE QUEUE: DLSS-G's CPU pacer
# reported 'waitCPUFence timed out after 500ms' every 500 ms until the picture froze. No Device
# removed, no error -- a stuck queue, and the cause is this pass being driven on EVERY present:
#   * MFG presents one rendered frame 3-4 times, while _frameCount (and therefore GetIndex()) only
#     advances once per RENDERED frame, so all 3-4 runs used the SAME _scCommandAllocator slot;
#   * Reprojection_Dx12::Present closes + ExecuteCommandLists that slot and the next run Reset()s
#     its allocator with NO fence in between (the UI path has WaitForUIAllocator, the SC path had
#     nothing) -- i.e. an allocator reset while it was still executing.
# T61 == one run per rendered frame (exactly the P3-E 'once per rendered frame' semantics).
# T62 == the missing SC fence, so a slot is never recycled before its own submission completed.
# ---------------------------------------------------------------------------
$t61aAnchor = '    void AdoptExistingSwapchain(ID3D12CommandQueue* queue, IDXGISwapChain* swapChain, HWND hwnd);'
@(
    '    // P2/E2c2: this pass runs ONCE per RENDERED frame -- MFG presents the same rendered frame 3-4'
    '    // times, and driving the pass on every present reused one command-allocator slot per frame.'
    '    UINT64 _lastWarpFrameCount = ~0ull;'
    '    // P2/E2c2: waits for this slot''s own submission before the base class resets its allocator.'
    '    bool WaitForSCAllocator(int index);'
) -join $nl | Set-Variable -Name t61a
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' $t61aAnchor ($t61a -join $nl) 'T61a (E2c2) Reprojection_Dx12.h += once-per-rendered-frame guard + SC allocator wait'

$t61bAnchor = 'bool Reprojection_Dx12::ReleaseSwapchain(HWND hwnd)'
@(
    '// P2/E2c2: never reset a command allocator whose command list may still be executing. In the MFG'
    '// configuration this pass is driven on the present chain, several times per rendered frame, and'
    '// the 2026-09-29 13:12 run wedged the game queue exactly there (DLSS-G pacer waitCPUFence'
    '// timeouts, then a frozen picture, with no Device removed). Mirrors WaitForUIAllocator.'
    'bool Reprojection_Dx12::WaitForSCAllocator(int index)'
    '{'
    '    if (index < 0 || index >= BUFFER_COUNT)'
    '        return true;'

    '    if (_scFence == nullptr || _scFenceEvent == nullptr)'
    '        return true;'

    '    const auto fenceValue = _scAllocatorFenceValues[index];'
    '    if (fenceValue == 0 || _scFence->GetCompletedValue() >= fenceValue)'
    '        return true;'

    '    if (FAILED(_scFence->SetEventOnCompletion(fenceValue, _scFenceEvent)))'
    '        return false;'

    '    if (WaitForSingleObject(_scFenceEvent, 5000) != WAIT_OBJECT_0)'
    '    {'
    '        LOG_ERROR("latewarp-e2c: SC allocator fence wait failed on slot {} (fence {}, completed {})", index,'
    '                  fenceValue, _scFence->GetCompletedValue());'
    '        return false;'
    '    }'

    '    return true;'
    '}'
    ''
) -join $nl | Set-Variable -Name t61b
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t61bAnchor (($t61b -join $nl) + $t61bAnchor) 'T61b (E2c2) Reprojection_Dx12.cpp += WaitForSCAllocator (SC path fence)'

$t61cAnchor = 'bool Reprojection_Dx12::Present()' + $nl + '{'
@(
    '    // P2/E2c2: ONE RUN PER RENDERED FRAME. Multi-frame generation presents the same rendered frame'
    '    // 3-4 times, and everything below is written for one run per rendered frame: GetIndex() is'
    '    // _frameCount % 4 and _frameCount only advances on a rendered frame, so driving the pass on'
    '    // every present re-used ONE command-allocator slot per frame and reset it while its command'
    '    // list was still executing -- that wedged the game queue in the 2026-09-29 13:12 run.'
    '    if (_frameCount == _lastWarpFrameCount)'
    '        return false;'

    '    _lastWarpFrameCount = _frameCount;'
) -join $nl | Set-Variable -Name t61c
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t61cAnchor ($t61cAnchor + $nl + ($t61c -join $nl)) 'T61c (E2c2) Reprojection_Dx12.cpp: Present() runs once per rendered frame'

$t62aAnchor = '            auto latewarpList = GetSCCommandList(fIndex);'
$t62aNew = '            // P2/E2c2: the base class resets this slot allocator inside GetSCCommandList, so the' + $nl + '            // wait has to happen BEFORE the call, not after.' + $nl + '            WaitForSCAllocator(fIndex);' + $nl + $t62aAnchor
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t62aAnchor $t62aNew 'T62a (E2c2) Reprojection_Dx12.cpp: wait for the SC slot fence before reusing it'

# NOTE: the blank lines inside these arrays MUST be '' elements -- a bare empty line contributes
# nothing to the array, so the joined literal would be missing it and the anchor would never match
# (that is exactly how T62b failed its first DryRun).
$t62bOld = @(
    '        if (_scCommandList[fIndex]->Close() == S_OK)'
    '            _gameCommandQueue->ExecuteCommandLists(1, (ID3D12CommandList**) &_scCommandList[fIndex]);'
    ''
    '        _scCommandListResetted[fIndex] = false;'
    '    }'
) -join $nl
$t62bNew = @(
    '        if (_scCommandList[fIndex]->Close() == S_OK)'
    '            _gameCommandQueue->ExecuteCommandLists(1, (ID3D12CommandList**) &_scCommandList[fIndex]);'
    ''
    '        // P2/E2c2: publish a fence for this slot so its NEXT use can wait for the GPU instead of'
    '        // resetting an allocator that is still in flight (the 2026-09-29 13:12 queue wedge).'
    '        static UINT64 lwScFenceValue = 0;'
    '        _scAllocatorFenceValues[fIndex] = ++lwScFenceValue;'
    '        _gameCommandQueue->Signal(_scFence, _scAllocatorFenceValues[fIndex]);'
    ''
    '        _scCommandListResetted[fIndex] = false;'
    '    }'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t62bOld $t62bNew 'T62b (E2c2) Reprojection_Dx12.cpp: signal the SC fence after each submission'

# ---------------------------------------------------------------------------
# T64 (E2c3): make the WARP SIZE observable. 'I see no effect' is not a measurement, and the matrix
# rows only print for the first 5 frames (which are usually a still menu). This prints, every 30th
# frame, the shift the kernel is actually being handed -- focal * tan(angle between the previous and
# the current camera forward), i.e. the same reference the P3-3 diagnostic uses. A sub-pixel value
# means the kernel was asked to do nothing and NO panel setting can change that.
# ---------------------------------------------------------------------------
$t64Anchor = '                    const long long p2FgId = (long long) _frameCount;'
@(
    '                    // P2/E2c3: HOW BIG IS THE WARP? focal * tan(prev -> cur camera angle).'
    '                    float p2PredPx = 0.0f;'
    '                    const float p2PredFocal = (lwFrame.hasCurrent && lwFrame.viewToClip[0] != 0.0f)'
    '                                                  ? lwFrame.viewToClip[0] * 0.5f * (float) lwW'
    '                                                  : 0.0f;'
    '                    if (lwCamCur && lwCamPrev && p2PredFocal > 0.0f &&'
    '                        p2::PredictCentreShiftPx(_cameraForward[fIndex], _cameraForward[lwPrevIndex],'
    '                                                 p2PredFocal, &p2PredPx))'
    '                        LOG_INFO("latewarp-pose-delta: kernel handed {:.2f} px (focal {:.1f} px, extent {}x{})",'
    '                                 p2PredPx, p2PredFocal, (uint32_t) lwW, (uint32_t) lwH);'
) -join $nl | Set-Variable -Name t64Lines
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t64Anchor ($t64Lines -join $nl) 'T64 (E2c3) Reprojection_Dx12.cpp: log the pixel size of the warp the kernel is handed'

# ---------------------------------------------------------------------------
# T69 (E2c8): the TILE CORRUPTION. `_lwOut` (the kernel output) and the composite's `_buffer` are
# single SHARED resources while the command ring has four in-flight slots, and T62 only fences the
# allocator of the slot being recorded -- so frame N+1 can write `_lwOut` while frame N's composite
# is still reading it, which is exactly the 16-32 px tile mess reported on 2026-09-29. Draining every
# slot before the warp serialises them. (The other suspect -- the NGX kernel completing its own work
# asynchronously -- is a separate step; this one is decidable from the code alone.)
# ---------------------------------------------------------------------------
$t69Anchor = '            bool lwEvaluated = false;'
@(
    '            // P2/E2c8 (TILE CORRUPTION): _lwOut and the composite _buffer are SHARED by all four'
    '            // in-flight slots, so the per-slot allocator fence is NOT enough -- frame N+1 could'
    '            // start writing _lwOut while frame N composite was still reading it. Drain every slot'
    '            // before touching either resource. It costs some overlap; this pass runs once per frame.'
    '            for (int lwSlot = 0; lwSlot < BUFFER_COUNT; ++lwSlot)'
    '                WaitForSCAllocator(lwSlot);'
    ''
) -join $nl | Set-Variable -Name t69
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t69Anchor ($t69 -join $nl) 'T69 (E2c8) Reprojection_Dx12.cpp: drain every slot before the warp touches the shared _lwOut/_buffer'

# ---------------------------------------------------------------------------
# T65-T66 (E2c4): THE MASK BECOMES A SLIDER, AND WE MEASURE WHAT THE MASK COMPARES.
#
# The 18:11 measurement run showed the mechanism exactly: the kernel was handed 1175-1471 px of warp
# (its own 'reference' equalled our new pose-delta line for line) and the composite then threw it away:
#     mask 95.35% / 99.11% / 99.14% / 99.58%   (cutout 0.00%)   diff 0.18-0.31
# The shader is  uiMask = smoothstep(UiDiffThreshold, 2*UiDiffThreshold, |present - hudless|)  with
# UiDiffThreshold HARD-CODED at 0.01 while the measured difference is 0.18-0.31: smoothstep saturates
# to 1.0 on every pixel, the blue-noise dither keeps it, and out = lerp(warped, present, 1) is
# literally the untouched game frame. The threshold is now an ini key and a LIVE panel slider (the
# shader reads it per frame), default = the old constant, so nothing changes until it is moved.
# T66 logs whether hudless and the backbuffer really are the same frame -- the colour-diff branch
# only means 'UI' if they are a same-frame pair.
# ---------------------------------------------------------------------------
$t65aAnchor = '    CustomOptional<float> LatewarpLateDeltaGain { 0.0f };   // P3-D: late-input rotation gain (0 = off, bit-identical to the old build)'
# ---------------------------------------------------------------------------
# T68 (E2c6): THE WARP-STRENGTH SLIDER. `color = lerp(warped, present, uiMask)` is a HARD swap: at
# uiMask = 0 the entire screen -- world included -- becomes the kernel's re-projection of the previous
# hudless, so the world shakes as soon as MFG interpolates it (measured 2026-09-29 18:47; the UI stays
# crisp because it is pasted back from `present`). The composite is now
# `lerp(present, warped, WarpStrength * (1 - uiMask))`: 1.0 = the old behaviour bit for bit, 0 = none,
# 0.2-0.4 nudges the world instead of replacing it. The field sits in TailReg's padding at cbuffer
# offset 4268 (pinned by a static_assert next to the other offsets), so nothing else moves.
# ---------------------------------------------------------------------------
Queue-InsertAfter 'Config.h' $t65aAnchor '    CustomOptional<float> LatewarpMaskThreshold { 0.01f };   // P3-E2c4: UI-mask diff threshold (0 = warp EVERYTHING, 0.01 = the old hard constant, higher = fewer pixels frozen)' 'T65a Config.h += Latewarp.MaskThreshold'
Queue-InsertAfter 'Config.h' '    CustomOptional<float> LatewarpMaskThreshold { 0.01f };   // P3-E2c4: UI-mask diff threshold (0 = warp EVERYTHING, 0.01 = the old hard constant, higher = fewer pixels frozen)' '    CustomOptional<float> LatewarpWarpStrength { 1.0f };   // P3-E2c6: how much of the warp the composite applies (1 = the old hard swap, 0 = none)' 'T68a Config.h += Latewarp.WarpStrength'

Queue-InsertAfter 'Config.cpp' '            LatewarpLateDeltaGain.set_from_config(readFloat("Latewarp", "LateDeltaGain"));' '            LatewarpMaskThreshold.set_from_config(readFloat("Latewarp", "MaskThreshold"));' 'T65b Config.cpp += read Latewarp.MaskThreshold'
Queue-InsertAfter 'Config.cpp' '            LatewarpMaskThreshold.set_from_config(readFloat("Latewarp", "MaskThreshold"));' '            LatewarpWarpStrength.set_from_config(readFloat("Latewarp", "WarpStrength"));' 'T68b Config.cpp += read Latewarp.WarpStrength'

$t65cAnchor = '                     GetFloatValue(Instance()->LatewarpLateDeltaGain.value_for_config()).c_str());'
Queue-InsertAfter 'Config.cpp' $t65cAnchor ('        ini.SetValue("Latewarp", "MaskThreshold",' + $nl + '                     GetFloatValue(Instance()->LatewarpMaskThreshold.value_for_config()).c_str());') 'T65c Config.cpp += save Latewarp.MaskThreshold'
Queue-InsertAfter 'Config.cpp' '                     GetFloatValue(Instance()->LatewarpMaskThreshold.value_for_config()).c_str());' ('        ini.SetValue("Latewarp", "WarpStrength",' + $nl + '                     GetFloatValue(Instance()->LatewarpWarpStrength.value_for_config()).c_str());') 'T68c Config.cpp += save Latewarp.WarpStrength'

$t65dOld = '                    lwUiParams.UiDiffThreshold = 0.01f;   // built-in: Reprojection_Dx12.cpp:498'
$t65dNew = @(
    '                    // P2/E2c4: the UI-mask threshold is a LIVE SLIDER now. The 18:11 run measured'
    '                    // |present - hudless| = 0.18-0.31 while this was the hard constant 0.01, so'
    '                    // smoothstep() saturated to 1 on every pixel and the mask threw the whole warp'
    '                    // away. Default == the old constant: nothing changes until the slider moves.'
    '                    lwUiParams.UiDiffThreshold = Config::Instance()->LatewarpMaskThreshold.value_or_default();'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t65dOld $t65dNew 'T65d Reprojection_Dx12.cpp: the UI-mask threshold comes from the ini/slider'
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' '                    lwUiParams.UiDiffThreshold = Config::Instance()->LatewarpMaskThreshold.value_or_default();' ('                    // P2/E2c6: how much of the warp is applied (1 = the old hard swap, 0 = none).' + $nl + '                    lwUiParams.WarpStrength = Config::Instance()->LatewarpWarpStrength.value_or_default();') 'T68d Reprojection_Dx12.cpp: hand the composite its warp strength'


$t66Anchor = '                                 p2PredPx, p2PredFocal, (uint32_t) lwW, (uint32_t) lwH);'
$t66 = @(
    '                    // P2/E2c4: is the mask comparing a SAME-FRAME pair? The colour-diff branch is'
    '                    // |present - hudless|, which only means UI if both come from this frame.'
    '                    LOG_INFO("latewarp-src: hudless {:X} validity {} frameIndex {} | backbuffer {:X} | same {}",'
    '                             (size_t) hudless->GetResource(), (int) hudless->validity, hudless->frameIndex,'
    '                             (size_t) lwBack, hudless->GetResource() == lwBack);'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t66Anchor ($t66 -join $nl) 'T66 Reprojection_Dx12.cpp: log the hudless/backbuffer pair the mask compares'

# ---------------------------------------------------------------------------
# T67 (E2c5): THE LATE-INPUT SOURCE. RawInputHook is what feeds InputCollection with the mouse
# counts that arrive AFTER the game sampled its camera -- the whole P3-D late-warp idea, and the only
# thing that can produce a warp bigger than the one-frame pose delta. Measured on 2026-09-29 18:34:
# `reference` was 0-5 px on most frames (nothing to warp), while `latewarp-lateinput` logged
# `simD 0/0 sinceFg 0/0 sinceRfx 0/0` for the ENTIRE session, because RawInputHook only started for
# FGOutput=Reprojection (dllmain.cpp:1879) and the MFG configuration is NoFG. Same hooks, same replay
# path as the sessions that worked; LateDeltaGain still ships at 0, so the picture does not change
# until it is raised -- this only gives the pass its data.
# ---------------------------------------------------------------------------
$t67Old = @(
    '        if (State::Instance().activeFgOutput == FGOutput::Reprojection)'
    '            RawInputHook::getInstance().start();'
) -join $nl
$t67New = @(
    '        // P2/E2c5: start the late-input source for the latewarp-only configuration too. Without it'
    '        // InputCollection never sees a mouse delta here (measured: 0/0 for a whole session) and'
    '        // P3-D has nothing to work with. Gain stays 0, so nothing changes on screen yet.'
    '        if (State::Instance().activeFgOutput == FGOutput::Reprojection ||'
    '            (State::Instance().activeFgOutput == FGOutput::NoFG &&'
    '             Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default()))'
    '            RawInputHook::getInstance().start();'
) -join $nl
Queue-ReplaceLiteral 'dllmain.cpp' $t67Old $t67New 'T67 (E2c5) dllmain.cpp: start the RawInputHook (the late-input source) in NoFG latewarp mode too'







# ---------------------------------------------------------------------------
# T39 (P3-4a): the CHINESE PANEL. The user reads Chinese, OptiScaler has NO translation layer, and
# its menu font ships Latin-1 only. So: (a) the font atlas gets exactly the ~57 CJK code points the
# labels below use (a full Chinese range would add ~20k glyphs of texture) and a custom font that
# FAILS to load now falls back instead of leaving FontDefault null, which would take the panel down
# with it; (b) every row this project touches gets a Chinese label in FRONT of its English one (the
# three P3-1/P3-2 rows were withdrawn on 2026-09-28, so the atlas glyph table is now a harmless
# superset of the labels below)
# English token stays last, so the gate markers and the documents keep matching); (c) one Chinese
# quick switch at the top of the Advanced Settings page, driving the same runtime flag as its
# English twin. The Chinese is written as UTF-8 BYTE ESCAPES on purpose: a literal Chinese string
# would be encoded with whatever code page the compiler assumes (ANSI, without /utf-8), while ImGui
# decodes UTF-8 -- escapes are the only codepage-proof spelling.
# ---------------------------------------------------------------------------
$cnTitle = 'latewarp \xE4\xB8\xAD\xE6\x96\x87\xE9\x80\x9F\xE6\x8E\xA7\xE9\x9D\xA2\xE6\x9D\xBF'
$cnTakeover = '\xE6\x8E\xA5\xE7\xAE\xA1\xE5\xBC\x80\xE5\x85\xB3\xEF\xBC\x88\xE5\x85\x88\xE5\x8B\xBE\xE8\xBF\x99\xE4\xB8\xAA\xEF\xBC\x89'
$cnArmed = '\xEF\xBC\x88\xE5\xB7\xB2\xE8\xA3\x85\xE9\x85\x8D\xEF\xBC\x89'
$cnUnarmed = '\xEF\xBC\x88\xE6\x9C\xAA\xE8\xA3\x85\xE9\x85\x8D\xEF\xBC\x89'
$cnShow = '\xE9\x9D\x99\xE6\x80\x81\xE5\x85\x83\xE7\xB4\xA0\xE5\x8F\xAF\xE8\xA7\x86\xE5\x8C\x96'
$cnDiag = '\xE8\xAF\x8A\xE6\x96\xAD\xE8\xAE\xB0\xE5\xBD\x95'
$cnCut = '\xE6\xB7\xB1\xE5\xBA\xA6\xE9\x98\x88\xE5\x80\xBC'
$cnHint1 = '\xE5\x8B\xBE\xE9\x80\x89\xE5\x90\x8E\xE7\xAB\x8B\xE5\x8D\xB3\xE7\x94\x9F\xE6\x95\x88\xEF\xBC\x9B\xE6\x94\xB9\xE5\xAE\x8C\xE6\x8C\x89 Save Settings \xE4\xBF\x9D\xE5\xAD\x98'
$cnHint2 = '\xE7\xAD\x89\xE6\x95\x88\xE4\xBA\x8E\xE4\xB8\x8B\xE9\x9D\xA2 Reprojection \xE5\x8C\xBA\xE7\x9A\x84 latewarp takeover: running'

$t39font = @(
    '        // P3-4a: the Chinese latewarp rows need CJK glyphs in the atlas -- and ONLY those: the builder'
    '        // adds the exact code points the labels use (~57) on top of the default Latin range, so the'
    '        // atlas grows by a few KB, not by the megabytes a full Chinese range would cost.'
    '        static ImVector<ImWchar> p2GlyphRanges;'
    '        if (p2GlyphRanges.empty())'
    '        {'
    '            ImFontGlyphRangesBuilder p2GlyphBuilder;'
    '            p2GlyphBuilder.AddRanges(io.Fonts->GetGlyphRangesDefault());'
    '            p2GlyphBuilder.AddText(p2::kChinesePanelGlyphs);'
    '            p2GlyphBuilder.BuildRanges(&p2GlyphRanges);'
    '        }'
    ''
    '        if (Config::Instance()->TTFFontPath.has_value())'
    '        {'
    '            io.FontDefault ='
    '                atlas->AddFontFromFileTTF(wstring_to_string(Config::Instance()->TTFFontPath.value()).c_str(), fontSize,'
    '                                          &fontConfig, p2GlyphRanges.Data);'
    ''
    '            // A configured font that fails to load would leave FontDefault NULL and take the whole'
    '            // panel with it, so fall back LOUDLY. (The Chinese rows then render blank -- the English'
    '            // half of every label still identifies them.)'
    '            if (io.FontDefault == nullptr)'
    '                LOG_WARN("P3-4a: the [Menu] TTFFontPath font could not be loaded; using the built-in "'
    '                         "HQ font (the Chinese latewarp labels will be blank)");'
    '        }'
    '        if (io.FontDefault == nullptr)'
    '        {'
    '            io.FontDefault = atlas->AddFontFromMemoryCompressedBase85TTF(hack_compressed_compressed_data_base85,'
    '                                                                         fontSize, &fontConfig, p2GlyphRanges.Data);'
    '        }'
)
$t39fontOld = '        if (Config::Instance()->TTFFontPath.has_value())' + $nl + '        {' + $nl + '            io.FontDefault =' + $nl + '                atlas->AddFontFromFileTTF(wstring_to_string(Config::Instance()->TTFFontPath.value()).c_str(), fontSize,' + $nl + '                                          &fontConfig, io.Fonts->GetGlyphRangesDefault());' + $nl + '        }' + $nl + '        else' + $nl + '        {' + $nl + '            io.FontDefault = atlas->AddFontFromMemoryCompressedBase85TTF(hack_compressed_compressed_data_base85,' + $nl + '                                                                         fontSize, &fontConfig);' + $nl + '        }'
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t39fontOld ($t39font -join $nl) 'T39a menu_common.cpp: CJK glyph range for the atlas + a fallback when the custom font fails'

# T39b: Chinese in front of each English label (the English token stays last, verbatim).
Queue-ReplaceLiteral 'menu\menu_common.cpp' 'ImGui::Checkbox("latewarp takeover: running", &latewarpRunning)' ('ImGui::Checkbox("' + $cnTakeover + ' latewarp takeover: running", &latewarpRunning)') 'T39b menu_common.cpp: Chinese label on the takeover switch'
Queue-ReplaceLiteral 'menu\menu_common.cpp' '"latewarp diag offset map"' ('"' + $cnDiag + ' latewarp diag offset map"') 'T39b menu_common.cpp: Chinese label on the diagnostic'
Queue-ReplaceLiteral 'menu\menu_common.cpp' 'ImGui::SliderFloat("Depth cutoff", &cutoff, 0.0f, 1.0f, "%.3f", ImGuiSliderFlags_Logarithmic)' ('ImGui::SliderFloat("' + $cnCut + ' Depth cutoff", &cutoff, 0.0f, 1.0f, "%.3f", ImGuiSliderFlags_Logarithmic)') 'T39b menu_common.cpp: Chinese label on the depth cutoff'
Queue-ReplaceLiteral 'menu\menu_common.cpp' 'ImGui::Checkbox("Show static elements", &state.fgHudlessCompare);' ('ImGui::Checkbox("' + $cnShow + ' Show static elements", &state.fgHudlessCompare);') 'T39b menu_common.cpp: Chinese label on Show static elements'

# T39c: the Chinese quick switch at the top of the Advanced Settings page, driving the same runtime
# flag as the English 'latewarp takeover: running' row.
$t39quick = @(
    '    // P3-4a: the CHINESE QUICK SWITCH (latewarp quick panel). The rest of this menu belongs to OptiScaler'
    '    // and stays English; this is the one control the user has to find every session.'
    '    {'
    '        ImGui::Spacing();'
    '        ImGui::Separator();'
    ('        ImGui::TextUnformatted("' + $cnTitle + '");')
    '        bool p2Running = p2::IsRuntimeEnabled();'
    ('        if (ImGui::Checkbox("' + $cnTakeover + '##p2run", &p2Running))')
    '        {'
    '            p2::SetRuntimeEnabled(p2Running);'
    '            LOG_INFO("latewarp quick panel: takeover {}", p2Running ? "STARTED" : "PAUSED");'
    '        }'
    '        ImGui::SameLine();'
    ('        ImGui::TextDisabled(p2::IsRuntimeEnabled() ? "' + $cnArmed + '" : "' + $cnUnarmed + '");')
    ('        ImGui::TextUnformatted("' + $cnHint2 + '");')
    ('        ImGui::TextUnformatted("' + $cnHint1 + '");')
    '        ImGui::Separator();'
    '        ImGui::Spacing();'
    '    }'
)
Queue-InsertAfter 'menu\menu_common.cpp' ('void MenuCommon::RenderAdvancedSettings(RenderMenuContext& ctx)' + $nl + '{' + $nl + '    auto& state = ctx.state;') ($t39quick -join $nl) 'T39c menu_common.cpp: the Chinese quick switch (P3-4a)'
$t65eAnchor = '        ImGui::TextUnformatted("\xE5\x8B\xBE\xE9\x80\x89\xE5\x90\x8E\xE7\xAB\x8B\xE5\x8D\xB3\xE7\x94\x9F\xE6\x95\x88\xEF\xBC\x9B\xE6\x94\xB9\xE5\xAE\x8C\xE6\x8C\x89 Save Settings \xE4\xBF\x9D\xE5\xAD\x98");'
$t65e = @(
    '        // P2/E2c4: THE MASK SLIDER. 0 = warp EVERYTHING (maximum effect, the weapon/UI will'
    '        // double), 0.01 = the old hard constant (froze 95-99% of the screen), higher = fewer'
    '        // pixels frozen. The shader reads it every frame, so the picture changes as you drag.'
    '        float p2MaskThreshold = Config::Instance()->LatewarpMaskThreshold.value_or_default();'
    '        if (ImGui::SliderFloat("\xE9\x81\xAE\xE7\xBD\xA9\xE9\x98\x88\xE5\x80\xBC Mask threshold (0 = warp everything)",'
    '                               &p2MaskThreshold, 0.0f, 0.5f, "%.3f", ImGuiSliderFlags_Logarithmic))'
    '            Config::Instance()->LatewarpMaskThreshold = p2MaskThreshold;'
    '        ImGui::TextUnformatted("\xE5\x8B\xBE\xE5\x88\xB0 0 \xE5\xB0\xB1\xE5\x85\xA8\xE5\xB1\x8F\xE9\x83\xBD\xE6\x89\xAD\xEF\xBC\x9B\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE4\xBD\x8F\xE7\x9A\x84\xE8\xB6\x8A\xE5\xA4\x9A");'
) -join $nl
Queue-InsertAfter 'menu\menu_common.cpp' $t65eAnchor ($t65e -join $nl) 'T65e menu_common.cpp: the mask-threshold slider in the always-visible Chinese quick panel'

$t68eAnchor = '        ImGui::TextUnformatted("\xE5\x8B\xBE\xE5\x88\xB0 0 \xE5\xB0\xB1\xE5\x85\xA8\xE5\xB1\x8F\xE9\x83\xBD\xE6\x89\xAD\xEF\xBC\x9B\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE4\xBD\x8F\xE7\x9A\x84\xE8\xB6\x8A\xE5\xA4\x9A");'
$t68e = @(
    '        // P2/E2c6: THE STRENGTH SLIDER. 1 = the whole frame becomes the re-projection (the old'
    '        // behaviour: the world shakes), 0 = no effect. Try 0.20 - 0.40: the world is then nudged'
    '        // by the pose correction instead of being replaced by a stale frame.'
    '        float p2WarpStrength = Config::Instance()->LatewarpWarpStrength.value_or_default();'
    '        if (ImGui::SliderFloat("\xE4\xBF\xAE\xE6\xAD\xA3\xE5\xBC\xBA\xE5\xBA\xA6 Warp strength (0 = off, 1 = full)", &p2WarpStrength, 0.0f, 1.0f, "%.2f"))'
    '            Config::Instance()->LatewarpWarpStrength = p2WarpStrength;'
    '        ImGui::TextUnformatted("0 = off, 1 = full re-projection (old), try 0.20 - 0.40");'
) -join $nl
Queue-InsertAfter 'menu\menu_common.cpp' $t68eAnchor ($t68e -join $nl) 'T68e menu_common.cpp: the warp-strength slider next to the mask slider'

# ---------------------------------------------------------------------------
# T79 (E2c22): THE TWO VIEWMODEL KNOBS, MOVED WHERE THEY CAN BE FOUND.
# The 19:10 run warped the whole frame: the weapon doubled. The mask that is supposed to
# freeze it exists, but both of its controls ("Depth cutoff", "Show static elements") live in
# XeFG -> Reprojection, a section this configuration never opens -- so the user could not see
# them, and the cutoff sat at 0.35.
# The log proves that value selects NOTHING: every diag block of the run printed
# "cutout 0.00%" while the same block measured centre-pixel depths of 0.0007 / 0.0011 /
# 0.0003. CP2077 depth is reverse-Z with an INFINITE far plane (d = near/z), so the values are
# tiny: ~0.001 at 100 m and only ~0.10 - 0.25 for the weapon at arm's length. 0.35 froze
# nothing at all. Both controls are mirrored into the Chinese quick panel below, on the same
# config value / state flag as the originals, so the gun can be tuned without hunting.
# ---------------------------------------------------------------------------
$t79Anchor = '        ImGui::TextUnformatted("0 = off, 1 = full re-projection (old), try 0.20 - 0.40");'
$t79 = @(
    '        // P2/E2c22: THE VIEWMODEL KNOBS. DepthCutoff is the only thing that can keep the'
    '        // weapon out of the warp: the kernel is handed NoWarpMask, and the mask is'
    '        // max(UI diff, depth cutout). Reverse-Z with an infinite far plane makes the useful'
    '        // range tiny (the gun is ~0.10 - 0.25), so the slider is LOGARITHMIC.'
    '        float p2DepthCutoff = Config::Instance()->ReprojectionDepthCutoff.value_or_default();'
    '        if (ImGui::SliderFloat("\xE6\xB7\xB1\xE5\xBA\xA6\xE9\x98\x88\xE5\x80\xBC Depth cutoff (viewmodel mask)", &p2DepthCutoff, 0.0f, 1.0f, "%.3f", ImGuiSliderFlags_Logarithmic))'
    '            Config::Instance()->ReprojectionDepthCutoff = p2DepthCutoff;'
    '        ImGui::TextUnformatted("\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE7\xBB\x93\xE8\xB6\x8A\xE5\xB0\x91\xEF\xBC\x9B\x30\x2E\x33\x35\x20\xE5\xA4\xAA\xE9\xAB\x98\xEF\xBC\x88\xE7\xAD\x89\xE4\xBA\x8E\xE6\xB2\xA1\xE5\xBC\x80\xEF\xBC\x89\xEF\xBC\x8C\xE8\xAF\x95\x20\x30\x2E\x31\x30");'
    '        // "Show static elements": the mask the kernel is told NOT to warp, painted PINK.'
    '        bool p2ShowMask = state.fgHudlessCompare;'
    '        if (ImGui::Checkbox("\xE9\x9D\x99\xE6\x80\x81\xE5\x85\x83\xE7\xB4\xA0\xE5\x8F\xAF\xE8\xA7\x86\xE5\x8C\x96 Show static elements (pink = not warped)", &p2ShowMask))'
    '            state.fgHudlessCompare = p2ShowMask;'
    '        ImGui::TextUnformatted("\xE9\x80\x89\xE4\xB8\xAD\xE5\x90\x8E\xE7\xB2\x89\xE8\x89\xB2\x20\x3D\x20\xE4\xB8\x8D\xE4\xBC\x9A\xE8\xA2\xAB\xE6\x89\xAD\xE6\x9B\xB2\xEF\xBC\x9B\xE8\xB0\x83\xE6\xB7\xB1\xE5\xBA\xA6\xE9\x98\x88\xE5\x80\xBC\xE7\x9B\xB4\xE5\x88\xB0\xE5\x8F\xAA\xE5\x89\xA9\xE6\x9E\xAA\xE5\x92\x8C\xE6\x89\x8B");'
) -join $nl
Queue-InsertAfter 'menu\menu_common.cpp' $t79Anchor ($t79) 'T79 menu_common.cpp: depth cutoff + show-static-elements in the Chinese quick panel'

# ---------------------------------------------------------------------------
# T32 (P3-5b): give the kernel the jitter that belongs to the image it reprojects. The image is the
# PREVIOUS rendered frame (our hudless is `validity != ValidNow`), so its jitter is prevJitter. The
# official FrameWarp sample writes Jitter.Offset.X/Y every frame for exactly this reason; leaving it
# at 0 while the host jittered the projection is a sub-pixel error. Logged once so the next live run
# can confirm sign and magnitude before anything else depends on it.
# ---------------------------------------------------------------------------
$t32anchor = '            // The two decisive keys; p2::Fill writes them LAST on purpose.'
$t32lines = @(
    '            // P3-5b: the jitter of the frame the kernel is about to reproject == the PREVIOUS one',
    '            latewarpIn.jitterX = lwFrame.prevJitter[0];',
    '            latewarpIn.jitterY = lwFrame.prevJitter[1];',
    '            {',
    '                static int p2jit = 0;',
    '                if (p2jit < 5)',
    '                {',
    '                    LOG_INFO("latewarp-jitter: cur ({:.4f}, {:.4f}) prev ({:.4f}, {:.4f}) frame {} (using prev)",',
    '                             lwFrame.jitter[0], lwFrame.jitter[1], lwFrame.prevJitter[0], lwFrame.prevJitter[1],',
    '                             lwFrame.frameIndex);',
    '                    ++p2jit;',
    '                }',
    '            }'
)
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t32anchor ($t32lines -join $nl) 'T32 T21: hand the kernel the jitter of the frame it reprojects (P3-5b)'

$t18anchor = '            LOG_INFO("Passthrough to native NGX CreateFeature for feature {}", (int) InFeatureID);'
$t18repl = '            // P2 / latewarp (feature 15). OptiScaler implements this entry point itself, so an' + $nl + '            // app that ALREADY creates latewarp arrives right here. Assert the two decisive' + $nl + '            // keys before the call is forwarded, and touch nothing else: the extent and planes' + $nl + '            // are what the app supplied for its own instance and are known to be correct.' + $nl + '            if ((int) InFeatureID == 15 && cfg.LatewarpRewrite.value_or_default())' + $nl + '                p2::RewriteLatewarpParams(InParameters, 0);' + $nl + $nl + '            LOG_INFO("Passthrough to native NGX CreateFeature for feature {}", (int) InFeatureID);'
Queue-ReplaceLiteral 'inputs\NVNGX_DLSS_Dx12.cpp' $t18anchor $t18repl 'T18 CreateFeature: feature 15 keys rewritten before the forward'

$t19anchor = '    // Native DLSS passthrough' + $nl + '    if (handleId < DLSS_MOD_ID_OFFSET)'
$t19repl = '    // P2 / latewarp (feature 15): the handle table above already tells us which feature this is,' + $nl + '    // so the two decisive keys are re-asserted on every frame, exactly as the P1 proxy did.' + $nl + '    if ((int) feature == 15 && cfg.LatewarpRewrite.value_or_default())' + $nl + '        p2::RewriteLatewarpParams(InParameters, handleId);' + $nl + $nl + '    // Native DLSS passthrough' + $nl + '    if (handleId < DLSS_MOD_ID_OFFSET)'
Queue-ReplaceLiteral 'inputs\NVNGX_DLSS_Dx12.cpp' $t19anchor $t19repl 'T19 EvaluateFeature: feature 15 keys re-asserted per frame'
# T20: a menu row for the intercept switch, in the always-visible Advanced Settings block (the
# reprojection row lives inside a block that only appears when FG Output == Reprojection, and the
# intercept must not be hidden behind an unrelated mode).
$t20anchor = '    if (auto ch = ScopedCollapsingHeader("Advanced Settings"); ch.IsHeaderOpen())' + $nl + '    {' + $nl + '        ScopedIndent indent {};' + $nl + '        ImGui::Spacing();'
$t20repl = $t20anchor + $nl + $nl + '        // P2 / latewarp (branch 1): assert the two decisive keys on a feature 15 that the APP' + $nl + '        // already created. Off by default -- this build behaves exactly like stock OptiScaler' + $nl + '        // until it is ticked.' + $nl + '        bool latewarpRewrite = config->LatewarpRewrite.value_or_default();' + $nl + '        if (ImGui::Checkbox("Latewarp: rewrite feature 15 params", &latewarpRewrite))' + $nl + '        {' + $nl + '            config->LatewarpRewrite = latewarpRewrite;' + $nl + '            LOG_DEBUG("Changed LatewarpRewrite: {}", latewarpRewrite);' + $nl + '        }' + $nl + '        ShowHelpMarker("When the application (or Streamline) creates NGX feature 15 itself, assert"' + $nl + '                       " Latewarp.IsRenderedFrame=0 and Latewarp.UIColorAlpha=null instead of a"' + $nl + '                       " bit-exact copy. Needs the latewarp-capable NGX core in place.");'
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t20anchor $t20repl 'T20 menu_common.cpp: Advanced Settings += the intercept switch'

# T5: register the new files in the project (MSVC lists every source: 0 wildcards)
$vcxAbs    = Join-Path $Src 'OptiScaler.vcxproj'
$vcx       = Get-Current $vcxAbs 'OptiScaler.vcxproj'
$incAnchor = '<ClInclude Include="upscalers\dlss\DLSSFeature_Dx12.h" />'
$cmpAnchor = '<ClCompile Include="upscalers\dlss\DLSSFeature_Dx12.cpp" />'
if (-not $vcx.Contains($incAnchor)) { throw "vcxproj anchor missing: $incAnchor" }
if (-not $vcx.Contains($cmpAnchor)) { throw "vcxproj anchor missing: $cmpAnchor" }
$incExtra = '    <ClInclude Include="upscalers\latewarp\LatewarpIntercept.h" />' + $nl + '    <ClInclude Include="upscalers\latewarp\LatewarpFeature.h" />' + $nl + '    <ClInclude Include="upscalers\latewarp\LatewarpFeature_Dx12.h" />' + $nl + '    <ClInclude Include="upscalers\latewarp\LatewarpParams.h" />' + $nl + '    <ClInclude Include="upscalers\latewarp\LatewarpFrameData.h" />' + $nl + '    <ClInclude Include="shaders\latewarp\LatewarpUi_Common.h" />' + $nl + '    <ClInclude Include="shaders\latewarp\LatewarpUi_Dx12.h" />' + $nl + '    <ClInclude Include="shaders\latewarp\LatewarpUi_Shader.h" />' + $nl + '    <ClInclude Include="shaders\latewarp\LatewarpBlueNoise32.h" />'
# The two dependency-free files must NOT use the project precompiled header, so the very
# same sources can be compiled standalone by p2\test\build_and_run_test.cmd.
$cmpExtra = '    <ClCompile Include="upscalers\latewarp\LatewarpIntercept.cpp" />' + $nl + '    <ClCompile Include="upscalers\latewarp\LatewarpFeature.cpp" />' + $nl + '    <ClCompile Include="upscalers\latewarp\LatewarpFeature_Dx12.cpp" />' + $nl + '    <ClCompile Include="upscalers\latewarp\LatewarpParams.cpp">' + $nl + '      <PrecompiledHeader>NotUsing</PrecompiledHeader>' + $nl + '    </ClCompile>' + $nl + '    <ClCompile Include="upscalers\latewarp\LatewarpFrameData.cpp">' + $nl + '      <PrecompiledHeader>NotUsing</PrecompiledHeader>' + $nl + '    </ClCompile>' + $nl + '    <ClCompile Include="shaders\latewarp\LatewarpUi_Dx12.cpp" />'
$vcxNew = $vcx.Replace($incAnchor, $incAnchor + $nl + $incExtra)
$vcxNew = $vcxNew.Replace($cmpAnchor, $cmpAnchor + $nl + $cmpExtra)
if ($vcxNew -eq $vcx) { throw "vcxproj patch produced no change" }
$script:fileState[$vcxAbs] = $vcxNew
$script:notes += @{ rel = 'OptiScaler.vcxproj'; note = 'T5 vcxproj += 4 ClInclude + 3 ClCompile (2 with PCH off)'; before = (LineCount $vcx); after = (LineCount $vcxNew) }


# T7: build hygiene for this workspace (documented in BUILD_FROM_SOURCE.md, and required
# for a from-scratch reproducible build):
#  (a) ReleaseDebug|x64's PreBuildEvent writes the metadata headers from the clock and
#      git rev-parse -> pin it to the shipped values so the build is reproducible;
#  (b) its PostBuildEvent shells out to 7z, which is not installed here -> neutralize it.
function Queue-VcxBuildHygiene() {
    $abs = Join-Path $Src 'OptiScaler.vcxproj'
    $t = Get-Current $abs 'OptiScaler.vcxproj'
    $before = LineCount $t

    $marker = '$date = Get-Date -Format ''yyyyMMdd_HHmmss'';'
    $idxs = @(); $i = 0
    while (($i = $t.IndexOf($marker, $i)) -ge 0) { $idxs += $i; $i += $marker.Length }
    if ($idxs.Count -lt 2) { throw ("T7: expected >= 2 metadata PreBuildEvents, found " + $idxs.Count) }
    $start = $t.LastIndexOf('<Command>', $idxs[1]) + 9
    $end   = $t.IndexOf('</Command>', $idxs[1])
    if ($end -lt $start) { throw "T7: could not delimit the ReleaseDebug PreBuildEvent" }
    # Per BUILD_FROM_SOURCE.md section 2 the ReleaseDebug PreBuildEvent is REPLACED by an
    # echo, and the two headers are written once with the shipped values. (An earlier hand
    # at this injected a nested -Command that re-wrote them, but the &quot; entities survive
    # XML -> cmd -> PowerShell with their quotes stripped, producing
    # "#define VER_BUILD_COMMIT 5b6bc822" and breaking BuildInfo.cpp. Do it the doc's way.)
    $fixed = 'echo p2: keep fixed metadata headers'
    $t = $t.Substring(0, $start) + $fixed + $t.Substring($end)

    $pb = '$timestamp = Get-Date -Format ''yyyyMMdd_HHmmss''; $fileName'
    $j = $t.IndexOf($pb)
    if ($j -lt 0) { throw "T7: ReleaseDebug PostBuildEvent (7z) not found" }
    $s2 = $t.LastIndexOf('<Command>', $j) + 9
    $e2 = $t.IndexOf('</Command>', $j)
    if ($e2 -lt $s2) { throw "T7: could not delimit the ReleaseDebug PostBuildEvent" }
    $t = $t.Substring(0, $s2) + 'echo p2: postbuild archiving skipped' + $t.Substring($e2)

    $script:fileState[$abs] = $t
    $script:notes += @{ rel = 'OptiScaler.vcxproj'; note = 'T7 replace metadata PreBuildEvent with echo (+ skip 7z archiving)'; before = $before; after = (LineCount $t) }

    # T7 also (re)writes the two metadata headers the build consumes, with the quoted values
    # the shipped binary was built from. These are BUILD METADATA, not product code.
    # S10 F-04: they must go through the same machinery as everything else, otherwise -Revert
    # leaves them behind and the tree is no longer byte-identical (the delivered tree has none).
    $dateText   = '#define VER_BUILD_DATE "20260923_154018"' + $nl
    $commitText = '#define VER_BUILD_COMMIT "5b6bc822"' + $nl
    foreach ($gen in @(@{ n = 'resource_build_date.h'; t = $dateText }, @{ n = 'resource_build_commit.h'; t = $commitText })) {
        $gp = Join-Path $Src $gen.n
        if (-not (Test-Path -LiteralPath $gp)) { $script:genAdded += $gen.n }   # revert deletes it
        $null = Get-Current $gp $gen.n                                          # registers + backs up if present
        $script:fileState[$gp] = $gen.t
        $script:notes += @{ rel = $gen.n; note = ('T7 ' + $gen.n + ' pinned (quoted metadata)'); before = 0; after = 1 }
    }
}
# ---------------------------------------------------------------------------
# T70 (E2c9, P0): WHY THE PICTURE NEVER CHANGED, AND THE FIX.
#
# MEASURED on the 2026-09-29 22:02 run: 35783 StartNewFrame calls (= the slSetConstants hook,
# frameIds 1..35783, every one distinct) against ~7530 composite passes => 4.7 CAMERA SAMPLES PER
# PRESENT. The FG camera ring is indexed by _frameCount % 4 and _frameCount advances on every one
# of those samples, so the whole ring is rewritten INSIDE ONE present interval: _cameraX[fIndex]
# and _cameraX[fIndex - 1] are two samples of the SAME rendered frame. The matrices handed to the
# kernel come out near-identical (w2v vs pw2v: translation 0.07 units apart, orientation 1e-4
# apart) and NGX early-outs into a bit-exact copy. The composite measured a centre shift of
# exactly 0.0 px while the camera turned 5.15 deg in that same frame -- the defect in one number.
#
# The fix is the present-boundary double buffer added to LatewarpFrameData in this same patch set:
# cur = newest sample at this present, prev = newest sample at the previous present. These patches
# swap the matrix SOURCE and stop the diagnostics from re-reading the ring.
# ---------------------------------------------------------------------------
$t70aAnchor = 'p2::SetStreamlineViewToClip(&values.cameraViewToClip.row[0].x, (uint32_t) frame);   // P2 latewarp: cache current/previous projection'
$t70a = @(
    'p2::SetStreamlineCameraPose(&values.cameraPos.x, &values.cameraUp.x, &values.cameraRight.x, &values.cameraFwd.x,'
    '                            &values.cameraViewToClip.row[0].x);   // P2/E2c9 (P0): the pose pair the latewarp matrices are built from'
)
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t70aAnchor ($t70a -join $nl) 'T70a Streamline_Hooks.cpp: push the camera pose+clip matrix into the present-boundary double buffer'

$t70bAnchor = @(
    '            const int lwPrevIndex = (fIndex == 0) ? (BUFFER_COUNT - 1) : (fIndex - 1);'
    '            float lwW2V[16] = {};'
    '            float lwPW2V[16] = {};'
) -join $nl
$t70b = @(
    '            const int lwPrevIndex = (fIndex == 0) ? (BUFFER_COUNT - 1) : (fIndex - 1);'
    '            // ---- P2/E2c9 (P0): THE MATRICES COME FROM A PRESENT-BOUNDARY DOUBLE BUFFER ----'
    '            // MEASURED: slSetConstants fires 4.7 times per present (35783 samples vs 7530'
    '            // passes), so the _frameCount % 4 camera ring is rewritten inside ONE present'
    '            // interval and _cameraX[fIndex] / _cameraX[fIndex - 1] are samples of the SAME'
    '            // rendered frame. The kernel then sees two near-identical matrices and early-outs'
    '            // into a bit-exact copy -- the composite measured a centre shift of 0.0 px while'
    '            // the camera turned 5.15 deg in that same frame, and the picture never changed.'
    '            // AdvanceStreamlineCameraPose rotates a strict two-entry history ONLY at the present'
    '            // boundary: cur = newest sample now, prev = newest sample at the previous present.'
    '            p2::LwCameraPose lwPoseCur {};'
    '            p2::LwCameraPose lwPosePrev {};'
    '            const bool lwPoseOk = p2::AdvanceStreamlineCameraPose(lwPoseCur, lwPosePrev);'
    '            // Fallback: before the first sample exists keep the old ring reads, so the first'
    '            // frames behave exactly as before instead of binding nothing at all.'
    '            const float* lwRightCur  = lwPoseOk ? lwPoseCur.right  : _cameraRight[fIndex];'
    '            const float* lwUpCur     = lwPoseOk ? lwPoseCur.up     : _cameraUp[fIndex];'
    '            const float* lwFwdCur    = lwPoseOk ? lwPoseCur.fwd    : _cameraForward[fIndex];'
    '            const float* lwPosCur    = lwPoseOk ? lwPoseCur.pos    : _cameraPosition[fIndex];'
    '            const float* lwRightPrev = lwPoseOk ? lwPosePrev.right : _cameraRight[lwPrevIndex];'
    '            const float* lwUpPrev    = lwPoseOk ? lwPosePrev.up    : _cameraUp[lwPrevIndex];'
    '            const float* lwFwdPrev   = lwPoseOk ? lwPosePrev.fwd   : _cameraForward[lwPrevIndex];'
    '            const float* lwPosPrev   = lwPoseOk ? lwPosePrev.pos   : _cameraPosition[lwPrevIndex];'
    '            float lwW2V[16] = {};'
    '            float lwPW2V[16] = {};'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70bAnchor $t70b 'T70b Reprojection_Dx12.cpp: the two camera matrices come from the present-boundary pose pair'

$t70cAnchor = @(
    '            const bool lwCamCur = p2::BuildWorldToView(_cameraRight[fIndex], _cameraUp[fIndex],'
    '                                                      _cameraForward[fIndex], _cameraPosition[fIndex], lwW2V);'
    '            const bool lwCamPrev = p2::BuildWorldToView(_cameraRight[lwPrevIndex], _cameraUp[lwPrevIndex],'
    '                                                       _cameraForward[lwPrevIndex], _cameraPosition[lwPrevIndex],'
    '                                                       lwPW2V);'
) -join $nl
$t70c = @(
    '            const bool lwCamCur = p2::BuildWorldToView(lwRightCur, lwUpCur, lwFwdCur, lwPosCur, lwW2V);'
    '            const bool lwCamPrev = p2::BuildWorldToView(lwRightPrev, lwUpPrev, lwFwdPrev, lwPosPrev, lwPW2V);'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70cAnchor $t70c 'T70c Reprojection_Dx12.cpp: build both matrices from the frozen pose pair'

# The clip-matrix pointer setup has to sit DIRECTLY after GetFrameData(): the pose-delta block
# below reads lwV2Cp, and the first build of this round failed with C2065 (used before declared)
# because it had been placed at the old site further down the function.
$t70d1Anchor = '            const p2::FrameData lwFrame = p2::GetFrameData();'
$t70d1 = @(
    '            // P2/E2c9 (P0): the clip matrices rotate with the SAME two samples as the camera when'
    '            // the snapshot is live. They collapse under the same 4.7-samples-per-present'
    '            // arithmetic (SetStreamlineViewToClip rotates prev on every frameId change), and'
    '            // pairing a one-present-old camera with a same-generation clip matrix would only'
    '            // trade one inconsistency for another. Jitter stays on its existing path: this build'
    '            // changes exactly one thing.'
    '            float lwV2CSnap[16] = {};'
    '            float lwPV2CSnap[16] = {};'
    '            const float* lwV2Cp = lwFrame.hasCurrent ? lwFrame.viewToClip : nullptr;'
    '            const float* lwPV2Cp = lwFrame.hasPrevious ? lwFrame.prevViewToClip : nullptr;'
    '            if (lwPoseOk)'
    '            {'
    '                for (int lwMi = 0; lwMi < 16; ++lwMi)'
    '                {'
    '                    lwV2CSnap[lwMi] = lwPoseCur.viewToClip[lwMi];'
    '                    lwPV2CSnap[lwMi] = lwPosePrev.viewToClip[lwMi];'
    '                }'
    '                lwV2Cp = lwV2CSnap;'
    '                lwPV2Cp = lwPV2CSnap;'
    '            }'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t70d1Anchor ($t70d1 -join $nl) 'T70d1 Reprojection_Dx12.cpp: clip matrices come from the same generation as the pose pair'

# The lwPW2Vp line is part of the anchor on purpose: T70d1 declares the SAME two pointers further
# up, so anchoring on them alone would match twice and the patch script would refuse to run.
$t70d2Anchor = @(
    '            const float* lwPW2Vp = lwCamPrev ? lwPW2V : nullptr;'
    '            const float* lwV2Cp = lwFrame.hasCurrent ? lwFrame.viewToClip : nullptr;'
    '            const float* lwPV2Cp = lwFrame.hasPrevious ? lwFrame.prevViewToClip : nullptr;'
    ''
) -join $nl
# The replacement keeps the lwPW2Vp line: it is part of the anchor only to make it unique, and it
# is still read by the latewarpIn binding below (the first attempt deleted it together with the two
# declarations and the tree no longer compiled).
$t70d2 = '            const float* lwPW2Vp = lwCamPrev ? lwPW2V : nullptr;' + $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70d2Anchor $t70d2 'T70d2 Reprojection_Dx12.cpp: the two clip-matrix declarations move up to GetFrameData (lwPW2Vp stays)'

$t70eAnchor = @(
    '                float p2TurnDeg = 0.0f;'
    '                if (lwCamCur && lwCamPrev)'
    '                    p2::ForwardAngleDeg(_cameraForward[fIndex], _cameraForward[lwPrevIndex], &p2TurnDeg);'
) -join $nl
$t70e = @(
    '                float p2TurnDeg = 0.0f;'
    '                if (lwCamCur && lwCamPrev)'
    '                    p2::ForwardAngleDeg(lwFwdCur, lwFwdPrev, &p2TurnDeg);   // P2/E2c9: the FROZEN pair, never a re-read'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70eAnchor $t70e 'T70e Reprojection_Dx12.cpp: the measured turn uses the frozen pose pair (the 91-138 px re-read is gone)'

$t70fAnchor = @(
    '                    LOG_INFO("latewarp-latelatch: pose age {:.2f} ms | present gap {:.2f} ms | age/gap {:.2f} "'
    '                             "| camera turn {:.2f} deg | sampled frame {} | fps {:.1f}",'
    '                             p2AgeMs, p2GapMs, p2LateFrac, p2TurnDeg,'
    '                             lwFrame.frameIndex, (p2GapMs > 0.01) ? (1000.0 / p2GapMs) : 0.0);'
) -join $nl
$t70f = @(
    '                    LOG_INFO("latewarp-latelatch: pose age {:.2f} ms | present gap {:.2f} ms | age/gap {:.2f} "'
    '                             "| camera turn {:.2f} deg | sampled frame {} | fps {:.1f}",'
    '                             p2AgeMs, p2GapMs, p2LateFrac, p2TurnDeg,'
    '                             lwFrame.frameIndex, (p2GapMs > 0.01) ? (1000.0 / p2GapMs) : 0.0);'
    '                    // P2/E2c9 (P0) THE DECISIVE LINE: the two poses the kernel is actually being'
    '                    // handed, printed straight from the snapshot. If pos/fwd here are identical the'
    '                    // pair failed; if they differ by the mouse motion of one present, the warp is'
    '                    // real and the NEXT number to watch is the centre shift in latewarp-diag.'
    '                    LOG_INFO("latewarp-campose: serial {} consumed {} | pos ({:.2f},{:.2f},{:.2f}) -> ({:.2f},{:.2f},{:.2f}) "'
    '                             "| fwd ({:.4f},{:.4f},{:.4f}) -> ({:.4f},{:.4f},{:.4f}) | turn {:.2f} deg | slots {} / {} | snapshot {}",'
    '                             p2::CameraPoseSerial(), p2::CameraPoseConsumed(),'
    '                             lwPosPrev[0], lwPosPrev[1], lwPosPrev[2], lwPosCur[0], lwPosCur[1], lwPosCur[2],'
    '                             lwFwdPrev[0], lwFwdPrev[1], lwFwdPrev[2], lwFwdCur[0], lwFwdCur[1], lwFwdCur[2],'
    '                             p2TurnDeg, fIndex, lwPrevIndex, lwPoseOk);'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70fAnchor $t70f 'T70f Reprojection_Dx12.cpp: log the two poses the kernel is handed (the P0 acceptance number)'

$t70gAnchor = @(
    '                    float p2PredPx = 0.0f;'
    '                    const float p2PredFocal = (lwFrame.hasCurrent && lwFrame.viewToClip[0] != 0.0f)'
    '                                                  ? lwFrame.viewToClip[0] * 0.5f * (float) lwW'
    '                                                  : 0.0f;'
    '                    if (lwCamCur && lwCamPrev && p2PredFocal > 0.0f &&'
    '                        p2::PredictCentreShiftPx(_cameraForward[fIndex], _cameraForward[lwPrevIndex],'
    '                                                 p2PredFocal, &p2PredPx))'
) -join $nl
$t70g = @(
    '                    float p2PredPx = 0.0f;'
    '                    // P2/E2c9 (P0): the prediction uses the SNAPSHOT the kernel is handed, never a'
    '                    // second read of _cameraForward[]. That re-read is what reported 91-138 px while'
    '                    // the shader, using the very matrices the kernel got, measured 0.0 px: the'
    '                    // render thread writes those arrays concurrently.'
    '                    const float p2PredFocal = (lwV2Cp != nullptr && lwV2Cp[0] != 0.0f)'
    '                                                  ? lwV2Cp[0] * 0.5f * (float) lwW'
    '                                                  : 0.0f;'
    '                    if (lwCamCur && lwCamPrev && p2PredFocal > 0.0f &&'
    '                        p2::PredictCentreShiftPx(lwFwdCur, lwFwdPrev, p2PredFocal, &p2PredPx))'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70gAnchor $t70g 'T70g Reprojection_Dx12.cpp: the pose-delta prediction reads the frozen pair'

$t70hAnchor = @(
    '                    const float p2CosPrev = _cameraForward[fIndex][0] * _cameraForward[lwPrevIndex][0] +'
    '                                           _cameraForward[fIndex][1] * _cameraForward[lwPrevIndex][1] +'
    '                                           _cameraForward[fIndex][2] * _cameraForward[lwPrevIndex][2];'
    '                    const float p2CosRight = _cameraForward[fIndex][0] * _cameraRight[lwPrevIndex][0] +'
    '                                            _cameraForward[fIndex][1] * _cameraRight[lwPrevIndex][1] +'
    '                                            _cameraForward[fIndex][2] * _cameraRight[lwPrevIndex][2];'
    '                    const float p2CosUp = _cameraForward[fIndex][0] * _cameraUp[lwPrevIndex][0] +'
    '                                         _cameraForward[fIndex][1] * _cameraUp[lwPrevIndex][1] +'
    '                                         _cameraForward[fIndex][2] * _cameraUp[lwPrevIndex][2];'
) -join $nl
$t70h = @(
    '                    const float p2CosPrev = lwFwdCur[0] * lwFwdPrev[0] + lwFwdCur[1] * lwFwdPrev[1] +'
    '                                           lwFwdCur[2] * lwFwdPrev[2];   // P2/E2c9: frozen pair'
    '                    const float p2CosRight = lwFwdCur[0] * lwRightPrev[0] + lwFwdCur[1] * lwRightPrev[1] +'
    '                                            lwFwdCur[2] * lwRightPrev[2];'
    '                    const float p2CosUp = lwFwdCur[0] * lwUpPrev[0] + lwFwdCur[1] * lwUpPrev[1] +'
    '                                         lwFwdCur[2] * lwUpPrev[2];'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70hAnchor $t70h 'T70h Reprojection_Dx12.cpp: the lateinput cosines read the frozen pair'

$t70iAnchor = @(
    '            const float lwFocalX = (lwFrame.hasCurrent && lwFrame.viewToClip[0] != 0.0f)'
    '                                                   ? lwFrame.viewToClip[0] * 0.5f * (float) lwW : 0.0f;'
) -join $nl
$t70i = @(
    '            // P2/E2c9 (P0): the focal length and both reprojection matrices come from the SAME'
    '            // generation as the pose pair the kernel is handed (lwV2Cp points at the snapshot when'
    '            // it is live, at the legacy cache otherwise).'
    '            const float lwFocalX = (lwV2Cp != nullptr && lwV2Cp[0] != 0.0f)'
    '                                                   ? lwV2Cp[0] * 0.5f * (float) lwW : 0.0f;'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70iAnchor $t70i 'T70i Reprojection_Dx12.cpp: the composite focal comes from the snapshot clip matrix'

$t70jAnchor = @(
    '                            const bool lwMatOk = lwCamCur && lwCamPrev && lwFrame.hasCurrent && lwFrame.hasPrevious &&'
    '                                p2::BuildReprojectionMatrices(lwW2V, lwFrame.viewToClip, lwPW2V,'
    '                                                              lwFrame.prevViewToClip, lwInvVP, lwVPP);'
) -join $nl
$t70j = @(
    '                            const bool lwMatOk = lwCamCur && lwCamPrev && lwV2Cp != nullptr && lwPV2Cp != nullptr &&'
    '                                p2::BuildReprojectionMatrices(lwW2V, lwV2Cp, lwPW2V,'
    '                                                              lwPV2Cp, lwInvVP, lwVPP);   // P2/E2c9: same generation as the poses'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70jAnchor $t70j 'T70j Reprojection_Dx12.cpp: the composite reprojection matrices use the snapshot clip pair'

$t70kAnchor = @(
    '                                p2::PredictCentreShiftPx(_cameraForward[fIndex], _cameraForward[lwPrevIndex],'
    '                                                         lwFocalX, &lwRefPx);'
) -join $nl
$t70k = @(
    '                                p2::PredictCentreShiftPx(lwFwdCur, lwFwdPrev, lwFocalX, &lwRefPx);   // P2/E2c9: frozen pair'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t70kAnchor $t70k 'T70k Reprojection_Dx12.cpp: the DiagRefPx reference reads the frozen pair'

# ---------------------------------------------------------------------------
# T71 (E2c10): THE FG-OFF GATE. A live run on 2026-09-29 23:46 -- the GAME frame generation turned
# OFF, which is the A/B the user asked for -- measured ZERO latewarp evaluations in a whole session
# while 4748 slSetConstants calls and 6270 resource-tag reports DID happen. The bootstrap was in
# place (latewarp-e2c: adopted the game swapchain) and lw->Activate() had run, so the pass was
# blocked by IsActive()/IsPaused(): IFGFeature::UpdateTarget() sets _targetFrame = _frameCount + 10
# and IFGFeature::IsPaused() is (_targetFrame >= _frameCount), so as soon as the FG manager keeps
# the target ahead -- which is what "paused" means for a FRAME-GENERATION backend -- the latewarp is
# gated off with it. The latewarp-only presenter runs on the PRESENT CHAIN (E2c) and has no pacing
# notion at all: one warp per present is the whole contract. Gate it on its own two switches.
# ---------------------------------------------------------------------------
$t71aAnchor = @(
    '    if (IsActive() && !IsPaused())'
    '    {'
    '        auto hudless = GetResource(FG_ResourceType::HudlessColor, fIndex);'
) -join $nl
$t71a = @(
    '    // P2/E2c10 (FG-OFF GATE): the latewarp-only presenter is driven by the present chain, NOT by'
    '    // the frame-generation pacer. IsPaused() is (_targetFrame >= _frameCount) and UpdateTarget()'
    '    // sets _targetFrame = _frameCount + 10, so whenever the FG manager holds the target ahead the'
    '    // pass below was skipped -- measured as ZERO evaluations in the FG-off session of 23:46.'
    '    const bool lwArmed = Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() &&'
    '                          p2::IsRuntimeEnabled();'
    '    const bool lwPaced = IsActive() && !IsPaused();'
    '    const bool lwRun = lwPaced || lwArmed;'
    ''
    '    if (lwRun)'
    '    {'
    '        auto hudless = GetResource(FG_ResourceType::HudlessColor, fIndex);'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t71aAnchor $t71a 'T71a Reprojection_Dx12.cpp: the latewarp pass is gated on its own switches, not on the FG pacer'

$t71bAnchor = @(
    '                LOG_INFO("latewarp-diag: active {} paused {} hudless {} depth {} velocity {} extent {}x{} switch {} "'
    '                         "(armed; started = runtime)",'
    '                         IsActive(), IsPaused(),'
) -join $nl
$t71b = @(
    '                LOG_INFO("latewarp-diag: active {} paused {} | gate paced {} armed {} | hudless {} depth {} velocity {} extent {}x{} switch {} "'
    '                         "(armed; started = runtime)",'
    '                         IsActive(), IsPaused(), lwPaced, lwArmed,'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t71bAnchor $t71b 'T71b Reprojection_Dx12.cpp: the one-shot input diag prints both gate terms'

$t71cAnchor = @(
    '        // ---- P2 branch 2: self-created latewarp (NGX feature 15), independent of _reproject ---'
    '        if (IsActive() && !IsPaused() &&'
    '            Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() && p2::IsRuntimeEnabled() &&'
) -join $nl
$t71c = @(
    '        // ---- P2 branch 2: self-created latewarp (NGX feature 15), independent of _reproject ---'
    '        if (lwRun && Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() &&'
    '            p2::IsRuntimeEnabled() &&'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t71cAnchor $t71c 'T71c Reprojection_Dx12.cpp: the kernel branch uses the same relaxed gate'

# ---------------------------------------------------------------------------
# T72 (E2c11): WARP BEFORE THE FRAME GENERATOR EATS THE FRAME.
#
# MEASURED (round 136/137): our Present hook sees ~37 presents/s while the DISPLAY runs at >100 fps
# (MFG inserts 3-4 generated frames per rendered frame), so the generated frames never reach our
# present-chain warp => only ~1/4-1/3 of the displayed frames carry it => the user sees a
# "semi-transparent" warped layer that only shows up while moving. The warp is one frame LATE: it
# hangs off the present chain, which is after the generator.
# The right place is the moment the game TAGS THE BACKBUFFER it is about to hand to the frame
# generator (sl::kBufferTypeBackbuffer): warp it there and the generator interpolates between warped
# frames, so the real AND the generated frames show the same content -- no duty-cycle ghost.
# T72 is deliberately SELF-GATED: if no backbuffer tag is ever seen, nothing changes.
# ---------------------------------------------------------------------------
$t72aAnchor = @(
    '    if (renderApi == sl::RenderAPI::eD3D11 || renderApi == sl::RenderAPI::eVulkan)'
    '    {'
    '        LOG_ERROR("hkslSetTag only supports DX12");'
    '        return o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    }'
) -join $nl
$t72a = @(
    '    if (renderApi == sl::RenderAPI::eD3D11 || renderApi == sl::RenderAPI::eVulkan)'
    '    {'
    '        LOG_ERROR("hkslSetTag only supports DX12");'
    '        return o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    }'
    ''
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t72aAnchor $t72a 'T72a Streamline_Hooks.cpp: probe the backbuffer tag in the slSetTag hook'

$t72bAnchor = 'sl::Result StreamlineHooks::hkslSetTag(const sl::ViewportHandle& viewport, const sl::ResourceTag* tags,'
$t72b = @(
    '// P2/E2c11 (T72): THE FRAME GENERATOR READS THE FRAME THE GAME TAGS AS ITS BACKBUFFER.'
    '// Everything we warp today happens on the PRESENT chain, i.e. AFTER the generator has already'
    '// interpolated its frames -- measured as ~37 presents/s in our hook against >100 fps on screen,'
    '// so only ~1/4-1/3 of the displayed frames can carry the warp (the "semi-transparent" layer the'
    '// user reported). Warping the frame at the TAG instead puts it BEFORE the generator: the real and'
    '// the generated frames then show the same content. Self-gated: no backbuffer tag, no change.'
    '// P2/E2c20: the cached frame the generator interpolates, and the state its own tag declared.'
    'static ID3D12Resource* g_lwScalingOut = nullptr;'
    'static uint32_t g_lwScalingOutState = 0;'
    ''
    'static void lwProbeBackbufferTag(const sl::ResourceTag* tags, uint32_t numTags, const char* hook)'
    '{'
    '    if (tags == nullptr)'
    '        return;'
    ''
    '    for (uint32_t i = 0; i < numTags; ++i)'
    '    {'
    '        // P2/E2c11b (round 139): INVENTORY. The first T72 build keyed on sl::kBufferTypeBackbuffer'
    '        // (53) and never fired once: this game does NOT tag a backbuffer through slSetTag. What it'
    '        // DOES tag (measured: 8856 each, frameId 0 => the no-frame-token hook slSetTag) is'
    '        // 0=Depth, 1=Velocity, 2=HudlessColor -- and the hudless is tagged at the END of the'
    '        // game frame, i.e. the last thing before it presents. Log every distinct type once so the'
    '        // next run leaves no doubt about the inventory.'
    '        static uint64_t lwSeenTypes = 0;'
    '        const uint32_t lwType = (uint32_t) tags[i].type;'
    '        if (lwType < 64 && (lwSeenTypes & (1ull << lwType)) == 0)'
    '        {'
    '            lwSeenTypes |= (1ull << lwType);'
    '            LOG_INFO("latewarp-e2c11: TAG INVENTORY type {} seen in {} ({} tags this call)", lwType, hook,'
    '                     numTags);'
    '        }'
    ''
    '        // P2/E2c20: CACHE THE SCALING-OUTPUT RESOURCE. Its pointer is stable across frames (the'
    '        // game allocates it once), and the in-place warp must happen at the UPSCALER evaluate --'
    '        // BEFORE the game composites the UI onto the backbuffer -- not here, where the tag only'
    '        // DECLARES the frame that is already built. The tag order is not a write order.'
    '        if (tags[i].type == sl::kBufferTypeScalingOutputColor && tags[i].resource != nullptr &&'
    '            tags[i].resource->native != nullptr)'
    '        {'
    '            g_lwScalingOut = (ID3D12Resource*) tags[i].resource->native;'
    '            g_lwScalingOutState = (uint32_t) tags[i].resource->state;'
    '            static int lwSoLog = 0;'
    '            if (lwSoLog < 3)'
    '                LOG_INFO("latewarp-e2c20: cached the game ScalingOutputColor {:X} (declaredState {})",'
    '                         (size_t) g_lwScalingOut, g_lwScalingOutState);'
    '            ++lwSoLog;'
    '        }'
    ''
    '        if (tags[i].type != sl::kBufferTypeHUDLessColor)'
    '            continue;'
    ''
    '        static int lwBbSeen = 0;'
    '        static int lwBbDriven = 0;'
    '        if (lwBbSeen < 5)'
    '            LOG_INFO("latewarp-e2c11: HUDLESS tag seen in {} ({} tags, resource {:X}) -- the app tags its FG inputs here, right before presenting",'
    '                     hook, numTags, (size_t) tags[i].resource);'
    '        ++lwBbSeen;'
    ''
    '        // P2/E2c13 (round 143): THE HUDLESS-TAG DRIVE IS REMOVED ON PURPOSE.'
    '        // It called the FULL present pass from inside the game frame, and that pass writes the'
    '        // swapchain backbuffer: the 16:26 run crashed the game exactly there (the log stops at'
    '        // GetSCCommandList for the composite). The warp the frame GENERATOR needs is produced by'
    '        // the ScalingOutputColor tag substitution (E2c12), which only writes OUR texture, and the'
    '        // displayed frame still gets its warp from the present chain. What stays here is the'
    '        // inventory line and nothing else.'
    '        return;'
    '    }'
    '}'
    ''
    'sl::Result StreamlineHooks::hkslSetTag(const sl::ViewportHandle& viewport, const sl::ResourceTag* tags,'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t72bAnchor $t72b 'T72b Streamline_Hooks.cpp: the self-gated backbuffer-tag warp helper'

$t72cAnchor = '    if (_frameCount == _lastWarpFrameCount)' + $nl + '        return false;' + $nl + '    _lastWarpFrameCount = _frameCount;'
$t72c = @(
    '    if (_frameCount == _lastWarpFrameCount)'
    '        return false;'
    ''
    '    // P2/E2c11 (T72): the pass can now be driven from the BACKBUFFER TAG (before the frame'
    '    // generator eats the frame) AND from the present chain (the fallback for frames the game'
    '    // never tags). Both happen inside ONE rendered frame, microseconds apart, so a 2 ms'
    '    // re-entry window keeps the tag drive and makes the present drive a no-op -- otherwise the'
    '    // backbuffer would be warped TWICE, which is a doubled shift.'
    '    if (p2::IsRuntimeEnabled() && !p2::LatewarpAtTag() && p2::LatewarpTagDriveRecent())'
    '        return false;'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t72cAnchor $t72c 'T72c Reprojection_Dx12.cpp: 2 ms re-entry guard so one rendered frame is warped exactly once'

$t72dAnchor = @(
    '    auto result = o_slSetTagForFrame(frame, viewport, resources, numResources, cmdBuffer);'
    '    return result;'
) -join $nl
$t72d = @(
    '    lwProbeBackbufferTag(resources, numResources, "slSetTagForFrame");'
    ''
    '    auto result = o_slSetTagForFrame(frame, viewport, resources, numResources, cmdBuffer);'
    '    return result;'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t72dAnchor $t72d 'T72d Streamline_Hooks.cpp: probe the backbuffer tag in the slSetTagForFrame hook too'

# ---------------------------------------------------------------------------
# T72e (E2c11b): the tag drive happens when the frame resources are CURRENT, i.e. validity is
# ValidNow -- the exact condition the present-time branch rejects. Allow it for the tag drive only;
# the present path keeps the old requirement so nothing else changes.
# ---------------------------------------------------------------------------
$t72eAnchor = @(
    '            hudless &&'
    '            (hudless->validity != FG_ResourceValidity::ValidNow) && depth &&'
    '            (depth->validity != FG_ResourceValidity::ValidNow))'
) -join $nl
$t72e = @(
    '            hudless &&'
    '            (p2::LatewarpAtTag() || hudless->validity != FG_ResourceValidity::ValidNow) && depth &&'
    '            (p2::LatewarpAtTag() || depth->validity != FG_ResourceValidity::ValidNow))'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t72eAnchor $t72e 'T72e Reprojection_Dx12.cpp: the pre-generator (tag) drive may use the current frame'

# ---------------------------------------------------------------------------
# T72f (E2c11c): WHERE THE PROBE RUNS MATTERS. The probe was inserted right after the renderApi
# check, i.e. BEFORE the loop that pushes the tagged resources into our feature (reportResource ->
# fgOutput->SetResource). At that instant the kernel inputs were still missing (measured:
# 'hudless -1 depth -1' in the one-shot gate line), so the pass could not run. Drive AFTER the push,
# immediately before the tag is forwarded to Streamline: that is both 'the frame is final' and
# 'the generator has not looked at it yet'.
# ---------------------------------------------------------------------------
$t72fAnchor = @(
    '    auto result = o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    return result;'
    '}'
) -join $nl
$t72f = @(
    '    lwProbeBackbufferTag(tags, numTags, "slSetTag");   // P2/E2c11c: AFTER the resource push'
    ''
    '    auto result = o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    return result;'
    '}'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t72fAnchor $t72f 'T72f Streamline_Hooks.cpp: drive AFTER the tagged resources are pushed into the feature'

# ---------------------------------------------------------------------------
# T72g (E2c11c): A FAILED DRIVE MUST NOT CONSUME THE FRAME TOKEN. The frame counter was assigned
# BEFORE the kernel gate, so a tag drive that could not run still marked the rendered frame as done
# and the present-chain fallback was rejected by the very first line of Present() -- measured as
# ZERO passes in the whole 16:08 run. The token now advances only when the kernel actually evaluated.
# ---------------------------------------------------------------------------
$t72gAnchor = '                lwEvaluated = _latewarp.Evaluate(latewarpList, latewarpIn);'
$t72g = @(
    '                lwEvaluated = _latewarp.Evaluate(latewarpList, latewarpIn);'
    '            // P2/E2c11c: the frame is consumed only when the pass really ran, so a drive that'
    '            // could not run leaves the present-chain fallback its chance.'
    '            _lastWarpFrameCount = _frameCount;'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t72gAnchor $t72g 'T72g Reprojection_Dx12.cpp: consume the frame token only when the kernel actually evaluated'

# ---------------------------------------------------------------------------
# T73 (E2c12): ROUTE A -- WARP THE FRAME THE FRAME GENERATOR EATS, WITHOUT EVER TOUCHING THE
# SWAPCHAIN.
#
# The tag inventory decoded against Streamline's own enum (sl_core_types.h) is the key:
#   0 Depth / 1 MotionVectors / 2 HUDLessColor / 3 ScalingInputColor / 4 ScalingOutputColor /
#   29 BiasCurrentColorHint -- and 53 (kBufferTypeBackbuffer) is NEVER tagged by this game.
# So the generator interpolates the resource the game tags as ScalingOutputColor (4). Warping the
# swapchain on the present chain could never reach that resource, which is exactly why only ~1/3 of
# the displayed frames carried the warp (the semi-transparent layer). Substituting THAT tag with our
# own warped texture puts the warp where the generator reads it; the game's resources are only ever
# READ, and the swapchain is not written at all -- the attempt that did write it mid-frame crashed
# the game (LOG round 141).
# ---------------------------------------------------------------------------
$t73aAnchor = @(
    '    UINT64 _fgFramePresentId = 0;'
    '    UINT64 _lastFGFramePresentId = 0;'
) -join $nl
$t73a = @(
    '    UINT64 _fgFramePresentId = 0;'
    '    UINT64 _lastFGFramePresentId = 0;'
    ''
    '  public:'
    '    // P2/E2c12 (T73): the frame the frame GENERATOR consumes is the resource the game tags as'
    '    // ScalingOutputColor (4) -- never the swapchain backbuffer (53, which this game never tags).'
    '    // A backend that can warp it hands back a replacement the tag will point at instead.'
    '    // Default: no substitution, i.e. nothing changes for anyone else.'
    '    // gameList = the command list the game handed Streamline with the tag: recording there is'
    '    // the only ordering guarantee that our warp runs AFTER this frame and BEFORE the consumer.'
    '    virtual ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
    '                                                                     uint32_t declaredState)'
    '    {'
    '        (void) color; (void) gameList; return nullptr;'
    '    }'
    ''
    '  protected:'
) -join $nl
Queue-ReplaceLiteral 'framegen\IFGFeature_Dx12.h' $t73aAnchor $t73a 'T73a IFGFeature_Dx12.h: a hook for substituting the tagged ScalingOutputColor'

$t73bAnchor = '    bool WaitForSCAllocator(int index);'
$t73b = @(
    '    bool WaitForSCAllocator(int index);'
    '    // P2/E2c12 (T73): Route A -- warp the frame the frame generator eats into OUR texture and hand'
    '    // it back so the caller can point the ScalingOutputColor tag at it. No swapchain write anywhere.'
    '    ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
    '                                                        uint32_t declaredState) override final;'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.h' $t73bAnchor $t73b 'T73b Reprojection_Dx12.h: the tag-warp override'

$t73cAnchor = '    std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;   // P2: re-composites the game UI over the warp'
$t73c = @(
    '    std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;   // P2: re-composites the game UI over the warp'
    '    // P2/E2c12 (T73): the texture the ScalingOutputColor tag is substituted with. Its desc is'
    '    // COPIED FROM THE TAGGED RESOURCE (format and size must match what the generator expects).'
    '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwTagOut;'
    '    UINT _lwTagW = 0;'
    '    UINT _lwTagH = 0;'
    '    DXGI_FORMAT _lwTagFmt = DXGI_FORMAT_UNKNOWN;'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.h' $t73cAnchor $t73c 'T73c Reprojection_Dx12.h: the tag-warp output texture'

# ---------------------------------------------------------------------------
# T73d (E2c12): the implementation. Reads the game colour and depth, writes OUR texture, submits on
# the game queue with the same slot fence the present path uses, and hands the texture back. The
# swapchain is never touched -- that is the whole point of Route A after the round-141 crash.
# ---------------------------------------------------------------------------
$t73dAnchor = @(
    '    LOG_INFO("latewarp-e2c: adopted the game swapchain {:X} (queue {:X}, hwnd {:X}), no FG swapchain",'
    '             (size_t) swapChain, (size_t) queue, (size_t) hwnd);'
    '}'
) -join $nl
$t73d = @(
    '// P2/E2c12 (T73): WARP THE FRAME THE FRAME GENERATOR EATS -- WITHOUT TOUCHING THE SWAPCHAIN.'
    '// The tag inventory (decoded against sl_core_types.h) says the game tags 0 Depth, 1 MotionVectors,'
    '// 2 HUDLessColor, 3 ScalingInputColor, 4 ScalingOutputColor, 29 BiasCurrentColorHint, and NEVER 53'
    '// (Backbuffer). The generator interpolates the ScalingOutputColor, so warping the swapchain on the'
    '// present chain could never reach it -- that is the semi-transparent layer (only ~1/3 of the'
    '// displayed frames carried the warp). Here the game resources are only READ and the result goes to'
    '// OUR texture, which the caller then puts into the tag. Nothing about the swapchain changes.'
    'ID3D12Resource* Reprojection_Dx12::LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
    '                                                           uint32_t declaredState)'
    '{'
    '    if (color == nullptr || _device == nullptr || _gameCommandQueue == nullptr)'
    '        return nullptr;'
    ''
    '    if (!Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() || !p2::IsRuntimeEnabled())'
    '        return nullptr;'
    ''
    '    p2::LwCameraPose lwCur {};'
    '    p2::LwCameraPose lwPrev {};'
    '    if (!p2::AdvanceStreamlineCameraPose(lwCur, lwPrev))'
    '        return nullptr;'
    ''
    '    float lwW2V[16] = {};'
    '    float lwPW2V[16] = {};'
    '    if (!p2::BuildWorldToView(lwCur.right, lwCur.up, lwCur.fwd, lwCur.pos, lwW2V))'
    '        return nullptr;'
    '    if (!p2::BuildWorldToView(lwPrev.right, lwPrev.up, lwPrev.fwd, lwPrev.pos, lwPW2V))'
    '        return nullptr;'
    ''
    '    const p2::FrameData lwFrame = p2::GetFrameData();'
    '    if (!lwFrame.hasCurrent || !lwFrame.hasPrevious)'
    '        return nullptr;'
    ''
    '    auto lwDepth = GetResource(FG_ResourceType::Depth, GetIndex());'
    '    if (!lwDepth || lwDepth->GetResource() == nullptr)'
    '        return nullptr;'
    ''
    '    const auto lwDesc = color->GetDesc();'
    '    if (_lwTagOut == nullptr || _lwTagW != (UINT) lwDesc.Width || _lwTagH != lwDesc.Height ||'
    '        _lwTagFmt != lwDesc.Format)'
    '    {'
    '        _lwTagOut.Reset();'
    '        auto lwHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);'
    '        auto lwTd = CD3DX12_RESOURCE_DESC::Tex2D(lwDesc.Format, (UINT) lwDesc.Width, lwDesc.Height, 1, 1, 1, 0,'
    '                                                 D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS |'
    '                                                     D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET);'
    '        if (FAILED(_device->CreateCommittedResource(&lwHeap, D3D12_HEAP_FLAG_NONE, &lwTd,'
    '                                                    D3D12_RESOURCE_STATE_COMMON, nullptr,'
    '                                                    IID_PPV_ARGS(&_lwTagOut))))'
    '        {'
    '            _lwTagOut.Reset();'
    '            LOG_ERROR("latewarp-e2c12: tag warp target {}x{} format {} could not be created",'
    '                      (UINT) lwDesc.Width, lwDesc.Height, (int) lwDesc.Format);'
    '            return nullptr;'
    '        }'
    '        _lwTagW = (UINT) lwDesc.Width;'
    '        _lwTagH = lwDesc.Height;'
    '        _lwTagFmt = lwDesc.Format;'
    '        LOG_INFO("latewarp-e2c12: tag warp target {}x{} format {} created (desc copied from the tagged ScalingOutputColor, sourceFlags 0x{:X})",'
    '                 _lwTagW, _lwTagH, (int) _lwTagFmt, (UINT) lwDesc.Flags);'
    '    }'
    ''
    '    const int lwIdx = GetIndex();'
    '    // P2/E2c14: RECORD ON THE GAME OWN LIST when we have it. Our own list is SUBMITTED from'
    '    // here, i.e. before this frame has finished on the GPU, so the kernel would warp the'
    '    // PREVIOUS frame. The list the game hands to slSetTag is ordered AFTER its own frame'
    '    // commands, which is precisely the guarantee needed (the prior art calls this the'
    '    // insertion point: after the upscaler, before the UI). No close, no submit, no fence.'
    '    const bool lwOwnList = (gameList == nullptr);'
    '    WaitForSCAllocator(lwIdx);'
    '    ID3D12GraphicsCommandList* lwList = lwOwnList ? GetSCCommandList(lwIdx) : gameList;'
    '    if (lwList == nullptr)'
    '        return nullptr;'
    ''
    '    const float* lwMat = _latewarp.MatrixRingRef().Bind(lwW2V, lwFrame.viewToClip, lwPW2V, lwFrame.prevViewToClip);'
    ''
    '    p2::Inputs lwIn {};'
    '    lwIn.outputWidth = _lwTagW;'
    '    lwIn.outputHeight = _lwTagH;'
    '    lwIn.hudlessColor = color;   // the world image the generator is about to interpolate'
    '    lwIn.backbuffer = color;'
    '    lwIn.depth = lwDepth->GetResource();'
    '    lwIn.output = _lwTagOut.Get();'
    '    lwIn.worldToView = lwMat + 0;'
    '    lwIn.viewToClip = lwMat + 16;'
    '    lwIn.prevWorldToView = lwMat + 32;'
    '    lwIn.prevViewToClip = lwMat + 48;'
    '    lwIn.jitterX = lwFrame.prevJitter[0];'
    '    lwIn.jitterY = lwFrame.prevJitter[1];'
    '    lwIn.isRenderedFrame = 0;'
    '    lwIn.nullOutUIColorAlpha = true;'
    ''
    '    if (!_latewarp.Init(_device, lwList, lwIn))'
    '    {'
    '        static int lwTagInitFail = 0;'
    '        if (lwTagInitFail < 5)'
    '            LOG_WARN("latewarp-e2c12: tag-side kernel Init FAILED ({}x{} format {}) -- no substitution this frame",'
    '                     _lwTagW, _lwTagH, (int) _lwTagFmt);'
    '        ++lwTagInitFail;'
    '        return nullptr;'
    '    }'
    '    if (!_latewarp.Evaluate(lwList, lwIn))'
    '    {'
    '        static int lwTagEvalFail = 0;'
    '        if (lwTagEvalFail < 5)'
    '            LOG_WARN("latewarp-e2c12: tag-side kernel Evaluate FAILED ({}x{} format {}) -- no substitution this frame",'
    '                     _lwTagW, _lwTagH, (int) _lwTagFmt);'
    '        ++lwTagEvalFail;'
    '        return nullptr;'
    '    }'
    ''
    '    // P2/E2c16: THE IN-PLACE ALTERNATIVE (opt-in). If the substitution is not honoured, put the'
    '    // warp where the generator already looks: copy our result INTO the game hudless texture and'
    '    // let the original tag through untouched. That is only defensible because (a) the hudless is'
    '    // an FG-only tag -- nothing else consumes it -- and (b) the StateBefore comes from the tag'
    '    // contract itself. Returns nullptr, which the caller reads as no substitution.'
    '    if (Config::Instance()->LatewarpTagWarpInPlace.value_or_default() && declaredState != 0u &&'
    '        declaredState != 0xFFFFFFFFu)'
    '    {'
    '        D3D12_RESOURCE_BARRIER lwIP[2] = {};'
    '        lwIP[0].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '        lwIP[0].Transition.pResource = color;'
    '        lwIP[0].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '        lwIP[0].Transition.StateBefore = (D3D12_RESOURCE_STATES) declaredState;'
    '        lwIP[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;'
    '        lwIP[1].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '        lwIP[1].Transition.pResource = _lwTagOut.Get();'
    '        lwIP[1].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '        lwIP[1].Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;'
    '        lwIP[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '        lwList->ResourceBarrier(2, lwIP);'
    '        lwList->CopyResource(color, _lwTagOut.Get());'
    '        lwIP[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;'
    '        lwIP[0].Transition.StateAfter = (D3D12_RESOURCE_STATES) declaredState;'
    '        lwIP[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '        lwIP[1].Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;'
    '        lwList->ResourceBarrier(2, lwIP);'
    ''
    '        static int lwInPlaceLog = 0;'
    '        if (lwInPlaceLog < 5)'
    '            LOG_INFO("latewarp-e2c16: IN-PLACE write-back into the game hudless ({:X}, declaredState {})",'
    '                     (size_t) color, declaredState);'
    '        ++lwInPlaceLog;'
    '        p2::SetLatewarpTagDriveOk();   // P2/E2c17: tell the present chain the frame is ALREADY'
    '                                       // warped (in place, before the UI composite), so it must'
    '                                       // not warp it again -- a second pass would also warp the'
    '                                       // UI and leave a HUD ghost against the generated frames.'
    '        return nullptr;'
    '    }'
    ''
    '    // The tag we hand over declares NON_PIXEL_SHADER_RESOURCE, so the texture has to BE in'
    '    // that state on the GPU: transition it right here, on our own list, before submitting.'
    '    {'
    '        D3D12_RESOURCE_BARRIER lwPub = {};'
    '        lwPub.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '        lwPub.Transition.pResource = _lwTagOut.Get();'
    '        lwPub.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '        lwPub.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;'
    '        lwPub.Transition.StateAfter = D3D12_RESOURCE_STATE_ALL_SHADER_RESOURCE;'
    '        lwList->ResourceBarrier(1, &lwPub);'
    '    }'
    ''
    '    if (lwOwnList)'
    '    {'
    '        if (lwList->Close() != S_OK)'
    '            return nullptr;'
    ''
    '        _gameCommandQueue->ExecuteCommandLists(1, (ID3D12CommandList**) &lwList);'
    '        if (_scFence != nullptr)'
    '        {'
    '            static UINT64 lwTagFenceValue = 0;'
    '            _scAllocatorFenceValues[lwIdx] = ++lwTagFenceValue;'
    '            _gameCommandQueue->Signal(_scFence, _scAllocatorFenceValues[lwIdx]);'
    '        }'
    '    }'
    ''
    '    float lwTagTurn = 0.0f;'
    '    p2::ForwardAngleDeg(lwCur.fwd, lwPrev.fwd, &lwTagTurn);'
    ''
    '    static int lwTagLog = 0;'
    '    if (lwTagLog < 5 || (lwTagLog % 300) == 0)'
    '        LOG_INFO("latewarp-e2c12: the frame generator is handed OUR warped texture ({}x{} format {}, pose turn {:.2f} deg, tag drive #{})",'
    '                 _lwTagW, _lwTagH, (int) _lwTagFmt, lwTagTurn, lwTagLog);'
    '    ++lwTagLog;'
    ''
    '    return _lwTagOut.Get();'
    '}'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t73dAnchor ($t73d) 'T73d Reprojection_Dx12.cpp: warp the tagged ScalingOutputColor into our own texture'

# ---------------------------------------------------------------------------
# T73e (E2c12): the substitution itself. The tag array is COPIED so the game memory is never
# modified; the copied entry for ScalingOutputColor points at our warped texture (keeping the
# resource type/state/flags the game declared). If the backend cannot produce one, the original
# call is forwarded untouched.
# ---------------------------------------------------------------------------
$t73eAnchor = @(
    '    lwProbeBackbufferTag(tags, numTags, "slSetTag");   // P2/E2c11c: AFTER the resource push'
    ''
    '    auto result = o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    return result;'
    '}'
) -join $nl
$t73e = @(
    '    lwProbeBackbufferTag(tags, numTags, "slSetTag");   // P2/E2c11c: AFTER the resource push'
    ''
    '    // P2/E2c12/T75: ROUTE A -- hand the frame GENERATOR our warped frame.'
    '    // The right tag is the HUDLESS one (type 2), NOT the ScalingOutputColor (type 4):'
    '    //   sl_dlss_g.h says DLSSG supports interpolating HUDless and UI Color & Alpha SEPARATELY'
    '    //   from the Color Backbuffer, and our own FG-input mapping consumes exactly 0 Depth /'
    '    //   1 MotionVectors / 2 HudlessColor / 23 UIColorAndAlpha. The ScalingOutputColor was the'
    '    //   wrong target -- the GAME itself blits that one, so touching it is neither needed nor'
    '    //   safe. The hudless is an FG-only tag, so substituting it cannot disturb anything else.'
    '    // The game resources are only READ; the warp goes to OUR texture (round-141 crash lesson).'
    '    // P2/E2c15: A NULL RESULT MUST BE EXPLAINABLE. If the hudless tag arrives while the'
    '    // latewarp is NOT armed (or the ini switch is off) the substitution is skipped in'
    '    // silence, and the log would simply contain no e2c12 line at all -- indistinguishable'
    '    // from the tag never having arrived. Say which one it is, once.'
    '    if (tags != nullptr && numTags > 0 &&'
    '        (!p2::IsRuntimeEnabled() ||'
    '         !Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default()))'
    '    {'
    '        for (uint32_t i = 0; i < numTags; ++i)'
    '        {'
    '            if (tags[i].type != sl::kBufferTypeHUDLessColor)'
    '                continue;'
    '            static int lwDeclined = 0;'
    '            if (lwDeclined < 5)'
    '                LOG_INFO("latewarp-e2c12: HUDLESS tag seen but the substitution is OFF (runtime {}, switch {}) -- arm the takeover",'
    '                         p2::IsRuntimeEnabled(),'
    '                         Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default());'
    '            ++lwDeclined;'
    '            break;'
    '        }'
    '    }'
    ''
    '    if (tags != nullptr && numTags > 0 && numTags <= 8 && p2::IsRuntimeEnabled() &&'
    '        Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default())'
    '    {'
    '        sl::ResourceTag lwSwap[8] = {};'
    '        sl::Resource lwOurs {};'
    '        bool lwSubstituted = false;'
    ''
    '        for (uint32_t i = 0; i < numTags; ++i)'
    '        {'
    '            lwSwap[i] = tags[i];'
    ''
    '            // P2/E2c17: WHICH TAG DEPENDS ON THE MECHANISM.'
    '            //  * in-place: the SCALING OUTPUT COLOUR (4). The game composites the UI onto the'
    '            //    backbuffer FROM it, so warping it here propagates into the frame the generator'
    '            //    interpolates. (CP2077 never tags UIColorAndAlpha, so DLSS-G UI recomposition --'
    '            //    the only codepath that would interpolate the HUDLESS -- cannot be active.)'
    '            //  * substitution: the HUDLESS (2); harmless if unused, and it is the right input if'
    '            //    the recomposition codepath is ever active.'
    '            // P2/E2c20: the in-place warp moved to the UPSCALER EVALUATE (see hkslEvaluateFeature);'
    '            // at the tag the frame is already built, so acting here would be too late. The'
    '            // substitution keeps the hudless tag -- that is its own mechanism.'
    '            const bool lwInteresting = !Config::Instance()->LatewarpTagWarpInPlace.value_or_default() &&'
    '                                      tags[i].type == sl::kBufferTypeHUDLessColor;'
    '            if (lwSubstituted || !lwInteresting || tags[i].resource == nullptr ||'
    '                tags[i].resource->native == nullptr)'
    '                continue;'
    ''
    '            auto* lwFg = State::Instance().currentFG;'
    '            if (lwFg == nullptr)'
    '                continue;'
    ''
    '            if (auto* lwWarped = lwFg->LatewarpWarpTaggedColor((ID3D12Resource*) tags[i].resource->native,'
    '                                                             (ID3D12GraphicsCommandList*) cmdBuffer,'
    '                                                             (uint32_t) tags[i].resource->state))'
    '            {'
    '                // sl_core_types.h is explicit: state is MANDATORY and must be CORRECT, and the'
    '                // view/size fields describe THAT resource. Copying the game struct verbatim handed'
    '                // Streamline the GAME frame state (a render target) with OUR native pointer, which'
    '                // is exactly the kind of mismatch that makes an interposer ignore a resource.'
    '                lwOurs = *tags[i].resource;   // keep the type/flags the game declared'
    '                lwOurs.memory = nullptr;'
    '                lwOurs.view = nullptr;   // the game view (if any) points at ITS resource'
    '                // ALL_SHADER_RESOURCE (compute OR pixel) -- DLSS-G reads it in a compute pass;'
    '                lwOurs.state = D3D12_RESOURCE_STATE_ALL_SHADER_RESOURCE;'
    '                const auto lwOd = ((ID3D12Resource*) lwWarped)->GetDesc();'
    '                lwOurs.width = (uint32_t) lwOd.Width;'
    '                lwOurs.height = lwOd.Height;'
    '                lwOurs.nativeFormat = (uint32_t) lwOd.Format;'
    '                lwOurs.native = lwWarped;'
    '                lwSwap[i].resource = &lwOurs;'
    '                lwSubstituted = true;'
    ''
    '                static int lwSubLog = 0;'
    '                if (lwSubLog < 5)'
    '                    LOG_INFO("latewarp-e2c12: HUDLESS tag substituted with our warped texture ({:X} -> {:X}, declaredState {}, flags 0x{:X})",'
    '                             (size_t) tags[i].resource->native, (size_t) lwWarped, (UINT) tags[i].resource->state,'
    '                             (UINT) ((ID3D12Resource*) tags[i].resource->native)->GetDesc().Flags);'
    '                ++lwSubLog;'
    '            }'
    '        }'
    ''
    '        if (lwSubstituted)'
    '        {'
    '            auto lwResult = o_slSetTag(viewport, lwSwap, numTags, cmdBuffer);'
    '            return lwResult;'
    '        }'
    '    }'
    ''
    '    auto result = o_slSetTag(viewport, tags, numTags, cmdBuffer);'
    '    return result;'
    '}'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t73eAnchor $t73e 'T73e Streamline_Hooks.cpp: substitute the ScalingOutputColor tag with our warped frame'

# ---------------------------------------------------------------------------
# T74 (E2c12b): ONE POSE PAIR PER FRAME.
# The tag path warps the frame the GENERATOR eats; the present chain then warps the DISPLAYED frame.
# Both call AdvanceStreamlineCameraPose, and that advances on every new slSetConstants sample (4-5 per
# rendered frame), so the second call would use a NEWER pair than the first -- the real and the
# generated frames would then be offset by a sub-frame of motion (~1 deg / ~16 px) and keep a residual
# ghost. Pinning the pair at the tag and reusing it in the present path keeps them identical.
# ---------------------------------------------------------------------------
$t74aAnchor = '    const bool lwPoseOk = p2::AdvanceStreamlineCameraPose(lwPoseCur, lwPosePrev);'
$t74a = @(
    '    // P2/E2c12b: if the tag path already warped this frame, reuse ITS pose pair instead of'
    '    // advancing again -- the generator frame and the displayed frame must share one pose.'
    '    const bool lwPoseOk = p2::LatewarpPosePinned() ? p2::CurrentLatewarpPosePair(lwPoseCur, lwPosePrev)'
    '                                                  : p2::AdvanceStreamlineCameraPose(lwPoseCur, lwPosePrev);'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t74aAnchor $t74a 'T74a Reprojection_Dx12.cpp: the present path reuses the pose pair the tag path warped with'

$t74bAnchor = '    return _lwTagOut.Get();'
$t74b = @(
    '    p2::PinLatewarpPosePair();   // P2/E2c12b: the present chain must warp the DISPLAYED frame with'
    '                                 // this very pair, or the two frames would disagree.'
    ''
    '    return _lwTagOut.Get();'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t74bAnchor $t74b 'T74b Reprojection_Dx12.cpp: pin the pose pair when the generator frame was warped'

# ---------------------------------------------------------------------------
# T76 (E2c16): THE IN-PLACE ALTERNATIVE, OPT-IN. If Streamline does not honour the tag
# substitution, the other way to get the warp into the generator is to put it where the generator
# already looks: warp the GAME HUDLESS texture in place (the prior art reached the same conclusion:
# IN-PLACE WRITE-BACK removes the substitution). That is only defensible for a texture NOTHING else
# consumes -- the hudless is an FG-only tag -- and it is a write into a game resource, which is why
# it ships OFF and is a separate switch from the substitution.
# ---------------------------------------------------------------------------
$t76aAnchor = 'CustomOptional<float> LatewarpWarpStrength { 1.0f };   // P3-E2c6: how much of the warp the composite applies (1 = the old hard swap, 0 = none)'
$t76a = @(
    'CustomOptional<bool> LatewarpTagWarpInPlace { false };   // P3-E2c16: copy the warped frame INTO the game hudless instead of substituting the tag'
) -join $nl
Queue-InsertAfter 'Config.h' $t76aAnchor ($t76a -join $nl) 'T76a Config.h += Latewarp.TagWarpInPlace (default off)'

$t76bAnchor = '        LatewarpWarpStrength.set_from_config(readFloat("Latewarp", "WarpStrength"));'
$t76b = @(
    '        LatewarpTagWarpInPlace.set_from_config(readBool("Latewarp", "TagWarpInPlace"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t76bAnchor ($t76b -join $nl) 'T76b Config.cpp += read Latewarp.TagWarpInPlace'

# The save insert must sit AFTER the COMPLETE two-line statement: anchoring on its first line only
# split it (C2143) -- the second lesson of this kind in one round.
$t76c2Anchor = @(
    '        ini.SetValue("Latewarp", "WarpStrength",'
    '                     GetFloatValue(Instance()->LatewarpWarpStrength.value_for_config()).c_str());'
) -join $nl
$t76c2 = @(
    '        ini.SetValue("Latewarp", "TagWarpInPlace",'
    '                     Instance()->LatewarpTagWarpInPlace.value_or_default() ? "true" : "false");'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t76c2Anchor ($t76c2 -join $nl) 'T76c Config.cpp += save Latewarp.TagWarpInPlace'

# ---------------------------------------------------------------------------
# T77 (E2c20, MECHANISM C): THE INSERTION POINT THE PRIOR ART IDENTIFIED.
# The prior art (PLAN_cyberpunk_reflex2.md:304-305) is explicit: hook slEvaluateFeature and, AFTER
# the original returns, enqueue our compute on the SAME command list -- at that moment DLSS is done
# and the UI has NOT been drawn yet. That is what makes the warp land in the frame the game then
# composites and the frame generator then interpolates. Doing it at the ScalingOutputColor TAG was
# too late: a tag DECLARES a frame that is already built (the tag order is not a write order), which
# is why the tag-side in-place mode could do nothing. The resource pointer is cached from the tag
# (it is a persistent game texture), and the switch is the same opt-in one.
# ---------------------------------------------------------------------------
# The anchor must NOT include the closing brace: Queue-InsertAfter appends after the WHOLE anchor, and
# a brace-terminated anchor puts the block outside the function (that slipped through once here).
# Anchor on the CALL ONLY, and let the block contain nothing but itself: the insert lands between the
# call and the existing return, inside the function. (Two earlier attempts failed on exactly this:
# an anchor that included the return put the block after it -- unreachable code -- and repeating the
# anchor line duplicated it.)
$t77Anchor = '    auto result = o_slEvaluateFeature(feature, frame, inputs, numInputs, cmdBuffer);'
$t77 = @(
    ''
    '    // P2/E2c20 (MECHANISM C): DLSS is done, the UI is not drawn yet -- warp the frame HERE.'
    '    // Same opt-in switch as the (removed) tag-side in-place mode; the game keeps its list.'
    '    if ((feature == sl::kFeatureDLSS || feature == sl::kFeatureDLSS_RR) &&'
    '        Config::Instance()->LatewarpTagWarpInPlace.value_or_default() && p2::IsRuntimeEnabled() &&'
    '        g_lwScalingOut != nullptr && cmdBuffer != nullptr)'
    '    {'
    '        if (auto* lwFgEval = State::Instance().currentFG; lwFgEval != nullptr)'
    '            lwFgEval->LatewarpWarpTaggedColor(g_lwScalingOut, (ID3D12GraphicsCommandList*) cmdBuffer,'
    '                                              g_lwScalingOutState);'
    '    }'
) -join $nl
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t77Anchor ($t77) 'T77 Streamline_Hooks.cpp: mechanism C -- warp at the upscaler evaluate, after DLSS, before the UI'

# ---------------------------------------------------------------------------
# T78 (E2c21): THE VIEWMODEL MUST NOT BE WARPED. The first successful run (19:10) showed the effect
# working everywhere EXCEPT the weapon, which double-images -- the kernel warps the whole frame, and
# in mechanism-C mode it is given NO NoWarpMask and the depth cutout is disabled (DepthCutoff=1.0).
# The mask that freezes the viewmodel is produced by the composite (depth cutout + UI diff); in C
# mode the present pass must therefore still RUN, but as a MASK REFRESHER only:
#   * its WarpStrength is forced to 0, which makes its output bit-identical to `present`;
#   * and the kernel of the NEXT frame consumes that mask.
# ---------------------------------------------------------------------------
$t78aAnchor = '    lwIn.output = _lwTagOut.Get();'
$t78a = @(
    '    lwIn.output = _lwTagOut.Get();'
    '    // P2/E2c21: hand the kernel the mask that freezes the viewmodel. The composite writes it'
    '    // (depth cutout + UI), and it is kept for the next frame; without it the weapon doubles.'
    '    if (_latewarpUi != nullptr && _latewarpUi->HasMask())'
    '    {'
    '        lwIn.noWarpMask = _latewarpUi->MaskForKernel();'
    '        lwIn.subrect[6][0] = 0;'
    '        lwIn.subrect[6][1] = 0;'
    '        lwIn.subrect[6][2] = (int32_t) _lwTagW;'
    '        lwIn.subrect[6][3] = (int32_t) _lwTagH;'
    '    }'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t78aAnchor $t78a 'T78a Reprojection_Dx12.cpp: the tag/C path hands the kernel the viewmodel mask'

$t78bAnchor = '    if (p2::IsRuntimeEnabled() && !p2::LatewarpAtTag() && p2::LatewarpTagDriveRecent())'
$t78b = @(
    '    // P2/E2c21: in mechanism-C mode the frame is ALREADY warped in place before the UI composite,'
    '    // so this pass must not warp it again -- but it must still RUN, because it is what produces'
    '    // the NoWarpMask the kernel consumes on the next frame. With WarpStrength 0 its output is'
    '    // bit-identical to `present`, so it only refreshes the mask.'
    '    if (p2::IsRuntimeEnabled() && !p2::LatewarpAtTag() && p2::LatewarpTagDriveRecent() &&'
    '        !Config::Instance()->LatewarpTagWarpInPlace.value_or_default())'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t78bAnchor $t78b 'T78b Reprojection_Dx12.cpp: C mode keeps the present pass alive as a mask refresher'

$t78cAnchor = '                    lwUiParams.WarpStrength = Config::Instance()->LatewarpWarpStrength.value_or_default();'
$t78c = @(
    '                    // P2/E2c21: mechanism-C mode uses this pass as a MASK REFRESHER: strength 0'
    '                    // leaves the picture untouched (color = present) while the shader still writes'
    '                    // the NoWarpMask the kernel reads next frame.'
    '                    lwUiParams.WarpStrength = Config::Instance()->LatewarpTagWarpInPlace.value_or_default()'
    '                                                  ? 0.0f'
    '                                                  : Config::Instance()->LatewarpWarpStrength.value_or_default();'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t78cAnchor $t78c 'T78c Reprojection_Dx12.cpp: strength 0 in C mode (mask refresher)'

# ---------------------------------------------------------------------------
# T80 (E2c23): THE VIEWMODEL MASK IS OPT-IN, AND OFF IN MECHANISM C.
# Measured on the 19:35 run (E2c21 + DepthCutoff 0.10): the mask went from
# `cutout 0.00%` to `cutout 9.16% ... 45.62%` -- a tenth to nearly half of the frame was
# being told NOT to warp. Half the picture turning with the camera and half not IS the
# 'jelly' the user reported, and the hard 1-bit blue-noise boundary plus the stale UI
# patches are the 'breakage'.
# The root reason is structural: in mechanism C the target of the warp is the UPSCALER
# OUTPUT. It carries no UI and no viewmodel -- the game composites both AFTER us -- so a
# mask computed from the composited frame marks content that does not exist in the image
# being warped. Freezing it can only leave stale patches behind. The mask therefore stays
# for mechanism A (where the warped image is the composited frame and the freeze is real)
# and becomes an OPT-IN experiment in C mode.
# ---------------------------------------------------------------------------
$t80aAnchor = 'CustomOptional<bool> LatewarpTagWarpInPlace { false };   // P3-E2c16: copy the warped frame INTO the game hudless instead of substituting the tag'
$t80a = @(
    'CustomOptional<bool> LatewarpViewmodelMask { false };   // P2/E2c23: C mode warps UNIFORMLY by default; the NoWarpMask freeze is opt-in (measured: 9-46% of the frame) '
) -join $nl
Queue-InsertAfter 'Config.h' $t80aAnchor ($t80a -join $nl) 'T80a Config.h += Latewarp.ViewmodelMask (default off)'

$t80bAnchor = '        LatewarpTagWarpInPlace.set_from_config(readBool("Latewarp", "TagWarpInPlace"));'
$t80b = @(
    '        LatewarpViewmodelMask.set_from_config(readBool("Latewarp", "ViewmodelMask"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t80bAnchor ($t80b -join $nl) 'T80b Config.cpp += read Latewarp.ViewmodelMask'

$t80cAnchor = @(
    '        ini.SetValue("Latewarp", "TagWarpInPlace",'
    '                     Instance()->LatewarpTagWarpInPlace.value_or_default() ? "true" : "false");'
) -join $nl
$t80c = @(
    '        ini.SetValue("Latewarp", "ViewmodelMask",'
    '                     Instance()->LatewarpViewmodelMask.value_or_default() ? "true" : "false");'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t80cAnchor ($t80c -join $nl) 'T80c Config.cpp += save Latewarp.ViewmodelMask'

$t80dAnchor = @(
    '    // P2/E2c21: hand the kernel the mask that freezes the viewmodel. The composite writes it'
    '    // (depth cutout + UI), and it is kept for the next frame; without it the weapon doubles.'
    '    if (_latewarpUi != nullptr && _latewarpUi->HasMask())'
) -join $nl
$t80d = @(
    '    // P2/E2c21: hand the kernel the mask that freezes the viewmodel. The composite writes it'
    '    // (depth cutout + UI), and it is kept for the next frame; without it the weapon doubles.'
    '    // P2/E2c23: ...but in mechanism C it is OPT-IN ONLY, and off by default. Measured on the'
    '    // 19:35 run: DepthCutoff 0.10 froze 9.16% - 45.62% of the frame (before: 0.00%), which'
    '    // is the jelly on turns, and its hard edge plus the stale UI patches are the breakage.'
    '    // In C mode the warped image is the upscaler output: no UI, no viewmodel (the game'
    '    // composites both AFTER this point), so the mask marks content that is not in the image.'
    '    if (_latewarpUi != nullptr && _latewarpUi->HasMask() &&'
    '        (!Config::Instance()->LatewarpTagWarpInPlace.value_or_default() ||'
    '         Config::Instance()->LatewarpViewmodelMask.value_or_default()))'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t80dAnchor $t80d 'T80d Reprojection_Dx12.cpp: the viewmodel mask is opt-in in C mode'

$t80eAnchor = '        ImGui::TextUnformatted("\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE7\xBB\x93\xE8\xB6\x8A\xE5\xB0\x91\xEF\xBC\x9B\x30\x2E\x33\x35\x20\xE5\xA4\xAA\xE9\xAB\x98\xEF\xBC\x88\xE7\xAD\x89\xE4\xBA\x8E\xE6\xB2\xA1\xE5\xBC\x80\xEF\xBC\x89\xEF\xBC\x8C\xE8\xAF\x95\x20\x30\x2E\x31\x30");'
$t80e = @(
    '        // P2/E2c23: the mask switch. OFF = warp UNIFORMLY (the 19:10 look). ON = the'
    '        // kernel freezes the masked pixels: measurable, but it freezes 9-46% of the frame.'
    '        bool p2ViewModelMask = Config::Instance()->LatewarpViewmodelMask.value_or_default();'
    '        if (ImGui::Checkbox("\xE6\xAD\xA6\xE5\x99\xA8\xE9\x81\xAE\xE7\xBD\xA9 Viewmodel mask (C mode: OFF = warp everything)", &p2ViewModelMask))'
    '            Config::Instance()->LatewarpViewmodelMask = p2ViewModelMask;'
    '        ImGui::TextUnformatted("\xE9\xBB\x98\xE8\xAE\xA4\xE5\x85\xB3\xEF\xBC\x9B\xE5\xBC\x80\xE5\x90\xAF\xE5\x90\x8E\x20\x6D\x61\x73\x6B\x20\xE4\xBC\x9A\xE5\x86\xBB\xE4\xBD\x8F\xE5\xA4\xA7\xE7\x89\x87\xE8\xBF\x91\xE6\x99\xAF\xEF\xBC\x88\xE6\x9E\x9C\xE5\x86\xBB\x2F\xE7\xA0\xB4\xE6\x8D\x9F\xEF\xBC\x89\xEF\xBC\x8C\xE5\x8F\xAA\xE4\xB8\xBA\xE5\xAE\x9E\xE9\xAA\x8C\xE4\xBF\x9D\xE7\x95\x99");'
) -join $nl
Queue-InsertAfter 'menu\menu_common.cpp' $t80eAnchor ($t80e -join $nl) 'T80e menu_common.cpp: the viewmodel-mask switch next to the cutoff slider'

# ---------------------------------------------------------------------------
# T81 (E2c24): THE MASK THRESHOLD SLIDER COULD SILENTLY DESTROY THE GOOD SETTING.
# `MaskThreshold` is the UI-difference half of the mask (smoothstep(T, 2T, |hudless-present|)) and
# the 19:35 run measured that difference at 0.4-0.75, so the user's working setting is T = 5.0
# (UI-diff term dead -> no motion-edge freezing -> no jelly). The panel slider was clamped to
# 0.0-0.5, so merely TOUCHING it rewrote 5.0 as <=0.5 and the jelly came back with no visible
# cause. Range widened to 0-10 and the label/hint now say what the value means.
# ---------------------------------------------------------------------------
$t81aAnchor = @(
    '        if (ImGui::SliderFloat("\xE9\x81\xAE\xE7\xBD\xA9\xE9\x98\x88\xE5\x80\xBC Mask threshold (0 = warp everything)",'
    '                               &p2MaskThreshold, 0.0f, 0.5f, "%.3f", ImGuiSliderFlags_Logarithmic))'
) -join $nl
$t81a = @(
    '        if (ImGui::SliderFloat("\xE9\x81\xAE\xE7\xBD\xA9\xE9\x98\x88\xE5\x80\xBC Mask threshold (UI-diff half; 1.0+ = off)",'
    '                               &p2MaskThreshold, 0.0f, 10.0f, "%.3f", ImGuiSliderFlags_Logarithmic))'
) -join $nl
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t81aAnchor $t81a 'T81a menu_common.cpp: the mask-threshold slider spans 0-10 so 5.0 (UI-diff off) is reachable'

$t81bAnchor = '        ImGui::TextUnformatted("\xE5\x8B\xBE\xE5\x88\xB0 0 \xE5\xB0\xB1\xE5\x85\xA8\xE5\xB1\x8F\xE9\x83\xBD\xE6\x89\xAD\xEF\xBC\x9B\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE4\xBD\x8F\xE7\x9A\x84\xE8\xB6\x8A\xE5\xA4\x9A");'
$t81b = @(
    '        ImGui::TextUnformatted("\x35\x2E\x30\x20\x3D\x20\x55\x49\x20\xE5\xB7\xAE\xE5\x88\x86\xE5\x85\xA8\xE5\x85\xB3\xEF\xBC\x88\xE6\x8E\xA8\xE8\x8D\x90\xEF\xBC\x8C\xE9\x98\xB2\xE6\xAD\xA2\xE8\xBF\x90\xE5\x8A\xA8\xE8\xBE\xB9\xE7\xBC\x98\xE8\xA2\xAB\xE5\x86\xBB\xE7\xBB\x93\xE6\x88\x90\xE6\x9E\x9C\xE5\x86\xBB\xEF\xBC\x89\xEF\xBC\x9B\x30\x2D\x30\x2E\x35\x20\x3D\x20\xE5\xB7\xAE\xE5\x88\x86\xE5\xBC\x80\xE5\x90\xAF");'
) -join $nl
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t81bAnchor ($t81b -join $nl) 'T81b menu_common.cpp: the mask-threshold hint now says what 5.0 means'

# ---------------------------------------------------------------------------
# T83 (E2c26): HIGHLIGHT PROTECTION. A 1-2 px specular highlight is the most fragile
# content in the frame: the reprojection samples a few pixels away, lands on the dark
# surround and the highlight is gone -- the reported 'the lamp highlights vanish when I
# turn'. The fix is the same instrument the viewmodel uses (Latewarp.NoWarpMask), applied
# to a much smaller set of pixels: an ISOLATED bright point (bright AND far brighter than
# all four neighbours) is frozen, so it keeps its rendered value instead of being
# re-sampled. Large bright areas (sky, big lamps, muzzle flashes) fail the isolation test
# and stay warped, so the frozen area stays at a fraction of a percent.
# OPT-IN on purpose: the E2c25 meter decides whether this is the right fix before anyone
# plays with it on.
# ---------------------------------------------------------------------------
$t83aAnchor = 'CustomOptional<bool> LatewarpViewmodelMask { false };   // P2/E2c23: C mode warps UNIFORMLY by default; the NoWarpMask freeze is opt-in (measured: 9-46% of the frame) '
$t83a = @(
    'CustomOptional<bool>  LatewarpHighlightProtect   { false };   // P2/E2c26: freeze ISOLATED bright points (specular highlights) instead of re-sampling them'
    'CustomOptional<float> LatewarpHighlightThreshold { 1.5f };    // P2/E2c26: luminance above which a pixel counts as a highlight (HDR; tuned with the meter)'
) -join $nl
Queue-InsertAfter 'Config.h' $t83aAnchor ($t83a -join $nl) 'T83a Config.h += Latewarp.HighlightProtect + .HighlightThreshold (both default off/1.5)'

$t83bAnchor = '        LatewarpViewmodelMask.set_from_config(readBool("Latewarp", "ViewmodelMask"));'
$t83b = @(
    '        LatewarpHighlightProtect.set_from_config(readBool("Latewarp", "HighlightProtect"));'
    '        LatewarpHighlightThreshold.set_from_config(readFloat("Latewarp", "HighlightThreshold"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t83bAnchor ($t83b -join $nl) 'T83b Config.cpp += read the highlight-protection keys'

$t83cAnchor = @(
    '        ini.SetValue("Latewarp", "ViewmodelMask",'
    '                     Instance()->LatewarpViewmodelMask.value_or_default() ? "true" : "false");'
) -join $nl
$t83c = @(
    '        ini.SetValue("Latewarp", "HighlightProtect",'
    '                     Instance()->LatewarpHighlightProtect.value_or_default() ? "true" : "false");'
    '        ini.SetValue("Latewarp", "HighlightThreshold",'
    '                     GetFloatValue(Instance()->LatewarpHighlightThreshold.value_or_default()).c_str());'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t83cAnchor ($t83c -join $nl) 'T83c Config.cpp += save the highlight-protection keys'

$t83dAnchor = '                    lwUiParams.ShowMask = State::Instance().fgHudlessCompare ? 1.0f : 0.0f;'
$t83d = @(
    '                    // P2/E2c26: the highlight-protection term of the same mask (opt-in).'
    '                    lwUiParams.HighlightProtect = Config::Instance()->LatewarpHighlightProtect.value_or_default() ? 1.0f : 0.0f;'
    '                    lwUiParams.HighlightThreshold = Config::Instance()->LatewarpHighlightThreshold.value_or_default();'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t83dAnchor ($t83d -join $nl) 'T83d Reprojection_Dx12.cpp: hand the composite the highlight-protection switch + threshold'

$t83eAnchor = @(
    '    if (_latewarpUi != nullptr && _latewarpUi->HasMask() &&'
    '        (!Config::Instance()->LatewarpTagWarpInPlace.value_or_default() ||'
    '         Config::Instance()->LatewarpViewmodelMask.value_or_default()))'
) -join $nl
$t83e = @(
    '    if (_latewarpUi != nullptr && _latewarpUi->HasMask() &&'
    '        (!Config::Instance()->LatewarpTagWarpInPlace.value_or_default() ||'
    '         Config::Instance()->LatewarpViewmodelMask.value_or_default() ||'
    '         Config::Instance()->LatewarpHighlightProtect.value_or_default()))'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t83eAnchor $t83e 'T83e Reprojection_Dx12.cpp: the highlight protection can bind the mask on its own'

# ---------------------------------------------------------------------------
# T84 (E2c27): THE WARP SCALE DIAL. The kernel warps the frame FORWARD from prevWorldToView to
# worldToView (P3-DIR: 1 deg yaw -> f*tan(1deg) px), so scaling the pose DELTA scales the shift.
# 1.0 = today's behaviour; 0.0 = an identical pair, which the offline suite measured as a
# BIT-EXACT early-out. It exists because the residual highlight loss is suspected to grow with
# the shift (H3): the dial is both the test for that and, if it holds, the latency/artifact
# compromise. Ships at 1.0, i.e. nothing changes until it is moved.
# ---------------------------------------------------------------------------
$t84aAnchor = 'CustomOptional<float> LatewarpHighlightThreshold { 1.5f };    // P2/E2c26: luminance above which a pixel counts as a highlight (HDR; tuned with the meter)'
$t84a = @(
    'CustomOptional<float> LatewarpWarpScale { 1.0f };   // P2/E2c27: scale the pose delta (1 = full warp, 0 = no warp / bit-exact early-out)'
) -join $nl
Queue-InsertAfter 'Config.h' $t84aAnchor ($t84a -join $nl) 'T84a Config.h += Latewarp.WarpScale (default 1.0 = unchanged)'

$t84bAnchor = '        LatewarpHighlightThreshold.set_from_config(readFloat("Latewarp", "HighlightThreshold"));'
$t84b = @(
    '        LatewarpWarpScale.set_from_config(readFloat("Latewarp", "WarpScale"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t84bAnchor ($t84b -join $nl) 'T84b Config.cpp += read Latewarp.WarpScale'

$t84cAnchor = @(
    '        ini.SetValue("Latewarp", "HighlightThreshold",'
    '                     GetFloatValue(Instance()->LatewarpHighlightThreshold.value_or_default()).c_str());'
) -join $nl
$t84c = @(
    '        ini.SetValue("Latewarp", "WarpScale",'
    '                     GetFloatValue(Instance()->LatewarpWarpScale.value_or_default()).c_str());'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t84cAnchor ($t84c -join $nl) 'T84c Config.cpp += save Latewarp.WarpScale'

$t84dAnchor = @(
    '    p2::LwCameraPose lwCur {};'
    '    p2::LwCameraPose lwPrev {};'
    '    if (!p2::AdvanceStreamlineCameraPose(lwCur, lwPrev))'
    '        return nullptr;'
) -join $nl
$t84d = @(
    '    p2::LwCameraPose lwCur {};'
    '    p2::LwCameraPose lwPrev {};'
    '    if (!p2::AdvanceStreamlineCameraPose(lwCur, lwPrev))'
    '        return nullptr;'
    '    // P2/E2c27: the WARP SCALE dial (1.0 = unchanged). A scaled delta is a proportionally'
    '    // smaller shift; alpha 0 hands the kernel an identical pair, i.e. a bit-exact copy.'
    '    {'
    '        const float lwScale = Config::Instance()->LatewarpWarpScale.value_or_default();'
    '        if (lwScale < 1.0f && p2::ScaleLatewarpWarpDelta(lwPrev, lwCur, lwScale, &lwCur))'
    '            LOG_DEBUG("latewarp: warp scale {} applied to the tag/C delta", lwScale);'
    '    }'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t84dAnchor $t84d 'T84d Reprojection_Dx12.cpp: the tag/C path honours the warp scale'

# NOTE: the anchor is the line AFTER the two-line pose acquisition, not its first line. Anchoring
# on the first line put the inserted block BEFORE `const bool lwPoseOk = ...` existed (C2065) --
# the same class of mistake the T76c comment records for a split statement.
$t84eAnchor = '    const float* lwRightCur  = lwPoseOk ? lwPoseCur.right  : _cameraRight[fIndex];'
$t84e = @(
    '    // P2/E2c27: the SAME scale as the tag/C path -- the displayed frame and the generator'
    '    // frame must warp with one delta, or the two disagree by the difference.'
    '    if (lwPoseOk && Config::Instance()->LatewarpWarpScale.value_or_default() < 1.0f)'
    '        (void) p2::ScaleLatewarpWarpDelta(lwPosePrev, lwPoseCur,'
    '                                          Config::Instance()->LatewarpWarpScale.value_or_default(), &lwPoseCur);'
    '    const float* lwRightCur  = lwPoseOk ? lwPoseCur.right  : _cameraRight[fIndex];'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t84eAnchor $t84e 'T84e Reprojection_Dx12.cpp: the present path honours the same warp scale'

$t84fAnchor = '        ImGui::TextUnformatted("\xE9\xBB\x98\xE8\xAE\xA4\xE5\x85\xB3\xEF\xBC\x9B\xE5\xBC\x80\xE5\x90\xAF\xE5\x90\x8E\x20\x6D\x61\x73\x6B\x20\xE4\xBC\x9A\xE5\x86\xBB\xE4\xBD\x8F\xE5\xA4\xA7\xE7\x89\x87\xE8\xBF\x91\xE6\x99\xAF\xEF\xBC\x88\xE6\x9E\x9C\xE5\x86\xBB\x2F\xE7\xA0\xB4\xE6\x8D\x9F\xEF\xBC\x89\xEF\xBC\x8C\xE5\x8F\xAA\xE4\xB8\xBA\xE5\xAE\x9E\xE9\xAA\x8C\xE4\xBF\x9D\xE7\x95\x99");'
$t84f = @(
    '        // P2/E2c27: THE WARP SCALE. 1.0 = the full latewarp (today), 0.0 = no warp at all'
    '        // (the kernel early-outs bit-exact). It is the dial for the H3 test: if the highlight'
    '        // loss shrinks with the shift, it is the shift -- and this is also the compromise.'
    '        float p2WarpScale = Config::Instance()->LatewarpWarpScale.value_or_default();'
    '        if (ImGui::SliderFloat("\x77\x61\x72\x70\x20\xE5\xB9\x85\xE5\xBA\xA6 Warp scale (1 = full, 0 = none)", &p2WarpScale, 0.0f, 1.0f, "%.2f"))'
    '            Config::Instance()->LatewarpWarpScale = p2WarpScale;'
    '        ImGui::TextUnformatted("\x31\x2E\x30\x20\x3D\x20\xE4\xBB\x8A\xE5\xA4\xA9\xE7\x9A\x84\xE5\x85\xA8\xE6\x89\xAD\xEF\xBC\x9B\x30\x2E\x30\x20\x3D\x20\xE5\xAE\x8C\xE5\x85\xA8\xE4\xB8\x8D\xE6\x89\xAD\xEF\xBC\x88\xE5\x86\x85\xE6\xA0\xB8\xE9\x80\x90\xE4\xBD\x8D\xE6\x97\xA9\xE9\x80\x80\xEF\xBC\x89\xE3\x80\x82\xE7\x94\xA8\xE6\x9D\xA5\xE9\xAA\x8C\xE8\xAF\x81\xE3\x80\x8C\xE9\xAB\x98\xE5\x85\x89\xE6\x8D\x9F\xE5\xA4\xB1\xE6\x98\xAF\xE5\x90\xA6\xE9\x9A\x8F\xE4\xBD\x8D\xE7\xA7\xBB\xE5\xA2\x9E\xE9\x95\xBF\xE3\x80\x8D\xEF\xBC\x8C\xE4\xB9\x9F\xE6\x98\xAF\xE5\xBB\xB6\xE8\xBF\x9F\xE4\xB8\x8E\xE7\x91\x95\xE7\x96\xB5\xE4\xB9\x8B\xE9\x97\xB4\xE7\x9A\x84\xE6\x8A\x98\xE4\xB8\xAD\xE6\x97\x8B\xE9\x92\xAE");'
    '        ImGui::Separator();'
    '        ImGui::Spacing();'
) -join $nl
Queue-InsertAfter 'menu\menu_common.cpp' $t84fAnchor ($t84f -join $nl) 'T84f menu_common.cpp: the warp-scale slider in the Chinese quick panel'

# P2 cleanup (2026-10-01): the peak-boost LIVE sliders were deleted from the quick panel. The
# Latewarp.PeakBoost / .PeakBoostThreshold keys (T93a-g) stay in the C++ and the ini, but the boost
# itself is hard-disabled (E2c37d), so no UI is wired to them any more.
# ---------------------------------------------------------------------------
# T85 (E2c28): PresentOnly -- THE SEALED BUILD'S WARP POINT, AS A SWITCH.
# The user's reference (versions\P3C-pre_noWarpMask_20260928) warps the DISPLAYED frame only,
# i.e. its inputs are the frame AFTER the game composited the late layers, so those layers are
# never touched. Our mechanism C warps ScalingOutputColor BEFORE that composite, which is what
# buys the generator inheritance -- and what the user reports as missing lamp highlights.
# PresentOnly disables BOTH mechanism C and the HUDLESS tag substitution, leaving exactly the
# present-chain warp the sealed build ran (with the ini WarpStrength + our mask).
# Default false: nothing changes for an existing config.
# ---------------------------------------------------------------------------
$t85aAnchor = 'CustomOptional<float> LatewarpWarpScale { 1.0f };   // P2/E2c27: scale the pose delta (1 = full warp, 0 = no warp / bit-exact early-out)'
$t85a = @(
    'CustomOptional<bool> LatewarpPresentOnly { false };   // P2/E2c28: warp ONLY the displayed frame (the sealed build point); disables mechanism C and the tag substitution'
) -join $nl
Queue-InsertAfter 'Config.h' $t85aAnchor ($t85a -join $nl) 'T85a Config.h += Latewarp.PresentOnly (default off)'

$t85bAnchor = '        LatewarpWarpScale.set_from_config(readFloat("Latewarp", "WarpScale"));'
$t85b = @(
    '        LatewarpPresentOnly.set_from_config(readBool("Latewarp", "PresentOnly"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t85bAnchor ($t85b -join $nl) 'T85b Config.cpp += read Latewarp.PresentOnly'

$t85cAnchor = @(
    '        ini.SetValue("Latewarp", "WarpScale",'
    '                     GetFloatValue(Instance()->LatewarpWarpScale.value_or_default()).c_str());'
) -join $nl
$t85c = @(
    '        ini.SetValue("Latewarp", "PresentOnly",'
    '                     Instance()->LatewarpPresentOnly.value_or_default() ? "true" : "false");'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t85cAnchor ($t85c -join $nl) 'T85c Config.cpp += save Latewarp.PresentOnly'

$t85dAnchor = '            const bool lwInteresting = !Config::Instance()->LatewarpTagWarpInPlace.value_or_default() &&'
$t85d = @(
    '            // P2/E2c28: PresentOnly also silences the substitution, so the frame generator keeps'
    '            // getting the game own hudless (that is what the sealed build did).'
    '            const bool lwInteresting = !Config::Instance()->LatewarpTagWarpInPlace.value_or_default() &&'
    '                                      !Config::Instance()->LatewarpPresentOnly.value_or_default() &&'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t85dAnchor $t85d 'T85d Streamline_Hooks.cpp: PresentOnly disables the HUDLESS substitution'

$t85eAnchor = '        Config::Instance()->LatewarpTagWarpInPlace.value_or_default() && p2::IsRuntimeEnabled() &&'
$t85e = @(
    '        Config::Instance()->LatewarpTagWarpInPlace.value_or_default() &&'
    '        !Config::Instance()->LatewarpPresentOnly.value_or_default() && p2::IsRuntimeEnabled() &&'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t85eAnchor $t85e 'T85e Streamline_Hooks.cpp: PresentOnly disables mechanism C'

$t85fAnchor = '            Config::Instance()->LatewarpWarpScale = p2WarpScale;'
$t85f = @(
    '            Config::Instance()->LatewarpWarpScale = p2WarpScale;'
    '        // P2/E2c28: THE SEALED BUILD POINT (what the user asked for). ON = warp only the'
    '        // DISPLAYED frame, i.e. the frame the game already composited; the late layer (the lamp'
    '        // highlights) is never touched. OFF = mechanism C (the generator inherits the warp).'
    '        bool p2PresentOnly = Config::Instance()->LatewarpPresentOnly.value_or_default();'
    '        if (ImGui::Checkbox("\xE5\x8F\xAA\xE6\x89\xAD\xE6\x98\xBE\xE7\xA4\xBA\xE5\xB8\xA7 PresentOnly (sealed-build warp point)", &p2PresentOnly))'
    '            Config::Instance()->LatewarpPresentOnly = p2PresentOnly;'
    '        ImGui::TextUnformatted("\xE5\xBC\x80 = \xE5\x9C\xA8\xE5\x90\x88\xE6\x88\x90\xE4\xB9\x8B\xE5\x90\x8E\xE6\x89\xAD\xEF\xBC\x88\xE9\xAB\x98\xE5\x85\x89\xE4\xB8\x8D\xE5\x8F\x97\xE5\xBD\xB1\xE5\x93\x8D\xEF\xBC\x8C\xE4\xBD\x86\xE7\x94\x9F\xE6\x88\x90\xE5\xB8\xA7\xE4\xB8\x8D\xE7\xBB\xA7\xE6\x89\xBF\xEF\xBC\x89\xEF\xBC\x9B\xE5\x85\xB3 = \xE6\x9C\xBA\xE5\x88\xB6 C\xEF\xBC\x88\xE7\x94\x9F\xE6\x88\x90\xE5\xB8\xA7\xE7\xBB\xA7\xE6\x89\xBF\xEF\xBC\x89");'
) -join $nl
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t85fAnchor $t85f 'T85f menu_common.cpp: the PresentOnly switch (the sealed build warp point)'

# ---------------------------------------------------------------------------
# T86 (E2c29): HAND THE GENERATOR THE COMPOSITED FRAME (the user's idea, opt-in).
# The constraint measured on 2026-09-30: the generator interpolates ScalingOutputColor, which is
# written BEFORE the game composites its late layers (the lamp highlights). So the two warp
# points trade one artifact for the other -- mechanism C has no ghost but the generated frames
# lack the late layer, PresentOnly keeps the layer but the generated frames miss the warp.
# This closes it: at the generator own evaluate (kFeatureDLSS_G) the colour input is the 1:1
# copy of the CURRENT backbuffer, which by then carries world(warped)+late layer. Generated
# frames then interpolate exactly what the real frames show.
# Risk, stated plainly: the backbuffer resource STATE at that instant is not observable from
# outside, so the barrier below ASSUMES RENDER_TARGET (the standard state after a composite).
# If that is wrong the picture breaks visibly, so this ships opt-in, logs both descs on the
# first frames, and the panel checkbox turns it off live.
# ---------------------------------------------------------------------------
$t86aAnchor = 'CustomOptional<bool> LatewarpPresentOnly { false };   // P2/E2c28: warp ONLY the displayed frame (the sealed build point); disables mechanism C and the tag substitution'
$t86a = @(
    'CustomOptional<bool> LatewarpFeedComposite { false };   // P2/E2c29: copy the composited backbuffer into the generator colour input (kills the missing late layer)'
) -join $nl
Queue-InsertAfter 'Config.h' $t86aAnchor ($t86a -join $nl) 'T86a Config.h += Latewarp.FeedComposite (default off)'

$t86bAnchor = '        LatewarpPresentOnly.set_from_config(readBool("Latewarp", "PresentOnly"));'
$t86b = @(
    '        LatewarpFeedComposite.set_from_config(readBool("Latewarp", "FeedComposite"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t86bAnchor ($t86b -join $nl) 'T86b Config.cpp += read Latewarp.FeedComposite'

$t86cAnchor = @(
    '        ini.SetValue("Latewarp", "PresentOnly",'
    '                     Instance()->LatewarpPresentOnly.value_or_default() ? "true" : "false");'
) -join $nl
$t86c = @(
    '        ini.SetValue("Latewarp", "FeedComposite",'
    '                     Instance()->LatewarpFeedComposite.value_or_default() ? "true" : "false");'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t86cAnchor ($t86c -join $nl) 'T86c Config.cpp += save Latewarp.FeedComposite'

$t86dAnchor = '    auto result = o_slEvaluateFeature(feature, frame, inputs, numInputs, cmdBuffer);'
$t86d = @(
    '    // P2/E2c29 (T86): THE COMPOSITED FRAME, HANDED TO THE GENERATOR (opt-in, see the patch header).'
    '    // Mechanism C warps the colour input BEFORE the game composites its late layers, so the'
    '    // generator interpolates a frame without them (the lamp-highlight loss). The backbuffer at'
    '    // THIS moment already carries the composite -- the HUD is never missing from generated'
    '    // frames, which is the evidence -- so copying it over the colour input closes the gap.'
    '    if (Config::Instance()->LatewarpFeedComposite.value_or_default() && feature == sl::kFeatureDLSS_G &&'
    '        p2::IsRuntimeEnabled() && cmdBuffer != nullptr && g_lwScalingOut != nullptr && g_lwScalingOutState != 0)'
    '    {'
    '        IDXGISwapChain3* lwSC3 = nullptr;'
    '        IDXGISwapChain* lwSC = State::Instance().currentSwapchain;'
    '        if (lwSC != nullptr && SUCCEEDED(lwSC->QueryInterface(IID_PPV_ARGS(&lwSC3))) && lwSC3 != nullptr)'
    '        {'
    '            const UINT lwIdx = lwSC3->GetCurrentBackBufferIndex();'
    '            ID3D12Resource* lwBB = nullptr;'
    '            if (SUCCEEDED(lwSC3->GetBuffer(lwIdx, IID_PPV_ARGS(&lwBB))) && lwBB != nullptr)'
    '            {'
    '                const D3D12_RESOURCE_DESC lwDA = g_lwScalingOut->GetDesc();'
    '                const D3D12_RESOURCE_DESC lwDB = lwBB->GetDesc();'
    '                const bool lwSame = (lwDA.Width == lwDB.Width) && (lwDA.Height == lwDB.Height) &&'
    '                                    (lwDA.Format == lwDB.Format) && (lwDA.SampleDesc.Count == lwDB.SampleDesc.Count);'
    '                static int lwFeedLog = 0;'
    '                if (lwFeedLog < 4)'
    '                {'
    '                    LOG_INFO("latewarp-e2c29: feed-composite: ScalingOutput {:X} {}x{} fmt {} declaredState {} | backbuffer {} {:X} {}x{} fmt {} | same {} "'
    '                             "(backbuffer state ASSUMED render-target)",'
    '                             (size_t) g_lwScalingOut, (uint32_t) lwDA.Width, (uint32_t) lwDA.Height, (int) lwDA.Format,'
    '                             g_lwScalingOutState, lwIdx, (size_t) lwBB, (uint32_t) lwDB.Width, (uint32_t) lwDB.Height,'
    '                             (int) lwDB.Format, lwSame);'
    '                    ++lwFeedLog;'
    '                }'
    '                if (lwSame)'
    '                {'
    '                    auto* lwList = (ID3D12GraphicsCommandList*) cmdBuffer;'
    '                    D3D12_RESOURCE_BARRIER lwBar[2] = {};'
    '                    lwBar[0].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '                    lwBar[0].Transition.pResource = g_lwScalingOut;'
    '                    lwBar[0].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '                    lwBar[0].Transition.StateBefore = (D3D12_RESOURCE_STATES) g_lwScalingOutState;'
    '                    lwBar[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;'
    '                    lwBar[1].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '                    lwBar[1].Transition.pResource = lwBB;'
    '                    lwBar[1].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '                    lwBar[1].Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;'
    '                    lwBar[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '                    lwList->ResourceBarrier(2, lwBar);'
    '                    lwList->CopyResource(g_lwScalingOut, lwBB);'
    '                    lwBar[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;'
    '                    lwBar[0].Transition.StateAfter = (D3D12_RESOURCE_STATES) g_lwScalingOutState;'
    '                    lwBar[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '                    lwBar[1].Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;'
    '                    lwList->ResourceBarrier(2, lwBar);'
    '                }'
    '                lwBB->Release();'
    '            }'
    '            lwSC3->Release();'
    '        }'
    '    }'
    '    auto result = o_slEvaluateFeature(feature, frame, inputs, numInputs, cmdBuffer);'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t86dAnchor $t86d 'T86d Streamline_Hooks.cpp: feed the composited backbuffer to the generator (opt-in)'

$t86eAnchor = '            Config::Instance()->LatewarpPresentOnly = p2PresentOnly;'
$t86e = @(
    '            Config::Instance()->LatewarpPresentOnly = p2PresentOnly;'
    '        // P2/E2c29: THE INJECTION. ON = at the generator evaluate, copy the composited backbuffer'
    '        // into its colour input, so generated frames carry the late layer too (no ghost, no'
    '        // missing highlights). Opt-in: it writes a game resource at a point whose state we can'
    '        // only assume, and it logs what it saw on the first frames.'
    '        bool p2FeedComposite = Config::Instance()->LatewarpFeedComposite.value_or_default();'
    '        if (ImGui::Checkbox("\xE9\xA5\xB2\xE7\xBB\x99\xE7\x94\x9F\xE6\x88\x90\xE5\x99\xA8 Feed composite (experimental)", &p2FeedComposite))'
    '            Config::Instance()->LatewarpFeedComposite = p2FeedComposite;'
    '        ImGui::TextUnformatted("\xE5\xBC\x80 = \xE5\x9C\xA8\xE7\x94\x9F\xE6\x88\x90\xE5\x99\xA8\xE6\xB1\x82\xE5\x80\xBC\xE5\x89\x8D\xE6\x8A\x8A\xE5\xB7\xB2\xE5\x90\x88\xE6\x88\x90\xE7\x94\xBB\xE9\x9D\xA2\xE8\xA1\xA5\xE7\xBB\x99\xE5\xAE\x83\xEF\xBC\x9B\xE5\x87\xBA\xE9\x94\x99\xE7\xAB\x8B\xE5\x88\xBB\xE5\x85\xB3\xE6\x8E\x89");'
) -join $nl
Queue-ReplaceLiteral 'menu\menu_common.cpp' $t86eAnchor $t86e 'T86e menu_common.cpp: the feed-composite checkbox'

# ---------------------------------------------------------------------------
# T87 (E2c30): WHERE DOES THE GENERATOR EVALUATE? The T86 injection never fired (zero e2c29 lines
# in the 22:12 run) even though the config was on, so one guard or the hook path is wrong. Rather
# than guess, probe: log every DISTINCT feature that reaches hkslEvaluateFeature (INFO, so it
# shows in a normal run) plus the first DLSS-G option call. One run then says exactly where the
# injection can live: this hook, the DLSS-G wrapper, or the option/marker path.
# ---------------------------------------------------------------------------
$t87aAnchor = '    // P2/E2c29 (T86): THE COMPOSITED FRAME, HANDED TO THE GENERATOR (opt-in, see the patch header).'
$t87a = @(
    '    // P2/E2c30 (T87): WHERE DOES THE GENERATOR EVALUATE? One-shot probe, INFO level so it shows in'
    '    // a normal run. It lists every DISTINCT feature that reaches this hook -- the T86 injection'
    '    // logged nothing at all, so the question is whether kFeatureDLSS_G is even here.'
    '    {'
    '        static sl::Feature lwSeenFeatures[16] = {};'
    '        static int lwSeenCount = 0;'
    '        bool lwSeenAlready = false;'
    '        for (int lwI = 0; lwI < lwSeenCount; ++lwI)'
    '        {'
    '            if (lwSeenFeatures[lwI] == feature)'
    '            {'
    '                lwSeenAlready = true;'
    '                break;'
    '            }'
    '        }'
    '        if (!lwSeenAlready && lwSeenCount < 16)'
    '        {'
    '            lwSeenFeatures[lwSeenCount++] = feature;'
    '            // No magic_enum here: sl::Feature is not registered for it (only the SL1 enum is).'
    '            LOG_INFO("latewarp-e2c30: evaluate probe: feature {} reached hkslEvaluateFeature", (int) feature);'
    '        }'
    '    }'
    '    // P2/E2c29 (T86): THE COMPOSITED FRAME, HANDED TO THE GENERATOR (opt-in, see the patch header).'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t87aAnchor $t87a 'T87a Streamline_Hooks.cpp: one-shot feature probe on the evaluate hook'

# NOTE: the replacement must NOT add a `{` -- the original function has its own on the next line
# (adding one made every following function a local definition: C2601 x3).
# The anchor must sit INSIDE the body: anchoring on the signature put the probe between the signature
# and the body's `{` (C2447 missing function header). The body's first comment line is the anchor.
$t87bAnchor = '    // MFG compatibility: the game owns frame generation here, so its options are not ours to'
$t87b = @(
    '    // P2/E2c30 (T87): probe -- does the DLSS-G option call run per frame, and with what?'
    '    // Only fields that exist in THIS SDK version are printed (numInterpolatedFrames and'
    '    // executionPriority are not members of sl::DLSSGOptions -- C2039).'
    '    {'
    '        static int lwDlssgOpt = 0;'
    '        if (lwDlssgOpt < 6)'
    '        {'
    '            ++lwDlssgOpt;'
    '            LOG_INFO("latewarp-e2c30: DLSSGSetOptions probe #{}: mode {} (0=off 1=on) uiRecomp {}",'
    '                     lwDlssgOpt, (int) options.mode, (int) options.enableUserInterfaceRecomposition);'
    '        }'
    '    }'
    '    // MFG compatibility: the game owns frame generation here, so its options are not ours to'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t87bAnchor $t87b 'T87b Streamline_Hooks.cpp: one-shot DLSS-G option probe'

# ---------------------------------------------------------------------------
# T88 (E2c31): THE INJECTION MOVES TO THE TAG. The E2c30 probe settled it: our sl2 evaluate hook
# only ever sees feature 0 (kFeatureDLSS) -- kFeatureDLSS_G never arrives -- and the DLSS-G option
# probe prints garbage (the option struct layout does not match the runtime), so neither is a
# usable injection point. The TAG is: the game writes its FG inputs there BEFORE the generator
# reads them, and it happens on the SAME command list the game is recording, so a copy recorded
# here is ordered after the game own composite -- exactly the window we need.
# ---------------------------------------------------------------------------
$t88aAnchor = 'static void lwProbeBackbufferTag(const sl::ResourceTag* tags, uint32_t numTags, const char* hook)'
$t88a = @(
    'static void lwProbeBackbufferTag(const sl::ResourceTag* tags, uint32_t numTags, sl::CommandBuffer* cmdBuffer,'
    '                                    const char* hook)'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t88aAnchor $t88a 'T88a Streamline_Hooks.cpp: the tag probe takes the command buffer'

$t88bAnchor = '    lwProbeBackbufferTag(tags, numTags, "slSetTag");   // P2/E2c11c: AFTER the resource push'
$t88b = @(
    '    lwProbeBackbufferTag(tags, numTags, cmdBuffer, "slSetTag");   // P2/E2c11c: AFTER the resource push'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t88bAnchor $t88b 'T88b Streamline_Hooks.cpp: slSetTag passes its command buffer'

$t88cAnchor = '    lwProbeBackbufferTag(resources, numResources, "slSetTagForFrame");'
$t88c = @(
    '    lwProbeBackbufferTag(resources, numResources, cmdBuffer, "slSetTagForFrame");'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t88cAnchor $t88c 'T88c Streamline_Hooks.cpp: slSetTagForFrame passes its command buffer'

$t88dAnchor = '            ++lwSoLog;'
$t88d = @(
    '            ++lwSoLog;'
    ''
    '            // P2/E2c31 (T88): THE INJECTION. Feed the generator the composited frame: the'
    '            // backbuffer at TAG time already carries world(warped by mechanism C) + the late'
    '            // layer the generated frames were missing, and this command buffer is the one the'
    '            // game is recording, so the copy lands after its composite and before the generator.'
    '            if (Config::Instance()->LatewarpFeedComposite.value_or_default() && cmdBuffer != nullptr &&'
    '                p2::IsRuntimeEnabled())'
    '            {'
    '                IDXGISwapChain3* lwSC3 = nullptr;'
    '                IDXGISwapChain* lwSC = State::Instance().currentSwapchain;'
    '                if (lwSC != nullptr && SUCCEEDED(lwSC->QueryInterface(IID_PPV_ARGS(&lwSC3))) && lwSC3 != nullptr)'
    '                {'
    '                    const UINT lwIdx = lwSC3->GetCurrentBackBufferIndex();'
    '                    ID3D12Resource* lwBB = nullptr;'
    '                    if (SUCCEEDED(lwSC3->GetBuffer(lwIdx, IID_PPV_ARGS(&lwBB))) && lwBB != nullptr)'
    '                    {'
    '                        const D3D12_RESOURCE_DESC lwDA = g_lwScalingOut->GetDesc();'
    '                        const D3D12_RESOURCE_DESC lwDB = lwBB->GetDesc();'
    '                        const bool lwSame = (lwDA.Width == lwDB.Width) && (lwDA.Height == lwDB.Height) &&'
    '                                            (lwDA.Format == lwDB.Format) &&'
    '                                            (lwDA.SampleDesc.Count == lwDB.SampleDesc.Count);'
    '                        static int lwFeedT = 0;'
    '                        if (lwFeedT < 4)'
    '                        {'
    '                            LOG_INFO("latewarp-e2c31: feed-composite at tag: ScalingOutput {:X} {}x{} fmt {} state {} | "'
    '                                     "backbuffer {} {:X} {}x{} fmt {} | same {} (backbuffer state ASSUMED render-target)",'
    '                                     (size_t) g_lwScalingOut, (uint32_t) lwDA.Width, (uint32_t) lwDA.Height,'
    '                                     (int) lwDA.Format, g_lwScalingOutState, lwIdx, (size_t) lwBB, (uint32_t) lwDB.Width,'
    '                                     (uint32_t) lwDB.Height, (int) lwDB.Format, lwSame);'
    '                            ++lwFeedT;'
    '                        }'
    '                        if (lwSame)'
    '                        {'
    '                            auto* lwList = (ID3D12GraphicsCommandList*) cmdBuffer;'
    '                            D3D12_RESOURCE_BARRIER lwBar[2] = {};'
    '                            lwBar[0].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '                            lwBar[0].Transition.pResource = g_lwScalingOut;'
    '                            lwBar[0].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '                            lwBar[0].Transition.StateBefore = (D3D12_RESOURCE_STATES) g_lwScalingOutState;'
    '                            lwBar[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;'
    '                            lwBar[1].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '                            lwBar[1].Transition.pResource = lwBB;'
    '                            lwBar[1].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '                            lwBar[1].Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;'
    '                            lwBar[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '                            lwList->ResourceBarrier(2, lwBar);'
    '                            lwList->CopyResource(g_lwScalingOut, lwBB);'
    '                            lwBar[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;'
    '                            lwBar[0].Transition.StateAfter = (D3D12_RESOURCE_STATES) g_lwScalingOutState;'
    '                            lwBar[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '                            lwBar[1].Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;'
    '                            lwList->ResourceBarrier(2, lwBar);'
    '                        }'
    '                        lwBB->Release();'
    '                    }'
    '                    lwSC3->Release();'
    '                }'
    '            }'
) -join $nl
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t88dAnchor ($t88d -join $nl) 'T88d Streamline_Hooks.cpp: feed the composited backbuffer to the generator at tag time'

# T89 (E2c32): the converting copy that hands the generator the COMPOSITED frame.
# Why not CopyResource: ScalingOutputColor is R16G16B16A16_FLOAT (fmt 10) and the composited
# backbuffer is R10G10B10A2_UNORM (fmt 24) -- the 22:45 run printed exactly that (`same false`).
# Our composite shader with WarpStrength 0 returns its t1 sample and the UAV write converts.
# Every binding is a DIFFERENT resource with a state we can name: one resource transitioned twice
# in one dispatch removes the device.
# ---------------------------------------------------------------------------
$t89aAnchor = 'std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;   // P2: re-composites the game UI over the warp'
$t89a = @(
    'std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;   // P2: re-composites the game UI over the warp'
    '    // P2/E2c32 (T89): a SECOND instance used only for the format-converting copy that hands the'
    '    // generator the composited frame. Its working buffer is created from the TARGET desc (FP16)'
    '    // and its own mask ring cannot disturb the kernel NoWarpMask.'
    '    std::unique_ptr<LatewarpUi_Dx12> _latewarpFeed;'
    '    ID3D12Resource* LatewarpFeedComposite(ID3D12Resource* target, ID3D12Resource* source,'
    '                                          D3D12_RESOURCE_STATES sourceState, ID3D12Resource* hudless,'
    '                                          D3D12_RESOURCE_STATES hudlessState, ID3D12Resource* depth,'
    '                                          D3D12_RESOURCE_STATES depthState, ID3D12GraphicsCommandList* list);'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.h' $t89aAnchor $t89a 'T89a Reprojection_Dx12.h: the feed-composite instance + method'

$t89bAnchor = 'bool Reprojection_Dx12::Present()'
$t89b = @(
    '// P2/E2c32 (T89): the CONVERTING copy. ScalingOutputColor is FP16 while the composited backbuffer'
    '// is R10G10B10A2, so CopyResource is illegal; our composite with WarpStrength 0 returns its t1'
    '// sample and the UAV write converts the format on the way into the target.'
    'ID3D12Resource* Reprojection_Dx12::LatewarpFeedComposite(ID3D12Resource* target, ID3D12Resource* source,'
    '                                                         D3D12_RESOURCE_STATES sourceState,'
    '                                                         ID3D12Resource* hudless,'
    '                                                         D3D12_RESOURCE_STATES hudlessState,'
    '                                                         ID3D12Resource* depth,'
    '                                                         D3D12_RESOURCE_STATES depthState,'
    '                                                         ID3D12GraphicsCommandList* list)'
    '{'
    '    if (target == nullptr || source == nullptr || hudless == nullptr || depth == nullptr || list == nullptr ||'
    '        _device == nullptr)'
    '        return nullptr;'
    '    if (!Config::Instance()->LatewarpFeedComposite.value_or_default() || !p2::IsRuntimeEnabled())'
    '        return nullptr;'
    '    // warped is only read by mask branches this call disables, so _lwOut stands in: the present'
    '    // chain leaves it in UAV state, so every barrier state below is KNOWN, not assumed.'
    '    if (_lwOut.Get() == nullptr || _lwOut.Get() == source || _lwOut.Get() == target)'
    '        return nullptr;'
    '    if (_latewarpFeed == nullptr)'
    '        _latewarpFeed = std::make_unique<LatewarpUi_Dx12>("LatewarpFeed", _device);'
    '    if (_latewarpFeed == nullptr)'
    '        return nullptr;'
    '    LatewarpUiDispatchParams lwFeedParams {};'
    '    lwFeedParams.UiDiffThreshold = 100.0f;'
    '    lwFeedParams.WarpStrength = 0.0f;'
    '    lwFeedParams.DepthCutoff = 1.0f;'
    '    lwFeedParams.InvertedDepth = 1u;'
    '    const D3D12_RESOURCE_DESC lwFeedTarget = target->GetDesc();'
    '    lwFeedParams.InvScreenWidth = (lwFeedTarget.Width > 0) ? (1.0f / (float) lwFeedTarget.Width) : 0.0f;'
    '    lwFeedParams.InvScreenHeight = (lwFeedTarget.Height > 0) ? (1.0f / (float) lwFeedTarget.Height) : 0.0f;'
    '    const bool lwFeedOk = _latewarpFeed->Dispatch(list, _lwOut.Get(), hudless, target, depth,'
    '                                                 D3D12_RESOURCE_STATE_UNORDERED_ACCESS, hudlessState,'
    '                                                 // E2c33: the TARGET pre-state is the state the game TAG declared'
    '                                                 // (logged as declaredState 8 on every run). Passing UAV here made the'
    '                                                 // first target barrier illegal and removed the device at 23:06.'
    '                                                 D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, depthState,'
    '                                                 lwFeedParams, source, sourceState);'
    '    static int lwFeedLog = 0;'
    '    if (lwFeedLog < 4)'
    '    {'
    '        ++lwFeedLog;'
    '        LOG_INFO("latewarp-e2c32: feed-composite {} target {:X} fmt {} <- source {:X} fmt {}",'
    '                 lwFeedOk ? "OK" : "FAILED", (size_t) target, (int) lwFeedTarget.Format, (size_t) source,'
    '                 (int) source->GetDesc().Format);'
    '    }'
    '    return lwFeedOk ? target : nullptr;'
    '}'
    ''
    'bool Reprojection_Dx12::Present()'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t89bAnchor $t89b 'T89b Reprojection_Dx12.cpp: the converting feed-composite'

$t89cAnchor = 'static uint32_t g_lwScalingOutState = 0;'
$t89c = @(
    'static uint32_t g_lwScalingOutState = 0;'
    '// P2/E2c32 (T89): the other two planes the converting copy binds. Cached from the tags, so'
    '// their declared states are KNOWN rather than assumed.'
    'static ID3D12Resource* g_lwHudlessTag = nullptr;'
    'static uint32_t g_lwHudlessTagState = 0;'
    'static ID3D12Resource* g_lwDepthTag = nullptr;'
    'static uint32_t g_lwDepthTagState = 0;'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t89cAnchor $t89c 'T89c Streamline_Hooks.cpp: cache the tagged hudless/depth for the converting copy'

# Two-line anchor on purpose: the single-line form appears a second time in the substitution
# diagnostics (deeper indent) and Queue-ReplaceLiteral requires exactly one match.
$t89c2Anchor = @(
    '        if (tags[i].type != sl::kBufferTypeHUDLessColor)'
    '            continue;'
) -join $nl
$t89c2 = @(
    '        // P2/E2c32 (T89): cache the two planes the converting copy must bind. Their states come'
    '        // from the tag as well, so every barrier in that pass has a state we can name.'
    '        if (tags[i].resource != nullptr && tags[i].resource->native != nullptr)'
    '        {'
    '            if (tags[i].type == sl::kBufferTypeDepth)'
    '            {'
    '                g_lwDepthTag = (ID3D12Resource*) tags[i].resource->native;'
    '                g_lwDepthTagState = (uint32_t) tags[i].resource->state;'
    '            }'
    '            else if (tags[i].type == sl::kBufferTypeHUDLessColor)'
    '            {'
    '                g_lwHudlessTag = (ID3D12Resource*) tags[i].resource->native;'
    '                g_lwHudlessTagState = (uint32_t) tags[i].resource->state;'
    '            }'
    '        }'
    '        if (tags[i].type != sl::kBufferTypeHUDLessColor)'
    '            continue;'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t89c2Anchor $t89c2 'T89c2 Streamline_Hooks.cpp: cache the tagged depth/hudless'
$t89dAnchor = '            // P2/E2c31 (T88): THE INJECTION. Feed the generator the composited frame: the'
$t89d = @(
    '            // P2/E2c32 (T89): THE CONVERTING COPY -- same window as T88 (the tag is written before'
    '            // the generator reads its inputs, and this is the game command list), but the copy is'
    '            // done by our composite pass so the R10G10B10A2 to FP16 conversion happens.'
    '            if (Config::Instance()->LatewarpFeedComposite.value_or_default() && cmdBuffer != nullptr &&'
    '                p2::IsRuntimeEnabled() && g_lwHudlessTag != nullptr && g_lwDepthTag != nullptr)'
    '            {'
    '                if (auto* lwFgFeed = State::Instance().currentFG; lwFgFeed != nullptr)'
    '                {'
    '                    IDXGISwapChain3* lwSC3f = nullptr;'
    '                    IDXGISwapChain* lwSCf = State::Instance().currentSwapchain;'
    '                    if (lwSCf != nullptr && SUCCEEDED(lwSCf->QueryInterface(IID_PPV_ARGS(&lwSC3f))) &&'
    '                        lwSC3f != nullptr)'
    '                    {'
    '                        ID3D12Resource* lwBBf = nullptr;'
    '                        if (SUCCEEDED(lwSC3f->GetBuffer(lwSC3f->GetCurrentBackBufferIndex(),'
    '                                            IID_PPV_ARGS(&lwBBf))) &&'
    '                            lwBBf != nullptr)'
    '                        {'
    '                            (void) lwFgFeed->LatewarpFeedComposite('
    '                                g_lwScalingOut, lwBBf, D3D12_RESOURCE_STATE_RENDER_TARGET, g_lwHudlessTag,'
    '                                (D3D12_RESOURCE_STATES) g_lwHudlessTagState, g_lwDepthTag,'
    '                                (D3D12_RESOURCE_STATES) g_lwDepthTagState, (ID3D12GraphicsCommandList*) cmdBuffer);'
    '                            lwBBf->Release();'
    '                        }'
    '                        lwSC3f->Release();'
    '                    }'
    '                }'
    '            }'
    '            // P2/E2c31 (T88): THE INJECTION. Feed the generator the composited frame: the'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t89dAnchor $t89d 'T89d Streamline_Hooks.cpp: call the converting feed-composite at tag time'
# The call goes through State::Instance().currentFG, whose static type is IFGFeature_Dx12, so the
# method must exist on the base -- exactly the reason T73a put LatewarpWarpTaggedColor there.
$t89eAnchor = 'virtual ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
$t89e = @(
    '    // P2/E2c32 (T89): hand the generator the COMPOSITED frame (converting copy). Implemented by'
    '    // Reprojection_Dx12; the base returns nullptr so every other feature is unchanged.'
    '    virtual ID3D12Resource* LatewarpFeedComposite(ID3D12Resource* target, ID3D12Resource* source,'
    '                                                  D3D12_RESOURCE_STATES sourceState, ID3D12Resource* hudless,'
    '                                                  D3D12_RESOURCE_STATES hudlessState, ID3D12Resource* depth,'
    '                                                  D3D12_RESOURCE_STATES depthState,'
    '                                                  ID3D12GraphicsCommandList* list)'
    '    {'
    '        return nullptr;'
    '    }'
    'virtual ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
) -join $nl
Queue-ReplaceLiteral 'framegen\IFGFeature_Dx12.h' $t89eAnchor $t89e 'T89e IFGFeature_Dx12.h: the base declaration for the feed-composite'

# P2/E2c38a: read the back buffer with the state the recorder MEASURED (0 = COMMON, not the assumed
# RENDER_TARGET(4)); the two device removals came from exactly that wrong assumption.
$t95bAnchor = 'virtual ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
$t95b = @(
    '    // P2/E2c38a: read the back buffer into OUR texture; writes nothing to a game resource.'
    '    virtual bool LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
    '    {'
    '        return false;'
    '    }'
    'virtual ID3D12Resource* LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
) -join $nl
Queue-ReplaceLiteral 'framegen\IFGFeature_Dx12.h' $t95bAnchor $t95b 'T95b IFGFeature_Dx12.h: the base declaration for the back-buffer read'

# ---------------------------------------------------------------------------
# T90 (P2/E2c34): WHAT STATE IS THE BACK BUFFER REALLY IN?   (RECORD ONLY)
#
# Two injection attempts (E2c32/E2c33) removed the device, and the only unverified line in both was
# the back buffer's resource STATE -- the probe printed it as "ASSUMED render-target". No D3D12 API
# reports a resource's state, and CP2077 never tags the back buffer (our tag inventory is
# 0/1/2/3/4/29; 53 = Backbuffer is never seen), so the answer has to come from the app's OWN
# barriers. This patches ID3D12GraphicsCommandList::ResourceBarrier (vtable slot 26 -- the slots the
# hudfix hooks already read pin the table: Reset 10, ClearState 11, Draw* 12/13, Dispatch 14,
# SetComputeRootDescriptorTable 31, SetGraphicsRootDescriptorTable 32, OMSetRenderTargets 46) and
# remembers the StateAfter of the SWAP-CHAIN BUFFERS ONLY: at most four pointer compares per
# barrier, no allocation, no lock, nothing else in the frame is touched. The tag-time probe then
# prints the recorded value. This build writes NOTHING to any game resource.
#
# Gate: [Latewarp] ProbeState (default false).
#
# Extra safety: the injection stays HARD-GATED. [Latewarp] FeedCompositeApply (default false, not in
# the panel) must ALSO be true before the converting copy in T89b may run, so this build cannot
# repeat the E2c32/E2c33 device removal even if the panel's FeedComposite checkbox is ticked.
# ---------------------------------------------------------------------------
$t90aAnchor = 'CustomOptional<bool> LatewarpFeedComposite { false };   // P2/E2c29: copy the composited backbuffer into the generator colour input (kills the missing late layer)'
$t90a = @(
    'CustomOptional<bool> LatewarpProbeState { false };    // P2/E2c34: RECORD (log only) the back buffer''s real resource state from the app own barriers; writes nothing'
    'CustomOptional<bool> LatewarpFeedCompositeApply { false };   // P2/E2c34: the SECOND key the converting feed-composite needs; absent from the panel on purpose'
) -join $nl
Queue-InsertAfter 'Config.h' $t90aAnchor $t90a 'T90a Config.h += Latewarp.ProbeState + Latewarp.FeedCompositeApply (both default off)'

$t90bAnchor = '        LatewarpFeedComposite.set_from_config(readBool("Latewarp", "FeedComposite"));'
$t90b = @(
    '        LatewarpProbeState.set_from_config(readBool("Latewarp", "ProbeState"));'
    '        LatewarpFeedCompositeApply.set_from_config(readBool("Latewarp", "FeedCompositeApply"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t90bAnchor $t90b 'T90b Config.cpp += read Latewarp.ProbeState + FeedCompositeApply'

$t90cAnchor = @(
    '        ini.SetValue("Latewarp", "FeedComposite",'
    '                     Instance()->LatewarpFeedComposite.value_or_default() ? "true" : "false");'
) -join $nl
$t90c = @(
    '        ini.SetValue("Latewarp", "ProbeState",'
    '                     Instance()->LatewarpProbeState.value_or_default() ? "true" : "false");'
    '        ini.SetValue("Latewarp", "FeedCompositeApply",'
    '                     Instance()->LatewarpFeedCompositeApply.value_or_default() ? "true" : "false");'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t90cAnchor $t90c 'T90c Config.cpp += save Latewarp.ProbeState + FeedCompositeApply'

# The recorder must be reachable from Streamline_Hooks.cpp, and the hk* declarations sit in the
# class PRIVATE section (the next public: is far below) -- so the API goes in the public block.
$t90dAnchor = '    static bool TrackResourceRelease(ID3D12Resource* resource);'
$t90d = @(
    '    // P2/E2c34 (T90): the swap-chain state recorder. NoteSwapchainBuffer() tells the ResourceBarrier'
    '    // hook which pointers to watch (it records nothing else), and GetRecordedState() returns the'
    '    // StateAfter the APP last left a buffer in. No D3D12 API exposes that value.'
    '    static void NoteSwapchainBuffer(ID3D12Resource* res, int idx);'
    '    static void NoteSwapchainRange(IDXGISwapChain* sc);'
    '    static bool GetRecordedState(ID3D12Resource* res, uint32_t* outState);'
) -join $nl
Queue-InsertAfter 'resource_tracking\ResTrack_dx12.h' $t90dAnchor $t90d 'T90d ResTrack_dx12.h: the swap-chain state recorder API'

# T92 (P2/E2c35): the recorder could not answer, because T90 hung its install on ResTrack's own hook
# transaction -- and that never runs here. ResTrack_Dx12::HookDevice() returns immediately when
# activeFgInput == FGInput::NvngxFG (the GAME owns frame generation in this MFG deployment), so
# HookCommandList() -- and with it the T90 DetourAttach -- was never called: two live runs logged no
# ARMED line and not one barrier. The recorder gets its OWN install entry point, called from
# AdoptExistingSwapchain(), which runs in every session.
$t92aAnchor = '    static void NoteSwapchainRange(IDXGISwapChain* sc);'
$t92a = @(
    '    static void NoteSwapchainRange(IDXGISwapChain* sc);'
    '    static bool InstallBarrierRecorder(ID3D12Device* device);'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.h' $t92aAnchor $t92a 'T92a ResTrack_dx12.h: the recorder own install entry point'

$t90eAnchor = 'static PFN_SetComputeRootDescriptorTable o_SetComputeRootDescriptorTable = nullptr;'
$t90e = @(
    'typedef void(STDMETHODCALLTYPE* PFN_ResourceBarrier)(ID3D12GraphicsCommandList* This, UINT NumBarriers,'
    '                                                    const D3D12_RESOURCE_BARRIER* pBarriers);'
    'static PFN_ResourceBarrier o_ResourceBarrier = nullptr;'
    '// P2/E2c34 (T90): the recorder. Fixed size, no allocation, no lock: at most four swap-chain'
    '// buffers are watched and the hook only ever compares pointers.'
    'static ID3D12Resource* g_lwWatchRes[16] = {};'
    'static volatile LONG g_lwWatchState[16] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };'
    'static volatile LONG g_lwWatchCount[16] = {};'
    'static volatile LONG g_lwWatchLogs = 0;'
    '// Every barrier call bumps this, whether or not it touches a watched buffer: it is the proof'
    '// that the hook is LIVE (the first run logged no barrier at all, which could equally mean'
    '// "not armed" or "the watched pointer never appeared").'
    'static volatile LONG g_lwBarriersSeen = 0;'
) -join $nl
Queue-InsertAfter 'resource_tracking\ResTrack_dx12.cpp' $t90eAnchor $t90e 'T90e ResTrack_dx12.cpp: the ResourceBarrier hook pointer + the recorder storage'

$t90fAnchor = 'void ResTrack_Dx12::HookCommandList(ID3D12Device* InDevice)'
$t90f = @(
    '// P2/E2c34 (T90): the swap-chain buffer state recorder. OptiScaler owns the swap chain, so a'
    '// pointer set of its buffers is all this needs; everything else falls through after four compares.'
    'void ResTrack_Dx12::NoteSwapchainBuffer(ID3D12Resource* res, int idx)'
    '{'
    '    // The first live run sniffed indices 1, 2, 4 and 5: this swap chain has MORE than four'
    '    // buffers (MFG), so a four-slot table silently refused half of them. 16 is the ceiling.'
    '    if (res == nullptr || idx < 0 || idx > 15)'
    '        return;'
    '    g_lwWatchRes[idx] = res;'
    '}'
    ''
    '// Note EVERY buffer of the chain at once. The first live run only ever noted the buffer it was'
    '// standing on, and the flip index rotates (it was seen as 1, 2, 4, 5, ...), so every sample was'
    '// a FIRST sighting and the recorded state was -1 four times out of four. Watching the whole'
    '// chain removes that failure mode by construction.'
    'void ResTrack_Dx12::NoteSwapchainRange(IDXGISwapChain* sc)'
    '{'
    '    if (sc == nullptr)'
    '        return;'
    '    DXGI_SWAP_CHAIN_DESC sd = {};'
    '    if (FAILED(sc->GetDesc(&sd)))'
    '        return;'
    '    const UINT n = (sd.BufferCount < 16u) ? sd.BufferCount : 16u;'
    '    for (UINT i = 0; i < n; ++i)'
    '    {'
    '        ID3D12Resource* r = nullptr;'
    '        if (SUCCEEDED(sc->GetBuffer(i, IID_PPV_ARGS(&r))) && r != nullptr)'
    '        {'
    '            ResTrack_Dx12::NoteSwapchainBuffer(r, (int) i);'
    '            r->Release();'
    '        }'
    '    }'
    '}'
    ''
    'bool ResTrack_Dx12::GetRecordedState(ID3D12Resource* res, uint32_t* outState)'
    '{'
    '    if (res == nullptr || outState == nullptr)'
    '        return false;'
    '    for (int i = 0; i < 16; ++i)'
    '    {'
    '        if (g_lwWatchRes[i] != res)'
    '            continue;'
    '        const LONG s = g_lwWatchState[i];'
    '        if (s < 0)'
    '            return false;'
    '        *outState = (uint32_t) s;'
    '        return true;'
    '    }'
    '    return false;'
    '}'
    ''
    'static void hkResourceBarrier(ID3D12GraphicsCommandList* This, UINT NumBarriers,'
    '                              const D3D12_RESOURCE_BARRIER* pBarriers)'
    '{'
    '    // Record FIRST, forward afterwards: this hook must never change what the game does.'
    '    __try'
    '    {'
    '        // Bumped for EVERY call, match or not: this is how a log proves the hook is live.'
    '        const LONG lwSeenNow = InterlockedIncrement(&g_lwBarriersSeen);'
    '        if (lwSeenNow == 1 || lwSeenNow == 100 || lwSeenNow == 10000)'
    '            LOG_INFO("latewarp-e2c34: ResourceBarrier hook is LIVE ({} calls seen so far)", lwSeenNow);'
    '        if (pBarriers != nullptr)'
    '        {'
    '            for (UINT b = 0; b < NumBarriers; ++b)'
    '            {'
    '                if (pBarriers[b].Type != D3D12_RESOURCE_BARRIER_TYPE_TRANSITION)'
    '                    continue;'
    '                ID3D12Resource* r = pBarriers[b].Transition.pResource;'
    '                if (r == nullptr)'
    '                    continue;'
    '                for (int i = 0; i < 16; ++i)'
    '                {'
    '                    if (g_lwWatchRes[i] != r)'
    '                        continue;'
    '                    InterlockedExchange(&g_lwWatchState[i], (LONG) pBarriers[b].Transition.StateAfter);'
    '                    InterlockedIncrement(&g_lwWatchCount[i]);'
    '                    if (InterlockedIncrement(&g_lwWatchLogs) <= 12)'
    '                        LOG_INFO("latewarp-e2c34: barrier: buffer {} {} -> {}", i,'
    '                                 (uint32_t) pBarriers[b].Transition.StateBefore,'
    '                                 (uint32_t) pBarriers[b].Transition.StateAfter);'
    '                    break;'
    '                }'
    '            }'
    '        }'
    '    }'
    '    __except (EXCEPTION_EXECUTE_HANDLER)'
    '    {'
    '    }'
    '    if (o_ResourceBarrier != nullptr)'
    '        o_ResourceBarrier(This, NumBarriers, pBarriers);'
    '}'
    ''
    'void ResTrack_Dx12::HookCommandList(ID3D12Device* InDevice)'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90fAnchor $t90f 'T90f ResTrack_dx12.cpp: the ResourceBarrier recorder hook'

$t92bAnchor = 'void ResTrack_Dx12::HookCommandList(ID3D12Device* InDevice)'
$t92b = @(
    'static void hkResourceBarrier(ID3D12GraphicsCommandList* This, UINT NumBarriers,'
    '                              const D3D12_RESOURCE_BARRIER* pBarriers);'
    ''
    '// P2/E2c35 (T92): install ONLY the ResourceBarrier recorder, from a call site that always runs.'
    '// It does not touch the hudfix hooks, so the existing behaviour is unchanged.'
    'bool ResTrack_Dx12::InstallBarrierRecorder(ID3D12Device* device)'
    '{'
    '    if (device == nullptr)'
    '        return false;'
    '    if (o_ResourceBarrier != nullptr)'
    '        return true;                       // already armed'
    ''
    '    ID3D12CommandAllocator* allocator = nullptr;'
    '    ID3D12GraphicsCommandList* list = nullptr;'
    '    if (FAILED(device->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&allocator))) ||'
    '        allocator == nullptr)'
    '    {'
    '        LOG_ERROR("latewarp-e2c35: recorder install: CreateCommandAllocator failed");'
    '        return false;'
    '    }'
    '    if (FAILED(device->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, allocator, nullptr,'
    '                                         IID_PPV_ARGS(&list))) || list == nullptr)'
    '    {'
    '        LOG_ERROR("latewarp-e2c35: recorder install: CreateCommandList failed");'
    '        allocator->Release();'
    '        return false;'
    '    }'
    ''
    '    ID3D12GraphicsCommandList* real = nullptr;'
    '    if (!CheckForRealObject(__FUNCTION__, list, (IUnknown**) &real))'
    '        real = list;'
    '    PVOID* vt = *(PVOID**) real;'
    '    o_ResourceBarrier = (PFN_ResourceBarrier) vt[26];'
    ''
    '    list->Release();'
    '    allocator->Release();'
    ''
    '    if (o_ResourceBarrier == nullptr)'
    '    {'
    '        LOG_ERROR("latewarp-e2c35: recorder install: vtable slot 26 was NULL -- NOT armed");'
    '        return false;'
    '    }'
    ''
    '    DetourTransactionBegin();'
    '    DetourUpdateThread(GetCurrentThread());'
    '    DetourAttach(&(PVOID&) o_ResourceBarrier, hkResourceBarrier);'
    '    const LONG rc = DetourTransactionCommit();'
    '    if (rc != NO_ERROR)'
    '    {'
    '        LOG_ERROR("latewarp-e2c35: recorder install: DetourTransactionCommit = {:X}", (int) rc);'
    '        return false;'
    '    }'
    '    LOG_INFO("latewarp-e2c35: ResourceBarrier recorder ARMED (slot 26 = {:X})", (size_t) o_ResourceBarrier);'
    '    return true;'
    '}'
    ''
    'void ResTrack_Dx12::HookCommandList(ID3D12Device* InDevice)'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t92bAnchor $t92b 'T92b ResTrack_dx12.cpp: InstallBarrierRecorder (own transaction, no hudfix side effects)'

$t90gAnchor = '            o_Dispatch = (PFN_Dispatch) pVTable[14];'
$t90g = @(
    '            o_Dispatch = (PFN_Dispatch) pVTable[14];'
    '            // P2/E2c34 (T90): slot 26 = ID3D12GraphicsCommandList::ResourceBarrier. The slots read'
    '            // just above pin the table layout, so this index is not a guess.'
    '            o_ResourceBarrier = (PFN_ResourceBarrier) pVTable[26];'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90gAnchor $t90g 'T90g ResTrack_dx12.cpp: read the ResourceBarrier slot'

$t90hAnchor = '                auto detourResult = DetourTransactionCommit();'
$t90h = @(
    '                // P2/E2c34 (T90): the recorder rides the same transaction but is NOT under the'
    '                // activeFgInput gate: the state question must be answerable in this very run.'
    '                if (o_ResourceBarrier != nullptr)'
    '                {'
    '                    DetourAttach(&(PVOID&) o_ResourceBarrier, hkResourceBarrier);'
    '                    LOG_INFO("latewarp-e2c34: ResourceBarrier recorder ARMED (vtable slot 26)");'
    '                }'
    '                else'
    '                    LOG_WARN("latewarp-e2c34: vtable slot 26 was NULL -- the recorder is NOT armed");'
    '                auto detourResult = DetourTransactionCommit();'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90hAnchor $t90h 'T90h ResTrack_dx12.cpp: attach the ResourceBarrier recorder'

# The two unhook paths are otherwise identical line for line: only the LOG_ERROR text tells them
# apart ("unhook DX12 methods" vs "unhook CommandList methods"), so the anchor carries it.
$t90iAnchor = @(
    '    if (o_Dispatch != nullptr)'
    '        DetourDetach(&(PVOID&) o_Dispatch, hkDispatch);'
    ''
    '    auto detourResult = DetourTransactionCommit();'
    '    if (detourResult != NO_ERROR)'
    '    {'
    '        LOG_ERROR("Failed to unhook DX12 methods: {:X}", detourResult);'
) -join $nl
$t90i = @(
    '    if (o_Dispatch != nullptr)'
    '        DetourDetach(&(PVOID&) o_Dispatch, hkDispatch);'
    ''
    '    if (o_ResourceBarrier != nullptr)'
    '        DetourDetach(&(PVOID&) o_ResourceBarrier, hkResourceBarrier);'
    ''
    '    auto detourResult = DetourTransactionCommit();'
    '    if (detourResult != NO_ERROR)'
    '    {'
    '        LOG_ERROR("Failed to unhook DX12 methods: {:X}", detourResult);'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90iAnchor $t90i 'T90i ResTrack_dx12.cpp: detach the ResourceBarrier recorder (DX12 unhook)'

$t90i2Anchor = @(
    '    if (o_Dispatch != nullptr)'
    '        DetourDetach(&(PVOID&) o_Dispatch, hkDispatch);'
    ''
    '    auto detourResult = DetourTransactionCommit();'
    '    if (detourResult != NO_ERROR)'
    '    {'
    '        LOG_ERROR("Failed to unhook CommandList methods: {:X}", detourResult);'
) -join $nl
$t90i2 = @(
    '    if (o_Dispatch != nullptr)'
    '        DetourDetach(&(PVOID&) o_Dispatch, hkDispatch);'
    ''
    '    if (o_ResourceBarrier != nullptr)'
    '        DetourDetach(&(PVOID&) o_ResourceBarrier, hkResourceBarrier);'
    ''
    '    auto detourResult = DetourTransactionCommit();'
    '    if (detourResult != NO_ERROR)'
    '    {'
    '        LOG_ERROR("Failed to unhook CommandList methods: {:X}", detourResult);'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90i2Anchor $t90i2 'T90i2 ResTrack_dx12.cpp: detach the ResourceBarrier recorder (CommandList unhook)'

# The nulling block exists twice (both unhook bodies); the one that matters is preceded by the
# 8-space "// CommandList" comment, which makes this anchor unique.
$t90jAnchor = @(
    '        // CommandList'
    '        o_Reset = nullptr;'
    '        o_ClearState = nullptr;'
    '        o_OMSetRenderTargets = nullptr;'
    '        o_SetGraphicsRootDescriptorTable = nullptr;'
    '        o_SetComputeRootDescriptorTable = nullptr;'
    '        o_DrawIndexedInstanced = nullptr;'
    '        o_DrawInstanced = nullptr;'
    '        o_Dispatch = nullptr;'
) -join $nl
$t90j = @(
    '        // CommandList'
    '        o_Reset = nullptr;'
    '        o_ClearState = nullptr;'
    '        o_OMSetRenderTargets = nullptr;'
    '        o_SetGraphicsRootDescriptorTable = nullptr;'
    '        o_SetComputeRootDescriptorTable = nullptr;'
    '        o_DrawIndexedInstanced = nullptr;'
    '        o_DrawInstanced = nullptr;'
    '        o_Dispatch = nullptr;'
    '        o_ResourceBarrier = nullptr;'
) -join $nl
Queue-ReplaceLiteral 'resource_tracking\ResTrack_dx12.cpp' $t90jAnchor $t90j 'T90j ResTrack_dx12.cpp: clear the ResourceBarrier pointer on unhook'

$t90kAnchor = '#include <upscalers/latewarp/LatewarpFrameData.h>'
$t90k = @(
    '#include <resource_tracking/ResTrack_dx12.h>   // P2/E2c34 (T90): the swap-chain state recorder'
) -join $nl
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t90kAnchor $t90k 'T90k Streamline_Hooks.cpp: include the ResourceBarrier recorder'

# The sniff lives INSIDE the T88d probe block (it reuses that block's lwBB/lwIdx/lwSame), so that
# block has to run in state-sniff mode too. Its guard is unique: T89d's guard continues with the two
# cached tag pointers.
$t90nAnchor = @(
    '            if (Config::Instance()->LatewarpFeedComposite.value_or_default() && cmdBuffer != nullptr &&'
    '                p2::IsRuntimeEnabled())'
) -join $nl
$t90n = @(
    '            if ((Config::Instance()->LatewarpFeedComposite.value_or_default() ||'
    '                 Config::Instance()->LatewarpProbeState.value_or_default()) && cmdBuffer != nullptr &&'
    '                p2::IsRuntimeEnabled())'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t90nAnchor $t90n 'T90n Streamline_Hooks.cpp: the tag probe also runs in state-sniff mode'

$t90lAnchor = '                            ++lwFeedT;'
$t90l = @(
    '                            ++lwFeedT;'
    ''
    '                            // P2/E2c34 (T90): WHAT STATE IS THE BACK BUFFER REALLY IN? Both device'
    '                            // removals (E2c32/E2c33) rested on an ASSUMED RENDER_TARGET, and no D3D12'
    '                            // API can report the real value. The ResourceBarrier recorder has been'
    '                            // watching the swap-chain buffers since the first hook, so this prints what'
    '                            // the APP itself last declared. Measurement only: nothing below writes to a'
    '                            // game resource.'
    '                            if (Config::Instance()->LatewarpProbeState.value_or_default())'
    '                            {'
    '                                // NOTE THE WHOLE CHAIN, not just the buffer we are standing on. The flip'
    '                                // index rotates (the first live run sniffed 1, 2, 4 and 5), and a buffer only'
    '                                // starts being watched when it is first noted -- so noting per sample meant every'
    '                                // sample was a FIRST SIGHTING and the answer was -1 four times out of four.'
    '                                ResTrack_Dx12::NoteSwapchainRange(lwSC3);'
    '                                uint32_t lwSniffState = 0xFFFFFFFFu;'
    '                                const bool lwSniffOk = ResTrack_Dx12::GetRecordedState(lwBB, &lwSniffState);'
    '                                LOG_INFO("latewarp-e2c34: state sniff idx {} ptr {:X} recordedState {} | ScalingOutput {:X} declaredState {} | same {} "'
    '                                         "(0=COMMON/PRESENT 4=RENDER_TARGET 8=NON_PIXEL_SR 16=COPY_DEST; -1 = UNTRACKED)",'
    '                                         lwIdx, (size_t) lwBB, lwSniffOk ? (int) lwSniffState : -1,'
    '                                         (size_t) g_lwScalingOut, g_lwScalingOutState, lwSame);'
    '                            }'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t90lAnchor $t90l 'T90l Streamline_Hooks.cpp: the back-buffer state sniff (record only, default off)'

# P2/E2c38a: the CALL. It sits in the T88d probe block (where lwBB / lwIdx / cmdBuffer already exist)
# and is gated by the HIDDEN key FeedCompositeApply (default false, not in the panel), so a normal run
# never reaches it.
$t95dAnchor = '                            ++lwFeedT;'
$t95d = @(
    '                            ++lwFeedT;'
    '                            // P2/E2c38a: the READ half of the feed-composite, with the state the recorder'
    '                            // measured (0 = COMMON). Writes nothing to a game resource.'
    '                            if (Config::Instance()->LatewarpFeedCompositeApply.value_or_default() && cmdBuffer != nullptr)'
    '                            {'
    '                                if (auto* lwBbFg = State::Instance().currentFG; lwBbFg != nullptr)'
    '                                    (void) lwBbFg->LatewarpReadBackbuffer(lwBB, (ID3D12GraphicsCommandList*) cmdBuffer);'
    '                            }'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t95dAnchor $t95d 'T95d Streamline_Hooks.cpp: read the back buffer at tag time (hidden key, read only)'

$t90mAnchor = '    if (!Config::Instance()->LatewarpFeedComposite.value_or_default() || !p2::IsRuntimeEnabled())'
$t90m = @(
    '    if (!Config::Instance()->LatewarpFeedComposite.value_or_default() ||'
    '        !Config::Instance()->LatewarpFeedCompositeApply.value_or_default() || !p2::IsRuntimeEnabled())'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t90mAnchor $t90m 'T90m Reprojection_Dx12.cpp: the converting feed-composite now needs TWO keys (apply set by hand)'

$t92cAnchor = '#include <hudfix/Hudfix_Dx12.h>'
$t92c = @(
    '#include <resource_tracking/ResTrack_dx12.h>   // P2/E2c35 (T92): the swap-chain state recorder'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t92cAnchor $t92c 'T92c Reprojection_Dx12.cpp: include the recorder'

$t92dAnchor = '             (size_t) swapChain, (size_t) queue, (size_t) hwnd);'
$t92d = @(
    '    // P2/E2c35 (T92): arm the swap-chain state recorder. This function runs in every session'
    '    // (the log line above is in all of them), unlike ResTrack own hook transaction, which bails'
    '    // out as soon as the game owns frame generation -- the reason two runs produced no answer.'
    '    if (Config::Instance()->LatewarpProbeState.value_or_default())'
    '        ResTrack_Dx12::InstallBarrierRecorder(_device);'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.cpp' $t92dAnchor $t92d 'T92d Reprojection_Dx12.cpp: arm the recorder when AdoptExistingSwapchain runs'

# ---------------------------------------------------------------------------
# T93 (P2/E2c37): PEAK BOOST -- give the specular highlights back.
#
# In-game A/B (user, 2026-10-01): with the warp ON the lamp highlight is visibly dimmer; WarpScale
# 0 restores it; the HighlightProtect switch makes no difference. So the loss is the KERNEL's own
# bilinear resample spreading a 1-2 px peak over its neighbours -- the game bloom is superlinear in
# luminance, so the glow collapses with the peak.
#
# The fix runs on OUR textures only: the kernel output (_lwTagOut) is lifted into a second texture
# (_lwBoost) by the existing UI compute pass in its ShowMask > 200 mode, and the in-place copy into
# the game texture then takes its source from there. Nothing new touches a game resource: the
# barriers in the copy block are the ones that already work in production.
# ---------------------------------------------------------------------------
$t93aAnchor = 'CustomOptional<bool> LatewarpFeedCompositeApply { false };   // P2/E2c34: the SECOND key the converting feed-composite needs; absent from the panel on purpose'
$t93a = @(
    'CustomOptional<float> LatewarpPeakBoost { 0.0f };     // P2/E2c37: lift the specular peaks the kernel resample damps (0 = off; ini only)'
    'CustomOptional<float> LatewarpPeakBoostThreshold { 1.5f };   // P2/E2c37: only pixels above this HDR luminance are lifted (1.0 caught the WHOLE frame; 8.0 lifted nothing) -- inside the slider range'
) -join $nl
Queue-InsertAfter 'Config.h' $t93aAnchor $t93a 'T93a Config.h += Latewarp.PeakBoost + .PeakBoostThreshold (default off)'

$t93bAnchor = '        LatewarpFeedCompositeApply.set_from_config(readBool("Latewarp", "FeedCompositeApply"));'
$t93b = @(
    '        LatewarpPeakBoost.set_from_config(readFloat("Latewarp", "PeakBoost"));'
    '        LatewarpPeakBoostThreshold.set_from_config(readFloat("Latewarp", "PeakBoostThreshold"));'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t93bAnchor $t93b 'T93b Config.cpp += read the peak-boost keys'

$t93cAnchor = @(
    '        ini.SetValue("Latewarp", "FeedCompositeApply",'
    '                     Instance()->LatewarpFeedCompositeApply.value_or_default() ? "true" : "false");'
) -join $nl
$t93c = @(
    '        ini.SetValue("Latewarp", "PeakBoost",'
    '                     GetFloatValue(Instance()->LatewarpPeakBoost.value_for_config()).c_str());'
    '        ini.SetValue("Latewarp", "PeakBoostThreshold",'
    '                     GetFloatValue(Instance()->LatewarpPeakBoostThreshold.value_for_config()).c_str());'
) -join $nl
Queue-InsertAfter 'Config.cpp' $t93cAnchor $t93c 'T93c Config.cpp += save the peak-boost keys'

$t93dAnchor = '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwTagOut;'
$t93d = @(
    '    // P2/E2c37: the peak-boost destination. Same desc as _lwTagOut (created lazily beside it);'
    '    // the boost reads _lwTagOut and writes this, and the copy back into the game texture takes'
    '    // whichever of the two is in play.'
    '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwBoost;'
    '    UINT _lwBoostW = 0;'
    '    UINT _lwBoostH = 0;'
    '    DXGI_FORMAT _lwBoostFmt = DXGI_FORMAT_UNKNOWN;'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' $t93dAnchor $t93d 'T93d Reprojection_Dx12.h: the peak-boost destination texture'

$t95aAnchor = '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwTagOut;'
$t95a = @(
    '    // P2/E2c38a: read the back buffer into our own texture, with the MEASURED state (COMMON). Read only.'
    '    bool LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list);'
    '    // P2/E2c38a: the back-buffer READ destination (desc copied from the back buffer).'
    '    Microsoft::WRL::ComPtr<ID3D12Resource> _lwBBCopy;'
    '    UINT _lwBBW = 0;'
    '    UINT _lwBBH = 0;'
    '    DXGI_FORMAT _lwBBFmt = DXGI_FORMAT_UNKNOWN;'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' $t95aAnchor $t95a 'T95a Reprojection_Dx12.h: the back-buffer read destination'

$t93eAnchor = '    // P2/E2c16: THE IN-PLACE ALTERNATIVE (opt-in). If the substitution is not honoured, put the'
$t93e = @(
    '    // P2/E2c37: PEAK BOOST (opt-in, ini Latewarp.PeakBoost). The kernel bilinear resample damps a'
    '    // 1-2 px specular peak and the game bloom is superlinear in luminance, so the glow goes with it.'
    '    // In-game A/B: WarpScale 0 restores the lamp highlight, HighlightProtect changes nothing. The'
    '    // lift happens on OUR textures only: _lwTagOut -> _lwBoost, and the copy below takes _lwBoost.'
    '    ID3D12Resource* lwCopySrc = _lwTagOut.Get();'
    '    {'
    '        // P2/E2c37d -> E2c41: RE-ENABLED (2026-10-01). The ini key Latewarp.PeakBoost drives the' + $nl + '        // amount again, default 0 = off. Why it was disabled: two attempts washed the frame white' + $nl + '        // before E2c37b/c added the amount-scaled pull and the 3x cap, and E2c37c added the init guard' + $nl + '        // that blocks a dispatch before the pass has a PSO. T94 removed the sliders on 2026-10-01.' + $nl + '        const float lwBoostAmt = Config::Instance()->LatewarpPeakBoost.value_or_default();'
    '        if (lwBoostAmt > 0.0f && _latewarpUi != nullptr)'
    '        {'
    '            if (_lwBoost == nullptr || _lwBoostW != _lwTagW || _lwBoostH != _lwTagH || _lwBoostFmt != _lwTagFmt)'
    '            {'
    '                _lwBoost.Reset();'
    '                auto lwBHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);'
    '                auto lwBTd = CD3DX12_RESOURCE_DESC::Tex2D(lwDesc.Format, (UINT) lwDesc.Width, (UINT) lwDesc.Height, 1, 1, 1, 0,'
    '                                                          D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);'
    '                if (FAILED(_device->CreateCommittedResource(&lwBHeap, D3D12_HEAP_FLAG_NONE, &lwBTd,'
    '                                                            D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr,'
    '                                                            IID_PPV_ARGS(&_lwBoost))))'
    '                {'
    '                    _lwBoost.Reset();'
    '                    LOG_ERROR("latewarp-e2c37: peak-boost target could not be created");'
    '                }'
    '                else'
    '                {'
    '                    _lwBoostW = (UINT) lwDesc.Width;'
    '                    _lwBoostH = lwDesc.Height;'
    '                    _lwBoostFmt = lwDesc.Format;'
    '                }'
    '            }'
    '            if (_lwBoost != nullptr)'
    '            {'
    '                const float lwBoostThr = Config::Instance()->LatewarpPeakBoostThreshold.value_or_default();'
    '                const bool lwBoostOk = _latewarpUi->Boost(lwList, _lwTagOut.Get(), _lwBoost.Get(), lwBoostAmt, lwBoostThr);'
    '                if (lwBoostOk)'
    '                    lwCopySrc = _lwBoost.Get();'
    '                static int lwBoostLog = 0;'
    '                if (lwBoostLog < 5)'
    '                {'
    '                    LOG_INFO("latewarp-e2c37: peak boost {} amount {} threshold {} ({}x{})", lwBoostOk ? "OK" : "FAILED",'
    '                             lwBoostAmt, lwBoostThr, _lwTagW, _lwTagH);'
    '                    ++lwBoostLog;'
    '                }'
    '            }'
    '        }'
    '    }'
    ''
    '    // P2/E2c16: THE IN-PLACE ALTERNATIVE (opt-in). If the substitution is not honoured, put the'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t93eAnchor $t93e 'T93e Reprojection_Dx12.cpp: the peak boost runs on our own textures before the copy back'

$t95cAnchor = 'ID3D12Resource* Reprojection_Dx12::LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
$t95c = @(
    '// P2/E2c38a: READ THE BACK BUFFER with the state the recorder actually measured (0 = COMMON).'
    '// D3D12 allows COMMON as the BeforeState of a transition on a resource that is in the common state,'
    '// and the app itself walks 0 -> COPY_DEST -> 0 on this very buffer. Nothing here writes a game'
    '// resource: the copy lands in _lwBBCopy, which is ours.'
    'bool Reprojection_Dx12::LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
    '{'
    '    if (backbuffer == nullptr || list == nullptr || _device == nullptr)'
    '        return false;'
    '    const D3D12_RESOURCE_DESC bd = backbuffer->GetDesc();'
    '    if (bd.Width == 0 || bd.Height == 0)'
    '        return false;'
    '    if (_lwBBCopy == nullptr || _lwBBW != (UINT) bd.Width || _lwBBH != bd.Height || _lwBBFmt != bd.Format)'
    '    {'
    '        _lwBBCopy.Reset();'
    '        auto lwBBHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);'
    '        auto lwBBTd = CD3DX12_RESOURCE_DESC::Tex2D(bd.Format, (UINT) bd.Width, bd.Height, 1, 1, 1, 0);'
    '        if (FAILED(_device->CreateCommittedResource(&lwBBHeap, D3D12_HEAP_FLAG_NONE, &lwBBTd,'
    '                                                    D3D12_RESOURCE_STATE_COPY_DEST, nullptr,'
    '                                                    IID_PPV_ARGS(&_lwBBCopy))))'
    '        {'
    '            _lwBBCopy.Reset();'
    '            LOG_ERROR("latewarp-e2c38: back-buffer read target could not be created");'
    '            return false;'
    '        }'
    '        _lwBBW = (UINT) bd.Width;'
    '        _lwBBH = bd.Height;'
    '        _lwBBFmt = bd.Format;'
    '        LOG_INFO("latewarp-e2c38: back-buffer read target {}x{} fmt {}", _lwBBW, _lwBBH, (int) _lwBBFmt);'
    '    }'
    '    D3D12_RESOURCE_BARRIER lwBBBar = {};'
    '    lwBBBar.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;'
    '    lwBBBar.Transition.pResource = backbuffer;'
    '    lwBBBar.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;'
    '    lwBBBar.Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON;   // MEASURED: recordedState 0'
    '    lwBBBar.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '    list->ResourceBarrier(1, &lwBBBar);'
    '    list->CopyResource(_lwBBCopy.Get(), backbuffer);'
    '    lwBBBar.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;'
    '    lwBBBar.Transition.StateAfter = D3D12_RESOURCE_STATE_COMMON;    // hand it back as we found it'
    '    list->ResourceBarrier(1, &lwBBBar);'
    '    static int lwBBLog = 0;'
    '    if (lwBBLog < 5)'
    '    {'
    '        LOG_INFO("latewarp-e2c38: read the back buffer {:X} {}x{} fmt {} (COMMON as the before-state)",'
    '                 (size_t) backbuffer, (UINT) bd.Width, (UINT) bd.Height, (int) bd.Format);'
    '        ++lwBBLog;'
    '    }'
    '    return true;'
    '}'
    ''
    'ID3D12Resource* Reprojection_Dx12::LatewarpWarpTaggedColor(ID3D12Resource* color, ID3D12GraphicsCommandList* gameList,'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t95cAnchor $t95c 'T95c Reprojection_Dx12.cpp: the COMMON-state back-buffer read (read only)'

$t93fAnchor = '        lwIP[1].Transition.pResource = _lwTagOut.Get();'
$t93f = @(
    '        lwIP[1].Transition.pResource = lwCopySrc;   // P2/E2c37: _lwBoost when the boost ran'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t93fAnchor $t93f 'T93f Reprojection_Dx12.cpp: the copy source follows the boost'

$t93gAnchor = '        lwList->CopyResource(color, _lwTagOut.Get());'
$t93g = @(
    '        lwList->CopyResource(color, lwCopySrc);   // P2/E2c37: _lwBoost when the boost ran'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t93gAnchor $t93g 'T93g Reprojection_Dx12.cpp: copy the boosted frame into the game texture'

# ---------------------------------------------------------------------------
# T96 (P2/E2c38c): THE FEED -- hand the composited back buffer to the generator.
#
# E2c38a proved the read: at tag time the back buffer is in state 0 (COMMON, MEASURED by the
# ResourceBarrier recorder), and 0 -> COPY_SOURCE -> 0 plus a copy into our own texture runs with no
# device removal. This closes the loop: the copy in _lwBBCopy (world already warped by mechanism C +
# the late-composited layer the generated frames were missing) is handed to the generator own colour
# input through the existing converting-copy path (T89b), reading OUR texture so the game back buffer
# never leaves COMMON.
#
# Gate: FeedComposite AND FeedCompositeApply (both default off; the first has a panel checkbox).
# ---------------------------------------------------------------------------
$t96aAnchor = '    // P2/E2c38a: the back-buffer READ destination (desc copied from the back buffer).'
$t96a = @(
    '    // P2/E2c38c: hand the composited back buffer (in _lwBBCopy) to the generator colour input.'
    '    void LatewarpFeedFromCopy(ID3D12Resource* target, ID3D12Resource* hudless, uint32_t hudlessState,'
    '                              ID3D12Resource* depth, uint32_t depthState, ID3D12GraphicsCommandList* list);'
    '    // P2/E2c38a: the back-buffer READ destination (desc copied from the back buffer).'
) -join $nl
Queue-InsertAfter 'framegen\reprojection\Reprojection_Dx12.h' $t96aAnchor $t96a 'T96a Reprojection_Dx12.h: the feed-from-our-copy entry point'

$t96bAnchor = '    virtual bool LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
$t96b = @(
    '    // P2/E2c38c: feed the composited back buffer (read into our own texture) to the generator.'
    '    virtual void LatewarpFeedFromCopy(ID3D12Resource* target, ID3D12Resource* hudless, uint32_t hudlessState,'
    '                                       ID3D12Resource* depth, uint32_t depthState, ID3D12GraphicsCommandList* list)'
    '    {'
    '    }'
    '    virtual bool LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
) -join $nl
Queue-ReplaceLiteral 'framegen\IFGFeature_Dx12.h' $t96bAnchor $t96b 'T96b IFGFeature_Dx12.h: the feed-from-our-copy declaration'

$t96cAnchor = 'bool Reprojection_Dx12::LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
$t96c = @(
    '// P2/E2c38c: the WRITE half. The source is OUR copy (_lwBBCopy), so the game back buffer is never'
    '// touched: its state stays COMMON and the game own 0 -> COPY_DEST -> 0 walk remains legal. The'
    '// target is the generator own colour input and its declared state comes from the tag, exactly as'
    '// the in-place mechanism-C write already does every frame.'
    'void Reprojection_Dx12::LatewarpFeedFromCopy(ID3D12Resource* target, ID3D12Resource* hudless, uint32_t hudlessState,'
    '                                             ID3D12Resource* depth, uint32_t depthState, ID3D12GraphicsCommandList* list)'
    '{'
    '    if (target == nullptr || hudless == nullptr || depth == nullptr || list == nullptr || _lwBBCopy == nullptr)'
    '        return;'
    '    if (!Config::Instance()->LatewarpFeedComposite.value_or_default() ||'
    '        !Config::Instance()->LatewarpFeedCompositeApply.value_or_default() || !p2::IsRuntimeEnabled())'
    '        return;'
    '    static int lwFeedLog = 0;'
    '    ID3D12Resource* lwR = LatewarpFeedComposite(target, _lwBBCopy.Get(), D3D12_RESOURCE_STATE_COPY_DEST,'
    '                                                hudless, (D3D12_RESOURCE_STATES) hudlessState, depth,'
    '                                                (D3D12_RESOURCE_STATES) depthState, list);'
    '    if (lwFeedLog < 5)'
    '    {'
    '        LOG_INFO("latewarp-e2c38c: feed {} target {:X} from our back-buffer copy {:X}", lwR != nullptr ? "OK" : "FAILED",'
    '                 (size_t) target, (size_t) _lwBBCopy.Get());'
    '        ++lwFeedLog;'
    '    }'
    '}'
    ''
    'bool Reprojection_Dx12::LatewarpReadBackbuffer(ID3D12Resource* backbuffer, ID3D12GraphicsCommandList* list)'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t96cAnchor $t96c 'T96c Reprojection_Dx12.cpp: the feed-from-our-copy implementation'

$t96dAnchor = '                            if (Config::Instance()->LatewarpFeedCompositeApply.value_or_default() && cmdBuffer != nullptr)'
$t96d = @(
    '                            if (Config::Instance()->LatewarpFeedCompositeApply.value_or_default() && cmdBuffer != nullptr)'
    '                            {'
    '                                // P2/E2c38c: read the composited back buffer, then hand it to the generator.'
    '                                if (auto* lwBbFg = State::Instance().currentFG; lwBbFg != nullptr)'
    '                                {'
    '                                    (void) lwBbFg->LatewarpReadBackbuffer(lwBB, (ID3D12GraphicsCommandList*) cmdBuffer);'
    '                                    if (g_lwScalingOut != nullptr)'
    '                                        lwBbFg->LatewarpFeedFromCopy(g_lwScalingOut, g_lwHudlessTag, g_lwHudlessTagState,'
    '                                                                     g_lwDepthTag, g_lwDepthTagState,'
    '                                                                     (ID3D12GraphicsCommandList*) cmdBuffer);'
    '                                }'
    '                            }'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t96dAnchor $t96d 'T96d Streamline_Hooks.cpp: read then feed the composited frame'

# ---------------------------------------------------------------------------
# T97 (P2/E2c39): THE FEED, MOVED TO THE SAFE WINDOW.
#
# 12:30 measured exactly why the tag-time feed removed the device: the read was fine (COMMON worked),
# but WRITING the generator colour input at tag time collides with the generator own in-flight read
# ('[presentFrame] Async present failed' right after).
#
# Fix: keep the READ at tag time (proven safe, into _lwBBCopy), and do the WRITE at the mechanism-C
# insertion point of the NEXT frame -- the upscaler evaluate -- which is the write this patch set
# already performs every frame without incident. Implementation: before the in-place write-back,
# override _lwTagOut with the composited frame we saved, using OUR textures only; the existing
# in-place block then carries it into the game texture with the barrier states it already uses.
# ---------------------------------------------------------------------------
$t97Anchor = '    // P2/E2c37: PEAK BOOST (opt-in, ini Latewarp.PeakBoost). The kernel bilinear resample damps a'
$t97 = @(
    '    // P2/E2c39: THE FEED AT THE SAFE WINDOW. The composited frame read at the PREVIOUS tag is',
    '    // copied over _lwTagOut here, at the upscaler evaluate; the in-place write-back below then',
    '    // carries it into the generator colour input with the states it already uses every frame.',
    '    // Both ends of this copy are OUR textures, so no game resource changes state here.',
    '    if (Config::Instance()->LatewarpFeedComposite.value_or_default() &&',
    '        Config::Instance()->LatewarpFeedCompositeApply.value_or_default() && _lwBBCopy != nullptr &&',
    '        Config::Instance()->LatewarpTagWarpInPlace.value_or_default() && _lwTagOut != nullptr)',
    '    {',
    '        D3D12_RESOURCE_BARRIER lwFb[2] = {};',
    '        lwFb[0].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;',
    '        lwFb[0].Transition.pResource = _lwTagOut.Get();',
    '        lwFb[0].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;',
    '        lwFb[0].Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;',
    '        lwFb[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;',
    '        lwFb[1].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;',
    '        lwFb[1].Transition.pResource = _lwBBCopy.Get();',
    '        lwFb[1].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;',
    '        lwFb[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;',
    '        lwFb[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;',
    '        lwList->ResourceBarrier(2, lwFb);',
    '        lwList->CopyResource(_lwTagOut.Get(), _lwBBCopy.Get());',
    '        lwFb[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;',
    '        lwFb[0].Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;',
    '        lwFb[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;',
    '        lwFb[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;',
    '        lwList->ResourceBarrier(2, lwFb);',
    '        static int lwFeedSwapLog = 0;',
    '        if (lwFeedSwapLog < 5)',
    '        {',
    '            LOG_INFO("latewarp-e2c39: feed swap: _lwTagOut now carries the composited frame {}x{}", _lwTagW, _lwTagH);',
    '            ++lwFeedSwapLog;',
    '        }',
    '    }',
    '',
    '    // P2/E2c37: PEAK BOOST (opt-in, ini Latewarp.PeakBoost). The kernel bilinear resample damps a'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t97Anchor $t97 'T97 Reprojection_Dx12.cpp: the feed moves to the upscaler evaluate (safe window)'

# P2/E2c39: at TAG time only the READ runs. The WRITE moved to the upscaler evaluate (T97), because
# writing the generator colour input here removed the device at 12:30 (its read was in flight).
$t98Anchor = @(
    '                                    if (g_lwScalingOut != nullptr)'
    '                                        lwBbFg->LatewarpFeedFromCopy(g_lwScalingOut, g_lwHudlessTag, g_lwHudlessTagState,'
    '                                                                     g_lwDepthTag, g_lwDepthTagState,'
    '                                                                     (ID3D12GraphicsCommandList*) cmdBuffer);'
) -join $nl
$t98 = @(
    '                                    // P2/E2c39: ONLY the read happens at tag time; the write moved to the'
    '                                    // upscaler evaluate (T97). The tag-time write removed the device at 12:30'
    '                                    // because the generator own read of this resource was still in flight.'
) -join $nl
Queue-ReplaceLiteral 'hooks\Streamline_Hooks.cpp' $t98Anchor $t98 'T98 Streamline_Hooks.cpp: tag time reads only, the write happens at the evaluate'

# ---------------------------------------------------------------------------
# T99 (P2/E2c40): FEED BY TAG SUBSTITUTION -- the last safe design.
#
# E2c39 proved the mechanics (read + swap ran 65 s / 3231 frames) but writing the game texture still
# lost the device eventually: the frame generator consumes its colour input ASYNCHRONOUSLY, so ANY
# write to it outside its own window is a race, no matter which command list we use.
#
# The only design that writes NO game resource is the tag substitution we already have for the warp:
# hand the generator OUR texture instead of the game one. So when the feed is on, return the
# composited frame we read at the previous tag (_lwBBCopy) as the substituted resource -- the
# generator then reads a texture that is entirely ours.
# ---------------------------------------------------------------------------
$t99Anchor = '    // P2/E2c39: THE FEED AT THE SAFE WINDOW. The composited frame read at the PREVIOUS tag is'
$t99 = @(
    '    // P2/E2c40: FEED BY TAG SUBSTITUTION. Hand the generator OUR composited frame (_lwBBCopy) as'
    '    // the tagged colour input. NOTHING here writes a game resource -- that is the whole point: the'
    '    // generator own read of the game texture is asynchronous, so writing it is a race (12:30 and'
    '    // 12:41 both lost it). Our texture only needs to be in the state the tag declares.',
    '    if (Config::Instance()->LatewarpFeedComposite.value_or_default() &&',
    '        Config::Instance()->LatewarpFeedCompositeApply.value_or_default() && _lwBBCopy != nullptr)',
    '    {',
    '        D3D12_RESOURCE_BARRIER lwSub = {};',
    '        lwSub.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;',
    '        lwSub.Transition.pResource = _lwBBCopy.Get();',
    '        lwSub.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;',
    '        lwSub.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;',
    '        lwSub.Transition.StateAfter = D3D12_RESOURCE_STATE_ALL_SHADER_RESOURCE;',
    '        lwList->ResourceBarrier(1, &lwSub);',
    '        static int lwSubLog = 0;',
    '        if (lwSubLog < 5)',
    '        {',
    '            LOG_INFO("latewarp-e2c40: feed by SUBSTITUTION -- the generator gets our composited frame {:X}",',
    '                     (size_t) _lwBBCopy.Get());',
    '            ++lwSubLog;',
    '        }',
    '        return _lwBBCopy.Get();',
    '    }',
    '',
    '    // P2/E2c39: THE FEED AT THE SAFE WINDOW. The composited frame read at the PREVIOUS tag is'
) -join $nl
Queue-ReplaceLiteral 'framegen\reprojection\Reprojection_Dx12.cpp' $t99Anchor $t99 'T99 Reprojection_Dx12.cpp: feed by tag substitution (no game resource is written)'

# ---------------------------------------------------------------------------
# T100 (E2c44): FEED THE LATEWARP BACKEND FROM THE UPSCALER INPUTS IN NoFG MODE.
# The backend reads its planes (Depth / MotionVectors / HudlessColor) from the FG resource ring,
# and that ring is filled by the Streamline input hook (Sl_Inputs_Dx12::reportResource). The game
# stops tagging those planes the moment it stops generating frames. MEASURED 2026-10-01 on the
# 13:48 run (FG off, 112 s): reportResource printed 4392 lines but Reprojection_Dx12::SetResource
# was 0 -- the backend never saw a single plane, so the depth cutout could not run (no viewmodel
# mask and no pink overlay either) while the warp itself kept running. The upscaler inputs are
# always there (DLSS SR still evaluates), so UpscalerInputsDx12 feeds the same backend instead.
# Scope: the new term is true only for FGOutput=NoFG AND Reprojection.UseNvidiaLatewarp, so the
# normal frame-generation path stays unchanged.
$t100aOld = 'void UpscalerInputsDx12::Init(ID3D12Device* device)' + $nl + '{' + $nl + '    if (State::Instance().activeFgInput != FGInput::Upscaler)' + $nl + '        return;'
$t100aNew = 'void UpscalerInputsDx12::Init(ID3D12Device* device)' + $nl + '{' + $nl + '    const bool lwFeed = Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();' + $nl + $nl + '    if (!lwFeed && State::Instance().activeFgInput != FGInput::Upscaler)' + $nl + '        return;'
Queue-ReplaceLiteral 'inputs\FG\Upscaler_Inputs_Dx12.cpp' $t100aOld $t100aNew 'T100a Upscaler_Inputs_Dx12.cpp: Init keeps the device in latewarp-only NoFG'

$t100bOld = '    if (fg == nullptr || State::Instance().activeFgInput != FGInput::Upscaler || _device == nullptr)' + $nl + '        return;' + $nl + $nl + '    FG_Constants fgConstants {};'
$t100bNew = '    const bool lwFeed = Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default();' + $nl + $nl + '    if (fg == nullptr || _device == nullptr ||' + $nl + '        (!lwFeed && State::Instance().activeFgInput != FGInput::Upscaler))' + $nl + '        return;' + $nl + $nl + '    FG_Constants fgConstants {};'
Queue-ReplaceLiteral 'inputs\FG\Upscaler_Inputs_Dx12.cpp' $t100bOld $t100bNew 'T100b Upscaler_Inputs_Dx12.cpp: the upscaler feed also runs in latewarp-only NoFG mode'

$t100cOld = '    if (!State::Instance().isShuttingDown && fg->IsActive() && Config::Instance()->FGEnabled.value_or_default() &&' + $nl + '        State::Instance().currentSwapchain != nullptr)'
$t100cNew = '    if (!State::Instance().isShuttingDown && fg->IsActive() &&' + $nl + '        (lwFeed || (Config::Instance()->FGEnabled.value_or_default() &&' + $nl + '                    State::Instance().currentSwapchain != nullptr)))'
Queue-ReplaceLiteral 'inputs\FG\Upscaler_Inputs_Dx12.cpp' $t100cOld $t100cNew 'T100c Upscaler_Inputs_Dx12.cpp: feed the planes without an OptiScaler-owned swapchain'

# --- T101 (E2c45): THE MISSING PLANE FOR THE NoFG PRESENT-CHAIN PASS -----------------------------
# Measured on the 13:48/14:03 runs with the game NOT generating frames: reportResource still fires for
# Depth (0) and MotionVectors (1), but HUDLessColor (2) is never tagged -- the game only tags it while
# it generates frames. The present-chain pass needs a hudless plane, so its depth-cutout mask and the
# pink overlay never ran (latewarp-diag printed 0 lines for a whole run). The game DOES keep tagging
# ScalingOutputColor (4), and that is exactly the frame the C path feeds as hudlessColor.
$t101Anchor = '    lwProbeBackbufferTag(tags, numTags, cmdBuffer, "slSetTag");   // P2/E2c11c: AFTER the resource push'
$t101 = '    // P2/E2c45: THE MISSING PLANE (see the T101 note in the patch script). The game keeps tagging' + $nl + '    // ScalingOutputColor even when it does not generate frames; the present-chain pass needs a' + $nl + '    // hudless plane, so hand this one to the backend with the state the tag contract declares.' + $nl + '    if (Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() &&' + $nl + '        State::Instance().currentFG != nullptr)' + $nl + '    {' + $nl + '        for (uint32_t i = 0; i < numTags; ++i)' + $nl + '        {' + $nl + '            if (tags[i].type != sl::kBufferTypeScalingOutputColor || tags[i].resource == nullptr ||' + $nl + '                tags[i].resource->native == nullptr)' + $nl + '                continue;' + $nl + '            if (auto* lwFgFeed = State::Instance().currentFG; lwFgFeed != nullptr)' + $nl + '            {' + $nl + '                const auto lwFeedDesc = ((ID3D12Resource*) tags[i].resource->native)->GetDesc();' + $nl + '                Dx12Resource lwFeed {};' + $nl + '                lwFeed.type = FG_ResourceType::HudlessColor;' + $nl + '                lwFeed.cmdList = (ID3D12GraphicsCommandList*) cmdBuffer;' + $nl + '                lwFeed.resource = (ID3D12Resource*) tags[i].resource->native;' + $nl + '                lwFeed.width = (uint32_t) lwFeedDesc.Width;' + $nl + '                lwFeed.height = (uint32_t) lwFeedDesc.Height;' + $nl + '                lwFeed.state = (D3D12_RESOURCE_STATES) tags[i].resource->state;' + $nl + '                lwFeed.validity = FG_ResourceValidity::UntilPresent;' + $nl + '                lwFgFeed->SetResource(&lwFeed);' + $nl + '                lwFgFeed->SetInterpolationRect(lwFeed.width, lwFeed.height);' + $nl + '            }' + $nl + '        }' + $nl + '    }'
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t101Anchor $t101 'T101 Streamline_Hooks.cpp: feed ScalingOutputColor as the hudless plane in latewarp-only mode'

# --- T102 (E2c46): GIVE THE UPSCALER-FED DEPTH A VALIDITY THE PRESENT-CHAIN GATE ACCEPTS ------------
# The gate in Reprojection_Dx12.cpp wants depth->validity != ValidNow (that is how it tells the FG own
# frame from ours). The upscaler feed marks the plane ValidNow, so the gate stayed shut even with the
# depth present. In the latewarp-only NoFG mode the plane is for OUR pass, so UntilPresent is correct.
$t102Anchor = '            if (!done)' + $nl + '            {' + $nl + '                Dx12Resource setResource {};' + $nl + '                setResource.type = FG_ResourceType::Depth;' + $nl + '                setResource.cmdList = commandList;' + $nl + '                setResource.resource = paramDepth;' + $nl + '                setResource.width = feature->RenderWidth();' + $nl + '                setResource.height = feature->RenderHeight();' + $nl + '                setResource.state = (D3D12_RESOURCE_STATES) Config::Instance()->DepthResourceBarrier.value_or(' + $nl + '                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);' + $nl + '                setResource.validity = FG_ResourceValidity::ValidNow;'
$t102 = $t102Anchor.Replace('                setResource.validity = FG_ResourceValidity::ValidNow;', '                setResource.validity =' + $nl + '                    lwFeed ? FG_ResourceValidity::UntilPresent : FG_ResourceValidity::ValidNow;')
Queue-ReplaceLiteral 'inputs\FG\Upscaler_Inputs_Dx12.cpp' $t102Anchor $t102 'T102 Upscaler_Inputs_Dx12.cpp: the NoFG depth plane is UntilPresent, not ValidNow'

Queue-VcxBuildHygiene

# ---------------------------------------------------------------------------
# T103 (2026-10-01 PANEL CLEANUP). Both edits run on the FINAL menu text (Queue-Patch, last in
# the file) so no anchor any earlier patch depends on moves: (a) the two leftover DEBUG rows are
# disabled, (b) every long label moves onto its own line above its widget -- ImGui draws a label
# NEXT TO the item, and a long one stretches the whole panel.
$t103_p2MaskThreshold = 'if \(ImGui::SliderFloat\("([^"]*)",\s*&p2MaskThreshold,\s*([^)]*)\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2MaskThreshold ('ImGui::TextUnformatted("$1");' + $nl + '        ImGui::SetNextItemWidth(-1.0f);' + $nl + '        if (ImGui::SliderFloat("##p2MaskThreshold", &p2MaskThreshold, $2))') 'T103 mask threshold: label above the slider'
$t103_p2WarpStrength = 'if \(ImGui::SliderFloat\("([^"]*)",\s*&p2WarpStrength,\s*([^)]*)\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2WarpStrength ('ImGui::TextUnformatted("$1");' + $nl + '        ImGui::SetNextItemWidth(-1.0f);' + $nl + '        if (ImGui::SliderFloat("##p2WarpStrength", &p2WarpStrength, $2))') 'T103 warp strength: label above the slider'
$t103_p2DepthCutoff = 'if \(ImGui::SliderFloat\("([^"]*)",\s*&p2DepthCutoff,\s*([^)]*)\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2DepthCutoff ('ImGui::TextUnformatted("$1");' + $nl + '        ImGui::SetNextItemWidth(-1.0f);' + $nl + '        if (ImGui::SliderFloat("##p2DepthCutoff", &p2DepthCutoff, $2))') 'T103 depth cutoff: label above the slider'
$t103_p2WarpScale = 'if \(ImGui::SliderFloat\("([^"]*)",\s*&p2WarpScale,\s*([^)]*)\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2WarpScale ('ImGui::TextUnformatted("$1");' + $nl + '        ImGui::SetNextItemWidth(-1.0f);' + $nl + '        if (ImGui::SliderFloat("##p2WarpScale", &p2WarpScale, $2))') 'T103 warp scale: label above the slider'
$t103_p2ViewModelMask = 'if \(ImGui::Checkbox\("([^"]*)", &p2ViewModelMask\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2ViewModelMask ('ImGui::TextUnformatted("$1");' + $nl + '        if (ImGui::Checkbox("##p2ViewModelMask", &p2ViewModelMask))') 'T103 viewmodel mask: label above the checkbox'
$t103_p2PresentOnly = 'if \(ImGui::Checkbox\("([^"]*)", &p2PresentOnly\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2PresentOnly ('ImGui::TextUnformatted("$1");' + $nl + '        if (ImGui::Checkbox("##p2PresentOnly", &p2PresentOnly))') 'T103 PresentOnly: label above the checkbox'
$t103_p2ShowMask = 'if \(ImGui::Checkbox\("([^"]*)", &p2ShowMask\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103_p2ShowMask ('ImGui::TextUnformatted("$1");' + $nl + '        if (ImGui::Checkbox("##p2ShowMask", &p2ShowMask))') 'T103 show static elements: label above the checkbox'
$t103diag = 'if \(ImGui::SliderFloat\("([^"]*)", &lwDiagMap, ([^)]*)\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103diag 'if (false && ImGui::SliderFloat("$1", &lwDiagMap, $2))' 'T103 hide the P3-3 diagnostic slider (label kept: the gate asserts it; the ini key still works)'
$t103feed = 'if \(ImGui::Checkbox\("([^"]*)", &p2FeedComposite\)\)'
Queue-Patch 'menu\menu_common.cpp' $t103feed 'if (false && ImGui::Checkbox("$1", &p2FeedComposite))' 'T103 hide the experimental feed-composite checkbox (label kept)'
$t103hints = '(Config::Instance\(\)->LatewarpFeedComposite = p2FeedComposite;)(\s*ImGui::TextUnformatted\("[^"]*"\);){3}'
Queue-Patch 'menu\menu_common.cpp' $t103hints '$1' 'T103 drop its three debug hint lines'

# --- T104 (2026-10-07): the tag-hook entry probe --------------------------------------------------
# B1 in BUGS_AND_ROBUSTNESS.md: in the NoFG/present-chain mode the tag hook never reached the probe
# at the end of hkslSetTag, so the hudless plane never arrived and the present-chain pass stayed
# shut. This probe answers which early return it takes -- the fix goes in after that answer.
$t104anchor = '    if (tags == nullptr)' + $nl + '    {' + $nl + '        LOG_WARN("Game trying to remove a tag");' + $nl + '        return o_slSetTag(viewport, tags, numTags, cmdBuffer);' + $nl + '    }'
$t104 = '    // P2/E2c49 (T104) DIAGNOSTIC, first calls only. The NoFG (present-chain) mode never reached our' + $nl + '    // tag probe at the end of this function (measured 15:07: TAG INVENTORY 0 lines for a whole run),' + $nl + '    // which means an early return swallowed it. These lines say whether the hook runs at all and' + $nl + '    // with what, so the next round does not have to guess.' + $nl + '    {' + $nl + '        static int lwTagEntry = 0;' + $nl + '        if (lwTagEntry < 3)' + $nl + '        {' + $nl + '            LOG_INFO("latewarp-tag: hkslSetTag entered (tags {:X}, numTags {}, api {})", (size_t) tags,' + $nl + '                     numTags, (int) renderApi);' + $nl + '            ++lwTagEntry;' + $nl + '        }' + $nl + '    }'
Queue-InsertAfter 'hooks\Streamline_Hooks.cpp' $t104anchor $t104 'T104 Streamline_Hooks.cpp: one-shot entry probe for the tag hook'
Write-Host ("target tree : " + $Tree)
Write-Host ("patches     : " + $script:notes.Count + " in " + $script:fileOrder.Count + " file(s)")
foreach ($n in $script:notes) { Write-Host ("  - " + $n.note + "   [" + $n.before + " -> " + $n.after + "]") }
Write-Host ("new files   : " + $NewFiles.Count)
foreach ($f in $NewFiles) { Write-Host ("  - OptiScaler\" + $f) }
if ($DryRun) { Write-Host "[dry] nothing written"; return }

New-Item -ItemType Directory -Force -Path $BakDir | Out-Null
$log = @('# APPLIED_DIFF -- P2 latewarp patch set', ('# applied ' + (Get-Date).ToString('s')), ('# target: ' + $Tree), '')
foreach ($abs in $script:fileOrder) {
    $rel = $script:fileRel[$abs]
    $bak = Join-Path $BakDir $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $bak -Parent) | Out-Null
    if (Test-Path -LiteralPath $abs) { Copy-Item -LiteralPath $abs -Destination $bak -Force }
    Write-Text $abs $script:fileState[$abs]
    $log += ('== ' + $rel)
    $log += ('   lines: ' + (LineCount $script:fileOriginal[$abs]) + ' -> ' + (LineCount $script:fileState[$abs]))
    $log += ('   backup: ' + $bak)
    foreach ($n in ($script:notes | Where-Object { $_.rel -eq $rel })) { $log += ('   - ' + $n.note) }
    $log += ''
    Write-Host ("[apply] wrote " + $rel + "  (" + (LineCount $script:fileOriginal[$abs]) + " -> " + (LineCount $script:fileState[$abs]) + " lines)")
}
$addedList = @()
foreach ($rel in $script:genAdded) { $addedList += $rel; $log += ('== generated (revert deletes): ' + $rel) }
foreach ($rel in $NewFiles) {
    $dst = Join-Path $Src $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $dst -Parent) | Out-Null
    Copy-Item -LiteralPath (Join-Path $P2 ('files\' + $rel)) -Destination $dst -Force
    $addedList += $rel
    $log += ('== added file: ' + $rel)
    Write-Host ("[apply] added " + $rel)
}
$log += ''
$log += '# revert: .\apply_to_optiscaler.ps1 -Revert'
[System.IO.File]::WriteAllLines($DiffFile, $log)
$state = @(('backup=' + $BakDir)) + ($addedList | ForEach-Object { 'added=' + $_ })
[System.IO.File]::WriteAllLines($StateFile, $state)
Write-Host ("[apply] diff list -> " + $DiffFile)
Write-Host "[apply] OK"
