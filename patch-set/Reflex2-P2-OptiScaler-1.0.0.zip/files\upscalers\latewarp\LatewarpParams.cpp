// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#include "LatewarpParams.h"

namespace p2
{

static const char* const kW[] = {
    "Latewarp.Output.Width", "Latewarp.Output.Height",
    "Latewarp.Output.Subrect.Base.X", "Latewarp.Output.Subrect.Base.Y",
    "Latewarp.Output.Subrect.Width", "Latewarp.Output.Subrect.Height",
    "Latewarp.HudlessColor",
    "Latewarp.HudlessColor.Subrect.Base.X", "Latewarp.HudlessColor.Subrect.Base.Y",
    "Latewarp.HudlessColor.Subrect.Width", "Latewarp.HudlessColor.Subrect.Height",
    "Latewarp.Depth.Subrect.Base.X", "Latewarp.Depth.Subrect.Base.Y",
    "Latewarp.Depth.Subrect.Width", "Latewarp.Depth.Subrect.Height",
    "Latewarp.Backbuffer",
    "Latewarp.Backbuffer.Subrect.Base.X", "Latewarp.Backbuffer.Subrect.Base.Y",
    "Latewarp.Backbuffer.Subrect.Width", "Latewarp.Backbuffer.Subrect.Height",
    "Latewarp.UIColorAlpha",
    "Latewarp.UIColorAlpha.Subrect.Base.X", "Latewarp.UIColorAlpha.Subrect.Base.Y",
    "Latewarp.UIColorAlpha.Subrect.Width", "Latewarp.UIColorAlpha.Subrect.Height",
    "Latewarp.MV.Subrect.Base.X", "Latewarp.MV.Subrect.Base.Y",
    "Latewarp.MV.Subrect.Width", "Latewarp.MV.Subrect.Height",
    "Latewarp.NoWarpMask",
    "Latewarp.NoWarpMask.Subrect.Base.X", "Latewarp.NoWarpMask.Subrect.Base.Y",
    "Latewarp.NoWarpMask.Subrect.Width", "Latewarp.NoWarpMask.Subrect.Height",
    "Latewarp.EvalFlags", "Latewarp.DepthInverted", "Latewarp.IsRenderedFrame",
    "Latewarp.FrameID", "Latewarp.UsePremultiplyUIAlpha",
    "Latewarp.WorldToViewMatrix", "Latewarp.ViewToClipMatrix",
    "Latewarp.PrevRenderedWorldToViewMatrix", "Latewarp.PrevRenderedViewToClipMatrix",
};
static const int kWCount = (int)(sizeof(kW) / sizeof(kW[0]));

static const char* const kPlanes[] = { "Depth", "MotionVectors", "Output" };
static const int kPlaneCount = (int)(sizeof(kPlanes) / sizeof(kPlanes[0]));

// NGX-generic keys (no "Latewarp." prefix) that the kernel also reads; see the header.
static const char* const kExtra[] = { "Jitter.Offset.X", "Jitter.Offset.Y" };
static const int kExtraCount = (int)(sizeof(kExtra) / sizeof(kExtra[0]));

int LatewarpKeyCount() { return kWCount; }
int PlaneKeyCount() { return kPlaneCount; }
const char* LatewarpKeyAt(int i) { return (i >= 0 && i < kWCount) ? kW[i] : nullptr; }
const char* PlaneKeyAt(int i) { return (i >= 0 && i < kPlaneCount) ? kPlanes[i] : nullptr; }
int ExtraKeyCount() { return kExtraCount; }
const char* ExtraKeyAt(int i) { return (i >= 0 && i < kExtraCount) ? kExtra[i] : nullptr; }

static bool Eq(const char* a, const char* b)
{
    if (a == nullptr || b == nullptr) return false;
    while (*a && *b) { if (*a != *b) return false; ++a; ++b; }
    return *a == 0 && *b == 0;
}

bool IsLatewarpKey(const char* key)
{
    for (int i = 0; i < kWCount; ++i) if (Eq(kW[i], key)) return true;
    for (int i = 0; i < kPlaneCount; ++i) if (Eq(kPlanes[i], key)) return true;
    for (int i = 0; i < kExtraCount; ++i) if (Eq(kExtra[i], key)) return true;
    return false;
}

// ---------------------------------------------------------------------------
//  write helpers: one whitelist gate for every single write
// ---------------------------------------------------------------------------
static void W(ISink& s, Stats* st, const char* key, ValueType t, const void* v)
{
    if (!IsLatewarpKey(key))
    {
        if (st) { st->refused++; }
        return;                                   // REFUSED, never written
    }
    if (s.Set(key, t, v))
    {
        if (st) st->written++;
    }
}

static void WInt(ISink& s, Stats* st, const char* k, int32_t v)   { W(s, st, k, ValueType::Int32, &v); }
static void WUInt(ISink& s, Stats* st, const char* k, uint32_t v) { W(s, st, k, ValueType::UInt32, &v); }
static void WFloat(ISink& s, Stats* st, const char* k, float v)   { W(s, st, k, ValueType::Float, &v); }
static void WPtr(ISink& s, Stats* st, const char* k, void* v)     { W(s, st, k, ValueType::Pointer, &v); }

static void WSubrect(ISink& s, Stats* st, const char* prefix, const int32_t r[4])
{
    char buf[96];
    int n = 0;
    const char* a = prefix;
    while (*a && n < 60) buf[n++] = *a++;
    if (r[2] == 0 && r[3] == 0) return;          // unset => leave the keys alone

    const char* names[4] = { ".Subrect.Base.X", ".Subrect.Base.Y", ".Subrect.Width", ".Subrect.Height" };
    for (int i = 0; i < 4; ++i)
    {
        int m = n;
        const char* t = names[i];
        while (*t && m < 90) buf[m++] = *t++;
        buf[m] = 0;
        WInt(s, st, buf, r[i]);
    }
}

bool TryWriteKey(ISink& sink, Stats* st, const char* key, ValueType type, const void* value)
{
    const int refusedBefore = st ? st->refused : 0;
    W(sink, st, key, type, value);
    return !(st && st->refused > refusedBefore);
}

int Fill(ISink& sink, const Inputs& in, Stats* st)
{
    if (st) { st->written = 0; st->refused = 0; }

    // ---- 1. output extent (its absence is a HARD failure: 0xBAD00005) --------
    WUInt(sink, st, "Latewarp.Output.Width", in.outputWidth);
    WUInt(sink, st, "Latewarp.Output.Height", in.outputHeight);

    // ---- 2. plane handles ---------------------------------------------------
    // S10 F-05: ONLY bind a plane when we actually have one. Writing a nullptr for a key the
    // game already set would clobber the game's own input -- and the frame probe reads exactly
    // these keys, so the probe's answer would be discarded in the same frame.
    if (in.backbuffer)    WPtr(sink, st, "Latewarp.Backbuffer", in.backbuffer);
    if (in.hudlessColor)  WPtr(sink, st, "Latewarp.HudlessColor", in.hudlessColor);
    if (in.noWarpMask)    WPtr(sink, st, "Latewarp.NoWarpMask", in.noWarpMask);
    if (in.depth)         WPtr(sink, st, "Depth", in.depth);
    if (in.motionVectors) WPtr(sink, st, "MotionVectors", in.motionVectors);
    if (in.output)        WPtr(sink, st, "Output", in.output);
    // Latewarp.UIColorAlpha is the ONE plane we deliberately set to null (the decisive key),
    // and it is written last, together with IsRenderedFrame.

    // ---- 3. subrects (index order matches the payload: see LATEWARP_ABI.md) --
    static const char* const kSubPrefix[7] = {
        "Latewarp.Backbuffer", "Latewarp.HudlessColor", "Latewarp.UIColorAlpha",
        "Latewarp.Depth", "Latewarp.MV", "Latewarp.Output", "Latewarp.NoWarpMask"
    };
    for (int i = 0; i < 7; ++i) WSubrect(sink, st, kSubPrefix[i], in.subrect[i]);

    // ---- 4. per-frame scalars ----------------------------------------------
    WUInt(sink, st, "Latewarp.FrameID", in.frameId);
    WInt(sink, st, "Latewarp.DepthInverted", in.depthInverted);
    WInt(sink, st, "Latewarp.UsePremultiplyUIAlpha", in.usePremultiplyUIAlpha);
    WInt(sink, st, "Latewarp.EvalFlags", in.evalFlags);

    // Jitter is carried by the NGX-GENERIC keys (no "Latewarp." prefix), which is exactly why it
    // is not one of the 43 Latewarp.* literals: the payload has the fields at +0x158/+0x15C
    // (spec/LATEWARP_ABI.md) and the real feature DLL carries both literals. The official FrameWarp
    // sample writes them every frame; we write whatever the caller sets (0 until P3-5b wires the
    // host's jitter from Streamline's constants). Written BEFORE the two decisive keys on purpose.
    WFloat(sink, st, "Jitter.Offset.X", in.jitterX);
    WFloat(sink, st, "Jitter.Offset.Y", in.jitterY);

    // ---- 5. matrices -------------------------------------------------------
    if (in.worldToView)     W(sink, st, "Latewarp.WorldToViewMatrix", ValueType::Pointer, &in.worldToView);
    if (in.viewToClip)      W(sink, st, "Latewarp.ViewToClipMatrix", ValueType::Pointer, &in.viewToClip);
    if (in.prevWorldToView) W(sink, st, "Latewarp.PrevRenderedWorldToViewMatrix", ValueType::Pointer, &in.prevWorldToView);
    if (in.prevViewToClip)  W(sink, st, "Latewarp.PrevRenderedViewToClipMatrix", ValueType::Pointer, &in.prevViewToClip);

    // ---- 6. THE TWO DECISIVE KEYS, LAST ------------------------------------
    if (in.nullOutUIColorAlpha) WPtr(sink, st, "Latewarp.UIColorAlpha", nullptr);
    WInt(sink, st, "Latewarp.IsRenderedFrame", in.isRenderedFrame);

    return st ? st->written : 0;
}

}   // namespace p2
