# ADR-001 — 通用 Reflex 2 (latewarp) enable mod 的架构决策

- 状态: **已定稿**(2026-09-26)
- 决策者: Lead
- 依赖证据: `_re\reflex2_mod\spec\LATEWARP_ABI.md`、`spec\LATEWARP_API.md` §7(更正)、
  `_re\00_必读_入口.md` §A0/§C.3、`_re\routeA\evidence\routea_hook_proof\PROOF.md`、
  `_re\reflex2_mod\verify\warp\fwtest.vfy_{ctl,mod,ref}.log`

## 1. 要解决的问题

在不改游戏本体、不碰驱动、不绕反作弊的前提下, 让**已经会创建并每帧评估 latewarp**的游戏,
把"逐位拷贝"变成**真正的重投影**。

## 2. 关键事实(全部 T2 自测或 T1 直读, 不是推理)

| # | 事实 | 证据 |
|---|---|---|
| F1 | warp 与否由**两个 app 侧参数**决定: `Latewarp.IsRenderedFrame`(门控)与 `Latewarp.UIColorAlpha`(整屏不透明会盖掉重投影) | `fwtest --irf 1 --uialpha color` = 0.000000% vs `--irf 0 --uialpha null` = **81.088820%** |
| F2 | 两者都在 43 键白名单内 ⇒ **参数侧代理就足以产生真 warp** | `docs\LATEWARP_KEYS.tsv` + F1 |
| F3 | 载荷 `[0,0x40)` 的 7 个资源句柄**本来就由绑定侧写满**(demo 进程实测 0xC020C8xx, 跨进程确定) ⇒ 从来不是 demo 不 warp 的原因 | `spec\LATEWARP_ABI.md` §5.1 |
| F4 | `NVSDK_NGX_Parameter::Set`(槽位 0/3/4/6) **返回 void**; 只有槽位 8 的 `Get` 返回 result | 实测读返回值得到垃圾 0x972732A0; `ngxproxy.cpp` thunk 亦按 void 调用 |
| F5 | 真核**必须保持文件名 `nvngx.dll`**; 改名 → `CreateFeature` 返回 `0xBAD00007` | 代理跑法文档 + 已复现 |
| F6 | 代理**不能用 linker 转发器**(目标模块解析不到 → 宿主进程直接死); 必须用 `jmp qword ptr [表]` 蹦床 | 首次部署事故记录 |
| F7 | 应用目录旁的 NGX 核在 **demo** 里被接受(镜像版本资源即可); 在 **CP2077** 里被**数字签名校验拒绝**(`0x80092009 CRYPT_E_NO_MATCH`, 3 次复现) | `_re\00_必读_入口.md` §A0/§A.1 |
| F8 | 离核最近的 feature DLL 必须与核**同目录**(否则 `CreateFeature` 返回 `0xBAD0000B`) | 本次 verify 的 probe 目录事故 |

## 3. 决策

### 主方案 P1:参数侧 NGX 代理(本 ADR 选定)
把我们的 DLL 放在 `<target>\nvngx.dll`, 真核搬到 `<target>\realdir\nvngx.dll`(**保持原名**)。
- 62 个导出用蹦床透传; 我们自己实现 9 个 D3D12 导出。
- `CreateFeature(featureId==15)` 记下 handle → 之后该 handle 的**每次** `EvaluateFeature` 在转发**之前**:
  `Latewarp.IsRenderedFrame := 0`、`Latewarp.UIColorAlpha := nullptr`。
- 所有写入先过 43 键白名单; 白名单外**显式报错且不写**(INV-4)。
- 写入包在 `__try/__except` 里: 参数对象异常只会退化为"不修", 绝不崩宿主。

**为什么是它**: F1+F2 说明效果不需要碰游戏/驱动/反作弊; F5+F6 说明代价只是文件名与蹦床;
且它天然通用 —— 任何"会创建 feature 15 的游戏"都适用, 不需要认识那个游戏。

### 回退方案 P0:进程内 inline hook 真核(已有资产)
钩真核的 `NVSDK_NGX_D3D12_EvaluateFeature`, 转发前改同样两个键。
- **用于 F7 那类目标**(CP2077): 应用目录代理被签名拒, 钩进程内已加载的 DriverStore 核不受签名约束。
- 已证明可用: `_re\routeA\evidence\routea_hook_proof\PROOF.md`(用游戏那个确切的核, 81.088670%)。
- 代价: 需要注入载体(ASI/ReShade addon), 每个目标要各自找加载点。

### 不作主方案
- **P2 纯 OptiScaler 插件**: OptiScaler 已自带 TAAU/帧生成一类重投影, 与"让 NVIDIA 原生 latewarp 生效"目标不同;
  收敛成本高且收益不明。保留为"若某目标既拒代理又拒注入"时的最后手段。
- **P3 双通道**: 无必要。F1 表明单通道(参数)已能生效。

## 4. 数据流

```
游戏 / demo
  |  NVSDK_NGX_D3D12_Init / AllocateParameters           -> 透传真核
  |  NVSDK_NGX_D3D12_CreateFeature(featureId=15, params) -> 透传 + 记 handle
  |  NVSDK_NGX_D3D12_EvaluateFeature(h == latewarpHandle, params)
        |
        +--> [我们] 白名单校验 -> Set(IsRenderedFrame,0) / Set(UIColorAlpha,null)
        |             + Get 回读 UIColorAlpha 验证为 null
        +--> 透传真核 -> 内核真的重投影
  |  其余 62 个导出 -> 蹦床 -> 真核
```

## 5. 失败模式与对策

| 失败模式 | 观测 | 对策 |
|---|---|---|
| 目标从不创建 feature 15 | 日志无 `LATEWARP created` | **不猜不造**: 如实报"该目标未启用 reflex2 warp"; 不替游戏创建实例(那会改变游戏行为) |
| 应用目录代理被签名拒(F7) | 日志/NGX 日志显示走了 DriverStore 核, 我们一行都没有 | 换回退方案 P0 |
| 真核目录缺 feature DLL(F8) | `CreateFeature` → `0xBAD0000B` | 安装器保证 feature DLL 与核同目录; verify 之前先建对照目录 |
| 参数对象不是预期类型 | 写入被 `__except` 吞掉并打 ERROR | 日志有 `ERROR fault while fixing params`, 此时该目标标"不支持" |
| 我们写了白名单外的键 | 日志 `ERROR key outside the 43-key whitelist` | 拒绝写入; verify.ps1 出现该行即 FAIL |

## 6. 如何一键停用

1. `_re\reflex2_mod\install.ps1 -Action Uninstall` → 还原安装前的 `nvngx.dll` 并校验真核哈希未变;
2. 或把 `<target>\nvngx.dll` 删掉、把 `realdir\nvngx.dll` 拷回上一层(手动回退, 文件都在)。

## 7. 本决策**不**声称的事

- 不声称"任意游戏都能生效": 需要目标**自己会创建 feature 15**(F1 的前提)。
- 不声称 CP2077 能用代理形式(那是 F7 的硬边界, 走 P0)。
- 不声称 216 字节 `NVSDK_NGX_D3D12_Latewarp_Eval_Params` 是必需路径(Q-A 仍未答, 但已不影响本方案)。

---

## 8. [修订 2026-09-26, 用户裁定] P2 (OptiScaler 整合) 升为**主方向**

### 8.1 我原先的否决是错的

本节 §3"不作主方案"里对 P2 写的是:"OptiScaler 已自带 TAAU/帧生成一类重投影, 与目标不同; 收敛成本高且收益不明"。
**这两句都站不住**: ① 它自带重投影并不妨碍它当**宿主**, 我们不用它的重投影即可;
② 收益恰恰是**通用性本身**——而这正是本项目最缺的东西。该否决没有证据支撑, 是对原计划(P1 打完再决定 P2)的越权收敛。

### 8.2 勘察结论(S3, `spec\OPTISCALER_INTEGRATION.md`, 逐条带 文件:行号)

OptiScaler 已经有通用性所需的**全部**基础设施: 注入/多 API 代理、**它自己代理 NGX core**
(`proxies\NVNGX_Proxy.h` 46 处 `CreateFeature/EvaluateFeature`)、**它自己创建并驱动 NGX feature**
(`upscalers\FeatureProvider_Dx12.cpp:47`)、**已经在 Streamline 里**(全树 `slSetConstants` 45 处)、
资源追踪与 `hudfix`(无 UI 帧)、深度/MV/jitter/尺寸语义(`upscalers\IFeature.h`)。
**它唯一没有的是 `latewarp`(全树 0 命中)** —— 而那正是我们这轮挖出来的知识。

### 8.3 修订后的架构

* **主方向 P2**: 在 OptiScaler 里加一个 `LatewarpFeature` 后端(照 `DLSSFeature_Dx12` 的形态),
  复用其 NGX 代理 + Streamline 常量 + 资源/无 UI 帧 + 深度/MV/jitter。对**从不创建 feature 15** 的游戏,
  由我们用它的管线**自己创建并驱动** —— 这是 P1 结构上做不到、而它做得到的那一步, 也就是"通用"。
* **P1 退役为"知识载体 + 最小可验证实现"**: 两个决定键 / `Set` 返回 void / `UIColorAlpha` 在载荷 +0x10 /
  43 键白名单 / 可复现构建 + 精确还原安装器。整合时搬进 `LatewarpFeature`, 不重写。
* **范围**: 用户裁定 **有反作弊的游戏直接排除** ⇒ "通用" = 无内核级反作弊的游戏(单机为主)。
* **二进制**: 用户口径"有助于兼容性就要"。实测**驱动不提供 `nvngx_latewarp.dll`**, 而缺它 `CreateFeature(15)` = `0xBAD0000B`
  ⇒ 该文件是**兼容性必需品**。但供给方式采用**"安装器就地取用用户自己的那份 + 校验哈希"**,
  而不是再分发 NVIDIA 专有二进制。详见 `spec\NVIDIA_BINARY_POLICY.md`。

### 8.4 代价(已知)

1. **GPL-3**: 整合进源码树 ⇒ 新增代码 GPL-3(用户已选"整合", 视为接受);
2. **语义对齐仍未验证**: `hudfix` 的无 UI 帧能否直接喂 latewarp、矩阵/jitter 是否齐、深度/MV 约定是否一致 —— 见 `OPTISCALER_INTEGRATION.md` §3;
3. **反作弊边界的代价**: 覆盖不到在线竞技类游戏。
