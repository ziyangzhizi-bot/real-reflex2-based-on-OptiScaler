// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
// Re-composites the UI and the static viewmodel over the latewarp output with the SAME mask the
// built-in reprojection uses (shaders\reproject\Reproject_Common.h:104-114):
//
//   uiMask = max(smoothstep(UiDiffThreshold, 2*UiDiffThreshold, |present - hudless|),
//                IsDepthCutoutExpanded(uv, CutoffExpandPx))     // arms/weapon ("Depth cutoff")
//   uiMask = quantized to 0/1 with Bayer4x4                     // no double exposure
//   color  = lerp(warped, present, uiMask)
//
// The stochastic quantization is what kills the "double image" on the viewmodel: a soft mask would
// blend the warped gun and the current gun at every pixel. The built-in reprojection dithers its
// edges the same way (Bayer4x4, Reproject_Common.h:40-51/170-176).
//
// NOTE the HLSL below is the runtime-compile twin of LatewarpUi.hlsl; the cso in
// LatewarpUi_Shader.h is compiled from that same file (fxc /T cs_5_0 /E CSMain /Vn LatewarpUi_cso).
#pragma once

#include "pch.h"

class LatewarpUi_Common
{
  protected:
    struct alignas(256) InternalLatewarpUiParams
    {
        float DiffThreshold = 0.01f;   // UiDiffThreshold (built-in: Reprojection_Dx12.cpp:498)
        float ShowMask = 0.0f;         // "Show static elements" -> paint the mask pink
        float DepthCutoff = 0.0f;      // panel: Depth cutoff (0 = disabled, matches the predicate)
        float CutoffExpandPx = 0.0f;   // panel: Cutoff expand (dilation radius, in depth pixels)
        uint32_t InvertedDepth = 0;
        float InvScreenWidth = 0.0f;
        float InvScreenHeight = 0.0f;
        // ALIGNAS(16) IS LOAD-BEARING, not decoration: HLSL places a `float4`/`float4x4` (and every
        // ARRAY ELEMENT) on a 16-byte boundary, while a plain C++ `float[16]` has alignment 4. Without
        // it a member sits one word early and the shader reads the host's data shifted -- measured on
        // the now-withdrawn P3-1b `float4 LeadFillPx`. The static_asserts in LatewarpUi_Dx12.cpp pin
        // every offset below; they failed on exactly this the first time the assertions ran, which is
        // why the alignment is explicit instead of assumed.
        // HLSL packs an ARRAY inside a constant buffer at ONE ELEMENT PER 16-BYTE REGISTER, so the
        // shader's `uint BlueNoiseWords[256]` occupies 4096 bytes, not 1024. The cso's own reflection
        // says it: 'uint BlueNoiseWords[256]; Offset: 32' followed by 'float4x4 InvVPCur; Offset:
        // 4128'. Mirroring that stride here is what makes every member AFTER the table land where the
        // shader actually reads it.
        //
        // 2026-09-28 -- this was a REAL and completely invisible bug: with a packed 1024-byte array
        // this struct was 1216 bytes while the shader addressed up to 4288, so InvVPCur / VPPPrev /
        // DepthFlipY were read as ZERO (D3D returns 0 outside a view), the diagnostic reprojection
        // never ran, and nothing the panel offered could ever produce a measurement. The
        // static_asserts in LatewarpUi_Dx12.cpp now pin these offsets against the cso, so the class
        // of bug cannot come back quietly.
        struct alignas(16) BlueNoiseSlot { uint32_t word; uint32_t pad[3]; };
        BlueNoiseSlot BlueNoiseWords[256] = {};
        // P3-3: the host hands over the two reprojection matrices (the shader never inverts anything)
        // and the v-axis flag -- all three are the diagnostic's inputs. P3-1/P3-2 were withdrawn
        // 2026-09-28 (see LOG), which is why there is no lead-fill band and no hole-fill gain here.
        alignas(16) float InvVPCur[16] = {};  // inverse(W2V*V2C) of THIS frame     (clip -> world)
        alignas(16) float VPPPrev[16] = {};   // (W2V*V2C) of the PREVIOUS frame     (world -> clip)
        float DepthFlipY = 0.0f;
        // P3-3: the diagnostic mode (0 = off) and the reference shift the log prints next to the
        // shader's own measurement. They occupy the same 16-byte tail the old `float2 Pad0` did.
        float DiagMap = 0.0f;
        float DiagRefPx = 0.0f;
        // P2/E2c6: 0..1, how much of the warp the composite applies (1 = the old behaviour).
        float WarpStrength = 1.0f;
        // P2/E2c26: the highlight protection. >0.5 = freeze ISOLATED bright points (see the HLSL
        // below); the threshold is an HDR luminance, tuned with the E2c25 meter's maxlum reading.
        float HighlightProtect = 0.0f;
        float HighlightThreshold = 1.5f;
    };

    const std::string shaderCode = R"(
        // ---------------------------------------------------------------------------
        //  LatewarpUi.hlsl -- UI/static-element re-composite over the latewarp output.
        //  Compiled with (see LatewarpUi_Shader.h):
        //    fxc /nologo /T cs_5_0 /E CSMain /Vn LatewarpUi_cso /Fh LatewarpUi_Shader.h LatewarpUi.hlsl
        //
        //  Exactly the mask the built-in reprojection uses (shaders\reproject\Reproject_Common.h:104-114),
        //  applied to a base of our own instead of a shader-reprojected frame:
        //
        //    uiMask = smoothstep(UiDiffThreshold, 2*UiDiffThreshold, |present - hudless|)   // real UI
        //    uiMask = max(uiMask, isCutout(depth))                                          // static viewmodel
        //    color  = lerp(present, warped, WarpStrength * (1 - uiMask))                  // P2/E2c6: strength
        //
        //  The depth half is what covers arms/weapon: those are close to the camera and must stay
        //  unwarped. It is tuned with the panel's existing "Depth cutoff" slider (ReprojectionDepthCutoff).
        //
        // ---------------------------------------------------------------------------
        cbuffer Params : register(b0)
        {
            float DiffThreshold;    // "UiDiffThreshold" in the built-in shader
            float ShowMask;         // >0.5 => paint the mask pink ("Show static elements")
            float DepthCutoff;      // panel: Depth cutoff
            float CutoffExpandPx;   // panel: Cutoff expand
            uint InvertedDepth;
            float InvScreenWidth;
            float InvScreenHeight;
            uint BlueNoiseWords[256];    // the 32x32 8-bit blue-noise table, 4 bytes per word
            float4x4 InvVPCur;           // P3-3: inverse(W2V*V2C) of THIS frame  (clip -> world)
            float4x4 VPPPrev;            // P3-3: (W2V*V2C) of the PREVIOUS frame (world -> clip)
            float DepthFlipY;            // P3-3: 1 = the depth buffer's v axis is flipped vs the pixels
            float DiagMap;               // P3-3: 1 = paint the reprojection OFFSET as a heat map + collect stats
            float DiagRefPx;             // P3-3: host-written, unused by the shader -- it only keeps the 16-byte
                                         //   tail's layout. Carries the host's PREDICTED centre shift in px
                                         //   (focal * tan(pose angle)) so the logged measurement has a reference.
                    // P2/E2c6: HOW MUCH of the warp is applied, 0..1. The composite below used to be the hard
                    // lerp(warped, present, uiMask), so uiMask = 0 turned the ENTIRE screen -- world included -- into a
                    // re-projection of the previous frame, which shakes as soon as MFG interpolates it. With this the
                    // same pass applies a FRACTION of the correction: the world is nudged, not replaced. 1.0 = old
                    // behaviour, bit for bit.
                    float WarpStrength;
        float HighlightProtect;     // P2/E2c26: >0.5 = freeze isolated bright points
        float HighlightThreshold;   // P2/E2c26: HDR luminance above which a point counts
        };

        // P3-3: the diagnostic word block, written by this shader and read back by LatewarpUi_Dx12. The
        // indices are mirrored by p2::kDiag* in LatewarpFrameData.h and pinned by the gate + the unit test,
        // so the shader, the host and the test cannot drift apart silently.
        static const uint kDiagMaxShiftPx   = 0;    // atomicMax, asuint(float): max |shift| of the frame, px
        static const uint kDiagOutsideCount = 1;    // atomicAdd: pixels landing outside the previous frame
        static const uint kDiagMaxOutsidePx = 2;    // atomicMax, asuint(float): how far outside, in px
        static const uint kDiagMmSumQ       = 3;    // atomicAdd: sum of |history - present| * 1024 (sampled)
        static const uint kDiagMmCount      = 4;    // atomicAdd: samples in that sum (every 16th pixel)
        static const uint kDiagMmOutSumQ    = 5;    // the same mismatch, over the outside pixels only
        static const uint kDiagMmOutCount   = 6;
        static const uint kDiagBehindCount  = 7;    // w <= 0: the point is behind the previous camera
        static const uint kDiagPixels       = 8;    // plain store: pixels this pass covered
        static const uint kDiagDepthW       = 9;    // plain store: the DEPTH TEXTURE's own size. It is NOT
        static const uint kDiagDepthH       = 10;   //   necessarily the composite's: if it differs, the
                                                    //   depth load below reads the wrong pixel and no
                                                    //   amount of gain tuning can fix that.
        static const uint kDiagCentreCurX   = 11;   // plain store: the centre pixel's NDC in THIS frame
        static const uint kDiagCentreCurY   = 12;
        static const uint kDiagCentrePrevX  = 13;   //   ... and where that point was in the PREVIOUS one
        static const uint kDiagCentrePrevY  = 14;
        static const uint kDiagCentreDepth  = 15;   // plain store: the depth the centre pixel used
        static const uint kDiagCentreValid  = 16;   // plain store: 1 = the centre sample was written
        // P3-3b: the UI mask, quantified. The first live run with the diagnostic built produced exactly one
        // concrete observation -- 'objects inside the smart-weapon aiming frame are masked as UI' -- so the
        // mask itself gets counters: how much of the frame is masked, how much of that the DEPTH predicate
        // (not the colour diff) selected, and how strong that colour diff is. A large cutout share points at
        // the depth predicate / InvertedDepth; a small diff strength means the mask is latching onto a
        // subtle screen-space TINT that should have moved with the world.
        static const uint kDiagMaskCount    = 17;   // atomicAdd: pixels whose uiMask ended up 1
        static const uint kDiagMaskCutout   = 18;   // atomicAdd: of those, the DEPTH predicate's share
        static const uint kDiagMaskDiffQ    = 19;   // atomicAdd: their |present-hudless| * 1024
        static const uint kDiagBin0InQ      = 20;   // T82: input energy of pixels with luminance 0.5-1.0, * 32
        static const uint kDiagBin0OutQ     = 21;   //      the SAME pixels, in the WARPED image, * 32
        static const uint kDiagBin1InQ      = 22;   // 1.0-2.0
        static const uint kDiagBin1OutQ     = 23;
        static const uint kDiagBin2InQ      = 24;   // 2.0-4.0
        static const uint kDiagBin2OutQ     = 25;
        static const uint kDiagBin3InQ      = 26;   // 4.0 and up
        static const uint kDiagBin3OutQ     = 27;
        static const uint kDiagMaxLumQ      = 28;   // atomicMax: the frame max luminance, * 32 (clamped at 256)
        static const uint kDiagWords        = 29;

        Texture2D<float3> Warped : register(t0);       // NGX feature 15 output (UI-free world, warped)
        Texture2D<float3> PresentCopy : register(t1);  // the game frame: world + UI + viewmodel
        Texture2D<float3> Hudless : register(t2);      // the SAME frame without UI (fed to the kernel)
        Texture2D<float> Depth : register(t3);         // the game depth (panel: Depth cutoff)
        Texture2D<float3> History : register(t4);      // P3-2 B: the PREVIOUS composite (same size as present)
        RWTexture2D<float3> Present : register(u0);    // the backbuffer
        RWTexture2D<float> NoWarpMask : register(u1);  // R8: 1 = do NOT warp this pixel (Latewarp.NoWarpMask)
        RWBuffer<uint> Diag : register(u2);            // P3-3: the diagnostic word block (kDiagWords)

        // P3-3: the per-group reduction of the diagnostic. One atomic to a single address per GROUP instead
        // of one per pixel: a full-HD frame is 4M pixels, and 4M serialised atomics to one address would
        // cost more than the whole pass.
        groupshared uint g_diagMax[256];
        groupshared uint g_diagOut[256];
        groupshared uint g_diagOutPx[256];
        groupshared uint g_diagMmQ[256];
        groupshared uint g_diagMmN[256];
        groupshared uint g_diagMmOutQ[256];
        groupshared uint g_diagMmOutN[256];
        groupshared uint g_diagBehind[256];
        groupshared uint g_maskCount[256];
        groupshared uint g_maskCutout[256];
        groupshared uint g_maskDiffQ[256];
        groupshared uint g_bin0In[256];
        groupshared uint g_bin0Out[256];
        groupshared uint g_bin1In[256];
        groupshared uint g_bin1Out[256];
        groupshared uint g_bin2In[256];
        groupshared uint g_bin2Out[256];
        groupshared uint g_bin3In[256];
        groupshared uint g_bin3Out[256];
        groupshared uint g_maxLum[256];

        // --- copied from the built-in reprojection (Reproject_Common.h:40-60): its edge dithering ---
        float Bayer4x4(uint2 p)
        {
            static const float4x4 bayer =
            {
                 0.0f / 16.0f,  8.0f / 16.0f,  2.0f / 16.0f, 10.0f / 16.0f,
                12.0f / 16.0f,  4.0f / 16.0f, 14.0f / 16.0f,  6.0f / 16.0f,
)" R"(
                 3.0f / 16.0f, 11.0f / 16.0f,  1.0f / 16.0f,  9.0f / 16.0f,
                15.0f / 16.0f,  7.0f / 16.0f, 13.0f / 16.0f,  5.0f / 16.0f
            };

            return bayer[p.y & 3][p.x & 3];
        }

        bool IsDepthCutoutExpanded(float2 uv, int radius)
        {
            int2 depthDimension;
            Depth.GetDimensions(depthDimension.x, depthDimension.y);
            int2 basePixel = int2(uv * float2(depthDimension));

            if (radius == 0)
            {
                float d = Depth.Load(int3(basePixel, 0));
                return InvertedDepth ? (d > DepthCutoff) : (d < DepthCutoff);
            }

            for (int y = -radius; y <= radius; ++y)
            {
                for (int x = -radius; x <= radius; ++x)
                {
                    int2 sampleCoord = clamp(basePixel + int2(x, y), int2(0, 0), int2(depthDimension.x - 1, depthDimension.y - 1));
                    float d = Depth.Load(int3(sampleCoord, 0));
                    if (InvertedDepth ? (d > DepthCutoff) : (d < DepthCutoff))
                        return true;
                }
            }
            return false;
        }

        [numthreads(16, 16, 1)]
        void CSMain(uint3 dispatchThreadID : SV_DispatchThreadID, uint3 groupThreadID : SV_GroupThreadID)
        {
            uint2 pixelCoord = dispatchThreadID.xy;

        // P2/E2c37: PEAK BOOST -- a MODE selected by a magic ShowMask value (> 200). Every offset in this
        // constant block is pinned by static_asserts, so a new field would move all of them; this mode
        // costs none. In it:
        //     t0 (Warped)        = the KERNEL OUTPUT, whose specular peaks its resample has damped
        //     u0 (Present)       = destination
        //     WarpStrength       = boost amount    (ini: Latewarp.PeakBoost)
        //     HighlightThreshold = luminance gate  (ini: Latewarp.PeakBoostThreshold)
        // The report it answers: with the warp ON a lamp highlight is visibly dimmer, and WarpScale 0
        // brings it back -- i.e. the kernel bilinear filter spreads a 1-2 px peak over its neighbours and
        // the game bloom is superlinear in luminance, so the glow collapses with the peak. Here the peak
        // is pulled toward the strongest neighbour and lifted, ONLY above the threshold, so dark content
        // and noise stay untouched. The early-out is UNIFORM (a constant-buffer test): a per-pixel return
        // before the group syncs below is exactly the flow control fxc rejects with X4026. Out-of-range
        // Loads read 0 and an out-of-range UAV store is discarded, so no per-pixel bounds test is needed.
        if (ShowMask > 200.0f)
        {
            const float3 lwPb = Warped.Load(int3(pixelCoord, 0));
            const float lwPl = dot(lwPb, float3(0.2126f, 0.7152f, 0.0722f));
            float3 lwPo = lwPb;
            if (lwPl >= HighlightThreshold)
            {
                float3 lwPm = lwPb;
                [unroll] for (int lwDy = -1; lwDy <= 1; ++lwDy)
                {
                    [unroll] for (int lwDx = -1; lwDx <= 1; ++lwDx)
                    {
                        lwPm = max(lwPm, Warped.Load(int3(int2(pixelCoord) + int2(lwDx, lwDy), 0)));
                    }
                }
                const float lwPmL = dot(lwPm, float3(0.2126f, 0.7152f, 0.0722f));
                const float lwPr = (lwPl > 1e-5f) ? (lwPmL / lwPl) : 1.0f;
                // P2/E2c37b: the pull MUST scale with the amount. It did not, so a large area above the
        // threshold was pulled toward its 3x3 maximum at full strength and the frame went white.
        const float lwPwgt = saturate((lwPr - 1.0f) * 0.5f) * saturate(WarpStrength * 0.5f);
                // P2/E2c37c: HARD CAP -- whatever happens to the parameters, a pixel may never come out more
        // than 3x brighter than it went in. The first version had no ceiling and turned the screen white.
        lwPo = min(lerp(lwPb, lwPm * (1.0f + WarpStrength), lwPwgt), lwPb * 3.0f);   // E2c41: the lift is weight-gated too
            }
            Present[pixelCoord] = lwPo;
            return;
        }
            float3 warped = Warped.Load(int3(pixelCoord, 0));
            float3 present = PresentCopy.Load(int3(pixelCoord, 0));
            float3 hudless = Hudless.Load(int3(pixelCoord, 0));

            float3 diff = abs(hudless - present);
            float delta = max(diff.x, max(diff.y, diff.z));
            float uiMask = smoothstep(DiffThreshold, DiffThreshold * 2.0f, delta);

            // static elements (arms / weapon) are nearer than DepthCutoff and must not be warped
            float2 uv = (float2(pixelCoord) + 0.5f) * float2(InvScreenWidth, InvScreenHeight);
            bool isCutout = IsDepthCutoutExpanded(uv, (int) CutoffExpandPx);
            uiMask = max(uiMask, isCutout ? 1.0f : 0.0f);

            // Stochastic quantization. A soft mask (say 0.5) would blend BOTH images at every pixel, which
            // is exactly the 'double image' seen on the viewmodel: the warped gun and the current gun at 50%
            // each. Quantizing per pixel with the same Bayer pattern the built-in reprojection uses for its
            // edges (Reproject_Common.h:170-176) makes every pixel take ONE of the two images; the boundary
            // becomes dither instead of a ghost.
            // Blue-noise dither from the reflex2 material (_re\bluenoise32): a validated 32x32 8-bit
            // rank table. It quantises the soft mask to one bit without the ordered-pattern structure
            // Bayer shows, so the boundary reads as noise rather than as a fixed lattice.
            uint bnIdx = (pixelCoord.y & 31u) * 32u + (pixelCoord.x & 31u);
            uint bnByte = (BlueNoiseWords[bnIdx >> 2u] >> ((bnIdx & 3u) * 8u)) & 0xFFu;
            float maskThreshold = (float) bnByte / 255.0f;
            if (uiMask > 0.0f && uiMask < 1.0f)
                uiMask = (uiMask > maskThreshold) ? 1.0f : 0.0f;

            float2 pixelCenter = float2(pixelCoord) + 0.5f;
            float2 resolution = float2(1.0f / InvScreenWidth, 1.0f / InvScreenHeight);

            // Hand the same decision to the kernel: 255 = "this pixel must not be warped". Measured
            // offline with the harness (`fwtest --maskval`): 0 -> warp everywhere (81.09% of pixels
            // changed), 128/255 -> the frame comes back bit-exact, i.e. non-zero excludes the pixel.
            // P2/E2c26: HIGHLIGHT PROTECTION (opt-in). A 1-2 px specular highlight is the most fragile
            // content in the frame: the reprojection samples a few pixels away and lands on the dark
            // surround, so the highlight is simply gone. The isolation test keeps the frozen set narrow --
            // the pixel must exceed the threshold AND be far brighter than ALL four neighbours, so large
            // bright areas (sky, big lamps, muzzle flashes) still take the warp.
            if (HighlightProtect > 0.5f)
            {
                float3 nc0 = Hudless.Load(int3(pixelCoord + int2(-1, 0), 0));
                float3 nc1 = Hudless.Load(int3(pixelCoord + int2( 1, 0), 0));
                float3 nc2 = Hudless.Load(int3(pixelCoord + int2( 0, -1), 0));
                float3 nc3 = Hudless.Load(int3(pixelCoord + int2( 0, 1), 0));
                const float3 lw = float3(0.2126f, 0.7152f, 0.0722f);
                float lumC = dot(hudless, lw);
                float nMax = max(max(dot(nc0, lw), dot(nc1, lw)), max(dot(nc2, lw), dot(nc3, lw)));
                if ((lumC > HighlightThreshold) && (lumC > (nMax * 1.05f)))   // E2c42b: the 2x test matched only ~0.02% of pixels
                    uiMask = 1.0f;
            }
                        NoWarpMask[pixelCoord] = uiMask;

)" R"(
            // P2/E2c6: WarpStrength scales HOW MUCH of the correction is applied. 1.0 = the old hard lerp
        // (uiMask = 0 => the whole frame is the re-projection), 0 = always keep `present`.
        float3 color = lerp(present, warped, WarpStrength * (1.0f - uiMask));

            // "Show static elements": pink = what the kernel is told NOT to warp.
            const float showMask = (ShowMask > 0.5f) ? 1.0f : 0.0f;
            color = lerp(color, float3(1.0f, 0.0f, 1.0f), uiMask * 0.6f * showMask);

            // ---- P3-3: the reprojection diagnostic -------------------------------------------------------
            // The matrices come from the host (inv(W2V*V2C) of this frame and (W2V*V2C) of the previous one,
            // row-vector convention == mul(v, M)), so there is no inverse here. A pixel whose position in the
            // previous frame lands OUTSIDE the frame is a disocclusion: that content simply did not exist and
            // the warped/`present` result is a stretch. The history is the previous composite, i.e. the best
            // REAL content available for those pixels.
            //
            // The diagnostic is a heat map of the per-pixel offset plus a 20-word block the host reads back
            // and logs. That exists because a wrong depth / v-axis / scale convention is INVISIBLE in the
            // picture: the heat map shows a coherent motion FIELD when the convention is right, and the
            // logged numbers can be compared against the pose angle the host also logs. (P3-2's history FILL
            // was withdrawn on 2026-09-28 -- the kernel does its own hole repair.)
            const bool lwDiag = (DiagMap > 0.5f);
            const bool lwReproject = (ShowMask > 0.5f) || lwDiag;

            // Out-of-range threads exist: the dispatch rounds the composite size up to the 16x16 group. They
            // must contribute ZERO to the diagnostic (a depth of 0 projects to a nonsense point and would
            // dominate every max), and they must not be sent away early either: the reduction below has a
            // group barrier that EVERY thread of the group has to reach.
            const bool lwInScreen = (pixelCenter.x <= resolution.x) && (pixelCenter.y <= resolution.y);
            const uint2 centrePixel = uint2((uint) resolution.x >> 1u, (uint) resolution.y >> 1u);

            // Per-pixel diagnostic results. Carried out of the divergent part in locals because the barrier
            // that reduces them may not be crossed under a per-pixel condition.
            float diagShift = 0.0f;
            float diagOutsidePx = 0.0f;
            uint diagOutside = 0u;
            uint diagBehind = 0u;
            uint diagMmQ = 0u;
            uint diagMmN = 0u;
            uint diagMmOutQ = 0u;
            uint diagMmOutN = 0u;
            uint diagMask = 0u;
            uint diagMaskCutout = 0u;
            uint diagMaskDiffQ = 0u;
            uint diagBin = 0u;
            uint diagBinInQ = 0u;
            uint diagBinOutQ = 0u;
            uint diagMaxLumQ = 0u;

            if (lwReproject && lwInScreen)
            {
                int2 depthDim;
                Depth.GetDimensions(depthDim.x, depthDim.y);

                // The depth texture is NOT necessarily the composite's size (CP2077 hands us
                // 1280x800 for a 2560x1600 pass). Sample it in DEPTH pixels -- reading it at the
                // pass coordinate made 3/4 of the frame load out of range and return 0, which is
                // exactly what 'centre depth 0.0000' in the log was. Same mapping as
                // the depth-cutout predicate above.
                const float2 uvD = (float2(pixelCoord) + 0.5f) * float2(InvScreenWidth, InvScreenHeight);
                const int2 basePixel = clamp(int2(uvD * float2(depthDim)), int2(0, 0), depthDim - 1);
                float d = Depth.Load(int3(basePixel, 0));
                float ndcY = (DepthFlipY > 0.5f) ? (pixelCenter.y * InvScreenHeight * 2.0f - 1.0f)
                                                 : (1.0f - pixelCenter.y * InvScreenHeight * 2.0f);
                float4 clipCur = float4(pixelCenter.x * InvScreenWidth * 2.0f - 1.0f, ndcY, d, 1.0f);
                float4 world = mul(clipCur, InvVPCur);
                float4 clipPrev = mul(world, VPPPrev);

                if (clipPrev.w > 1e-6f)
                {
                    float2 ndcCur = clipCur.xy;   // w == 1 by construction
                    float2 ndcPrev = clipPrev.xy / clipPrev.w;
                    // the reprojection OFFSET: how far this pixel moved between the two frames, in pixels
                    float2 shiftPx = (ndcPrev - ndcCur) * 0.5f * resolution;
                    diagShift = length(shiftPx);

                    float2 over = max(abs(ndcPrev) - 1.0f, 0.0f);
                    diagOutsidePx = length(over * 0.5f * resolution);
                    diagOutside = (max(abs(ndcPrev.x), abs(ndcPrev.y)) > 1.0f) ? 1u : 0u;

                    int2 histDim;
                    History.GetDimensions(histDim.x, histDim.y);
                    float2 uvPrev = saturate(ndcPrev * 0.5f + 0.5f);
                    int2 hx = clamp(int2(uvPrev * float2(histDim)), int2(0, 0), histDim - 1);
                    float3 hist = History.Load(int3(hx, 0));

                    // P3-3: the semantic-free convention check. The history sampled where the maths SAYS this
                    // content came from must be (almost) the pixel itself. A mirrored / rotated / mis-scaled
                    // lookup gives a large mismatch EVERYWHERE, which is decisive in a way that "the yellow
                    // band never showed up" was not. Sampled 1/256 for the mean, plus every outside pixel.
                    if (lwDiag && ((pixelCoord.x & 15u) == 0u) && ((pixelCoord.y & 15u) == 0u))
                    {
                        float mm = saturate((abs(hist.x - present.x) + abs(hist.y - present.y) + abs(hist.z - present.z)) / 3.0f);
                        diagMmQ = (uint) min(mm * 1024.0f + 0.5f, 4095.0f);
                        diagMmN = 1u;
                    }
                    if (lwDiag && (diagOutside != 0u))
                    {
                        float mmo = saturate((abs(hist.x - present.x) + abs(hist.y - present.y) + abs(hist.z - present.z)) / 3.0f);
                        diagMmOutQ = (uint) min(mmo * 1024.0f + 0.5f, 4095.0f);
                        diagMmOutN = 1u;
                    }

                    // DiagMap alone = NUMBERS ONLY: the block below accumulates the statistics and the host
                    // logs them, while the picture stays the normal composite (a run has to stay playable --
                    // a full-screen heat map makes it impossible to fly or aim). Combine it with "Show static
                    // elements" to also SEE the field painted.
                    if (lwDiag && (ShowMask > 0.5f))
                    {
                        // black -> green -> yellow -> red -> white over 0..32 px: the FIELD is visible, not
                        // just the disocclusion. A pixel that lands outside the previous frame stays pure
                        // yellow, i.e. the reading the older diagnostic paint used is still valid.
                        float t = saturate(diagShift / 32.0f);
                        float3 heat = (t < 0.3333f) ? lerp(float3(0.0f, 0.0f, 0.0f), float3(0.0f, 1.0f, 0.0f), t * 3.0f)
                                    : (t < 0.6667f) ? lerp(float3(0.0f, 1.0f, 0.0f), float3(1.0f, 1.0f, 0.0f), (t - 0.3333f) * 3.0f)
                                                    : lerp(float3(1.0f, 1.0f, 0.0f), float3(1.0f, 1.0f, 1.0f), (t - 0.6667f) * 3.0f);
                        color = (diagOutside != 0u) ? float3(1.0f, 1.0f, 0.0f) : lerp(color, heat, 0.85f);
                    }
                    else if ((diagOutside != 0u) && (ShowMask > 0.5f))
                    {
                        // the pre-P3-3 diagnostic paint, unchanged for a plain "Show static elements" run
                        color = lerp(color, float3(1.0f, 1.0f, 0.0f), 0.5f);
                    }

                    // plain stores, one thread: the centre pixel is the number the host log compares against
                    // its own pose angle, and the depth texture size exposes a resolution mismatch.
                    if (lwDiag && all(pixelCoord == centrePixel))
                    {
                        Diag[kDiagCentreCurX]  = asuint(ndcCur.x);
                        Diag[kDiagCentreCurY]  = asuint(ndcCur.y);
)" R"(
                        Diag[kDiagCentrePrevX] = asuint(ndcPrev.x);
                        Diag[kDiagCentrePrevY] = asuint(ndcPrev.y);
                        Diag[kDiagCentreDepth] = asuint(d);
                        Diag[kDiagCentreValid] = 1u;
                    }
                }
                else
                {
                    diagBehind = 1u;
                }

                if (lwDiag && all(pixelCoord == uint2(0u, 0u)))
                {
                    Diag[kDiagPixels] = (uint) resolution.x * (uint) resolution.y;
                    Diag[kDiagDepthW] = (uint) depthDim.x;
                    Diag[kDiagDepthH] = (uint) depthDim.y;
                }

                // P3-3b: the mask this pixel ends up with. `delta` is the colour difference the diff half
                // of the mask uses, `isCutout` is the depth predicate's verdict -- the split between the two
                // is what tells a wrong depth predicate from a mask that keeps grabbing a screen-space tint.
                // P2/E2c25 (T82): THE WARP COST TO THIN BRIGHT CONTENT. `hudless` is the image the kernel was
                // HANDED and `warped` is what it returned, so this compares one image with itself before/after
                // the reprojection -- no brightness-space assumption, no mask, no UI. A bright bin whose output
                // energy collapses while the darker bins stay near 100% IS the reported lamp-highlight loss.
                // It sits INSIDE the lwInScreen guard on purpose: out-of-range lanes must stay at zero or they
                // would pollute the group reduction with reads past the frame.
                float lumIn  = dot(hudless, float3(0.2126f, 0.7152f, 0.0722f));
                float lumOut = dot(warped,  float3(0.2126f, 0.7152f, 0.0722f));
                diagMaxLumQ = (uint) min(lumIn * 32.0f, 256.0f);
                if (lumIn >= 0.5f)
                {
                    diagBin = (lumIn >= 4.0f) ? 3u : ((lumIn >= 2.0f) ? 2u : ((lumIn >= 1.0f) ? 1u : 0u));
                    diagBinInQ  = (uint) min(lumIn  * 32.0f, 256.0f);
                    diagBinOutQ = (uint) min(lumOut * 32.0f, 256.0f);
                }
                                if (lwDiag && (uiMask > 0.5f))
                {
                    diagMask = 1u;
                    if (isCutout) diagMaskCutout = 1u;
                    diagMaskDiffQ = (uint) min(saturate(delta) * 1024.0f + 0.5f, 4095.0f);
                }
            }

            // P3-3: reduce the per-pixel diagnostic to one atomic per GROUP. The guard is a constant-buffer
            // value, i.e. uniform over the whole dispatch, which is what makes the barrier legal here.
            if (lwDiag)
            {
                const uint lane = groupThreadID.y * 16u + groupThreadID.x;

                if (!(diagShift >= 0.0f)) diagShift = 0.0f;   // also catches NaN from a poisoned matrix

                g_diagMax[lane]    = asuint(diagShift);
                g_diagOut[lane]    = diagOutside;
                g_diagOutPx[lane]  = asuint(diagOutsidePx);
                g_diagMmQ[lane]    = diagMmQ;
                g_diagMmN[lane]    = diagMmN;
                g_diagMmOutQ[lane] = diagMmOutQ;
                g_diagMmOutN[lane] = diagMmOutN;
                g_diagBehind[lane] = diagBehind;
                g_maskCount[lane]  = diagMask;
                g_maskCutout[lane] = diagMaskCutout;
                g_maskDiffQ[lane]  = diagMaskDiffQ;
                g_bin0In[lane]  = diagBinInQ  * ((diagBin == 0u) ? 1u : 0u);
                g_bin0Out[lane] = diagBinOutQ * ((diagBin == 0u) ? 1u : 0u);
                g_bin1In[lane]  = diagBinInQ  * ((diagBin == 1u) ? 1u : 0u);
                g_bin1Out[lane] = diagBinOutQ * ((diagBin == 1u) ? 1u : 0u);
                g_bin2In[lane]  = diagBinInQ  * ((diagBin == 2u) ? 1u : 0u);
                g_bin2Out[lane] = diagBinOutQ * ((diagBin == 2u) ? 1u : 0u);
                g_bin3In[lane]  = diagBinInQ  * ((diagBin == 3u) ? 1u : 0u);
                g_bin3Out[lane] = diagBinOutQ * ((diagBin == 3u) ? 1u : 0u);
                g_maxLum[lane]  = diagMaxLumQ;

                GroupMemoryBarrierWithGroupSync();

                [unroll]
                for (uint step = 128u; step > 0u; step >>= 1u)
                {
                    if (lane < step)
                    {
                        g_diagMax[lane]    = max(g_diagMax[lane], g_diagMax[lane + step]);
                        g_diagOut[lane]   += g_diagOut[lane + step];
                        g_diagOutPx[lane]  = max(g_diagOutPx[lane], g_diagOutPx[lane + step]);
                        g_diagMmQ[lane]   += g_diagMmQ[lane + step];
                        g_diagMmN[lane]   += g_diagMmN[lane + step];
                        g_diagMmOutQ[lane]+= g_diagMmOutQ[lane + step];
                        g_diagMmOutN[lane]+= g_diagMmOutN[lane + step];
                        g_diagBehind[lane]+= g_diagBehind[lane + step];
                        g_maskCount[lane] += g_maskCount[lane + step];
                        g_maskCutout[lane]+= g_maskCutout[lane + step];
                        g_maskDiffQ[lane]+= g_maskDiffQ[lane + step];
                        g_bin0In[lane]   += g_bin0In[lane + step];
                        g_bin0Out[lane]  += g_bin0Out[lane + step];
                        g_bin1In[lane]   += g_bin1In[lane + step];
                        g_bin1Out[lane]  += g_bin1Out[lane + step];
                        g_bin2In[lane]   += g_bin2In[lane + step];
                        g_bin2Out[lane]  += g_bin2Out[lane + step];
                        g_bin3In[lane]   += g_bin3In[lane + step];
                        g_bin3Out[lane]  += g_bin3Out[lane + step];
                        g_maxLum[lane]    = max(g_maxLum[lane], g_maxLum[lane + step]);
                    }
                    GroupMemoryBarrierWithGroupSync();
                }

                if (lane == 0u)
                {
                    InterlockedMax(Diag[kDiagMaxShiftPx], g_diagMax[0]);
                    InterlockedAdd(Diag[kDiagOutsideCount], g_diagOut[0]);
                    InterlockedMax(Diag[kDiagMaxOutsidePx], g_diagOutPx[0]);
                    InterlockedAdd(Diag[kDiagMmSumQ], g_diagMmQ[0]);
                    InterlockedAdd(Diag[kDiagMmCount], g_diagMmN[0]);
                    InterlockedAdd(Diag[kDiagMmOutSumQ], g_diagMmOutQ[0]);
                    InterlockedAdd(Diag[kDiagMmOutCount], g_diagMmOutN[0]);
                    InterlockedAdd(Diag[kDiagBehindCount], g_diagBehind[0]);
                    InterlockedAdd(Diag[kDiagMaskCount], g_maskCount[0]);
                    InterlockedAdd(Diag[kDiagMaskCutout], g_maskCutout[0]);
                    InterlockedAdd(Diag[kDiagMaskDiffQ], g_maskDiffQ[0]);
                    InterlockedAdd(Diag[kDiagBin0InQ],  g_bin0In[0]);
                    InterlockedAdd(Diag[kDiagBin0OutQ], g_bin0Out[0]);
                    InterlockedAdd(Diag[kDiagBin1InQ],  g_bin1In[0]);
                    InterlockedAdd(Diag[kDiagBin1OutQ], g_bin1Out[0]);
                    InterlockedAdd(Diag[kDiagBin2InQ],  g_bin2In[0]);
                    InterlockedAdd(Diag[kDiagBin2OutQ], g_bin2Out[0]);
                    InterlockedAdd(Diag[kDiagBin3InQ],  g_bin3In[0]);
                    InterlockedAdd(Diag[kDiagBin3OutQ], g_bin3Out[0]);
                    InterlockedMax(Diag[kDiagMaxLumQ],  g_maxLum[0]);
                }
            }

            Present[pixelCoord] = color;
        }
    )";
};
