# ---------------------------------------------------------------------------
#  verify_p2.ps1 -- acceptance checks for the P2 patch set.
#
#  L1 PRISTINE  the delivered source tree must contain no trace of our work (INV-P4)
#  L2 DRY RUN   apply -DryRun must report exactly the expected patch/file counts
#  L3 MARKERS   every patch must be present in the applied tree EXACTLY ONCE (content level,
#               this is the reproducible half of AC-P2-001)
#  L4 DEFAULT   nothing may select the backend except the menu list (AC-P2-006)
#  L5 (with -Full)  offline unit test + provisioning tests, then AFTER the rollback
#                   round-trip the build gate, so it blesses a build of the tree that the
#                   rollback step re-applies (-Full implies the L6 round-trip: F-10)
#  L6 (with -Full or -TestRevert)  revert round-trip must be byte-identical (AC-P2-001)
#
#  usage:  .\verify_p2.ps1 [-Tree <repro_src>] [-Full] [-SkipBuild] [-TestRevert]
# ---------------------------------------------------------------------------
param(
    [string]$Tree = '',
    [switch]$Full,
    [switch]$SkipBuild,
    [switch]$TestRevert
)
$ErrorActionPreference = 'Stop'
$P2   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
if (-not $Tree) { $Tree = Join-Path $Repo '_re\repro_src' }
$Tree = (Resolve-Path -LiteralPath $Tree).Path
$Src  = Join-Path $Tree 'OptiScaler'
$Pristine = Join-Path $Repo 'OptiScaler_20260923_154112\OptiScaler_source_5b6bc822\OptiScaler'

# ---------------------------------------------------------------------------
#  SAFETY (added 2026-09-28 after the incident): this script starts a PARALLEL
#  msbuild (/m = every core). At 21:40 on 2026-09-28 that ran while Cyberpunk 2077
#  was being played, and the machine hard-reset one second later (Kernel-Power 41,
#  BugcheckCode 0 = no bugcheck, i.e. the box lost power / was cut out under load).
#  A heavy build must never race a game: refuse while the game process is alive.
#  There is deliberately NO bypass switch -- wait for the game to exit.
# ---------------------------------------------------------------------------
$gameProc = @(Get-Process -Name Cyberpunk2077 -ErrorAction SilentlyContinue)
if ($gameProc.Count -gt 0) {
    Write-Host ('[build] REFUSED: Cyberpunk2077.exe is running (pid ' + $gameProc[0].Id + ').') -ForegroundColor Red
    Write-Host '        A parallel msbuild must not race the game (2026-09-28 hard-reset). Close the game first.'
    exit 2
}
$script:fails = 0
function Check([string]$name, [bool]$ok, [string]$detail) {
    if ($ok) { Write-Host ("  [PASS] " + $name + "  " + $detail) }
    else     { Write-Host ("  [FAIL] " + $name + "  " + $detail) -ForegroundColor Red; $script:fails++ }
}
function CountIn([string]$path, [string]$needle) {
    if (-not (Test-Path -LiteralPath $path)) { return -1 }
    return ([regex]::Matches([System.IO.File]::ReadAllText($path), [regex]::Escape($needle))).Count
}

Write-Host "================ L1 PRISTINE ================"
Check "delivered tree present" (Test-Path -LiteralPath $Pristine) $Pristine
$leak = @(Get-ChildItem $Pristine -Recurse -File -Include *.cpp,*.h,*.vcxproj -ErrorAction SilentlyContinue |
          Select-String -Pattern 'Latewarp' -ErrorAction SilentlyContinue)
Check "delivered tree has ZERO latewarp traces" ($leak.Count -eq 0) ("hits=" + $leak.Count)

# Native stderr must not become a terminating error in this script: PowerShell 5.1 turns
# "2>&1" output from a child process into one when ErrorActionPreference is Stop.
function Run-Child([string[]]$argv) {
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $head = $argv[0]
        $rest = @()
        if ($argv.Count -gt 1) { $rest = $argv[1..($argv.Count - 1)] }
        $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $head @rest 2>&1 | Out-String
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $prev }
    return @{ text = $out; code = $code }
}

Write-Host "================ L2 APPLY (dry run, or the pre-flight) ================"
$alreadyApplied = (CountIn (Join-Path $Src 'Config.h') 'ReprojectionUseNvidiaLatewarp') -gt 0
$dry = Run-Child @((Join-Path $P2 'apply_to_optiscaler.ps1'), '-DryRun', '-Tree', $Tree)
if ($alreadyApplied) {
    Check "applied tree: a second apply is REFUSED by the pre-flight" (($dry.code -ne 0) -and ($dry.text -match 'tree is not pristine')) ("exit=" + $dry.code)
    Check "the refusal names the remedy" ($dry.text -match '-Action Revert') ""
} else {
    Check "pristine tree: dry run exits 0" ($dry.code -eq 0) ("exit=" + $dry.code)
    # These two numbers are asserted so that a patch silently DISAPPEARING (an anchor that stops
    # matching and gets deleted, say) cannot pass unnoticed. They went stale once already (13/8
    # while the set had grown to 39/16), which is exactly the failure this check exists for.
    # 65 -> 48 on 2026-09-28: the 17 T30*/T35*/T36*/T39b-label patches were WITHDRAWN with P3-1
    # (edge fill), P3-2 (history hole fill) and P3-0a (pose gain). See the LOG, round 86.
    # 48 -> 49 in round 88: T40 adds the P3-B late-latch instrumentation (logging only).
    # 49 -> 51 in round 103: T42a/T42b (P3-E) let the game's own DLSS-G run and be seen.
    # 51 -> 55 in round 104: T43a/T43b/T43c + T44 (P3-D2) add the late-input gain (default 0).
    # 55 -> 59 in round 117: T45 helper + T45a/b/c keep us OUT of the DLSS-G path with FGOutput=NoFG.
    # 59 -> 71 in round 122: T47-T57 (E2c) decouple the latewarp from FGOutput=Reprojection -- the
    # pass is bootstrapped on the real present chain (WrappedIDXGISwapChain4::LocalPresent) and ADOPTS
    # the game swapchain, and the hudless/depth/MV tag pump no longer requires FGInput=DLSSG.
    # 71 -> 74 in round 122b: T58-T60 install the slSetTag/slSetTagForFrame/slSetConstants and
    # slPCLSetMarker hooks themselves -- the 23:53 live run proved the bootstrap worked while those
    # hooks were still gated on FGInput==DLSSG/NvngxFG, so nothing ever reached the pass.
    # 74 -> 79 in round 125: T61a-c/T62a-b fix the 2026-09-29 13:12 freeze -- the pass now runs ONCE
    # per RENDERED frame (MFG presents it 3-4x) and the SC command allocator is fenced before reuse.
    # 79 -> 80 in round 126: T64 logs the PIXEL SIZE of the warp the kernel is handed (the matrix rows
    # only print for the first 5 frames, which are usually a still menu) -- plus the new-file log fix
    # that makes eval #N print every 300 evaluations instead of every 1000.
    # 80 -> 86 in round 128: T65a-e turn the UI-mask diff threshold into an ini key + a LIVE slider
    # (the 18:11 run measured |present-hudless| = 0.18-0.31 against the hard constant 0.01, which froze
    # 95-99.6% of the screen and threw the whole warp away), and T66 logs the hudless/backbuffer pair.
    # 86 -> 87 in round 129: T67 starts RawInputHook in the NoFG latewarp configuration too -- it is
    # the only source of the post-camera-sample mouse counts P3-D needs (measured: 0/0 all session).
    # 87 -> 92 in round 131: T68a-e add WarpStrength -- the composite can apply a FRACTION of the
    # warp instead of the hard swap that turned the whole world into a stale re-projection.
    # 92 -> 93 in round 132: T69 drains every in-flight slot before the warp touches the SHARED
    # _lwOut/_buffer -- the tile corruption reported on 2026-09-29.
    # 93 -> 105 in round 133: T70a-k (E2c9 / P0) replace the matrix SOURCE with the
    # 135 -> 137 in round 26: T81a/T81b (E2c24) widen the mask-threshold slider to 0-10 and say what
    # the value means: the working setting is 5.0 (UI-diff half dead, measured diff 0.4-0.75), and the
    # old 0-0.5 clamp silently re-armed the motion-edge freezing (the jelly) on a single touch.
    # 130 -> 135 in round 25: T80a-e (E2c23) turn the viewmodel mask into an OPT-IN switch and ship
    # it OFF in mechanism C. The 19:35 run measured `cutout 9.16% - 45.62%` (was 0.00% with the dead
    # 0.35): a tenth to nearly half the frame was told not to warp -- the jelly on turns, and with the
    # stale UI patches and the dithered edge, the breakage. In C mode the warped image carries no UI
    # and no viewmodel, so a freeze there can only leave stale content behind.
    # 129 -> 130 in round 24: T79 (E2c22) moves "Depth cutoff" + "Show static elements" into the
    # Chinese quick panel. The cutoff sat at 0.35 and the log's own diag proves that selected NOTHING:
    # every frame printed `cutout 0.00%` while the same block measured centre depths of 0.0003-0.0011
    # (reverse-Z, INFINITE far plane: d = near/z). The viewmodel mask never fired once.
    # 126 -> 129 in round 23: T78a-c (E2c21) fix the VIEWMODEL double image the first successful
    # run reported: the C path now hands the kernel the mask, and the present pass stays alive as a
    # mask refresher (WarpStrength 0 => bit-identical output, and the user tunes DepthCutoff).
    # 125 -> 126 in round 19: T77 (E2c20) adds MECHANISM C -- warp at the upscaler slEvaluateFeature
    # AFTER the original returns (DLSS done, UI not drawn), the insertion point the prior art gives.
    # 122 -> 125 in round 11: T76a-c (E2c16) add the OPT-IN in-place alternative (the fallback if
    # Streamline ignores the tag substitution): warping the FG-only hudless texture in place.
    # 120 -> 122 in round 144: T74a/T74b (E2c12b) pin ONE pose pair per frame -- the tag path
    # warps the generator frame and the present chain warps the displayed frame, and without the pin
    # the second one advanced to a newer pose (a sub-frame offset = a residual ghost).
    # 115 -> 120 in round 142: T73a-e (E2c12, Route A) warp the frame the frame GENERATOR eats.
    # Decoded from the tag inventory against sl_core_types.h: the game tags ScalingOutputColor (4)
    # and NEVER Backbuffer (53), so the generator interpolates a resource the present-chain warp
    # never touches -- that is the semi-transparent layer. The substitution writes OUR texture (the
    # swapchain is never written; the round-141 crash came from writing it mid-frame).
    # 113 -> 115 in round 140: T72f/T72g (E2c11c) fix the two bugs that made the 16:08 run do
    # NOTHING: the probe ran BEFORE the tagged resources were pushed into the feature (hudless -1),
    # and a failed drive still consumed the frame token, so the present fallback was rejected too.
    # 112 -> 113 in round 139: T72e (E2c11b) lets the TAG drive use the CURRENT frame (validity ==
    # ValidNow) -- the 14:12 run measured zero passes because the tag drive was rejected by that
    # gate AND the 2 ms suppression then ate the present-chain fallback.
    # 108 -> 112 in round 138: T72a-d (E2c11) drive the warp from the BACKBUFFER TAG, i.e. BEFORE
    # the frame generator eats the frame (measured: our hook sees ~37 presents/s while the display
    # runs >100 fps, so the present-chain warp reached only 1/4-1/3 of the displayed frames).
    # 105 -> 108 in round 136: T71a-c (E2c10) gate the latewarp on its OWN switches -- with the
    # GAME frame generation OFF the FG pacer holds _targetFrame ahead, IsPaused() is true and the
    # pass never ran at all (measured: zero evaluations in the whole 23:46 session).
    # present-boundary camera double buffer. MEASURED on the 22:02 run: 35783 slSetConstants samples
    # against ~7530 composite passes -- 4.7 samples per PRESENT -- so the _frameCount % 4 camera ring
    # was rewritten inside ONE present interval, the two matrices handed to the kernel came out
    # near-identical and NGX early-outed into a bit-exact copy (the composite measured a centre shift
    # of 0.0 px while the camera turned 5.15 deg in the same frame). That is why the picture never
    # changed. The diagnostics now read the FROZEN pair instead of re-reading the ring.
    # The count is asserted so that an unintended patch comes out of the woodwork; it is updated
# DELIBERATELY whenever the set grows. 171 -> 198 in P2/E2c34..E2c37: the swap-chain state
# recorder (T90/T92) and the peak boost (T93) added 27 patches. 198 -> 210 across P2/E2c38..E2c40:
# the state sniff (T95) and the three rolled-back ScalingOutputColor feeds (T96..T99).
# 208 -> 211 on 2026-10-01 (T100a-c): the NoFG run measured SetResource 0 (the game stops tagging
# the FG planes when it does not generate frames), so the upscaler-input feed now also runs in the
# latewarp-only NoFG configuration. 208 -> 208 in the panel cleanup: the T83f highlight-protection block and the T94
# peak-boost sliders left the quick panel (their C++ keys stay, unwired). T84f had anchored on a
# line that T83f used to insert, so it was re-anchored onto the T80e viewmodel-mask hint.
# 208 is MEASURED, not inferred: the DryRun prints 'patches : 208 in 15 file(s)' and
# 'new files : 16' with exit 0.
Check "dry run reports 213 patches" ($dry.text -match 'patches\s+:\s+213\b') ""
    Check "dry run reports 16 new files" ($dry.text -match 'new files\s+:\s+16\b') ""
    Check "dry run writes nothing" ($dry.text -match '\[dry\] nothing written') ""
}

Write-Host "================ L3 MARKERS (each exactly once) ================"
# B1 touchpoints: the switch lives in the Reprojection block and the backend is driven from
# framegen\reprojection\Reprojection_Dx12. The REJECTED upscaler design must appear nowhere --
# that is asserted as a negative in L4 below.
$markers = @(
    @{ f = 'Config.h';                            s = 'CustomOptional<bool> ReprojectionUseNvidiaLatewarp { false };' },
    @{ f = 'Config.cpp';                          s = 'ReprojectionUseNvidiaLatewarp.set_from_config(readBool("Reprojection", "UseNvidiaLatewarp"));' },
    @{ f = 'Config.cpp';                          s = 'ini.SetValue("Reprojection", "UseNvidiaLatewarp",' },
    @{ f = 'menu\menu_common.cpp';                s = 'Use NVIDIA latewarp (Reflex 2)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h';   s = '#include <upscalers/latewarp/LatewarpFeature_Dx12.h>' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h';   s = 'LatewarpFeatureDx12 _latewarp;' },
    # 4 now: E2c10 (T71a) reads the switch once more for the latewarp-only gate (lwArmed), which is
    # what makes the pass run when the FG pacer reports "paused" (game frame generation OFF).
    # 5 now: E2c12 (T73d) reads it once more in LatewarpWarpTaggedColor, the tag-side warp.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'ReprojectionUseNvidiaLatewarp.value_or_default()'; n = 5 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = '_latewarp.Evaluate(latewarpList, latewarpIn);' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-diag:' },
    # the 3-input UI composite (warp + UI taken from present-gameHudless) and the copy-back guard
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h';   s = '#include <shaders/latewarp/LatewarpUi_Dx12.h>' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h';   s = 'std::unique_ptr<LatewarpUi_Dx12> _latewarpUi;' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = '_latewarpUi->Dispatch(latewarpList, _lwOut.Get(), hudless->GetResource(), lwBack,' },
    # "Show static elements" (State::fgHudlessCompare) paints the mask pink, like the built-in reprojection does
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'State::Instance().fgHudlessCompare ? 1.0f : 0.0f' },
    # the static-viewmodel half of the mask is tuned by the panel's EXISTING sliders
    # count 3: the built-in reprojection reads it too (its own DepthCutoff param), plus the T38
    # knob-change log, which prints the depth predicate's inputs (the suspect for the bad mask)
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'Config::Instance()->ReprojectionDepthCutoff.value_or_default()'; n = 3 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'Config::Instance()->ReprojectionCutoffExpand.value_or_default()'; n = 3 },
    # 2 hits: the runtime-compile HLSL twin declares and calls it
    # 3 hits: the header comment, the definition and the call in CSMain
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';       s = 'IsDepthCutoutExpanded'; n = 3 },
    # the anti-double-exposure dither, copied from the built-in reprojection
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';       s = 'float Bayer4x4(uint2 p)'; n = 1 },
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';       s = 'uiMask = (uiMask > maskThreshold) ? 1.0f : 0.0f;' },
    # the reflex2-native route: hand the kernel a NoWarpMask so it never warps UI/viewmodel pixels
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarpIn.noWarpMask = _latewarpUi->MaskForKernel();' },
    # 2 hits: the include and the memcpy into the constant buffer
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';       s = 'LatewarpBlueNoise32'; n = 2 },
    @{ f = 'shaders\latewarp\LatewarpBlueNoise32.h';     s = 'LatewarpBlueNoise32[1024]' },
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';       s = 'float DepthCutoff = 0.0f;' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'lwEvaluated && !lwComposited' },
    # the in-game hotkey, in OptiScaler's own Keybinds UI
    @{ f = 'menu\menu_common.cpp';                s = 'Keybind("Latewarp takeover", 14)' },
    @{ f = 'menu\menu_common.cpp';                s = 'latewarp.Render(config->LatewarpShortcutKey);' },
    # FOUR user entry points into the runtime flag: the armed checkbox, the panel running checkbox, the
    # optional keybind, and the Chinese quick switch added by T39c.
    @{ f = 'menu\menu_common.cpp';                s = 'p2::SetRuntimeEnabled'; n = 4 },
    # 2 now: the row itself, plus the Chinese quick switch's hint that points at it (T39c)
    @{ f = 'menu\menu_common.cpp';                s = 'latewarp takeover: running'; n = 2 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = '_reproject->Dispatch(' },
    @{ f = 'hooks\Streamline_Hooks.cpp';          s = '#include <upscalers/latewarp/LatewarpFrameData.h>' },
    @{ f = 'hooks\Streamline_Hooks.cpp';          s = 'p2::SetStreamlineViewToClip(' }
    # ---- P2/E2c9 (P0, round 133): the present-boundary camera double buffer -------------------
    # The camera ring collapses because slSetConstants runs 4.7x per present; these five markers
    # are the whole path: writer -> state -> reader -> frozen pair -> the decisive log line.
    @{ f = 'hooks\Streamline_Hooks.cpp';          s = 'p2::SetStreamlineCameraPose(' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h';    s = 'struct LwCameraPose' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp';  s = 'bool AdvanceStreamlineCameraPose(LwCameraPose& outCur, LwCameraPose& outPrev)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'p2::AdvanceStreamlineCameraPose(lwPoseCur, lwPosePrev)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-campose:' },
    # E2c10: the pass runs on the present chain, not on the FG pacer
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'const bool lwRun = lwPaced || lwArmed;' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'if (lwRun && Config::Instance()->ReprojectionUseNvidiaLatewarp.value_or_default() &&' },
    # E2c11 (T72): the warp is driven from the backbuffer TAG, before the frame generator eats it
@{ f = 'hooks\Streamline_Hooks.cpp'; s = 'static void lwProbeBackbufferTag(const sl::ResourceTag* tags, uint32_t numTags, sl::CommandBuffer* cmdBuffer,' },
    # E2c13: the tag-side drive of the FULL present pass is gone (it wrote the swapchain mid-frame
    # and crashed the game); only the inventory line stays.
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'THE HUDLESS-TAG DRIVE IS REMOVED ON PURPOSE' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-e2c12: tag-side kernel Evaluate FAILED' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'latewarp-e2c11: TAG INVENTORY type {} seen in {}' },
    # E2c12 (Route A): the generator is handed our warped texture, via a tag substitution
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'latewarp-e2c12: HUDLESS tag substituted with our warped texture' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-e2c12: the frame generator is handed OUR warped texture' },
    # E2c14: the tag path records on the GAME command list (ordering: after this frame, before the consumer)
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h'; s = 'uint32_t declaredState) override final;' },
    @{ f = 'Config.h'; s = 'CustomOptional<bool> LatewarpTagWarpInPlace { false };' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'lwProbeBackbufferTag(tags, numTags, cmdBuffer, "slSetTag");   // P2/E2c11c: AFTER the resource push' },
    # E2c11b: only a SUCCESSFUL tag drive suppresses the present-chain fallback (the 14:12 run
    # measured zero passes because a failed tag drive still reset the suppression timestamp).
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'p2::LatewarpTagDriveRecent()' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'latewarp-e2c12: HUDLESS tag substituted with our warped texture' },
    # the diagnostics must NOT re-read the ring: exactly ONE _cameraForward[fIndex] may survive, and
    # it is the fallback initialiser inside the ternary that picks the snapshot when it is live.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = '_cameraForward[fIndex]'; n = 1 },,
    @{ f = 'OptiScaler.vcxproj';                   s = '<ClInclude Include="upscalers\latewarp\LatewarpFeature_Dx12.h" />' },
    @{ f = 'OptiScaler.vcxproj';                   s = '<ClCompile Include="upscalers\latewarp\LatewarpFeature_Dx12.cpp" />' },
    @{ f = 'OptiScaler.vcxproj';                   s = '<PrecompiledHeader>NotUsing</PrecompiledHeader>'; n = 2 },
    @{ f = 'resource_build_date.h';                s = '#define VER_BUILD_DATE "20260923_154018"' },
    @{ f = 'resource_build_commit.h';              s = '#define VER_BUILD_COMMIT "5b6bc822"' },
    # T14-T19: the feature-layer intercept (strategy branch 1)
    @{ f = 'inputs\NVNGX_DLSS_Dx12.cpp';          s = '#include <upscalers/latewarp/LatewarpIntercept.h>' },
    @{ f = 'inputs\NVNGX_DLSS_Dx12.cpp';          s = 'if ((int) InFeatureID == 15 && cfg.LatewarpRewrite.value_or_default())' },
    @{ f = 'inputs\NVNGX_DLSS_Dx12.cpp';          s = 'if ((int) feature == 15 && cfg.LatewarpRewrite.value_or_default())' },
    @{ f = 'Config.h';                            s = 'CustomOptional<bool> LatewarpRewrite { false };' },
    @{ f = 'Config.cpp';                          s = 'LatewarpRewrite.set_from_config(readBool("Latewarp", "Rewrite"));' },
    @{ f = 'Config.cpp';                          s = 'ini.SetValue("Latewarp", "Rewrite",' },
    @{ f = 'menu\menu_common.cpp';                s = 'Latewarp: rewrite feature 15 params' },
    # ---- P3-1 (edge fill) and P3-0a (pose gain) were WITHDRAWN 2026-09-28. The tear is to be fixed
    # by OVER-RENDERING (P3-F), not by ramping the border back to the unwarped frame, and pose gain
    # is PREDICTION -- not the Reflex 2 mechanism (late input sampling is). Their config keys, panel
    # rows and call sites are gone; the pure-math helpers stay unit-tested with no caller, and L6
    # below now asserts the ABSENCE of every withdrawn knob instead of 'ships at 0'.
    # ---- P3-2: the disocclusion / background-buffer machinery. Each of these is a load-bearing
    # piece of the paper's module (sec.4.2); a silent deletion would only show up as a quality
    # regression in-game, so the gate pins them by name.
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'bool BuildReprojectionMatrices(const float curWorldToView[16],' },

    # ---- P3-2 B (GPU plumbing): the history texture, the extra SRV it needs, and the fill gain.
    # Everything is inert while the gain is 0, which is what the default build ships.
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'Texture2D<float3> History : register(t4);' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'float4x4 InvVPCur;' },
    # the diagnostic paint: with the gain at 0 the block still runs under "Show static elements" so a
    # single live run can SEE the disocclusion map (yellow) without changing the picture.
    # P3-3 changed this guard: the reprojection now also runs for the diagnostic alone. A group
    # barrier lives in the reduction below it, so the reproject block must NOT carry that barrier --
    # hence the per-pixel locals + a uniform guard (pinned by the markers after this one).
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'const bool lwReproject = (ShowMask > 0.5f) || lwDiag;' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'GroupMemoryBarrierWithGroupSync();'; n = 2 },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'color = lerp(color, float3(1.0f, 1.0f, 0.0f), 0.5f);' },
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';   s = 'color = lerp(color, float3(1.0f, 1.0f, 0.0f), 0.5f);' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.h';     s = 'ID3D12Resource* _history = nullptr;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'if (!SetupRootSignature(InDevice, 5, 3, 1))' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'cmdList->CopyResource(_history, _buffer);' },
    # ---- P3-2's FILL was withdrawn with the knob above. Its matrix build SURVIVES and is
    # load-bearing again: the P3-3 diagnostic reprojects with those two matrices.
    # E2c9/P0: the matrices are built from the SNAPSHOT clip pair (lwV2Cp/lwPV2Cp), which point at
    # the present-boundary pose buffer when it is live and at the legacy cache otherwise.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'p2::BuildReprojectionMatrices(lwW2V, lwV2Cp, lwPW2V,' },
    # ---- P3-5: parameter parity with the official FrameWarp sample. Jitter is carried by the
    # NGX-GENERIC key names (no "Latewarp." prefix), exactly like Depth / MotionVectors / Output.
    @{ f = 'upscalers\latewarp\LatewarpParams.h';   s = 'int          ExtraKeyCount();' },
    @{ f = 'upscalers\latewarp\LatewarpParams.cpp'; s = 'static const char* const kExtra[] = { "Jitter.Offset.X", "Jitter.Offset.Y" };' },
    @{ f = 'upscalers\latewarp\LatewarpParams.cpp'; s = 'WFloat(sink, st, "Jitter.Offset.X", in.jitterX);' },
    @{ f = 'upscalers\latewarp\LatewarpParams.cpp'; s = 'WInt(sink, st, "Latewarp.EvalFlags", in.evalFlags);' },
    # ---- P3-5b: the JITTER VALUE. Cached from Streamline's constants in the same hook, rotated with
    # the frame, and handed to the kernel for the image it actually reprojects.
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'p2::SetStreamlineJitter(values.jitterOffset.x, values.jitterOffset.y);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'void SetStreamlineJitter(float x, float y);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp'; s = 'g_frameData.prevJitter[0] = g_frameData.jitter[0];' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarpIn.jitterX = lwFrame.prevJitter[0];' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-jitter: cur' },
    # ---- P3-3: the diagnostic. The layout gate is the load-bearing one: the cso's reflection says
    # an ARRAY in a constant buffer takes one 16-byte register per element, so `uint[256]` is 4096
    # bytes and everything after it sits past 4096. A packed array here made InvVPCur / VPPPrev /
    # DepthFlipY read as ZERO (D3D reads 0 outside a view), which is why the diagnostic reprojection
    # could never run. The static_asserts keep that from coming back quietly. (Withdrawing P3-1/P3-2
    # moved BlueNoiseWords 48 -> 32 and InvVPCur 4144 -> 4128; the assert below moved with it).
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';   s = 'BlueNoiseSlot BlueNoiseWords[256] = {};' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'static_assert(offsetof(InternalLatewarpUiParams, InvVPCur) == 4128' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'constants.BlueNoiseWords[bn].word = LatewarpBlueNoise32[bn];' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'RWBuffer<uint> Diag : register(u2);' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'float DiagMap;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Common.h';   s = 'float DiagMap = 0.0f;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.h';     s = 'float DiagMap = 0.0f;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'LogDiagStats((uint32_t) presentDesc.Width' },
    # P3-3c: the 2026-09-27 CRASH. `CD3DX12_RESOURCE_DESC::Buffer()` defaults to FLAG_NONE, and a UAV
    # for a buffer without ALLOW_UNORDERED_ACCESS does not fail the call -- it removes the DEVICE. So
    # the diagnostic buffer's flag and its belt-and-braces check are pinned here, plus the separate
    # (flag-less) descriptor the READBACK / UPLOAD companions must use.
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'auto copyDesc = CD3DX12_RESOURCE_DESC::Buffer((UINT64) kLatewarpDiagBytes);' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = '_diag->GetDesc().Flags & D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'bool DecodeDiagStats(const uint32_t words[kDiagWords], int screenWidth, int screenHeight,' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'bool ForwardAngleDeg(const float curFwd[3], const float prevFwd[3], float* outDeg);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'bool PredictCentreShiftPx(const float curFwd[3], const float prevFwd[3], float focalPx, float* outPx);' },
    @{ f = 'Config.h';                            s = 'CustomOptional<float> LatewarpDiagMap { 0.0f };' },
    @{ f = 'Config.cpp';                          s = 'LatewarpDiagMap.set_from_config(readFloat("Latewarp", "DiagMap"));' },
    @{ f = 'Config.cpp';                          s = 'ini.SetValue("Latewarp", "DiagMap",' },
    @{ f = 'menu\menu_common.cpp';                s = 'latewarp diag offset map' },
    # 2 sites now: the P3-3 diagnostic's reference shift, and the E2c3 'latewarp-pose-delta' line
    # that prints the PIXEL SIZE of the warp the kernel is handed (added in round 126).
    # E2c9/P0: BOTH predictions now read the frozen pair the kernel is handed -- the pose-delta one
    # (p2PredFocal) and the diag reference one (lwFocalX). The old marker pinned the racy re-read.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'p2::PredictCentreShiftPx(lwFwdCur, lwFwdPrev, p2PredFocal, &p2PredPx)'; n = 1 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'p2::PredictCentreShiftPx(lwFwdCur, lwFwdPrev, lwFocalX, &lwRefPx)'; n = 1 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-diag-on: reference' },
    # P3-3b: the mask counters (the first live run's only concrete complaint was the UI mask) and the
    # knob-change log that makes a run self-describing.
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'static const uint kDiagMaskCount    = 17;' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'InterlockedAdd(Diag[kDiagMaskDiffQ], g_maskDiffQ[0]);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'static constexpr int kDiagMaskCount    = 17;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp';   s = 'mask {:.2f}% (cutout {:.2f}%) diff {:.3f}' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-knob: diag' },
    # P3-C prerequisite: the plane probe must call the RECOVERED GetPtr vtable slot (8). The interface
    # `Get(key, void**)` lands elsewhere and answered 0xBAD00010 for every key -- including Depth / Output /
    # MotionVectors, which the kernel demonstrably consumes. Pinned so the probe cannot go back to lying.
    @{ f = 'upscalers\latewarp\LatewarpIntercept.cpp'; s = 'const int32_t code = ((PFN_NgxGetPtr) vt[8])(obj, key, out);' },
    @{ f = 'upscalers\latewarp\LatewarpIntercept.cpp'; s = 'plane probe [{0}]: depth{1} output{2}' },
    @{ f = 'upscalers\latewarp\LatewarpFeature_Dx12.cpp'; s = 'p2::LogPlaneProbe(params, "after-fill")' },
    # P3-B: the late-latch instrumentation. Logging only, but it is the measurement the late-input
    # direction rests on, so the clock + the age function + the log line are all pinned.
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h';   s = 'double NewestSampleAgeMs(double nowMs);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp'; s = 'return nowMs - g_frameData.sampleMs;' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-latelatch: pose age' },
    # P3-E2: the game's own DLSS-G is handed the REAL entry points only when it owns frame
    # generation (FGOutput=DLSSG + FGNvngxReplacement=None); every other mode keeps the dummies.
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'if (feature == sl::kFeatureDLSS_G && !lwGameOwnsDlssg)'; n = 2 },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'const bool lwGameOwnsDlssg = (State::Instance().activeFgOutput == FGOutput::NoFG) &&'; n = 2 },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = '(State::Instance().activeFgNvngx == FGNvngxReplacement::None);'; n = 2 },
    # P3-D2: the late-input gain must exist, default to 0, be read AND saved, and the apply site
    # must be gated on it (>0) so a build with the default config stays bit-identical.
    @{ f = 'Config.h'; s = 'CustomOptional<float> LatewarpLateDeltaGain { 0.0f };' },
    @{ f = 'Config.cpp'; s = '"LateDeltaGain"'; n = 2 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'if (p2LateGain > 0.0f && lwCamCur)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-pose: late delta' },
    # P3-E2c: the presented-frame plan pins the two rules that are easy to get wrong -- one output
    # per presented frame (the E1 statefulness finding) and the k/(M+1) interpolation factor.
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'int BuildPresentedFramePlan(int framesToGenerate, int slots, PresentedFrame* plan, int planCapacity);' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp'; s = 'const float step = 1.0f / static_cast<float>(count);' },
    # MFG compatibility: with FGOutput=NoFG nothing of ours may touch the DLSS-G path -- the
    # plugin keeps its own config and the game sees its real options/state.
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'static bool lwHandsOffDlssg()' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'if (lwHandsOffDlssg())'; n = 3 },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'return o_slDLSSGSetOptions(viewport, options);' },
    # P3-3b: the diag slider must NOT paint by itself -- a run has to stay playable while it measures.
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl';       s = 'if (lwDiag && (ShowMask > 0.5f))' },
    # ---- P3-4a: the Chinese panel (the user reads Chinese; OptiScaler has NO translation layer). The
    # Chinese labels are UTF-8 BYTE ESCAPES in the patch -- a literal would be encoded with the code page
    # the compiler assumes, while ImGui decodes UTF-8 -- and the font atlas gets exactly the ~57 CJK code
    # points those labels use instead of a full (megabyte) Chinese range.
    @{ f = 'menu\menu_common.cpp';                s = 'ImFontGlyphRangesBuilder' },
    # 2 each: the custom-font branch AND the built-in fallback pass the same range; the quick switch's
    # comment tag and its log line both carry the English tag.
    @{ f = 'menu\menu_common.cpp';                s = 'p2GlyphRanges.Data'; n = 2 },
    @{ f = 'menu\menu_common.cpp';                s = 'latewarp quick panel'; n = 2 },
    @{ f = 'menu\menu_common.cpp';                s = '##p2run' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.h'; s = 'extern const char kChinesePanelGlyphs[];' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp'; s = 'const char kChinesePanelGlyphs[] =' },
    # ---- P3-E2c: the latewarp decoupled from FGOutput. The pass must be creatable without an FG
    # swapchain (AdoptExistingSwapchain), be bootstrapped and driven on the real present chain, and
    # the FGInput-keyed tag pump must open for the latewarp-only configuration -- plus the teardown
    # that drops the presenter together with the swapchain it adopted.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h'; s = 'void AdoptExistingSwapchain(ID3D12CommandQueue* queue, IDXGISwapChain* swapChain, HWND hwnd);' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'void Reprojection_Dx12::AdoptExistingSwapchain(' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-e2c: adopted the game swapchain' },
    @{ f = 'wrapped\wrapped_swapchain.cpp'; s = 'static bool lwLatewarpOnly()' },
    @{ f = 'wrapped\wrapped_swapchain.cpp'; s = '#include <framegen/reprojection/Reprojection_Dx12.h>' },
    @{ f = 'wrapped\wrapped_swapchain.cpp'; s = 'lw->AdoptExistingSwapchain(cq, pSwapChain, hWnd);' },
    # the bootstrap site AND the teardown site advertise themselves with the same tag
    @{ f = 'wrapped\wrapped_swapchain.cpp'; s = 'latewarp-e2c:'; n = 2 },
    @{ f = 'wrapped\wrapped_swapchain.cpp'; s = 'fg->Present();' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'static bool lwLatewarpOnlyTags()' },
    # 4 sites: slSetTag, slSetTagForFrame, slEvaluateFeature, slPCLSetMarker (markPresent).
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = '|| lwLatewarpOnlyTags())'; n = 4 },
    # the HOOK-TIME predicate: without these two call sites the slSetTag/slSetConstants and
    # slPCLSetMarker hooks are never installed while FGInput=nofg (measured 2026-09-28 23:53).
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = 'static bool lwLatewarpPlanned()' },
    @{ f = 'hooks\Streamline_Hooks.cpp'; s = '|| lwLatewarpPlanned()'; n = 2 },
    # P3-E2c3: the observability pair -- the pixel size of the warp, and an eval log that can show a
    # healthy run (the 14:03 run was 900 frames long and the old 1-in-1000 throttle printed nothing).
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-pose-delta: kernel handed' },
    @{ f = 'upscalers\latewarp\LatewarpFeature_Dx12.cpp'; s = '_frameCount % 300 == 0' },
    # P3-E2c4: the mask threshold is a slider now (default = the old hard constant), and the
    # hudless/backbuffer pair the colour-diff branch compares is logged.
    @{ f = 'Config.h'; s = 'CustomOptional<float> LatewarpMaskThreshold { 0.01f };' },
    @{ f = 'Config.cpp'; s = '"MaskThreshold"'; n = 2 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'lwUiParams.UiDiffThreshold = Config::Instance()->LatewarpMaskThreshold.value_or_default();' },
    @{ f = 'menu\menu_common.cpp'; s = 'Mask threshold (UI-diff half; 1.0+ = off)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'latewarp-src: hudless' },
    @{ f = 'upscalers\latewarp\LatewarpFrameData.cpp'; s = '\xE9\x81\xAE\xE7\xBD\xA9' },
    # P3-E2c5: the late-input source is started for the latewarp-only mode as well.
    @{ f = 'dllmain.cpp'; s = 'RawInputHook::getInstance().start();' },
    @{ f = 'dllmain.cpp'; s = 'State::Instance().activeFgOutput == FGOutput::NoFG &&' },
    # P3-E2c6: the warp-strength slider (blend instead of the hard swap) + its cbuffer slot.
    @{ f = 'Config.h'; s = 'CustomOptional<float> LatewarpWarpStrength { 1.0f };' },
    @{ f = 'Config.cpp'; s = '"WarpStrength"'; n = 2 },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'lwUiParams.WarpStrength = Config::Instance()->LatewarpTagWarpInPlace.value_or_default()' },
    @{ f = 'menu\menu_common.cpp'; s = 'Warp strength (0 = off, 1 = full)' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl'; s = 'float WarpStrength;' },
    @{ f = 'shaders\latewarp\LatewarpUi.hlsl'; s = 'float3 color = lerp(present, warped, WarpStrength * (1.0f - uiMask));' },
    # the default lives in the C++ dispatch struct (the HLSL cbuffer field has no initialiser)
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.h'; s = 'float WarpStrength = 1.0f;' },
    @{ f = 'shaders\latewarp\LatewarpUi_Dx12.cpp'; s = 'WarpStrength must sit at 4268' },
    # P3-E2c8: the shared _lwOut/_buffer are drained on every slot before the warp touches them.
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'for (int lwSlot = 0; lwSlot < BUFFER_COUNT; ++lwSlot)' },
    # ---- P3-E2c2: the freeze fix. One run per rendered frame + the SC allocator fence; without
    # either, MFG's 3-4 presents per frame recycle one command-allocator slot while it is still
    # executing and wedge the game queue (DLSS-G pacer 'waitCPUFence timed out').
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h'; s = 'UINT64 _lastWarpFrameCount = ~0ull;' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.h'; s = 'bool WaitForSCAllocator(int index);' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'bool Reprojection_Dx12::WaitForSCAllocator(int index)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'if (_frameCount == _lastWarpFrameCount)' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = 'WaitForSCAllocator(fIndex);' },
    @{ f = 'framegen\reprojection\Reprojection_Dx12.cpp'; s = '_scAllocatorFenceValues[fIndex] = ++lwScFenceValue;' }
)
foreach ($m in $markers) {
    $want = 1
    if ($m.ContainsKey('n')) { $want = $m.n }
    $n = CountIn (Join-Path $Src $m.f) $m.s
    Check ("marker: " + $m.s.Substring(0, [Math]::Min(46, $m.s.Length))) ($n -eq $want) ($m.f + "  count=" + $n + " (want " + $want + ")")
}



Write-Host "================ L3.5 SHADER TWIN (LatewarpUi.hlsl vs LatewarpUi_Common.h) ================"
# LatewarpUi_Common.h carries the SAME HLSL a second time as a runtime-compile string (the fallback
# when the pre-compiled cso cannot be used), and LatewarpUi_Shader.h is the cso built FROM the .hlsl.
# So an edit to one copy and not the other means the shader that RAN is not the shader that was
# reviewed. This layer makes that drift impossible to miss -- the two must be equal line for line,
# ignoring only the extra indentation the C++ raw string needs.
function Normalize-Hlsl([string]$text) {
    # The runtime copy is SPLIT into adjacent raw literals because MSVC truncates a single literal
    # over 16384 bytes (C2026, hit on 2026-09-28 when the shader grew past it). The splice markers
    # are not shader text, so they are dropped before the comparison; the concatenation itself is
    # what the runtime sees, and it is asserted below.
    (($text -replace "`r`n", "`n") -split "`n" | ForEach-Object { $_.Trim() } |
     Where-Object { $_ -ne '' -and $_ -ne ')" R"(' }) -join "`n"
}
$twinHlsl = Join-Path $Src 'shaders\latewarp\LatewarpUi.hlsl'
$twinSrc  = Join-Path $Src 'shaders\latewarp\LatewarpUi_Common.h'
$twinOk = $false; $twinDetail = 'files missing'
if ((Test-Path -LiteralPath $twinHlsl) -and (Test-Path -LiteralPath $twinSrc)) {
    $twinA = [System.IO.File]::ReadAllText($twinHlsl)
    $twinB = [System.IO.File]::ReadAllText($twinSrc)
    $twinOpen  = 'const std::string shaderCode = R"('
    $twinIdx   = $twinB.IndexOf($twinOpen)
    $twinClose = $twinB.IndexOf('    )";', $twinIdx)
    if (($twinIdx -ge 0) -and ($twinClose -gt $twinIdx)) {
        $twinCode = $twinB.Substring($twinIdx + $twinOpen.Length, $twinClose - ($twinIdx + $twinOpen.Length))
        $na = Normalize-Hlsl $twinA
        $nb = Normalize-Hlsl $twinCode
        $twinOk = ($na -eq $nb)
        if (-not $twinOk) {
            $al = $na -split "`n"; $bl = $nb -split "`n"
            for ($k = 0; $k -lt [Math]::Max($al.Count, $bl.Count); $k++) {
                if ($al[$k] -ne $bl[$k]) { $twinDetail = ('first diff at line ' + $k + ': hlsl[' + $al[$k] + '] twin[' + $bl[$k] + ']'); break }
            }
        } else { $twinDetail = ('identical, ' + ($na -split "`n").Count + ' significant lines') }
    } else { $twinDetail = 'R-string block not found' }
}
Check "the runtime HLSL twin equals LatewarpUi.hlsl" $twinOk $twinDetail

$added = @('LatewarpFeature.h','LatewarpFeature.cpp','LatewarpFeature_Dx12.h','LatewarpFeature_Dx12.cpp','LatewarpParams.h','LatewarpParams.cpp','LatewarpFrameData.h','LatewarpFrameData.cpp','LatewarpIntercept.h','LatewarpIntercept.cpp','LatewarpUi_Common.h','LatewarpUi_Dx12.h','LatewarpUi_Dx12.cpp','LatewarpUi_Shader.h','LatewarpUi.hlsl','LatewarpBlueNoise32.h')
# the added files live in two trees: the backend under upscalers\latewarp, the UI composite under shaders\latewarp
$missing = @($added | Where-Object {
    $a = Join-Path $Src ('upscalers\latewarp\' + $_)
    $b = Join-Path $Src ('shaders\latewarp\' + $_)
    -not ((Test-Path -LiteralPath $a) -or (Test-Path -LiteralPath $b))
})
Check "all $($added.Count) added files are in place" ($missing.Count -eq 0) ($(if ($missing.Count) { 'missing: ' + ($missing -join ', ') } else { '' }))

Write-Host "================ L4 DEFAULT OFF (AC-P2-006) ================"
# B1: the switch ships FALSE, so this build and a stock OptiScaler behave identically until the
# user ticks the box in the Reprojection section.
Check "the latewarp switch ships disabled" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<bool> ReprojectionUseNvidiaLatewarp { false };') -eq 1) ""
# Nothing may enable it by itself: the menu checkbox (T11) is the ONLY writer of the ini switch.
# The in-game hotkey (T25d, [Latewarp] ShortcutKey, default F9) moves p2::SetRuntimeEnabled instead,
# which starts STOPPED and never touches the ini switch -- flipping that switch at runtime was what
# re-armed the broken built-in reprojection path and crashed the host on 2026-09-27 15:38.
$writes = @(Get-ChildItem $Src -Recurse -File -Include *.cpp,*.h -ErrorAction SilentlyContinue |
            Select-String -Pattern 'ReprojectionUseNvidiaLatewarp\s*=' -ErrorAction SilentlyContinue)
Check "only the menu checkbox writes the ini switch (hotkey moves the runtime flag instead)" ($writes.Count -eq 1) ("writes=" + $writes.Count)
# ...and the backend may only READ it.
# 3 READ sites now (the one-shot diagnostic, the branch, and the stock-path guard) and still 0 writes.
Check "the reprojection path only reads the switch" ((CountIn (Join-Path $Src 'framegen\reprojection\Reprojection_Dx12.cpp') 'ReprojectionUseNvidiaLatewarp.value_or_default()') -eq 5) ""
# ...same invariant for the feature-layer intercept switch (branch 1): nothing may set it in code.
Check "the intercept switch ships disabled" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<bool> LatewarpRewrite { false };') -eq 1) ""
# ...and the menu row is its only writer (mirrors the reprojection switch check above).
$writes2 = @(Get-ChildItem $Src -Recurse -File -Include *.cpp,*.h -ErrorAction SilentlyContinue |
             Select-String -Pattern 'LatewarpRewrite\s*=' -CaseSensitive -ErrorAction SilentlyContinue)
# -CaseSensitive matters: the menu row also declares a LOCAL "bool latewarpRewrite = ...", and
# Select-String is case-insensitive by default, which counted that as a second write.
Check "the intercept switch is only written by the menu row" ($writes2.Count -eq 1) ("writes=" + $writes2.Count)
# The rejected design must be gone: no Upscaler::Latewarp and no latewarp in the upscaler provider.
$left = 0
foreach ($f in @('OptiTypes.h','OptiTypes.cpp','upscalers\FeatureProvider_Dx12.cpp')) { $left += (CountIn (Join-Path $Src $f) 'Latewarp') }
# P3-1/P3-2/P3-0a are WITHDRAWN (2026-09-28): their knobs must not exist at all any more -- not in
# the config, not in the panel, not in the ini. This replaces the old 'ships disabled' check, which
# kept passing while the user could still see three meaningless rows on the panel.
$leftKnobs = 0
foreach ($f in @('Config.h','Config.cpp','menu\menu_common.cpp')) {
    foreach ($pat in @('LatewarpEdgeFillPx','LatewarpHoleFillGain','LatewarpPoseGain','latewarp lead fill','latewarp hole fill','latewarp pose gain')) {
        $leftKnobs += (CountIn (Join-Path $Src $f) $pat)
    }
}
Check "the withdrawn P3-1/P3-2/P3-0a knobs appear nowhere" ($leftKnobs -eq 0) ("mentions=" + $leftKnobs)
# ...and the P3-3 diagnostic, which must not be able to switch ITSELF on: it is a measurement mode.
Check "the viewmodel mask ships disabled (C mode warps uniformly)" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<bool> LatewarpViewmodelMask { false };') -eq 1) ""
Check "the highlight protection ships disabled" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<bool>  LatewarpHighlightProtect   { false };') -eq 1) ""
Check "the warp scale ships at 1.0 (nothing changes until it is moved)" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<float> LatewarpWarpScale { 1.0f };') -eq 1) ""
Check "the P3-3 diagnostic ships disabled" ((CountIn (Join-Path $Src 'Config.h') 'CustomOptional<float> LatewarpDiagMap { 0.0f };') -eq 1) ""
$writes4 = @(Get-ChildItem $Src -Recurse -File -Include *.cpp,*.h -ErrorAction SilentlyContinue |
             Select-String -Pattern 'LatewarpDiagMap\s*=' -ErrorAction SilentlyContinue)
Check "only the menu slider writes the P3-3 diagnostic" ($writes4.Count -eq 1) ("writes=" + $writes4.Count)
Check "the REJECTED upscaler design appears nowhere" ($left -eq 0) ("mentions=" + $left)
Write-Host "================ L7 KEY TABLE vs THE REAL KERNEL ================"
# The unit test only proves table == spec TSV, which is SELF-consistency: both sides descend from
# the same RE notes. NGX silently IGNORES an unknown parameter name, so one typo would be
# invisible at runtime. This layer cross-checks the table against the literal strings inside the
# user-supplied feature DLL, in both directions, and SKIPs cleanly when there is no DLL to read.
$k = Run-Child @((Join-Path $P2 'test\test_keys_against_kernel.ps1'))
$kv = ((($k.text -split [char]10) | Where-Object { $_ -match '^=== (PASS|SKIP)' }) -join ' ').Trim()
Check 'key table cross-checked against the real kernel' (($k.code -eq 0) -and ($k.text -match '=== (PASS|SKIP)')) $kv


if ($Full) {
    Write-Host "================ L5 UNIT + PROVISIONING ================"
    # S10 F-10: the build gate is deliberately NOT here. It runs at the very end (see below),
    # so what it gates is a build of the FRESHLY RE-APPLIED tree. Running it here would gate a
    # tree that the rollback step rewrites two lines later.
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try {
        $t = & (Join-Path $P2 'test\build_and_run_test.cmd') 2>&1 | Out-String
        $pr = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $P2 'test\test_provisioning.ps1') 2>&1 | Out-String
        # these two suites ship in the package, so the gate must run them too (they were ungated)
        $cl = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $P2 'test\test_collect.ps1') 2>&1 | Out-String
        $gi = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $P2 'test\test_game_install.ps1') 2>&1 | Out-String
        # The kernel-level half of AC-P2-002: the REAL feature DLL must warp. Needs the user's own
        # NVIDIA binaries, so it SKIPs (exit 0 + "=== SKIP ...") inside the released package.
        $ow = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $P2 'test\test_offline_warp.ps1') 2>&1 | Out-String
    } finally { $ErrorActionPreference = $prev }
    Check "offline unit test" ($t -match 'PASS \(0 failure') ""
    Check "provisioning tests" ($pr -match 'PASS \(0 failure') ""
    Check "collector tests" ($cl -match 'PASS \(0 failure') ""
    Check "game install tests" ($gi -match 'PASS \(0 failure') ""
    $owv = ((($ow -split [char]10) | Where-Object { $_ -match '^=== (PASS|SKIP)' }) -join ' ').Trim()
    Check "offline kernel acceptance (real feature DLL)" ((($ow -match 'PASS \(0 failure') -or ($ow -match '=== SKIP')) -and ($ow -notmatch '\[FAIL\]')) $owv
}

if ($TestRevert -or $Full) {
    Write-Host "================ L6 REVERT ROUND TRIP (AC-P2-001) ================"
    # both the files we patch now AND the ones the rejected design used to patch (those must be
    # byte-identical to the delivered tree again, which proves the revert is complete)
    $tracked = @('Config.h','Config.cpp','framegen\reprojection\Reprojection_Dx12.h','framegen\reprojection\Reprojection_Dx12.cpp','inputs\NVNGX_DLSS_Dx12.cpp','hooks\Streamline_Hooks.cpp','menu\menu_common.cpp','OptiScaler.vcxproj','OptiTypes.h','OptiTypes.cpp','upscalers\FeatureProvider_Dx12.cpp')
    $rv = Run-Child @((Join-Path $P2 'apply_to_optiscaler.ps1'), '-Action', 'Revert', '-Tree', $Tree)
    Check "revert exits 0" ($rv.code -eq 0) ("exit=" + $rv.code)
    $diff = @()
    foreach ($rel in $tracked) {
        $a = Join-Path $Pristine $rel
        $b = Join-Path $Src $rel
        if (-not (Test-Path -LiteralPath $b)) { $diff += ($rel + ' (absent)'); continue }
        if ((Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash) { $diff += $rel }
    }
    Check "revert restores every patched file BYTE-IDENTICALLY" ($diff.Count -eq 0) ($(if ($diff.Count) { 'differs: ' + ($diff -join ', ') } else { $tracked.Count.ToString() + ' files match the delivered tree' }))
    Check "revert removes upscalers\latewarp" (-not (Test-Path -LiteralPath (Join-Path $Src 'upscalers\latewarp'))) ""
    Check "revert removes the generated metadata headers too" ((-not (Test-Path -LiteralPath (Join-Path $Src 'resource_build_date.h'))) -and (-not (Test-Path -LiteralPath (Join-Path $Src 'resource_build_commit.h')))) "S10 F-04: otherwise the tree is not byte-identical"
    Check "revert leaves no latewarp trace" (((CountIn (Join-Path $Src 'OptiTypes.h') 'Latewarp') -eq 0) -and ((CountIn (Join-Path $Src 'hooks\Streamline_Hooks.cpp') 'LatewarpFrameData') -eq 0)) ""

    # S10 (review B) F-01: a PREVIEW must not mutate the tree. Right now the tree is pristine
    # (we just reverted), which is exactly the state where a leak shows up as a new header file.
    $dryAfter = Run-Child @((Join-Path $P2 'apply_to_optiscaler.ps1'), '-DryRun', '-Tree', $Tree)
    $leak = @()
    foreach ($g in @('resource_build_date.h','resource_build_commit.h')) {
        if (Test-Path -LiteralPath (Join-Path $Src $g)) { $leak += $g }
    }
    Check "dry run leaves the pristine tree untouched" (($dryAfter.code -eq 0) -and ($leak.Count -eq 0)) ($(if ($leak.Count) { 'leaked: ' + ($leak -join ', ') } else { 'no files created' }))

    $ra = Run-Child @((Join-Path $P2 'apply_to_optiscaler.ps1'), '-Tree', $Tree)
    Check "re-apply after revert succeeds" ($ra.code -eq 0) ("exit=" + $ra.code)
    Check "markers are back after re-apply" ((CountIn (Join-Path $Src 'menu\menu_common.cpp') 'Use NVIDIA latewarp (Reflex 2)') -eq 1) ""
    $null = Run-Child @((Join-Path $P2 'apply_to_optiscaler.ps1'), '-DryRun', '-Tree', $Tree)
}

if ($Full -and (-not $SkipBuild)) {
    Write-Host "================ L5 BUILD GATE (on the re-applied tree) ================"
    $b = Run-Child @((Join-Path $P2 'build_verify.ps1'))
    Check "gated build" ($b.text -match '\[build\] PASS') (($b.text -split [char]10 | Where-Object { $_ -match 'msbuild exit' }) -join ' ')
}

Write-Host "============================================="
if ($script:fails -eq 0) { Write-Host "VERIFY-P2: PASS" -ForegroundColor Green; exit 0 }
Write-Host ("VERIFY-P2: FAIL (" + $script:fails + ")") -ForegroundColor Red
exit 1
