# SPEC: OptiScaler 整合勘察 (S3) — latewarp 后端接入点

> 证据分级: **T1** = 直接读源码(文件:行号); **T3** = 二手; **待验证** = 未查证, 明确标注。
> 源码: `OptiScaler_20260923_154112\OptiScaler_source_5b6bc822` (v10.0.0-dev, 5b6bc822), 567 个源文件。
> **LICENSE = GNU GPL v3**(该树根目录 `LICENSE`) —— 整合进这棵树 = 我们的新增代码走 GPL-3。此点已由用户选择"整合"接受。

## 1. 结论: OptiScaler 缺少的**只有 latewarp**, 其余全有 [T1]

| OptiScaler 已有的 | 证据 |
|---|---|
| 注入/多 API 代理 (D3D11/D3D12/Vulkan) | `OptiScaler\proxies\`、`with_dx12\`、`upscalers\FeatureProvider_{Dx11,Dx12,Vk}.cpp` |
| **它自己就在代理 NGX core** | `proxies\NVNGX_Proxy.h` 内有 46 处 `CreateFeature/EvaluateFeature`, 并声明 `PFN_D3D12_CreateFeature`(L268) / `PFN_D3D12_EvaluateFeature`(L274) |
| **它自己创建并驱动 NGX feature** | `upscalers\FeatureProvider_Dx12.cpp:47` = `*feature = std::make_unique<DLSSFeatureDx12>(handleId, parameters);` |
| **已经在 Streamline 里面**(相机常量) | `hooks\Streamline_Hooks.cpp`(`slGetPluginFunction` L1367 / `slOnPluginLoad` L1373 / `slDLSSGetOptimalSettings` L1380); 全树 `slSetConstants` **45 处** |
| **资源追踪 / 无 UI 帧** | `resource_tracking\`、`hudfix\`(4 文件) — 正是我们 P1 解决的那个问题的地基 |
| 深度/MV/jitter 语义 | `upscalers\IFeature.h`: `LowResMV`(L18) / `DepthInverted`(L20) / `JitteredMV`(L21) / `JitterInfo`(L50) / `_jitterInfo`(L66) / `_hasColor,_hasDepth,_hasMV`(L78-80) / `_depthLinear`(L85) / render·target·display 尺寸(L87-92) |
| **解析 NGX 参数对象** | `IFeature::GetRenderResolution(const NVSDK_NGX_Parameter* InParameters, ...)` `IFeature.h:104` |
| Reflex/low-latency 已有代码 | `low_latency\`(21 文件)、`nvapi\`(14 文件) |
| 后端枚举 + 菜单开关 | `OptiTypes.h:44` `enum class Upscaler`; `menu\menu_common.cpp:487/508/514/1506` |
| **没有任何 latewarp** | 全树 `latewarp` 命中 **0** |

**⇒ 通用性所需要的一切它都有; 唯一缺的正是我们这一轮挖出来的那块知识。**

## 2. 接入点(已定位到行) [T1]

1. **拦截点**: 游戏调用 `NVSDK_NGX_D3D12_CreateFeature(featureId=15)` 的地方 ——
   OptiScaler 已经在 `proxies\NVNGX_Proxy.h` 拿到了这个函数指针, 且 `inputs\NVNGX_DLSS_Dx12.cpp:601` 已示范"把游戏的 NGX 调用映射到某个后端"(`upscaler = Upscaler::DLSS;`)。
2. **后端工厂**: `upscalers\FeatureProvider_Dx12.cpp:47` —— 加一个 latewarp 分支即可。
3. **后端本体**: 照 `upscalers\dlss\DLSSFeature_Dx12.{h,cpp}`(4 KB) 的形态写 `LatewarpFeature`:
   实现 `IFeature`, 拿它已经提供的 color/depth/MV/jitter/尺寸/矩阵。
4. **菜单**: `menu\menu_common.cpp` 的同几处, 加一个开关项。
5. **"通用"的关键一步**: 对**从不创建 feature 15** 的游戏(如实测的 CP2077), 由**我们**用 OptiScaler 的管线**自己创建并驱动** feature 15 ——
   这正是我的 P1 代理做不到、而 OptiScaler 结构上能做到的事。

## 3. 待验证(不要当成已验证) [待验证]

1. `hudfix` 抓到的无 UI 帧能否直接作为 `Latewarp.HudlessColor`/`UIColorAlpha` 的输入(格式/尺寸/生命周期);
2. 它 `slSetConstants` 拿到的相机数据是否包含 latewarp 需要的**四个矩阵 + jitter**;
3. 它的深度/MV 约定(格式、极性、缩放)与 latewarp 内核是否一致;
4. 自己创建 feature 15 时, 命令行列表/资源状态是否安全(路线 A 曾因在热路径装钩子崩过);
5. latewarp 的输出要接到哪一步(OptiScaler 的呈现链是否留了位置)。

## 4. 已知代价

* **GPL-3**: 整合 = 新增代码 GPL-3, 且与 NVIDIA 专有二进制的打包关系要谨慎;
* **反作弊**: OptiScaler 是注入式。**用户已明确: 有反作弊的游戏直接排除** —— 在那类游戏上"装 mod"本身就是违规, 没有兼容性可言。⇒ "通用"的实际范围 = **无内核级反作弊的游戏(单机为主)**;
* **语义对齐**: 采集问题由 OptiScaler 解决, 但"数据对不对得上"仍需逐项验证(见 §3)。

## 5. 与已交付 P1 的关系

P1 代理(`_re\reflex2_mod\src\reflex2_nvngx.cpp`)与 OptiScaler 走的是**同一个拦截点**, 等于一个只覆盖 NGX 路径的微型实现。
它的价值是**知识载体**(两个决定键 / `Set` 返回 void / `UIColorAlpha` 在载荷 +0x10 / 白名单 / 可复现构建与精确还原的安装器),
整合时应把这些搬进 `LatewarpFeature`, 而不是重写一遍。
