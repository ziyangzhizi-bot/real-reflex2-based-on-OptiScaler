# RUNBOOK — 实机验证(需要你做的)

> P2 唯一需要动用游戏的一步。做完把日志给我, 我用 `collect_p2_run.ps1` 给结论。
> **反作弊游戏不要做**(OptiScaler 是注入式 mod; 这类目标已按你的裁定排除)。

## 现在缺的到底是什么

全部离线项已验完: 补丁 **20 处**落位 / 构建通过 / 两个开关**默认关且各有唯一写入者** / revert **11 文件**逐字节 /
43 键表对真内核**双向一致** / 四套件全绿(单测 28 · 供给 24 · 采集 22 · 安装器)。
**没验的只有一件**: 在真实宿主里, 改写(路①)或自建(路②)的 feature 15 到底跑成什么样。

## 前置(两件, 缺一不可)

| # | 东西 | 为什么 |
|---|---|---|
| 1 | `nvngx_latewarp.dll`(**你自己的**那份) | 特征 DLL; 没有它内核创建不出 feature 15 |
| 2 | **认识 latewarp 的 NGX 内核** | 驱动自带的内核**不认识** feature 15(本机 30.0.14.9516 里 `Latewarp.*` 名字数 = **0**), 只放特征 DLL 仍会 `0xBAD0000B` |

安装器会校验: 特征 DLL 按 **SHA256**(不符明确拒收); 内核按**内容**(必须含 `Latewarp.*` 名)。
内核会被落成 **`_nvngx.dll`** —— `NVNGX_Proxy.h:447` 是 `dllNames = { "_nvngx.dll", "nvngx.dll" }`, OptiScaler 优先加载它。

## 另外: 一处全机器残留需要你用管理员清掉

(之前把 NGX 日志重定向进了本仓库)

```powershell
Set-ItemProperty -Path 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NGXCore' -Name EnableLogPathOverride -Value 0
Remove-ItemProperty -Path 'HKLM:\SOFTWARE\NVIDIA Corporation\Global\NGXCore' -Name LogPath
```

## 步骤(以 CP2077 为例; 换游戏同理, 只是 bin 目录不同)

0. **先确认游戏没在运行**。
1. 供给两件(先 `-DryRun` 看会做什么, 再去掉正式执行):
   `install_latewarp_dll.ps1 -GameDir <...\bin\x64> -LatewarpDll <你的特征DLL> -CoreDll <你的内核> -DryRun`
2. 把补丁后的 OptiScaler 装成 **`nvngx.dll`**(不是 dxgi/d3d12 —— 作为 nvngx 代理它是**转发**, 不接管 FG 路径):
   `install_p2_into_game.ps1 -GameDir <...\bin\x64> -ProxyName nvngx.dll`
3. 进游戏, 按**该游戏属于哪条路**开开关:
   * **路①(游戏自己会创建 f15)**: 菜单 → `Advanced Settings` → 勾 **`Latewarp: rewrite feature 15 params`**
   * **路②(游戏从不创建 f15)**: 把 `FG Output` 选成 `Reprojection` → 勾 **`Use NVIDIA latewarp (Reflex 2)`**
4. 玩十几秒(**要有镜头运动**), 正常退出。
5. 把 `OptiScaler.log` 的路径发我。

## 我要的答案有两个, 缺一不可

1. **日志**(我用采集器判): 断言/创建/评估有没有跑、有没有 `0xBAD`、平面探针给了什么;
2. **画面** —— 这是 AC-P2-002 的实质。P1 量过"逐位拷贝 → 真 warp"的差别是 **0.000000% → 81.0888%** 的像素。
   你只需回一句: 动态物体边缘是**像静止的逐位拷贝**, 还是**真的跟手变形**?
   (要更硬的证据我们再比帧, 那一步我会给你脚本。)

## 我会怎么判(采集器的裁定表)

| verdict | 含义 |
|---|---|
| **INTERCEPT_ACTIVE** | **路①成功**: 游戏自己创建的 feature 15 上, 两个决定键被断言 N 次, 无 `0xBAD`, 无白名单拒绝(注意: 只证明改写生效, 画面仍要你判) |
| **QUALIFIED** | **路②成功**: 自建实例创建 + 每帧评估, 无 `0xBAD` |
| `INTERCEPT_INCOMPLETE` / `INTERCEPT_BAD_PARAMS` | 拦截跑了, 但键没写全 / 拿到空参数对象 |
| `CREATE_FAILED` / `EVAL_ERROR` | 创建或评估返回 `0xBAD`。**先看裁定文本后面点名的参数**: 采集器会把内核自己说的 `could not find <KEY> parameter` 汇总成 `MISSING <KEY> xN` 并写进裁定 —— 那就是"下一步要补什么"的清单 |
| `MATRIX_INPUTS_MISSING` | 求值跑了, 但自建的**四个矩阵没绑齐**。看 `latewarp-mat:` 行: `world->view` 来自 FG 相机环, `view->clip` 来自 `slSetConstants` 缓存, 哪一项 false 就是哪个来源断供 |
| `CORE_UNAVAILABLE` | 真内核没加载 |
| `WHITELIST_VIOLATION` | 试图写 43 键以外的键(不该发生) |
| `NO_LATEWARP_LINES` | 代码没跑。采集器会**顺带告诉你该走哪条路**(它打印 app 是否创建了 f15) |

## 跑完怎么读(一条命令)

    .\collect_p2_run.ps1 -Log "E:\SteamLibrary\steamapps\common\Cyberpunk 2077\bin\x64\OptiScaler.log"

`VERDICT: QUALIFIED` = 自建实例创建 + 每帧评估 + 无 `0xBAD`。报告里同时给出:

* `-- matrices (self-create path) --`: 一次性 `latewarp-mat:` 的四个矩阵真/假 + 两份矩阵的 row0/平移行数值;
* `-- NGX core: missing-parameter oracle --`: 内核点名缺的参数及次数(按 key 去重);
* 平面探针(游戏手里已有哪些平面)。

**判据(与目标一致)**: 日志里 `latewarp: feature 15 create; ...` / `CreateFeature(featureId=15) succeeded` 之后,
出现 `latewarp: eval #N` 而**不再**是 `latewarp: EvaluateFeature -> 0xBAD00005`。

## 还原(任何时候一条命令)

`install_p2_into_game.ps1 -GameDir <...\bin\x64> -Uninstall` —— 逐字节还原, 我方新增的文件会被删除。

## 纪律

* 装之前先备份、卸载后逐字节复核(安装器自动做);
* 反作弊目标不注入不调试;
* 交付包不含任何 NVIDIA 二进制(特征 DLL 与内核都由你自备)。
