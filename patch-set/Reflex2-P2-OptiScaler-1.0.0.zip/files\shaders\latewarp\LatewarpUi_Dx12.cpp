// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#include "pch.h"
#include "LatewarpUi_Dx12.h"
#include "LatewarpUi_Common.h"
#include "LatewarpBlueNoise32.h"

#include <Config.h>
#include <State.h>
#include "LatewarpUi_Shader.h"
#include <upscalers/latewarp/LatewarpFrameData.h>   // P3-3: p2::kDiag* + DecodeDiagStats

#include <cstddef>
#include <cstring>

// P3-3: the size of the diagnostic block, in bytes. The shader writes p2::kDiagWords uints into it.
static const UINT kLatewarpDiagBytes = (UINT) p2::kDiagWords * sizeof(uint32_t);

void LatewarpUi_Dx12::ResourceBarrier(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* resource,
                                      D3D12_RESOURCE_STATES beforeState, D3D12_RESOURCE_STATES afterState)
{
    if (beforeState == afterState)
        return;

    D3D12_RESOURCE_BARRIER barrier = {};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = resource;
    barrier.Transition.StateBefore = beforeState;
    barrier.Transition.StateAfter = afterState;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    cmdList->ResourceBarrier(1, &barrier);
}

bool LatewarpUi_Dx12::Dispatch(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* warped,
                               ID3D12Resource* hudless, ID3D12Resource* present, ID3D12Resource* depth,
                               D3D12_RESOURCE_STATES warpedState, D3D12_RESOURCE_STATES hudlessState,
                               D3D12_RESOURCE_STATES presentState, D3D12_RESOURCE_STATES depthState,
                               const LatewarpUiDispatchParams& params, ID3D12Resource* presentSource,
                               D3D12_RESOURCE_STATES presentSourceState)
{
    if (!_init || _device == nullptr || warped == nullptr || hudless == nullptr || present == nullptr ||
        depth == nullptr || cmdList == nullptr)
        return false;

    ScopedGpuTime_Dx12 scopedGpuTime(GpuTime.get(), cmdList);

    // P2/E2c32 (T89): `presentSource` is the image the shader reads as t1; `present` is the target.
    // When they differ the pass is a straight CONVERTING copy: with WarpStrength 0 the shader's
    // colour is exactly `present` (== the t1 sample), and the UAV write converts the format.
    const bool lwSplitSource = (presentSource != nullptr) && (presentSource != present);
    if (presentSource == nullptr)
        presentSource = present;

    _counter++;
    _counter = _counter % LatewarpUi_NUM_OF_HEAPS;
    FrameDescriptorHeap& currentHeap = _frameHeaps[_counter];

    auto resourceFlags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET | D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS |
                         D3D12_RESOURCE_FLAG_ALLOW_SIMULTANEOUS_ACCESS;

    if (_buffer == nullptr)
    {
        LOG_DEBUG("[{0}] Start!", _name);

        auto result = Shader_Dx12::CreateBufferResource(_device, present, D3D12_RESOURCE_STATE_COPY_DEST, &_buffer,
                                                        resourceFlags);

        if (result)
        {
            _buffer->SetName(L"LatewarpUi_Buffer");

            // P3-2 B: the history must exist before the first Dispatch reads it, so it is created in
            // the same one-shot block (the pass returns early on the first call anyway).
            if (Shader_Dx12::CreateBufferResource(_device, present, D3D12_RESOURCE_STATE_COPY_DEST,
                                                 &_history, resourceFlags))
                _history->SetName(L"LatewarpUi_History");

            // P3-3 / P3-3c: the diagnostic block, its readback companion, and an upload buffer of
            // zeros used to clear the block with a CopyBufferRegion (no descriptor heap needed for a
            // clear). Created here, with the rest of the pass, so the u2 descriptor is never empty.
            //
            // TWO DESCRIPTORS ON PURPOSE, AND THE UAV FLAG IS MANDATORY:
            //   * CD3DX12_RESOURCE_DESC::Buffer() defaults to D3D12_RESOURCE_FLAG_NONE, and creating
            //     a UAV for a buffer without ALLOW_UNORDERED_ACCESS does NOT fail the call -- it
            //     removes the DEVICE (the live log shows DXGI_ERROR_INVALID_CALL right after the mask
            //     ring was created and before the constants buffer, i.e. on the u2 descriptor). That
            //     was the 2026-09-27 crash: the diagnostic had never been switched ON in a live run
            //     before, so nothing had ever exercised this line.
            //   * a READBACK / UPLOAD heap resource must NOT carry the UAV flag, hence `copyDesc`.
            {
                auto diagDesc = CD3DX12_RESOURCE_DESC::Buffer((UINT64) kLatewarpDiagBytes,
                                                              D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
                auto copyDesc = CD3DX12_RESOURCE_DESC::Buffer((UINT64) kLatewarpDiagBytes);

                auto diagHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
                if (_device->CreateCommittedResource(&diagHeap, D3D12_HEAP_FLAG_NONE, &diagDesc,
                                                     D3D12_RESOURCE_STATE_COPY_DEST, nullptr,
                                                     IID_PPV_ARGS(&_diag)) == S_OK)
                    _diag->SetName(L"LatewarpUi_Diag");

                // Belt and braces: if the driver ever hands back a buffer without the flag, keep the
                // diagnostic OFF instead of binding a UAV for it (which would take the device down).
                if (_diag != nullptr &&
                    (_diag->GetDesc().Flags & D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS) == 0)
                {
                    LOG_ERROR("[{0}] the diagnostic buffer has no ALLOW_UNORDERED_ACCESS; the P3-3 "
                              "diagnostic stays OFF (binding u2 would remove the device)", _name);
                    SAFE_RELEASE(_diag);
                }

                auto readHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_READBACK);
                if (_device->CreateCommittedResource(&readHeap, D3D12_HEAP_FLAG_NONE, &copyDesc,
                                                     D3D12_RESOURCE_STATE_COPY_DEST, nullptr,
                                                     IID_PPV_ARGS(&_diagRead)) == S_OK)
                    _diagRead->SetName(L"LatewarpUi_DiagRead");

                auto zeroHeap = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);
                if (_device->CreateCommittedResource(&zeroHeap, D3D12_HEAP_FLAG_NONE, &copyDesc,
                                                     D3D12_RESOURCE_STATE_GENERIC_READ, nullptr,
                                                     IID_PPV_ARGS(&_diagZero)) == S_OK)
                {
                    _diagZero->SetName(L"LatewarpUi_DiagZero");
                    void* zero = nullptr;
                    if (_diagZero->Map(0, nullptr, &zero) == S_OK)
                    {
                        memset(zero, 0, kLatewarpDiagBytes);
                        _diagZero->Unmap(0, nullptr);
                    }
                }
            }
        }

        return result;   // first call only allocates, like HudCopy
    }

    // the two R8 masks are allocated once, in the state the kernel expects to sample them from
    if (_maskRing[0] == nullptr || _maskRing[1] == nullptr)
    {
        const D3D12_RESOURCE_FLAGS maskFlags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
        for (int i = 0; i < 2; ++i)
        {
            if (!Shader_Dx12::CreateBufferResource(_device, present, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                                                  &_maskRing[i], maskFlags, 0, 0, DXGI_FORMAT_R8_UNORM))
            {
                LOG_ERROR("[{0}] could not create the NoWarpMask texture", _name);
                return false;
            }

            _maskRing[i]->SetName(L"LatewarpUi_NoWarpMask");
        }
    }

    ID3D12Resource* maskTarget = _maskRing[_maskNext];

    ResourceBarrier(cmdList, present, presentState, D3D12_RESOURCE_STATE_COPY_SOURCE);

    // keep the composited frame: it is the source of the UI AND of the static viewmodel
    cmdList->CopyResource(_buffer, present);

    ResourceBarrier(cmdList, present, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, _buffer, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    if (lwSplitSource)
        ResourceBarrier(cmdList, presentSource, presentSourceState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, hudless, hudlessState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, warped, warpedState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, depth, depthState, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, maskTarget, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);

    // t0 = warped, t1 = present, t2 = hudless (same frame, no UI), t3 = depth
    CreateShaderResourceView(_device, warped, currentHeap.GetSrvCPU(0));
    CreateShaderResourceView(_device, presentSource, currentHeap.GetSrvCPU(1));   // P2/E2c32: may be a different resource than the target
    CreateShaderResourceView(_device, hudless, currentHeap.GetSrvCPU(2));
    CreateShaderResourceView(_device, depth, currentHeap.GetSrvCPU(3));
    // P3-2 B: t4 = last frame's composite. It is COPY_DEST while we write it and a shader resource
    // while the pass reads it, so the barrier flips it here and back at the end of the dispatch.
    if (_history != nullptr)
    {
        ResourceBarrier(cmdList, _history, D3D12_RESOURCE_STATE_COPY_DEST,
                        D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
        CreateShaderResourceView(_device, _history, currentHeap.GetSrvCPU(4));
    }
    // u0 = the composited frame, u1 = the NoWarpMask the kernel consumes next frame
    CreateUnorderedAccessView(_device, _buffer, currentHeap.GetUavCPU(0), 0);
    CreateUnorderedAccessView(_device, maskTarget, currentHeap.GetUavCPU(1), 0);

    // P3-3: u2 = the diagnostic block. It is cleared first (an 80-byte CopyBufferRegion from the
    // zero upload buffer) and then handed to the shader as an R32_UINT typed buffer view: an
    // RWBuffer<uint> needs a typed view, not a structured one. Off => none of this is recorded.
    const bool lwDiagOn = (params.DiagMap > 0.5f) && (_diag != nullptr) && (_diagRead != nullptr) &&
                          (_diagZero != nullptr);
    if (lwDiagOn)
    {
        D3D12_UNORDERED_ACCESS_VIEW_DESC diagUav = {};
        diagUav.Format = DXGI_FORMAT_R32_UINT;
        diagUav.ViewDimension = D3D12_UAV_DIMENSION_BUFFER;
        diagUav.Buffer.FirstElement = 0;
        diagUav.Buffer.NumElements = (UINT) p2::kDiagWords;
        diagUav.Buffer.StructureByteStride = 0;
        diagUav.Buffer.CounterOffsetInBytes = 0;
        diagUav.Buffer.Flags = D3D12_BUFFER_UAV_FLAG_NONE;
        _device->CreateUnorderedAccessView(_diag, nullptr, &diagUav, currentHeap.GetUavCPU(2));

        cmdList->CopyBufferRegion(_diag, 0, _diagZero, 0, (UINT64) kLatewarpDiagBytes);
        ResourceBarrier(cmdList, _diag, D3D12_RESOURCE_STATE_COPY_DEST,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    }

    InternalLatewarpUiParams constants {};
    constants.DiffThreshold = params.UiDiffThreshold;
    constants.ShowMask = params.ShowMask;
    constants.DepthCutoff = params.DepthCutoff;
    constants.CutoffExpandPx = params.CutoffExpandPx;
    // P3-3: the diagnostic's inputs. The matrices are copied only when the host has them; leaving the
    // struct's zeroes in place keeps a missing pose a no-op instead of reading junk (and _history is
    // only ever sampled when the shader's own reproject branch runs).
    constants.DepthFlipY = params.DepthFlipY;
    if (params.invVPCur != nullptr) memcpy(constants.InvVPCur, params.invVPCur, sizeof(constants.InvVPCur));
    if (params.vpPrev != nullptr) memcpy(constants.VPPPrev, params.vpPrev, sizeof(constants.VPPPrev));
    constants.InvertedDepth = params.InvertedDepth;
    constants.InvScreenWidth = params.InvScreenWidth;
    constants.InvScreenHeight = params.InvScreenHeight;
    constants.DiagMap = lwDiagOn ? 1.0f : 0.0f;
    constants.DiagRefPx = params.DiagRefPx;
    // P2/E2c6: the strength slider. It sits in the 12 bytes of padding the TailReg register already
    // had, so no other offset moves (pinned by the static_assert below).
    constants.WarpStrength = params.WarpStrength;
    constants.HighlightProtect = params.HighlightProtect;
    constants.HighlightThreshold = params.HighlightThreshold;
    // P3-3: the blue-noise table goes into the constant buffer the way HLSL PACKS it -- one element
    // per 16-byte register -- so table word k must land in element k, not at byte offset 4k. The
    // shader still reads BlueNoiseWords[bnIdx >> 2] and shifts out the byte; only the stride on THIS
    // side was wrong before (the constructor's static_asserts pin the array's size).
    for (int bn = 0; bn < 256; ++bn)
        constants.BlueNoiseWords[bn].word = LatewarpBlueNoise32[bn];

    if (!CreateConstantsBuffer(_device, _constantBuffer, constants, currentHeap.GetCbvCPU(0)))
    {
        LOG_ERROR("[{0}] Failed to create a constants buffer", _name);
        return false;
    }

    ID3D12DescriptorHeap* heaps[] = { currentHeap.GetHeapCSU() };
    cmdList->SetDescriptorHeaps(_countof(heaps), heaps);

    cmdList->SetComputeRootSignature(_rootSignature);
    cmdList->SetPipelineState(_pipelineState);

    cmdList->SetComputeRootDescriptorTable(0, currentHeap.GetTableGPUStart());

    auto presentDesc = present->GetDesc();
    UINT dispatchWidth = static_cast<UINT>((presentDesc.Width + InNumThreadsX - 1) / InNumThreadsX);
    UINT dispatchHeight = (UINT) ((presentDesc.Height + InNumThreadsY - 1) / InNumThreadsY);

    cmdList->Dispatch(dispatchWidth, dispatchHeight, 1);

    // P3-3: read the diagnostic block back. Map() returns whatever the GPU has already finished:
    // on a busy frame that is the PREVIOUS frame's block (one frame of latency -- irrelevant for a
    // diagnostic), so this does not stall the render thread waiting for this frame's dispatch.
    if (lwDiagOn)
    {
        ResourceBarrier(cmdList, _diag, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                        D3D12_RESOURCE_STATE_COPY_SOURCE);
        cmdList->CopyResource(_diagRead, _diag);
        ResourceBarrier(cmdList, _diag, D3D12_RESOURCE_STATE_COPY_SOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);

        LogDiagStats((uint32_t) presentDesc.Width, (uint32_t) presentDesc.Height, params.DiagRefPx);
    }

    ResourceBarrier(cmdList, maskTarget, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);
    ResourceBarrier(cmdList, _buffer, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    ResourceBarrier(cmdList, present, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, D3D12_RESOURCE_STATE_COPY_DEST);

    cmdList->CopyResource(present, _buffer);

    // P3-2 B: keep this composite for the next frame's fill. `_buffer` is COPY_SOURCE here.
    if (_history != nullptr)
    {
        ResourceBarrier(cmdList, _history, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_COPY_DEST);
        cmdList->CopyResource(_history, _buffer);
    }

    ResourceBarrier(cmdList, present, D3D12_RESOURCE_STATE_COPY_DEST, presentState);
    if (lwSplitSource)   // P2/E2c32: hand the source back in the state the caller lent it in
        ResourceBarrier(cmdList, presentSource, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, presentSourceState);
    ResourceBarrier(cmdList, hudless, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, hudlessState);
    ResourceBarrier(cmdList, warped, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, warpedState);
    ResourceBarrier(cmdList, depth, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, depthState);
    ResourceBarrier(cmdList, _buffer, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);

    _maskNext = 1 - _maskNext;
    _maskReady = true;

    return true;
}

// P2/E2c37: THE PEAK BOOST PASS. The reasoning lives in the mode branch at the top of
// LatewarpUi.hlsl: the kernel bilinear resample damps a 1-2 px specular peak, the game bloom is
// superlinear in luminance, and the glow goes with the peak (in-game A/B: WarpScale 0 restores the
// lamp, HighlightProtect makes no difference). This pass lifts the bright neighbours of the
// kernel OUTPUT before it is copied back into the game texture.
bool LatewarpUi_Dx12::Boost(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* src, ID3D12Resource* dst,
                            float amount, float threshold)
{
    if (cmdList == nullptr || src == nullptr || dst == nullptr || _device == nullptr)
        return false;

    const D3D12_RESOURCE_DESC sd = src->GetDesc();
    const D3D12_RESOURCE_DESC dd = dst->GetDesc();
    if (sd.Width != dd.Width || sd.Height != dd.Height || sd.Width == 0 || sd.Height == 0)
        return false;

    // P2/E2c37c: a pass that has not been Init()ed has no PSO and no root signature; dispatching
    // anyway writes nothing, and the caller would copy an UNINITIALISED texture into the game frame.
    if (_pipelineState == nullptr || _rootSignature == nullptr)
    {
        static int lwBoostNotReady = 0;
        if (lwBoostNotReady < 3)
        {
            LOG_WARN("[{0}] Boost skipped: the pass is not initialised yet (pso {} rs {})", _name,
                     (void*) _pipelineState, (void*) _rootSignature);
            ++lwBoostNotReady;
        }
        return false;
    }

    // Same descriptor-heap rotation Dispatch uses (there `currentHeap` is a local, not a member).
    _counter++;
    _counter = _counter % LatewarpUi_NUM_OF_HEAPS;
    FrameDescriptorHeap& currentHeap = _frameHeaps[_counter];

    // The kernel left its output as a UAV; the boost reads it. Both ends of this pair are OUR
    // resources, so neither state is an assumption about what the game did.
    ResourceBarrier(cmdList, src, D3D12_RESOURCE_STATE_UNORDERED_ACCESS,
                    D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE);

    ID3D12DescriptorHeap* heaps[] = { currentHeap.GetHeapCSU() };
    cmdList->SetDescriptorHeaps(_countof(heaps), heaps);
    CreateShaderResourceView(_device, src, currentHeap.GetSrvCPU(0));
    CreateUnorderedAccessView(_device, dst, currentHeap.GetUavCPU(0), 0);

    InternalLatewarpUiParams constants {};
    constants.ShowMask = 255.0f;                // the mode flag: > 200 selects the boost branch
    constants.WarpStrength = amount;            // re-used as the boost amount
    constants.HighlightThreshold = threshold;   // re-used as the luminance gate
    constants.InvScreenWidth = 1.0f / (float) sd.Width;
    constants.InvScreenHeight = 1.0f / (float) sd.Height;
    if (!CreateConstantsBuffer(_device, _boostConstantBuffer, constants, currentHeap.GetCbvCPU(0)))
    {
        LOG_ERROR("[{0}] Boost: failed to create the constants buffer", _name);
        ResourceBarrier(cmdList, src, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                        D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        return false;
    }

    cmdList->SetComputeRootSignature(_rootSignature);
    cmdList->SetPipelineState(_pipelineState);
    cmdList->SetComputeRootDescriptorTable(0, currentHeap.GetTableGPUStart());
    cmdList->Dispatch((UINT) ((sd.Width + InNumThreadsX - 1) / InNumThreadsX),
                      (UINT) ((sd.Height + InNumThreadsY - 1) / InNumThreadsY), 1);

    // src goes back to the UAV state the kernel left it in; dst STAYS a UAV -- the caller's copy
    // block owns the UAV -> COPY_SOURCE -> UAV transition for whichever texture it copies from.
    ResourceBarrier(cmdList, src, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE,
                    D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    return true;
}
LatewarpUi_Dx12::LatewarpUi_Dx12(std::string InName, ID3D12Device* InDevice) : Shader_Dx12(InName, InDevice)
{
    if (InDevice == nullptr)
    {
        LOG_ERROR("InDevice is nullptr!");
        return;
    }

    LOG_DEBUG("{0} start!", _name);

    // P3-3 / 2026-09-28: the constant-buffer layout is shared with HLSL, and HLSL packs an ARRAY at
    // ONE ELEMENT PER 16-BYTE REGISTER -- so a `uint[256]` array is 4096 bytes, not 1024. Those
    // assertions pin the byte offsets the cso's own reflection reports. They exist because the
    // opposite assumption was a REAL bug that no test could see: with a packed 1024-byte blue-noise
    // table this struct was 1216 bytes while the shader addressed up to 4288, and D3D reads ZERO
    // outside a view -- so InvVPCur / VPPPrev / DepthFlipY were all 0 and the diagnostic reprojection
    // NEVER ran. (cso reflection: "uint BlueNoiseWords[256]; Offset: 32" then "float4x4 InvVPCur;
    // Offset: 4128". The offsets moved when P3-1/P3-2's LeadFill/HoleFill members were withdrawn.)
    static_assert(offsetof(InternalLatewarpUiParams, BlueNoiseWords) == 32, "cbuffer: BlueNoiseWords must sit at 32");
    static_assert(sizeof(InternalLatewarpUiParams::BlueNoiseSlot) == 16, "cbuffer: one HLSL array element = one 16-byte register");
    static_assert(sizeof(InternalLatewarpUiParams::BlueNoiseWords) == 4096, "cbuffer: 256 array elements occupy 4096 bytes");
    static_assert(offsetof(InternalLatewarpUiParams, InvVPCur) == 4128, "cbuffer: InvVPCur must sit at 4128");
    static_assert(offsetof(InternalLatewarpUiParams, VPPPrev) == 4192, "cbuffer: VPPPrev must sit at 4192");
    static_assert(offsetof(InternalLatewarpUiParams, DepthFlipY) == 4256, "cbuffer: DepthFlipY must sit at 4256");
    static_assert(offsetof(InternalLatewarpUiParams, DiagMap) == 4260, "cbuffer: DiagMap must sit at 4260");
    static_assert(offsetof(InternalLatewarpUiParams, DiagRefPx) == 4264, "cbuffer: DiagRefPx must sit at 4264");
static_assert(offsetof(InternalLatewarpUiParams, WarpStrength) == 4268, "cbuffer: WarpStrength must sit at 4268 (TailReg padding)");
static_assert(offsetof(InternalLatewarpUiParams, HighlightProtect) == 4272, "cbuffer: HighlightProtect must sit at 4272 (right after WarpStrength)");
static_assert(offsetof(InternalLatewarpUiParams, HighlightThreshold) == 4276, "cbuffer: HighlightThreshold must sit at 4276");

    // 5 SRV (warped / present / hudless / depth + history), 3 UAV (composite / NoWarpMask /
    // P3-3 diag block), 1 CBV (the heap is sized from this SRV count, so the two must move together)
    if (!SetupRootSignature(InDevice, 5, 3, 1))
    {
        LOG_ERROR("Failed to setup root signature");
        return;
    }

    D3D12_RESOURCE_DESC desc = CD3DX12_RESOURCE_DESC::Buffer(sizeof(InternalLatewarpUiParams));
    auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);

    auto result =
        InDevice->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE, &desc, D3D12_RESOURCE_STATE_GENERIC_READ,
                                          nullptr, IID_PPV_ARGS(&_constantBuffer));

    if (result != S_OK)
    {
        LOG_ERROR("[{0}] CreateCommittedResource error {1:x}", _name, (unsigned int) result);
        return;
    }

    if (!CreateComputePipeline(InDevice, &_pipelineState, LatewarpUi_cso, sizeof(LatewarpUi_cso), shaderCode.c_str()))
    {
        LOG_ERROR("[{0}] Failed to create compute pipeline", _name);
        return;
    }

    _init = InitHeaps(InDevice, _frameHeaps, LatewarpUi_NUM_OF_HEAPS);
}

LatewarpUi_Dx12::~LatewarpUi_Dx12()
{
    if (!_init || State::Instance().isShuttingDown)
        return;

    for (int i = 0; i < LatewarpUi_NUM_OF_HEAPS; i++)
    {
        _frameHeaps[i].ReleaseHeaps();
    }

    SAFE_RELEASE(_buffer);
    SAFE_RELEASE(_history);
    SAFE_RELEASE(_maskRing[0]);
    SAFE_RELEASE(_maskRing[1]);
    SAFE_RELEASE(_diag);
    SAFE_RELEASE(_diagRead);
    SAFE_RELEASE(_diagZero);
}

// P3-3: decode + log one readback. The block is one frame old by construction (see the comment at
// the Dispatch), and the log is deliberately rare -- the first three frames and every 30th frame
// afterwards, because 60 lines per second are unreadable. The PEAK column keeps the worst frame of
// a fast camera flick visible between two lines.
void LatewarpUi_Dx12::LogDiagStats(uint32_t width, uint32_t height, float refPx)
{
    ++_diagFrames;

    if (_diagRead == nullptr)
        return;

    D3D12_RANGE readRange = { 0, kLatewarpDiagBytes };
    uint32_t* words = nullptr;
    if (_diagRead->Map(0, &readRange, reinterpret_cast<void**>(&words)) != S_OK || words == nullptr)
        return;

    uint32_t block[p2::kDiagWords] = {};
    memcpy(block, words, sizeof(block));
    _diagRead->Unmap(0, nullptr);

    p2::DiagReadout r {};
    if (!p2::DecodeDiagStats(block, (int) width, (int) height, &r) || !r.valid)
        return;   // the first diag frame: the block is still the zeroed one from the clear

    if (r.maxShiftPx > _diagPeakShiftPx)
        _diagPeakShiftPx = r.maxShiftPx;

    if (_diagFrames > 3 && (_diagFrames % 30) != 0)
        return;

    // Every column here answers a question that was unanswerable in the first live run:
    //   shift / peak   -- is the reprojection OFFSET plausible, and does it grow with the turn?
    //   outside / max  -- is there anything to fill at all, and how wide is the band?
    //   behind         -- a non-zero count means the depth/v-axis convention puts points BEHIND the
    //                     previous camera, i.e. the reprojection is wrong (not the fill).
    //   mismatch       -- history sampled where the maths says the content came from must equal the
    //                     pixel; a large mean over the WHOLE frame means the lookup is mirrored or
    //                     mis-scaled. `outside` mismatch is the fill quality itself.
    //   centre / reference -- the shader's measured shift at the centre pixel next to the host's
    //                     predicted one (focal * tan(pose angle)): the two must agree in magnitude.
    //   mask/cutout/diff -- how much of the frame the UI mask freezes, how much of THAT the depth
    //                     predicate selected (a big share = a wrong depth predicate / InvertedDepth),
    //                     and how strong the colour diff behind it is (a small one = the mask is
    //                     grabbing a subtle screen-space TINT that should have moved with the world).
    //   depth WxH      -- the DEPTH TEXTURE's size. If it is not the pass size, the depth load reads
    //                     the wrong pixel and nothing downstream can be trusted.
    LOG_INFO("latewarp-diag: frame {} shift max {:.1f} peak {:.1f} px | outside {} ({:.2f}%) max {:.1f} px behind {} | mismatch {:.3f} outside {:.3f} | centre {:.1f} px ndc ({:.4f},{:.4f})->({:.4f},{:.4f}) depth {:.4f} | reference {:.1f} px | mask {:.2f}% (cutout {:.2f}%) diff {:.3f} | pass {:.0f}x{:.0f} depth {}x{}",
             _diagFrames, r.maxShiftPx, _diagPeakShiftPx, r.outsideCount, r.outsidePercent, r.maxOutsidePx,
             r.behindCount, r.meanMismatch, r.meanMismatchOutside, r.centreShiftPx, r.centreCur[0],
             r.centreCur[1], r.centrePrev[0], r.centrePrev[1], r.centreDepth, refPx, r.maskPercent,
             r.maskCutoutPercent, r.meanMaskDiff, (float) width, (float) height, r.depthWidth,
             r.depthHeight);

    // P2/E2c25 (T82): WHAT THE WARP DID TO BRIGHT CONTENT. 'kept' is out/in per luminance bin over the
    // SAME pixels, so it needs no brightness-space assumption: the bins are slices of the image the
    // kernel was HANDED. A bright bin that collapses while the darker ones stay near 100% is the
    // reprojection destroying specular highlights -- the reported lamp-highlight loss, quantified.
    // The frame max luminance is logged next to it, so a run cannot be read as 'nothing was bright'
    // when the bins were simply unreachable.
    {
        auto keptPct = [](uint32_t inQ, uint32_t outQ) { return (inQ == 0u) ? 0.0f : (100.0f * (float) outQ / (float) inQ); };
        LOG_INFO("latewarp-bright: warp cost to bright content | 0.5-1 kept {:.1f}% (inQ {}) | 1-2 kept {:.1f}% "
                 "(inQ {}) | 2-4 kept {:.1f}% (inQ {}) | 4+ kept {:.1f}% (inQ {}) | maxlum {:.2f}",
                 keptPct(r.binInQ[0], r.binOutQ[0]), r.binInQ[0], keptPct(r.binInQ[1], r.binOutQ[1]), r.binInQ[1],
                 keptPct(r.binInQ[2], r.binOutQ[2]), r.binInQ[2], keptPct(r.binInQ[3], r.binOutQ[3]), r.binInQ[3],
                 r.maxLum);
    }

    // restart the peak window every ~5 s so it describes the RECENT motion, not the session
    if ((_diagFrames % 300) == 0)
        _diagPeakShiftPx = r.maxShiftPx;
}