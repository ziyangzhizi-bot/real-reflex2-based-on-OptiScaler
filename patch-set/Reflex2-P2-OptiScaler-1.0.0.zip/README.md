# p2/ — OptiScaler latewarp 整合补丁集

SPDX-License-Identifier: **GPL-3.0-or-later**(因为接入的是 GPL-3 的 OptiScaler; 见 `INV-P5`)。

## 这是什么

把 NVIDIA 原生 latewarp(Reflex 2 / NGX feature 15)接进 OptiScaler 的**补丁集**。
交付的是补丁 + 应用脚本,**不改**工作区里那棵交付源码树(INV-P4)。

**接点在 NGX 特征层**: OptiScaler 自己实现并导出 `NVSDK_NGX_D3D12_CreateFeature` / `EvaluateFeature`
(`inputs\NVNGX_DLSS_Dx12.cpp`), 所以以 `nvngx.dll` 部署时, 游戏(或 Streamline)的 NGX 调用会落进它的
代码里, feature 15 必经过该函数。两条路各有一个**默认关闭**的开关:

| 路 | 场景 | 行为 | 开关(默认关) |
|---|---|---|---|
| ① 拦截 | 游戏**自己**会创建 f15 | 转发给真内核**之前**只断言两个决定键(`Latewarp.IsRenderedFrame=0` / `Latewarp.UIColorAlpha=nullptr`), 把逐位拷贝变成真 warp | ini `[Latewarp] Rewrite=true` |
| ② 自建 | 游戏**从不**创建 f15 | 在同一模块里自己 `CreateFeature(15)` 并每帧 `EvaluateFeature` | FG Output = Reprojection + 勾选 `Use NVIDIA latewarp (Reflex 2)` |

> **被否决的设计(别再走回去)**: 曾把 `Latewarp` 加进 `Upscaler` 枚举、走超分后端列表。实机报
> `init failed with Latewarp (Reflex 2) feature` —— 那条路要求后端产出**超分图像**, 而 latewarp 是重投影。

## 目录

| 路径 | 内容 |
|---|---|
| `apply_to_optiscaler.ps1` | 应用 / 预览 / 还原; 默认目标是 `_re\repro_src`(**构建工作区**) |
| `build_verify.ps1` | **唯一可信的构建判据**(必须 msbuild exit=0 **且** DLL 被重写)。**不要**用 `_re\optiscaler_verify\repro_build2.ps1` —— 它在失败时也会打印上次成功的 DLL |
| `verify_p2.ps1` | **验收脚本** L1-L7: L1 交付树无痕 / L2 预检 / L3 每处补丁**内容级恰好命中** / L4 两个开关**默认关且无程序化赋值** / L5(`-Full`) 单测+供给+构建 / L6 revert **逐字节**往返 / **L7 43 键表对照真内核字面量** |
| `install_p2_into_game.ps1` | 把打完补丁的 OptiScaler 装进游戏(指定代理名)并**逐字节还原**; 含 **AC-P2-008 反作弊拒绝门** |
| `install_latewarp_dll.ps1` | **供给**: 定位使用者的 `nvngx_latewarp.dll` **和**一个**认识 latewarp 的内核**, 校验(特征 DLL 按 SHA256 / 内核按**内容**: 必须含 `Latewarp.*` 名), 缺失**明确报错**; 内核落成 `_nvngx.dll`。**不下载、不打包** |
| `collect_p2_run.ps1` | 读一份运行日志给出唯一 verdict + 单列**平面探针**小结 |
| `make_patch_review.ps1` → `PATCH_REVIEW.diff` / `.md` | 真 unified diff(3 行上下文) + 清单; 并独立证明作用范围(几改/几增/0 删) |
| `files\` | 要**新增**到 OptiScaler 源码树里的文件(按同样相对路径摆放) |
| `test\` | 离线单测与测试套件(见下) |
| `DESIGN.md` / `DESIGN_B1.md` | 接入契约与策略规格(带 文件:行号) |
| `RUNBOOK_p2_host-run.md` | 实机验证说明 |
| `APPLIED_DIFF.txt` / `backup\<时间戳>\` | 应用后自动产出的逐改动清单 / 被改文件备份 |

## 用法

```powershell
.\p2\apply_to_optiscaler.ps1 -DryRun         # 只打印将做什么
.\p2\apply_to_optiscaler.ps1                 # 应用到 _re\repro_src, 生成 APPLIED_DIFF.txt
.\p2\build_verify.ps1                        # 构建门(会真的 FAIL)
.\p2\verify_p2.ps1 -Full                     # L1..L7 全套(含回滚往返与构建)
.\p2\apply_to_optiscaler.ps1 -Action Revert  # 按备份还原并删除新增文件(也接受 -Revert)
```

## 部署配方(实机)

```powershell
# 1) 供给: 特征 DLL + 认识 latewarp 的内核(内核会被放成 _nvngx.dll)
.\p2\install_latewarp_dll.ps1 -GameDir <bin\x64> -LatewarpDll <你的 nvngx_latewarp.dll> -CoreDll <你的 nvngx.dll>
# 2) 把补丁后的 OptiScaler 装成 nvngx.dll(而不是 dxgi/d3d12: 作为 nvngx 代理它是**转发**, 不接管 FG 路径)
.\p2\install_p2_into_game.ps1 -GameDir <bin\x64> -ProxyName nvngx.dll
# 3) 开拦截开关: 菜单 -> Advanced Settings -> 勾选 "Latewarp: rewrite feature 15 params"
#    [Latewarp]
#    Rewrite=true
# 4) 退出游戏后读裁定
.\p2\collect_p2_run.ps1 -Log <OptiScaler.log>
```

**为什么内核要叫 `_nvngx.dll`**: `proxies\NVNGX_Proxy.h:447` 是 `dllNames = { L"_nvngx.dll", L"nvngx.dll" }`,
OptiScaler 优先加载它。于是「OptiScaler = `nvngx.dll` + 真内核 = `_nvngx.dll`」正好配套。

## 交付物对工作区的前提(冷启动请先读)

这套东西是**补丁集**, 不是独立程序。它假设:

| 前提 | 说明 |
|---|---|
| 目录嵌套 | 脚本按**上三级**推仓库根: `<repo>\_re\reflex2_mod\p2\` 必须成立 |
| 一个干净源码树 | 默认取 `<repo>\OptiScaler_20260923_154112\OptiScaler_source_5b6bc822\OptiScaler`; 也可 `-Tree` 指定别的 |
| 一个**构建工作区** | `<repo>\_re\repro_src` 必须已存在(**本补丁集不创建它**)。做法见 `OptiScaler_20260923_154112\BUILD_FROM_SOURCE.md` |
| MSVC | Visual Studio 2022 BuildTools; 别处装了要改 `build_verify.ps1` 里的 vcvars 路径 |
| **认识 latewarp 的内核 + 特征 DLL** | 驱动自带的内核**不认识** feature 15(本机 30.0.14.9516 里 `Latewarp.*` 名字数 = **0**), 只放特征 DLL 仍会 `0xBAD0000B`。两者都由使用者自备, 见 `install_latewarp_dll.ps1` |

## 触点(当前; 共 20 处补丁 / 10 个文件 / 10 个新增文件)

| # | 触点 | 作用 |
|---|---|---|
| T14 | `inputs\NVNGX_DLSS_Dx12.cpp` include | 引入拦截件 |
| T18 | `CreateFeature` 转发前 | **路①**: 断言两个决定键 |
| T19 | `EvaluateFeature` | **路①**: 每帧重申(靠既有的 `HandleToFeature[handleId]` 认出 f15) |
| T15/T16/T17 | `Config.h` + `Config.cpp` | 开关 `[Latewarp] Rewrite`(**默认 false**) |
| T20 | `menu\menu_common.cpp` | **菜单行**: `Advanced Settings` 里的 `Latewarp: rewrite feature 15 params`(放在永不被模式门控的块里) |
| T8/T9/T10/T11 | `Config.h`+`Config.cpp`+`menu_common.cpp` | 开关 `[Reprojection] UseNvidiaLatewarp`(**默认 false**) + 菜单勾选框 |
| T12/T13 | `Reprojection_Dx12.h/.cpp` | **路②**: 自建时的每帧求值站点 |
| T6a/b | `hooks\Streamline_Hooks.cpp` | 缓存 `cameraViewToClip`(自建路的 `viewToClip`/`prevViewToClip` 来源; 见「P2 输入清单与证据表」①) |
| T5 | `OptiScaler.vcxproj` | 登记 10 个新文件(0 通配 ⇒ 必须登记; 其中 2 个关 PCH) |
| T7 | `OptiScaler.vcxproj` + 两个版本头 | 构建事件 + 钉死版本头, 保证可复现 |

**默认关**怎么保证: 两个开关都是 `false`, 且 `verify_p2.ps1` 的 L4 断言**没有任何代码能程序化打开它们**
(`ReprojectionUseNvidiaLatewarp` 的唯一写入者是菜单勾选框; `LatewarpRewrite` 的写入者数 = 0)。
`-Action Revert` 把 10 个新文件与 10 个被改文件**逐字节**还原(L6 已验证 11 个受检文件)。

### T5 的一个细节(预编译头)

OptiScaler 每个 .cpp 首行都要 `#include <pch.h>`, 而装配层要保持"无依赖、可离线单测",
所以 vcxproj 里对**两个**无依赖文件(`LatewarpParams.cpp` 与 `LatewarpFrameData.cpp`)关掉 PCH。

## 离线单测与测试套件

```powershell
.\p2\test\build_and_run_test.cmd         # 28 项断言(装配层)
.\p2\test\test_keys_against_kernel.ps1   # 43 键表双向对照真 nvngx_latewarp.dll 字面量(无 DLL 则干净 SKIP)
.\p2\test\test_provisioning.ps1          # 供给 24 例(含能力内核)
.\p2\test\test_game_install.ps1          # 安装/还原 + AC-P2-008 反作弊拒绝
.\p2\test\test_collect.ps1               # 日志采集器
```

包**可自验**: 把 zip 解压到任意目录, 直接跑 `test\build_and_run_test.cmd` 即可 —— 它自己会从**同级**
`spec\LATEWARP_KEYS.tsv` 找到夹具(已在一个工作区之外的临时目录实测: 28 PASS / 0 failure)。

## P2 输入清单与证据表(RE ⇒ 代码 ⇒ 证据)

自建路(②)的每一个必填输入都必须由我们自己喂齐。这张表是那份清单的**唯一落点**:
每行 = 一条已定稿 RE ⇒ 代码落点 ⇒ 证据等级。

| # | RE 结论(来源) | 代码落点 | 证据 |
|---|---|---|---|
| ① 矩阵 | `Latewarp.WorldToViewMatrix` 与 `Latewarp.PrevRenderedWorldToViewMatrix` 的 16 个分量全部 `\|A-B\|<1e-6` 时内核**直通早退**(`_re\routeA\audit\LATEWARP_DLL_EARLYOUTS.md`); 而**缺**参数更直接: 内核日志 `NGXLatewarp::EvaluateFeature:589 error: could not find Latewarp.WorldToViewMatrix parameter` ⇒ `0xBAD00005` | `p2::BuildWorldToView()`(`files\upscalers\latewarp\LatewarpFrameData.cpp`, 零依赖) + T21 用 FG 相机环 `_cameraPosition/Up/Right/Forward[fIndex]` 与上一索引写 `worldToView`/`prevWorldToView`; `viewToClip`/`prevViewToClip` 取 T6b 的 `slSetConstants` 缓存 | **T1** 离线单测回归两份真实抓取(camrun `maxErr=0`; frame_4042 `maxErr=6e-6`); 内核日志 7792 次一一对应;**离线受控实验(单变量)**: 同一台架去掉这四个矩阵 ⇒ `EvaluateFeature -> 0xBAD00005`(与实机同码), 加回 ⇒ `Success`(`fwtest --nomats`); 且矩阵必须放在**持久环形缓冲**(`p2::MatrixRing`, 5 槽, 与游戏 stride 0x100 同构)而不是栈上 —— 内核在帧返回后才解引用那些指针 |
| ② 输出格式 | latewarp 只接受 87/10, 交换链后台缓冲是 24 ⇒ 不能直接当平面(`_re\routeA\audit\AUDIT_RESIDUE_ROBUSTNESS.md:268`) | T21 自建 `B8G8R8A8_UNORM` 中间纹理当 `Output`, 求值后 `CopyResource` 回后台缓冲 | **T1 反证**: 离线台架里输出 87 与 28 **都能 Success** ⇒ 该文件的「28 永不返回」已推翻; 自建 87 仍保留(与 RE 一致且零成本) |
| ③ 去 UI 帧 | `HudlessColor`/`Backbuffer` 必须是**去 UI 帧**(Route A 的 `g_clean` 经验) | T21 复用 FG 层的 Hudless 资源(`GetResource(FG_ResourceType::HudlessColor, fIndex)`) | **T2**: `latewarp-diag:` 实测 `hudless 1` |
| ④ 两个决定键 | `IsRenderedFrame=0` / `UIColorAlpha=nullptr`(P1 实测 `0.000000%` → `81.0888%`) | `LatewarpParams::Fill` 最后写这两键; T21 置 `isRenderedFrame=0` / `nullOutUIColorAlpha=true` | **T1** 单测断言「两键最后写」且值正确 |
| ⑤ 必填平面 | `Depth`/`MotionVectors`/`Output`(无前缀)为空时 ⇒ `0xBAD00005` | T21 的 `planesReady` 门 + `Fill` 仅在非空时绑键(不覆盖宿主已有的输入) | **T1** 单测「无平面时不绑键」+ 离线台架「置空即 `0xBAD00005`」 |
| ⑥ Subrect | **不必填**: 台架 `--nosubrect`(不写任何 `*.Subrect.*`)仍然 `EvaluateFeature Success` | `Fill` 只在 Subrect 宽高非 0 时写(`WSubrect` 提前返回) | **T1**: `fwtest --nosubrect 1` ⇒ `Success`(所以自建路的键集不含 Subrect 也是完整的) |

**矩阵布局(实证, 不是猜约定)**: 行主序、`XMMatrixLookAtLH` 语义 ——
`row0=(right.x,up.x,fwd.x,0)`, `row1=(right.y,up.y,fwd.y,0)`, `row2=(right.z,up.z,fwd.z,0)`,
`row3=(-dot(right,pos),-dot(up,pos),-dot(fwd,pos),1)`。
校验数据: `_re\routeA\demo_run\ngxproxy.camrun.log:25` 与 `_re\routeA\frame_4042.txt`(两者都反解出相机位姿 `(0,1.8,0)`, 交叉自洽)。

**实机判据**: 日志出现 `latewarp-mat: w2v … pw2v … v2c … pv2c …` 四项 true, 且 `CreateFeature(featureId=15) succeeded`
之后出现 `latewarp: eval #N`(**不再**是 `EvaluateFeature -> 0xBAD00005`)。

## 已知未验证项(诚实清单)

| # | 未验证项 | 为什么没证 | 谁来证 |
|---|---|---|---|
| 1 | **AC-P2-002 / 003: 真的出画** | 需要一个**宿主游戏** | 用户在真游戏里跑一次, 再用 `collect_p2_run.ps1` 读日志 |
| 2 | ~~**自建路(②)的矩阵语义**~~ **已离线钉死(2026-09-27)** | `sl::Constants` 没有 worldToView, 所以从 FG 相机基向量推导; 布局已用**两份真实抓取**回归验证(camrun `maxErr=0` / frame_4042 `maxErr=6e-6`) | 余下只差**实机**确认数值路径(`latewarp-mat:` ×4 + `latewarp: eval #N`), 与 AC-P2-002/003 同一次宿主跑 |
| 3 | **AC-P2-006 只是静态的** | L4 只能证明"没有代码程序化打开开关" | 宿主运行时开关对比(关/开各跑一次) |
| 4 | 只有 **D3D12** 后端 | 没有 D3D11/Vulkan 的测试载体 | 需要载体 |
| 5 | 多视口: 两个 swapchain 时**后写者赢** | 单视口宿主无法构造 | 需要多视口宿主 |

**风险缓解**: 两条路都**默认关闭**, 用户必须显式开开关才会走到上面这些路径。

**AC-P2-008 是强制的, 不是声明**: `install_p2_into_game.ps1` 检测到内核级反作弊标记(或游戏树里存在
任意 `*.sys`)会**直接拒绝安装**, 没有 `-Force` 后门(`-DryRun` 也拒); 卸载不受此门限制。
