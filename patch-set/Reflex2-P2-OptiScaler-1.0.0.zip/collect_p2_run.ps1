# ---------------------------------------------------------------------------
#  collect_p2_run.ps1 -- read ONE OptiScaler log from a live run and print a verdict.
#
#  This is the P2 counterpart of the P1 qualify.ps1: instead of "did it crash", it answers
#  the questions that actually matter for this integration:
#    * did anything create NGX feature 15, and did it succeed
#    * which PLANES did the game already hand us (the read-only probe logs Get() results)
#    * were any evaluations refused/errored (0xBAD0xxxx)
#    * were any parameter keys outside the whitelist (the code counts those)
#
#  usage: .\collect_p2_run.ps1 -Log <path to OptiScaler log>
# ---------------------------------------------------------------------------
param(
    [Parameter(Mandatory = $true)][string]$Log
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Log)) { Write-Host ("no log at " + $Log); exit 3 }
$t = [System.IO.File]::ReadAllText($Log)
$lines = $t -split "[char]10"
Write-Host ("== P2 run report: " + $Log + "  (" + $lines.Count + " lines) ==")

function Has([string]$re) { return [bool]([regex]::IsMatch($t, $re)) }
function Cnt([string]$re) { return ([regex]::Matches($t, $re)).Count }

$created   = Has 'latewarp: CreateFeature\(featureId=15\) succeeded'
# the create line is "latewarp: feature 15 create; extent WxH, keys written N, refused M" -- the
# extent sits between the two, so anchoring on 'create; keys written' never matched (it made a
# QUALIFIED run report NO_LATEWARP_LINES).
$createTry = Has 'latewarp: feature 15 create;'
$createBad = Has 'latewarp: CreateFeature\(featureId=15\) -> 0xBAD'
$evals     = Cnt 'latewarp: eval #'
$anyEval   = Has 'latewarp: eval #'
$evalBad   = Cnt 'latewarp: EvaluateFeature -> 0xBAD'
$bad       = Cnt '0xBAD[0-9A-Fa-f]{4}'
$wlViol    = 0
foreach ($m in [regex]::Matches($t, 'keys written (\d+), refused (\d+)')) { if ([int]$m.Groups[2].Value -gt 0) { $wlViol++ } }
$evalBad2  = Has 'latewarp: evaluated before the feature was created'
$noInit    = Has 'latewarp: D3D12_CreateFeature is nullptr|latewarp: nvngx.dll not loaded'

# --- feature-layer intercept (strategy branch 1) -------------------------------------------
# We assert the two decisive keys on the application's OWN feature 15. OptiScaler's own
# "Passthrough to native NGX CreateFeature for feature 15" line is the proof that the app (or
# Streamline) really did create feature 15 in this process -- i.e. branch 1 is the right branch.
$interceptSeen = Has 'latewarp: intercept'
$interceptOk   = Cnt 'latewarp: intercept asserted the 2 decisive keys'
$interceptBad  = Has 'latewarp: intercept wrote [01] of 2 decisive keys'
$interceptNull = Has 'latewarp: intercept got a null parameter object'
$appF15        = Has 'Passthrough to native NGX CreateFeature for feature 15'

Write-Host ("  create attempted        : " + $createTry)
Write-Host ("  create succeeded        : " + $created)
Write-Host ("  evaluations logged      : " + $evals + " line(s)")
Write-Host ("  0xBAD0xxxx anywhere     : " + $bad)
Write-Host ("  whitelist refusals      : " + $wlViol + " report(s) with refused > 0")
Write-Host ("  eval before init        : " + $evalBad2)
Write-Host ("  core/proxy missing      : " + $noInit)
Write-Host ("  intercept asserted keys : " + $interceptOk + " time(s)")
Write-Host ("  app itself created f15  : " + $appF15 + "  (from OptiScaler's passthrough line)")

# --- THE decisive answer: which planes does the game already provide? --------
Write-Host "  -- plane probe (Get results; this is what the first live run is for) --"
$anyPlane = $false
foreach ($m in [regex]::Matches($t, "latewarp: plane '([^']+)' -> ret 0x([0-9A-Fa-f]+) value (\S+)")) {
    $anyPlane = $true
    $key = $m.Groups[1].Value; $ret = $m.Groups[2].Value; $val = $m.Groups[3].Value
    $state = if ($ret -eq '1' -and $val -ne '0') { 'SUPPLIED' } elseif ($ret -eq '1') { 'present but null' } else { 'absent' }
    Write-Host ("     " + $key.PadRight(22) + " ret=0x" + $ret + "  value=" + $val + "   " + $state)
}
if (-not $anyPlane) { Write-Host "     (no probe lines -- the patched code did not run in this process)" }
$supplied = @()
foreach ($m in [regex]::Matches($t, "latewarp: plane '([^']+)' -> ret 0x1 value (0x[0-9A-Fa-f]+)")) { $supplied += $m.Groups[1].Value }
Write-Host ("  planes already supplied : " + $(if ($supplied.Count) { ($supplied | Select-Object -Unique) -join ', ' } else { '<none>' }))

# --- the FOUR MATRICES (self-create path) ---------------------------------------------------
# The matrices are the one input the game does NOT hand us: WorldToView has to be derived from
# the FG camera basis, ViewToClip comes from the slSetConstants cache. The one-shot latewarp-mat
# line names, per source, whether it produced a matrix at all.
$matLine = $null
foreach ($m in [regex]::Matches($t, 'latewarp-mat: w2v (\w+) pw2v (\w+) v2c (\w+) pv2c (\w+) cam (\w+) framedata cur (\w+) prev (\w+) upd (\d+)')) { $matLine = $m }
$mat = @{}
if ($matLine) {
    $mat['w2v'] = $matLine.Groups[1].Value;  $mat['pw2v'] = $matLine.Groups[2].Value
    $mat['v2c'] = $matLine.Groups[3].Value;  $mat['pv2c'] = $matLine.Groups[4].Value
    $mat['cam'] = $matLine.Groups[5].Value;  $mat['cur'] = $matLine.Groups[6].Value
    $mat['prev'] = $matLine.Groups[7].Value; $mat['upd'] = $matLine.Groups[8].Value
}
$matBad = ($matLine -ne $null) -and (($mat['w2v'] -ne 'True') -or ($mat['pw2v'] -ne 'True') -or
                                     ($mat['v2c'] -ne 'True') -or ($mat['pv2c'] -ne 'True'))
Write-Host "  -- matrices (self-create path) --"
if ($matLine) {
    Write-Host ("     latewarp-mat: world->view current=" + $mat['w2v'] + " previous=" + $mat['pw2v'] +
                " | view->clip current=" + $mat['v2c'] + " previous=" + $mat['pv2c'] +
                "  (camera basis " + $mat['cam'] + ", slSetConstants cache " + $mat['cur'] + "/" + $mat['prev'] + ", updates " + $mat['upd'] + ")")
    foreach ($m in [regex]::Matches($t, 'latewarp-mat row: (\w+) ([^\r\n]+)')) {
        Write-Host ("     value row " + $m.Groups[1].Value.PadRight(5) + ": " + $m.Groups[2].Value.Trim())
    }
} else {
    Write-Host "     (no latewarp-mat line -- the self-create branch never reached its matrix step)"
}

# --- the NGX CORE OWN ERROR ORACLE ----------------------------------------------------------
# When a mandatory parameter is missing the core says so by NAME. That name is the fix list, so
# print it instead of only the 0xBAD0xxxx code.
$missing = @{}
foreach ($m in [regex]::Matches($t, 'could not find ([A-Za-z0-9_.]+) parameter')) {
    $k = $m.Groups[1].Value
    if ($missing.ContainsKey($k)) { $missing[$k]++ } else { $missing[$k] = 1 }
}
Write-Host "  -- NGX core: missing-parameter oracle --"
if ($missing.Count -eq 0) { Write-Host "     (the core never reported a missing parameter)" }
else {
    foreach ($k in ($missing.Keys | Sort-Object)) { Write-Host ("     MISSING " + $k.PadRight(40) + " x" + $missing[$k]) }
}

Write-Host ""
if ($noInit)        { Write-Host "  => VERDICT: CORE_UNAVAILABLE (see the latewarp: error lines above)"; exit 10 }
if ($wlViol -gt 0)  { Write-Host "  => VERDICT: WHITELIST_VIOLATION (a key outside the 43-key list was attempted)"; exit 11 }
if ($interceptNull) { Write-Host "  => VERDICT: INTERCEPT_BAD_PARAMS (the intercept was handed a null parameter object)"; exit 18 }
if ($interceptBad)  { Write-Host "  => VERDICT: INTERCEPT_INCOMPLETE (fewer than 2 of the decisive keys were accepted)"; exit 19 }
if ($createBad)     { Write-Host "  => VERDICT: CREATE_FAILED (CreateFeature(featureId=15) returned 0xBAD0xxxx)"; exit 12 }
if ($evalBad -gt 0) {
    if ($missing.Count -gt 0) {
        Write-Host ("  => VERDICT: EVAL_ERROR (the NGX core could not find: " + (($missing.Keys | Sort-Object) -join ', ') + ")")
        Write-Host "     every name here is a parameter this integration still has to supply -- that is the fix list."
    } else {
        Write-Host "  => VERDICT: EVAL_ERROR (EvaluateFeature returned 0xBAD0xxxx)"
    }
    exit 13
}

# branch 1: we rewrote the application's own feature 15 and nothing errored.
if ($interceptOk -gt 0) {
    Write-Host "  => VERDICT: INTERCEPT_ACTIVE"
    Write-Host ("     the 2 decisive keys were asserted on the application's own feature 15 " + $interceptOk + " time(s),")
    Write-Host "     with no 0xBAD0xxxx and no whitelist refusals."
    if ($createTry) { Write-Host "     (the self-create branch also ran in this process -- see the eval lines)" }
    Write-Host "     NOTE: this proves the REWRITE is live. Whether the frame is now a real warp instead of"
    Write-Host "     a bit-exact copy can only be judged from the picture (or by comparing frames)."
    exit 0
}

if (-not $createTry) {
    if ($appF15) {
        Write-Host "  => VERDICT: NO_LATEWARP_LINES (OptiScaler did forward feature 15, but the intercept never"
        Write-Host "     logged -- check that [Latewarp] Rewrite=true is set and that this build is the patched one)"
        exit 14
    }
    Write-Host "  => VERDICT: NO_LATEWARP_LINES (this app never created feature 15 and the self-create branch"
    Write-Host "     did not run either. For a game that never creates it, use branch 2: set FG Output ="
    Write-Host "     Reprojection and tick 'Use NVIDIA latewarp (Reflex 2)')"
    exit 14
}
if (-not $created)  { Write-Host "  => VERDICT: CREATE_INCOMPLETE (create attempted but no success line)"; exit 15 }
if (-not $anyEval)  { Write-Host "  => VERDICT: NO_EVALUATION (created but never evaluated)"; exit 16 }
if ($evalBad2)      { Write-Host "  => VERDICT: EVAL_BEFORE_INIT"; exit 17 }
if ($matBad) {
    Write-Host "  => VERDICT: MATRIX_INPUTS_MISSING (the feature was evaluated but one of the four matrices"
    Write-Host "     was never bound -- the flags above name which source was empty: world->view = FG camera"
    Write-Host "     basis, view->clip = the slSetConstants cache)"
    exit 20
}
Write-Host "  => VERDICT: QUALIFIED"
Write-Host "     feature 15 was created and evaluated, no NGX error codes, no whitelist refusals."
Write-Host "     Next: check the plane probe above -- 'SUPPLIED' means that plane came from the game."
exit 0
