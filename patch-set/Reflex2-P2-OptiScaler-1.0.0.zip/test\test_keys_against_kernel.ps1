# ---------------------------------------------------------------------------
#  test_keys_against_kernel.ps1 -- the 43-key whitelist, checked against the KERNEL ITSELF.
#
#  Why this test exists: LatewarpParams_test.cpp proves "embedded table == spec\LATEWARP_KEYS.tsv",
#  which is SELF-consistency -- both sides descend from the same RE notes. NGX silently IGNORES an
#  unknown parameter name, so a single typo in a key would fail at runtime with no diagnostic at
#  all. This test compares the table against the literal strings inside the real feature DLL, in
#  BOTH directions.
#
#  LESSON BAKED IN (found the hard way): a file called nvngx.dll on this machine is NOT necessarily
#  the NGX core. bin\nvngx.dll is 221 KB with no version info and carries our INPUT key names -- it
#  is a proxy/shim. Treating it as kernel truth produced a false FAIL. So every auto-detected
#  candidate is validated as a real core (product NGX + plausible size) before it is used, and
#  anything that fails that test is reported as INFO only.
#
#  The feature DLL is the authority for the 43 write keys. Nothing is copied or redistributed:
#  this only reads strings from files that already exist on this machine.
#  No feature DLL found => SKIP, because the deliverable must work without one.
#
#  usage: .\test_keys_against_kernel.ps1 [-FeatureDll <path>] [-CoreDll <path>] [-SearchRoots <dirs>]
# ---------------------------------------------------------------------------
param(
    [string]$FeatureDll = '',
    [string]$CoreDll = '',
    [string[]]$SearchRoots = @()
)
$ErrorActionPreference = 'Stop'
$P2   = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Repo = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $P2))
$Tsv  = Join-Path (Split-Path -Parent $P2) 'spec\LATEWARP_KEYS.tsv'
$fails = 0
function Check([string]$n, [bool]$ok, [string]$d) {
    if ($ok) { Write-Host ("  [PASS] " + $n + "  " + $d) }
    else { Write-Host ("  [FAIL] " + $n + "  " + $d) -ForegroundColor Red; $script:fails++ }
}
function Info([string]$m) { Write-Host ("  [INFO] " + $m) -ForegroundColor DarkGray }
function Get-LatewarpStrings([string]$path) {
    $b = [System.IO.File]::ReadAllBytes($path)
    $t = [System.Text.Encoding]::ASCII.GetString($b)
    return @([regex]::Matches($t, 'Latewarp\.[A-Za-z0-9_.]+') | ForEach-Object { $_.Value } | Sort-Object -Unique)
}
function Test-RealCore([string]$path) {
    $f = Get-Item -LiteralPath $path
    $prod = '' + $f.VersionInfo.ProductName
    $ok = ($prod -match 'NGX') -and ($f.Length -gt 500000)
    return @{ ok = $ok; size = $f.Length; ver = ('' + $f.VersionInfo.FileVersion); prod = $prod }
}
function Find-Feature([string]$extra) {
    $c = @()
    if ($extra) { $c += $extra }
    $c += @((Join-Path $Repo 'bin\nvngx_latewarp.dll'), (Join-Path $Repo '_re\demo_re\harness\ctrl2\nvngx_latewarp.dll'))
    foreach ($x in $c) { if ($x -and (Test-Path -LiteralPath $x)) { return (Resolve-Path -LiteralPath $x).Path } }
    return ''
}

if (-not $FeatureDll) { $FeatureDll = Find-Feature '' }

Write-Host "=== key table vs the real kernel ==="

# ---- checks that need no DLL at all ---------------------------------------
$table = @(Get-Content -LiteralPath $Tsv -Encoding UTF8 |
           Where-Object { $_ -match '\S' -and $_ -notmatch '^\s*#' } |
           ForEach-Object { ($_ -split [char]9)[1].Trim() } |
           Where-Object { $_ -match '^Latewarp\.' })
Check "table parsed from spec\LATEWARP_KEYS.tsv" ($table.Count -eq 43) ("rows=" + $table.Count)

# capability/query keys live in the CORE and must never enter the write whitelist
$capability = @('Latewarp.Available','Latewarp.FeatureInitResult','Latewarp.MinDriverVersionMajor','Latewarp.MinDriverVersionMinor','Latewarp.NeedsUpdatedDriver')
$leak = @($capability | Where-Object { $table -contains $_ })
Check "no capability/query key in the WRITE whitelist" ($leak.Count -eq 0) $(if ($leak.Count) { "leaked: " + ($leak -join ', ') } else { "0 of " + $capability.Count })

if (-not $FeatureDll) {
    Write-Host "  [SKIP] no nvngx_latewarp.dll found -- the literal cross-check needs the user-supplied DLL."
    Write-Host "         Pass -FeatureDll <path>; the installer performs the same search at install time."
    Write-Host ("=== SKIP (0 failure(s)) ===")
    exit 0
}

# ---- the decisive cross-check: the feature DLL is the authority -----------
$kernel = Get-LatewarpStrings $FeatureDll
Info ("authority: " + $FeatureDll + " (" + (Get-Item -LiteralPath $FeatureDll).Length + " bytes)")
Check "feature DLL carries exactly 43 Latewarp.* literals" ($kernel.Count -eq 43) ("count=" + $kernel.Count)

$missing = @($table | Where-Object { $kernel -notcontains $_ })
Check "EVERY key we write exists in the kernel (no typo, no silent ignore)" ($missing.Count -eq 0) $(if ($missing.Count) { "NOT IN DLL: " + ($missing -join ', ') } else { "43/43" })

$extra = @($kernel | Where-Object { $table -notcontains $_ })
Check "EVERY kernel key is known to us (no coverage gap)" ($extra.Count -eq 0) $(if ($extra.Count) { "UNKNOWN TO US: " + ($extra -join ', ') } else { "43/43" })

# ---- candidate cores: validate before believing --------------------------
if ($CoreDll) { $cands = @($CoreDll) } else {
    $cands = @((Join-Path $Repo '_re\demo_re\harness\ctrl2\nvngx.dll'), (Join-Path $Repo 'bin\nvngx.dll'))
}
$sawRealCore = $false
foreach ($c in $cands) {
    if (-not (Test-Path -LiteralPath $c)) { Info ("core candidate absent: " + $c); continue }
    $v = Test-RealCore $c
    $names = Get-LatewarpStrings $c
    if (-not $v.ok) {
        Info ("NOT a real NGX core, ignored as truth: " + $c + " (size=" + $v.size + " ver='" + $v.ver + "' prod='" + $v.prod + "', " + $names.Count + " Latewarp.* names)")
        $odd = @($names | Where-Object { ($table -notcontains $_) -and ($capability -notcontains $_) })
        if ($odd.Count) { Info ("  names there that are neither ours nor capability keys (proxy-side, not kernel truth): " + ($odd -join ', ')) }
        continue
    }
    $sawRealCore = $true
    Info ("real core: " + $c + " (size=" + $v.size + " ver=" + $v.ver + ") exposes " + $names.Count + " Latewarp.* names")
    $d = @(Compare-Object $names ($capability | Sort-Object))
    Check "real core exposes exactly the 5 capability keys" ($d.Count -eq 0) ($names -join ', ')
}
if (-not $sawRealCore) { Info "no validated real core found -- capability-key claim rests on the write-table invariant above" }

Write-Host ("=== " + $(if ($script:fails -eq 0) { 'PASS' } else { 'FAIL' }) + " (" + $script:fails + " failure(s)) ===")
exit $(if ($script:fails -eq 0) { 0 } else { 1 })
