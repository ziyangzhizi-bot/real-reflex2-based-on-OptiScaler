# P2 DESIGN — 接入契约 (P2-S2 前置)

> ## 已被取代 —— 当前设计请看 `README.md` / `DESIGN_B1.md` / `HANDOFF.md`
>
> 这份文档是 **S2 骨架期**写的, 描述的是**已被否决**的接入方式: 把 `Latewarp` 加进 `Upscaler` 枚举、
> 走 `FeatureProvider_Dx12` 的超分后端。实机报 `init failed with Latewarp (Reflex 2) feature` ——
> 因为那条路要求后端产出**超分图像**, 而 latewarp 是**重投影**。
>
> | 文档 | 现在的权威内容 |
> |---|---|
> | `README.md` | 总览 + 部署配方 + **当前触点表(20 处补丁 / 10 文件)** + 已知未验证项 |
> | `DESIGN_B1.md` | 策略规格: 为什么接在特征层/重投影层, FG 层给了哪些输入, NGX 参数对象怎么拿 |
> | `../HANDOFF.md` §11 | 冷启动入口(§11.9.x 记录了历次关键实测与更正) |
>
> 下面 **第 1 节的"四个触点" 与第 5 节的"待写文件清单"只作历史记录**, 不要照着做;
> 第 2 节的接口签名仍有参考价值(自建路仍然实现 Init/Evaluate)。

> 本文件是"照它写代码就能编译"的契约。每条带 `文件:行号`。
> 应用目标 = **`_re\repro_src`**(构建工作区), **不是**交付的源码树 ⇒ 满足 INV-P4。

## 1. 四个触点(全部已定位)

| # | 触点 | 位置 | 改法 |
|---|---|---|---|
| T1 | 后端枚举 | `OptiScaler\OptiTypes.h:44` `enum class Upscaler { XeSS, XeSS_on12, FSR21, FSR21_on12, FSR22, FSR22_on12, FSR31, FFX, FFX_on12, DLSS, DLSSD, Reset }` | 在 **`Reset` 之前**插入 `Latewarp,` (枚举值顺序不能动, 只能追加) |
| T2 | 后端工厂 | `upscalers\FeatureProvider_Dx12.cpp:47` `*feature = std::make_unique<DLSSFeatureDx12>(handleId, parameters);` | 加一个 `upscaler == Upscaler::Latewarp` 分支, `make_unique<LatewarpFeatureDx12>(handleId, parameters)` |
| T3 | 后端本体 | 新文件 `upscalers\latewarp\LatewarpFeature_Dx12.{h,cpp}` | 照 `upscalers\dlss\DLSSFeature_Dx12.h` 的形态 |
| T4a–d | 菜单/配置 | `OptiTypes.cpp`(显示名/`UpscalerToCode`/`CodeToUpscaler`) + `menu\menu_common.cpp` 的 `AddDx12Backends` | 加一个可选后端, **默认关** —— **S7 已完成** |

## 2. 必须实现的接口(签名已确认)

```
class FeatureProvider_Dx12 {
    static bool GetFeature(Upscaler upscaler, UINT handleId, NVSDK_NGX_Parameter* parameters,
                           std::unique_ptr<IFeature_Dx12>* feature);
    static bool ChangeFeature(Upscaler upscaler, ID3D12Device* device, ID3D12GraphicsCommandList* cmdList,
                              UINT handleId, NVSDK_NGX_Parameter* parameters,
                              ContextData<IFeature_Dx12>* contextData);
};                                            // upscalers\FeatureProvider_Dx12.h
```

`class DLSSFeatureDx12 : public DLSSFeature, public IFeature_Dx12` 覆盖:
```
bool InitInternal(ID3D12GraphicsCommandList* InCommandList, NVSDK_NGX_Parameter* InParameters) override;
bool EvaluateInternal(ID3D12GraphicsCommandList* InCommandList, NVSDK_NGX_Parameter* InParameters) override;
feature_version Version() override;
Upscaler GetUpscalerType() const final;
API Api() const override;
bool IsWithDx12() override;
static void Shutdown(ID3D12Device* InDevice);
ctor(unsigned int InHandleId, NVSDK_NGX_Parameter* InParameters);
```
`IFeature` 纯虚(`upscalers\IFeature.h:115-118`): `IsWithDx12()` / `Version()` / `GetUpscalerType() const` / `Api() const`;
基类已提供: `HasColor/HasDepth/HasMV`(L144-146)、`RenderWidth/Height`(L133-134)、`DisplayWidth/Height`(L129-130)、
`TargetWidth/Height`(L131-132)、`JitterCount()`(L124)、`DepthLinear()`/`DepthInverted()`(L153/L156)、`IsInited()`(L137)。

## 3. 骨架阶段(S2)的最小目标 = "编译通过 + 默认关时行为不变"

* `LatewarpFeature_Dx12::InitInternal` / `EvaluateInternal` 先只 `LOG_TRACE` + `return false`(**不改变任何行为**);
* 菜单项默认关; 关闭时**不进入** `GetFeature` 的 Latewarp 分支;
* 验证 = `_re\optiscaler_verify\repro_build2.ps1` 增量编译成功并产出新的 `OptiScaler.dll`。

## 4. 后续步骤要用到的现成数据(来自 S1)

* 无 UI 帧: `hudfix\Hudfix_Dx12.cpp` 的 `_captureBuffer`(交换链尺寸, 捕获后为 SRV 状态)
* 相机/jitter: `hooks\Streamline_Hooks.cpp:1044 hkslSetConstants(const sl::Constants&, ...)`;
  字段见 `_re\probe\sdk\sl\sl_consts.h`(`cameraViewToClip` L188 / `clipToPrevClip` L196 / `jitterOffset` L202 …)
* 输出通道: `shaders\reproject\Reproject_Dx12.h:57 Dispatch(..., hudless, state, depth, depthState)`
* 参数对象取平面句柄的既有惯例: `framegen\nvngx\Nvngx_FFX.cpp:256 InParameters->Get("DLSSG.MVecs", &motionVectors)`

## 5. 待写文件的清单(S2 产出)

```
p2\files\upscalers\latewarp\LatewarpFeature.h
p2\files\upscalers\latewarp\LatewarpFeature_Dx12.h
p2\files\upscalers\latewarp\LatewarpFeature_Dx12.cpp
p2\files\upscalers\latewarp\*.{h,cpp}      (8 个新文件, 按同样相对路径摆放)
p2\apply_to_optiscaler.ps1                   (13 个锚定补丁, 见 README 的 T1..T7; 无 patches\ 目录)
p2\apply_to_optiscaler.ps1                   (默认目标 _re\repro_src; -DryRun; 记录 diff 清单)
p2\README.md
```
`apply_to_optiscaler.ps1` 要求: ① `-DryRun` 只打印; ② 应用前备份被改文件; ③ 产出 `p2\APPLIED_DIFF.txt`(逐改动清单);
④ 可 `-Revert` 按备份还原; ⑤ 绝不碰交付的源码树(除非显式 `-Tree` 指定)。
