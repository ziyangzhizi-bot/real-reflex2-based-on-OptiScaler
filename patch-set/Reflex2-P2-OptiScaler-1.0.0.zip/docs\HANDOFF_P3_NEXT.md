# 交接文档 —— P2(latewarp 自建路)已完成, P3(抗瑕疵)待做

写作时间: 2026-09-27。读者: **上下文被压缩后的下一个我**。目标仍处于 `paused`(见 §5.1)。

---

## 0. 一句话现状

`latewarp`(NGX feature 15)已经**在赛博朋克 2077 里真的出画**: 自建 `CreateFeature(15)` 成功、每帧
`latewarp: eval #N`、面板开关可控、UI/静态元件用内核原生 **`NoWarpMask`** 排除变形、蓝噪声量化遮罩。
验收判据(日志出现 `latewarp: eval #N` 而不再是 `0xBAD00005`)已达成并通过采集器 `VERDICT: QUALIFIED`。
剩下的都是**画质与跟手性**(P3)。

---

## 1. 已装机的精确状态(交付物)

| 项 | 值 |
|---|---|
| 游戏目录 | `E:\SteamLibrary\steamapps\common\Cyberpunk 2077\bin\x64` |
| 注入名 | `dxgi.dll`(我们的 OptiScaler 构建) |
| 装机 `dxgi.dll` sha256 | `735C61C8607319A8EB9D602AB97B9A5D1BD5588FCE9D546F222F003BCC7B8369` (第 56 轮 P3-1 构建, installed==built) |
| 随附 | `nvngx.dll`(能力内核 1,411,224 B) + `nvngx_latewarp.dll`(特征 DLL 907,296 B) 由**使用者自备**, 不入包 |
| ini 关键项 | `[FrameGen] Enabled=true / FGOutput=Reprojection / FGInput=DLSSG / FGNvngxReplacement=None`; `[Latewarp] Rewrite=true`; `[Reprojection] UseNvidiaLatewarp=true` |
| 补丁集 | **39 处 / 10 个文件 / 16 个新增文件**(`p2\apply_to_optiscaler.ps1`) |
| 离线回归 | `p2\test\test_offline_warp.ps1` 8 例(真内核 + 真抓帧, 含负对照与 NoWarpMask 极性) |
| 门禁 | `p2\verify_p2.ps1 -Full` = PASS(39 标记 + L3.5 孪生 + 4 套测试 + 构建 `msbuild exit=0`); `p2\make_patch_review.ps1` = PASS(0 失败, 8 改 + 16 增) |
| 交付包 | **48** 文件, 无任何 NVIDIA 二进制 |
| 本包 sha256 | 记录在 `LOG.md`(第 56 轮)与 `HANDOFF.md` §11.21 —— **故意不写进包内文档**: 包内的 `docs\HANDOFF_P3_NEXT.md` 自己也是包的一部分, 把包的 sha 写进去就永远对不上(重打包即失效) |
| ini 关键项(P3-1) | `[Latewarp] EdgeFillPx` **默认缺省 = 0(关)**; 面板滑条 `latewarp edge fill (px)` 会写这个键 |

重装/回滚一条命令(见 §3)。

---

## 2. 已验证的关键事实(带出处, **不要重推**)

### 2.1 latewarp 的必填输入(靠这些才从 0xBAD00005 变成 eval #N)

1. **四个矩阵**: `Latewarp.WorldToViewMatrix` / `ViewToClipMatrix` / `PrevRenderedWorldToViewMatrix` /
   `PrevRenderedViewToClipMatrix`。缺任何一个, 内核自己会打
   `NGXLatewarp::EvaluateFeature:589 error: could not find <KEY> parameter` => `0xBAD00005`(实测 7792 次)。
   布局 = 行主序 `XMMatrixLookAtLH` 语义: `row0/1/2` 是相机基向量的**列**, `row3 = -dot(basis,pos),1`;
   用两份真实抓取回归(camrun `maxErr=0` / `frame_4042` `maxErr=6e-6`)。
   来源: FG 层 `_cameraPosition/Up/Right/Forward[fIndex]` + 上一索引(`p2::BuildWorldToView`),
   以及 `slSetConstants` 缓存的 clip 矩阵(`p2::GetFrameData`)。
   **指针生存期**: 内核**稍后才解引用**, 所以矩阵放在 `p2::MatrixRing`(5 槽, 与游戏 stride 0x100 同构),
   绝不能用栈上数组。
2. **`Latewarp.NoWarpMask`(R8 平面 + Subrect)**: **非 0 = 该像素不要扭**。
   离线实测(台架 `fwtest --maskval`): 未绑 => 81.09% 像素变化; 全 0 => 81.09%(无效果); **128 / 255 => 逐位一致(0.000000%)**。
   这是我们"武器/UI 不被扭"的实现基础, 比事后合成正确。
3. **两个决定键**: `Latewarp.IsRenderedFrame=0`、`Latewarp.UIColorAlpha=nullptr`(P1 实测 0.000000% -> 81.0888%)。
4. **可缺项**: `MotionVectors` 缺席时内核仍 `Success`(台架 `--mvnull`), 所以缺 MV 不阻塞(缺席即不绑键)。
5. **`*.Subrect.*` 不必填**(台架 `--nosubrect` 仍 Success), 但用 `NoWarpMask` 平面时必须给它的 4 个 Subrect。
6. **输出平面**: 内核接受**交换链格式 24**(`--outfmt r10g10b10a2` Success), 我们用**跟后台缓冲同 desc** 的中间纹理,
   这样 `CopyResource` 拷回合法且画面可见(87 的纹理拷进 24 的后台缓冲是**非法调用**, 踩过)。
7. **蓝噪声**: `_re\bluenoise32\bluenoise32.bin`(已验收, sigma 2.5/seed 4) -> 按字节嵌入
   `p2\files\shaders\latewarp\LatewarpBlueNoise32.h`, 用来把软遮罩量化成 1 bit(避免边界双曝光)。

### 2.2 我们这条路的两个开关(容易搞错)

* **armed**(`[Reprojection] UseNvidiaLatewarp`, 面板勾选框/ini, 默认 false)与 **started**(`p2::SetRuntimeEnabled`,
  **默认 STOPPED**)是两个状态; 面板里 `latewarp takeover: running` 这个**复选框**是主要控制(使用者要求"坐进面板",
  **不要**再默认热键: 曾把默认热键设成 F9, 而 OptiScaler 的热键**不吞键**, F9 传到游戏触发读档, 使用者被顶回存档)。
  热键 `[Latewarp] ShortcutKey` 现在默认 `UnboundKey`, 想绑自己在 Keybinds 里绑。
* **热键不碰 ini 开关**: 一关 ini 开关会放出内置 `Reproject_Dx12` 路径, 而那条路在本机是**坏的**
  (`Failed to create a constants buffer` -> `DXGI_ERROR_INVALID_CALL` -> 设备移除 -> 闪退, 实测 2026-09-27 15:38)。

### 2.3 其它踩过的坑(别再踩)

* **黑帧教训**: 只有本帧 `Evaluate` 成功才允许把 warp 纹理拷回后台缓冲。无条件拷**未写过的**纹理 = 全黑
  (Route A 的原话: 不要让未验证的 pass 独占上屏)。代码里用 `lwEvaluated` / `lwComposited` 门控。
* **HudCopy 不能用来做我们的合成**: 它的遮罩是 `|hudless - present|` 且它的 `hudless` 是"被加 UI 的基准帧";
  把**被扭过的帧**当 hudless 喂进去 => 差异处处很大 => mask 全 1 => 输出 = 原帧 => "看不出区别"。
* **内置 `Reproject_Dx12` 是坏的**(见上), 不要为了对比去打开它。
* `Select-Object -First N` 会**掐断** PowerShell 脚本的输出管道并让它提前结束(安装器被它坑过)。
* 台架 `fwtest` 在 `--outfmt r10g10b10a2` 下 dump 阶段会 0xC0000005 崩(它自己不解 24 位), **与内核无关**;
  所以测试读它的 `fwtest.<tag>.log`, 不要依赖 stdout。
* **cbuffer 打包(第 56 轮发现并修好)**: HLSL 里**数组必须从 16 字节边界开始**, C++ 结构体按成员自然对齐。
  `InternalLatewarpUiParams` 原本 7 个 float(28 B)后接 `BlueNoiseWords[256]` => HLSL 从 **32** 读、C++ 写在 **28**,
  蓝噪声表被错位 4 字节读取(仍是噪声, 所以一直没人看出来)。P3-1 加第 8 个 float 后两边都落在 32, 顺带修好。
  新增门禁 `L3.5` 会逐行比对 `.hlsl` 与运行期孪生, 防止再次漂移。

---

## 3. 常备命令(全部在 `<repo>\_re\reflex2_mod\p2\`)

```powershell
# 应用/还原补丁(默认目标是 _re\repro_src 构建工作区)<p>
.\apply_to_optiscaler.ps1            # 应用; -Action Revert 还原; -DryRun 预览

# 唯一可信的构建判据
.\build_verify.ps1                   # 必须 msbuild exit=0 且 DLL 被重写

# 门禁(四套测试 + offline warp + 回滚往返 + 构建)
.\verify_p2.ps1 -Full

# 装机 / 卸载(逐字节还原)
.\install_p2_into_game.ps1 -GameDir "E:\SteamLibrary\steamapps\common\Cyberpunk 2077\bin\x64" -ProxyName dxgi.dll
.\install_p2_into_game.ps1 -GameDir "...\bin\x64" -Uninstall

# 读一次实机日志的裁定(一条命令)
.\collect_p2_run.ps1 -Log "E:\SteamLibrary\steamapps\common\Cyberpunk 2077\bin\x64\OptiScaler.log"

# 离线内核验收(真特征 DLL + 真抓帧; 需要使用者自备的二进制, 打包内会 SKIP)
.\test\test_offline_warp.ps1

# 离线台架(_re\demo_re\harness): --nomats / --nosubrect / --maskval N / --outfmt r10g10b10a2 ...
```

---

## 4. P3 待办(按性价比; 每项都独立, 一次只动一个变量)

### P3-4b-1 "超渲染裁切"旋钮 + 小余量试验(**可以先做; 不需要方向符号, 但需要使用者抬高游戏 FOV**)
* **原理**(详见 `DESIGN_P3_reflex2_artifacts.md` §0.3): 让游戏以更宽视锥渲染, 我们在 Present 把中央**裁回原取景**并放大
  => 四边多出一圈**真内容**(`m` 度余量), 迎向侧空洞被真内容填掉。**不裁 = 没用**(只是把洞推到新边缘)。
* **量化**: 显示空洞 ≈ **(`delta` - `m`) x (H/FOV_narrow)**; 代价 = 余量占比的线性糊化。现实区间 **2~5%**。
* **落地**: composite 里只给**世界类**图层(warpped base + 深度切出的武器)加中心裁切放大(`CropScale` 默认 1.0 = 关),
  **屏幕空间 UI/HUD 保持原坐标**(用现有差异遮罩叠加), 否则 HUD 会被放大/裁掉。
* **试验协议**: 使用者在游戏里把 FOV 抬 ~5%(记下数值), 面板把 `CropScale` 设成对应的比例 => 取景应与之前几乎一致, 看边缘撕裂是否消失。
* **加强版(需要 P3-DIR)**: 把裁切窗口**朝迎向侧平移**(不是四边均摊) => 同样余量只花一半 FOV 代价 = 参考的"自适应渲染窗口"。

### P3-5 参数对齐 —— **已全部实现(5a 第 60 轮 / 5b 第 61 轮)**
* **5a(已做)**: 白名单新增两个 **NGX 通用键** `Jitter.Offset.X/Y`(`ExtraKeyCount()==2`, 与 `Depth/MotionVectors/Output` 同类:
  特征 DLL 里**确实有**这两个字面量), `Fill` 显式写出它们 + `Latewarp.EvalFlags=0`; 值**默认 0 = 行为不变**;
  单测新增 5 条断言(含"带前缀的 `Latewarp.Jitter.Offset.X` 仍被拒绝")。**写入键数 20 -> 23**(下次实机日志的判据)。
* **⚠️ 更正**: `Latewarp.Reserved1` **不要加** —— 实测特征 DLL 里**没有**这个字面量, 加了会被 L7 门禁判"内核不认识"。
  官方样例写它, 是因为它的 core 版本不同/该键会被静默忽略。
* **5b(已做)**: `hkslSetConstants` 里同时缓存 `values.jitterOffset`(`sl_consts.h:196`); `FrameData` 新增 `jitter/prevJitter`, **轮转由 `SetStreamlineViewToClip` 拥有**(同一个钩子、同一帧, 不会各转各的); T21 取 **`prevJitter`**(= 内核要重投影的那一帧的抖动)交给内核, 并一次性日志 `latewarp-jitter: cur/prev/frame`。
  (注意: `IFGFeature::SetJitter` 在本树里**没人调用**, 所以不能直接读 `_jitterX` —— 那会永远是 0。)
* 官方样例显式写 49 键; 我们**完全没写**的是 `Jitter.Offset.X/Y`(不在白名单) —— 宿主有 TAA/DLSS 抖动,
  不把它交给内核就是**亚像素级**误差; (关于 `Reserved1` 见下面的更正 —— **不加**)。
* 已核对**无需改**: `DepthInverted=1` / `UsePremultiplyUIAlpha=1` 靠 `Inputs` 默认值就一致;
  `EvalFlags` 默认 0; 官方写全 7 组 subrect, 我们只写 mask 那组 = **更安全**(不去动别人的值)。
* 做法: 白名单 + 写入 + 单测(用 `ISink` 记录), 一次一个键。

### P3-4b 已定界(第 59 轮, **有出处**)
* demo 的渲染扩张 = 引擎侧 `EnableBorderFix`: render target 比**有效 viewport** 大 + `BlitTexture` 只呈现有效区 +
  用 `TagResources_Latewarp/DLSS_FG` 把 `validViewportExtent/backBufferExtent` 告诉 Streamline(内核知道哪块是边框)。
  切换它要**重建 pass** => 这是**纯引擎侧**的事; 我们宿主只有"游戏侧抬 FOV/分辨率 + 我们裁切"这一条, 且要付 2x 余量。
  详见 `DESIGN_P3_reflex2_artifacts.md §0.4` 与 `_re\demo_re\FRAMEWARP_demo_拆解.md`。
### P3-DIR 方向测量 —— **已完成(第 62 轮), 已进门禁**
* **为什么必须先做**: 我们只有"能跑、看起来变好", 从没实测过**内核把哪一组矩阵当目标 / 位移朝哪一边 / 多少像素**。
  它决定 P3-1b 该让哪一边、P3-0a 外推放进哪个矩阵槽(反了 = 反向扭, 会晕)。
* **怎么做**: 台架 `_re\demo_re\harness\fwtest` 喂**一对已知矩阵** + 一张有已知特征的图, 量出输出的位移方向与像素数,
  与 `pixelAngle = 2*atan(tanHalfFovY/resY)`(或已知矩阵差反算)对账; 正负两组各一次即可定性+定量。
* **验收(已达成)**: `test\test_offline_warp.ps1` E) 段 5 条断言全绿(见下)。
* **结论(下游全部依赖它, 已由台架实测 + 进门禁)**: 保留 demo 的真实投影, 只让相机偏航已知角度, 1.0 度下:
  +1 度偏航 => 输出比输入**左移 16 px**(预测 `f*tan(theta)=16.34`)、-1 度 => 右移 16 px、**交换槽位等价于反号**、相同矩阵对 => 逐位直通。
  1. 输入帧被当作**在 `PrevRenderedWorldToView` 姿态渲染**的, 向前 warp 到 **`WorldToView`** ⇒ T21 的配对就是契约的配对 ✓;
  2. 内容朝**转向反方向**移动 ⇒ **空洞在迎向侧**(右转 => 右边);
  3. 中心位移 = `f*tan(delta_theta)`, 且随 |x| 增大(纯偏航≠全局平移) ⇒ P3-1b 带宽按 `delta_theta` 换算,
     P3-0a 的外推放进 **`WorldToView`** 槽。
* 工具: `_re\demo_re\harness\p3dir_make.py`(造已知偏航矩阵对, 每行一个矩阵) + `p3dir_shift.py`(全图位移搜索)。

### P3-0a 输入驱动的姿态外推(跟手性; 使用者最关心)
* **为什么**: 我们喂内核的四个矩阵全来自游戏 Streamline 常数 = **渲染帧率**姿态, 所以镜头响应上限 = 渲染帧率。
  参考实现(demo)的做法是**在 Present 时刻用"模拟之后新产生的输入"外推姿态**, 响应跟着输入采样率走。
  注意: **单纯把 Present 跑更快没有意义**(姿态只在游戏更新时才变)。
* **零件现成**: `InputCollection::getInstance().readDelta(_frameCount)`(热路径 193 行已在读, 只用于日志);
  `Reprojection_Dx12::_calibration` + 学习代码(同文件 700-732); 相机 yaw/pitch 增量计算(505-530);
  旋转合成方式(541-583)。**我们绕过了内置路, 所以 `_calibration` 不会自己更新, 必须我们喂。**
* **落点**: `apply_to_optiscaler.ps1` 里 T21 的 heredoc(在组完 `lwW2V` 之后): 算 `camYaw/PitchDelta` ->
  `_calibration.Update(...)`; 用 `readDelta` + `pixelAngle = 2*atan(tanHalfFovY/resY)` 算外推 `yaw/pitch`;
  乘进 `lwW2V`(**`prevWorldToView` 保持游戏上一帧姿态** -> 内核变形的差值里就含这一段转动)。
* **风险**: 旋转符号/方向错了会**反向扭**(晕)。先一次性日志 `latewarp-pose: yaw/pitch deg (calib ...)`,
  增益做成配置项**默认 0 = 与现状完全一致**, 确认方向后再给默认值。

### P3-1 / P3-1b 边缘撕裂回填 —— **最终形态已实现(第 63 轮): 只填迎向侧, 宽度按该帧自身位移**
* **为什么形状错**: 现在四边一圈同宽。镜头右转 => 内容左移 => **空洞只在迎向侧(右)**; 背向侧(左)本来就有源内容,
  在那里回填等于把正确的 warp 结果换成旧姿态像素(差 d 像素的重复条) => **有害**。
  正解(下面 §4 的 P3-1b): **只让迎向侧 + 宽度 = 该帧角位移对应像素数**(位移可由两帧相机矩阵 + `pixelAngle = 2*atan(tanHalfFovY/resY)` 算出)。
  迎向侧的诚实定位 = **clamp/拉伸的替代品**(拿最新一帧真像素盖住内核的旧残留), **不产生信息**。
* 参考手段是"静止时大 FOV 低分辨率周期采集背景", 那是**额外渲染一帧**, 我们没有这个钩子。
* 等价的轻量做法(**已落地**): 我们本来就持有当前帧的 `present` 拷贝(`LatewarpUi._buffer`), 那里面**就是**
  被露出来的真实内容(姿态比目标旧一点点), 于是 `LatewarpUi.hlsl` 里
  `edgeFill = saturate(1 - 到最近屏幕边的像素距离 / EdgeFillPx)`,
  `color = lerp(warped, present, max(uiMask, edgeFill))`。
  `edgeFill` **故意不做 1-bit 抖动**: 两边是同一场景的两种姿态, 硬切换会看成"一条移动的线", 软过渡才是对的
  (这与武器遮罩必须量化正好相反)。
* **旋钮(语义已变, 第 63 轮)**: `[Latewarp] EdgeFillPx` 现在 = **迎向侧带宽的倍率**(0..3, 默认 0 = 关), 面板行 `latewarp lead fill (x)`; 旧的"四边同宽像素数"行为已取消。
  **默认 0 = 与加这个功能之前的版本逐位一致**; 打开 `Show static elements` 时该带画成**青色**(品红仍是内核遮罩)。
* **注意**: 边缘带**不进** `NoWarpMask`("非 0 = 不要扭")。让内核照常扭、我们再用真帧覆盖即可,
  否则白白损失边缘那一圈的变形覆盖。
* **首次试机建议**: 先设 **1.0**(= 恰好等于实测空洞宽度) 再看 **1.5 / 2.0**(略过一点); 一次性日志 `latewarp-lead-fill: gain ... -> L/R/T/B ... px` 会打印每帧算出的四侧宽度。
* 落点(改的时候三处必须同步, 否则跑的不是你改的那份): `p2\files\shaders\latewarp\LatewarpUi.hlsl`
  (用 fxc 重编 `LatewarpUi_Shader.h`) + `LatewarpUi_Common.h` 的运行期副本(门禁 L3.5 会比对) + `LatewarpUi_Dx12.*`
  的 `LatewarpUiDispatchParams`, 再由 T21/T30e 传参。
* 未做(P3-1b): 判据二"内核输出在该像素不可信"(近黑/NaN/与邻域严重不连续)。判据三"映射到画面外"拿不到变形向量, 不做。

### P3-2 武器轮廓"补洞" —— **A/B前置/C前置 已完成; 只剩 GPU 部分**
* **已完成(全部在 `upscalers\latewarp\LatewarpFrameData.*`, 零依赖 + 单测):**
  * **A**: `ReprojectClip()`(当前帧像素的 clip 位置 -> 上一帧) 与 `ClipToWorld()`; **行向量次序**
    (`vp = W2V * V2C`, 位置左乘 `RowTimesMat`)。踩过的坑: 用列向量次序会**丢掉相机平移并翻转旋转符号**。
  * **B 前置**: `BuildReprojectionMatrices()` —— 直接给着色器 `inv(VP_cur)` 与 `VP_prev`(HLSL 里不必写 4x4 求逆)。
  * **C 前置**: `UpdateBackgroundPixel()`(论文两条更新规则) 与 `BackgroundPyramid`(多层金字塔, 每层边长减半;
    `Push()` 逐层下降、更近者顶掉并把被顶掉的推下一层; `Lookup()` 从最深一层取 = **遮挡物背后的背景**)。
  * **两条客观验收(全绿)**: ①`clip -> world` = `p + 100*f_cur`; ②+1° 右转 => 源在上一帧**右侧 16.336 px**(与 P3-DIR 实测 16 px 符号一致)。
    金字塔那条: 遮挡物占第 0 层, 被遮挡的远背景在第 1 层活下来(单测实测 50.0 在最深层)。
* **只剩 GPU 部分(接口已定死)**: `LatewarpUiDispatchParams` 增 `HoleFillGain / DepthFlipY / invVPCur[16] / vpPrev[16]`;
  `LatewarpUi_Dx12` 增 history color+depth 两张(dispatch 末尾 `CopyResource` 存本帧, 下一帧当 SRV t4/t5);
  着色器: `clip = (ndcX, ndcY, depth, 1)` -> `world = mul(clip, invVPCur)` -> `clipPrev = mul(world, vpPrev)` ->
  越界 = disocclusion(可再叠一个"上一帧深度更近"的判定), 从 history 取色回填。**增益默认 0 = 零行为变化**;
  `DepthFlipY` 与深度->clip 的约定属于**接线参数**, 首次实机要用地板/天空对照确认。
* 参考: `DESIGN_P3_reflex2_artifacts.md` §0.4/§0.5 与 GFFE 论文 §4.2(`gffe_src\paper_method.tex`)。
* **区分两件事**: "低分辨率宽视野背景" 解决的是**边缘撕裂**; 武器**双影/轮廓空洞**要用他的**补洞方案**
  (持续收集武器背后的历史像素, 用于补下一帧的空缺; 他也承认回填像素有亮度差)。
* 我们现在已经用 `NoWarpMask` 让武器**不被扭**, 所以残留的是**武器轮廓处被露出的背景**(disocclusion 空洞)
  以及遮罩边界的一圈过渡。**补洞**应在此处做: 收集"曾出现在该像素上的历史颜色"(前 N 帧的合成结果),
  按有效性填充; 亮度差用局部均值匹配压一下。
* 需要新增: 1-2 张历史帧纹理 + 一份有效性/年龄通道; 落点同样是 `LatewarpUi` 那一遍(它已经持有 `present` 拷贝)。

### P3-3 与帧生成共存(使用者说"之后再考虑")
* 真正 FG(DLSSG/FSR3/XeSS)会把呈现帧率提到渲染的 N 倍, 每个呈现帧都会过我们的 Present 路;
  但我们现在 `FGOutput=Reprojection`(我们的路**替掉**了 FG 后端)。要"FG + 帧扭曲"共存, 得把 latewarp 挂到
  **FG 之后的呈现链**上, 风险更高, 排在最后。

---

## 5. 纪律与红线

### 5.1 目标状态

`goal-b6bc3412-d701-4ea7-8321-099d0948ef7d` 现在 **`paused` / `disarmed`**(第 79 轮查证)。
**模型不能自己 resume 一个 paused 目标**: 2026-09-28 实测 `update_goal action=resume` 被拒绝, 提示 “the user must resume it”。
要恢复自动续跑, 只能由使用者在 GUI 里 resume, 或重新发话。
压缩后如果使用者只说"跑完了/继续", 先 `get_goal` 看状态; 要 resume 就请他明确说一声。
要他跑游戏前，仍按老规矩让他先说一句**“暂停目标”**。

### 5.2 红线(使用者裁定过)

* **不改 OptiScaler 源码树**: 一切改动走 `p2\` 补丁集 + `apply_to_optiscaler.ps1`, 交付 diff 清单;
* **交付包内 0 个 NVIDIA 二进制**(特征 DLL 与内核由使用者自备);
* 新代码 **GPL-3**;
* **一次只改一个变量并追加日志**; 上下文紧张先更新 `_re\reflex2_mod\HANDOFF.md`;
* 反作弊游戏不注入不调试;
* 不要重复已定稿的 RE(引用 `_re\routeA\audit\*.md`、`_re\nvngx_latewarp_re\docs\*`、`spec\LATEWARP_KEYS.tsv`);
* Lead 不自己开游戏窗口: 跑游戏由使用者做, 我们读日志。

---

## 6. 下一次让使用者跑游戏时, 要问的三件事

1. `latewarp takeover: running`(面板)勾上后, **世界有没有被扭**(移动镜头观察)?
2. `Show static elements` 打开后, 品红覆盖的是不是**手臂/枪 + HUD**, 有没有把世界也染上(阈值 `Depth cutoff` 偏了)?
3. 武器周围那圈残留: 是**边缘撕裂**(屏幕边缘)还是**武器轮廓空洞**(枪背后露出的背景)? 这决定先做 P3-1 还是 P3-2。
4. 快速转镜时, 撕裂出现在**镜头转向的那一侧**吗(右转看到右边缘)? 这一条用来确认 P3-1b 的方向符号。

---

## 7. 快速定位表

| 文件 | 是什么 |
|---|---|
| `p2\apply_to_optiscaler.ps1` | 唯一真源: 34 处补丁(T21/T28/T29 在 `Reprojection_Dx12.cpp` 里是主体) |
| `p2\files\upscalers\latewarp\LatewarpFeature_Dx12.*` | 自建 feature 15 的 evaluator(CreateFeature/Evaluate) |
| `p2\files\upscalers\latewarp\LatewarpParams.*` | 43 键白名单 + Fill(两个决定键最后写) |
| `p2\files\upscalers\latewarp\LatewarpFrameData.*` | 矩阵构造 `BuildWorldToView` + `MatrixRing` + 运行时开关 |
| `p2\files\shaders\latewarp\*` | UI/静态元件合成 + NoWarpMask 生成(HLSL + fxc cso + 蓝噪声表) |
| `p2\test\test_offline_warp.ps1` | 离线内核验收(真内核, 含 NoWarpMask 极性) |
| `_re\demo_re\harness\fwtest.*` | 离线台架(`--nomats/--nosubrect/--maskval/--outfmt ...`) |
| `_re\bluenoise32\` | 已验收的蓝噪声表 + 报告 |
| `_re\nvngx_latewarp_re\docs\` | 特征 DLL 的 RE(键、ABI、Subrect 顺序) |
| `_re\routeA\audit\` | Route A 的审计(早退、格式、残差) |
| `LOG.md` / `HANDOFF.md` | 逐轮流水 / 长期交接(§11.11-§11.19 是 P2 后半段) |


## 附录 Z —— 最新状态速览（第 76 轮追加，读者优先看这一节）

### Z.1 已经做完的（全部离线可验证，门禁全绿）
1. **P3-5 参数对齐**：白名单补 `Jitter.Offset.X/Y`（NGX 通用名）+ 显式写 `Latewarp.EvalFlags`；**真实抖动**从 `slSetConstants` 的
   `values.jitterOffset` 缓存进 `FrameData`（当前/上一帧轮转），T21 取**与输入帧同帧**的 `prevJitter` 交给内核。注意：`Latewarp.Reserved1`
   **特征 DLL 里没有**，不能加（加了会被 L7 门禁判“内核不认识”）。实测写入键数 20 -> 23。
2. **P3-DIR 方向/量级（离线台架实测，已进门禁）**：+1° 偏航 => 输出比输入**左移 16 px**（预测 f*tan1°=16.34）；−1° => 右移；**交换矩阵槽位 = 反号**；
   相同矩阵对 => 逐位直通。结论：**输入帧被当作在 `PrevRenderedWorldToView` 姿态渲染，向前 warp 到 `WorldToView`**；内容朝**转向反方向**移动
   => **空洞在迎向侧**。工具：`_re\demo_re\harness\p3dir_make.py`（每行一个矩阵）+ `p3dir_shift.py`（位移搜索）。
3. **P3-1b 边缘让位**：`[Latewarp] EdgeFillPx` 语义改为**迎向侧带宽倍率**（面板 `latewarp lead fill (x)`，0..3，默认 0 = 关）；
   宽度 = 增益 × 该帧自身位移（`ComputeLeadFill`，方向由两帧相机前向算出）。旧的“四边同宽”已取消（它在背向侧有害）。
4. **P3-2 补洞**：A 段（重投影 + GFFE §4.2 两条更新规则，零依赖 + 单测）；B 段（GPU：history 纹理 + 第 5 个 SRV + 着色器越界判定回填，
   面板 `latewarp hole fill (x)`，默认 0 = 惰性）；C 段语义（多层背景金字塔：遮挡物占第 0 层、**被遮挡的背景在更深层存活**，单测实测 50.0 在最深层）。
   两条客观验收：`clip -> world` = `p + 100*f_cur`（含相机平移）；+1° 右转时源在上一帧**右侧 16.336 px**。
5. **P3-0a 姿态外推**：`BuildExtrapolatedWorldToView`（gain 0 与当前矩阵**逐位一致**；gain 1 推进到 2.000°）+ 面板 `latewarp pose gain (frames)`（0..2，默认 0）
   + T21 接线 + 一次性日志 `latewarp-pose: gain ... target fwd (...) game (...)`；退化时保留游戏姿态（绝不绑坏矩阵）。
6. **补洞判定可视化**：打开 `Show static elements` 时，把“将会回填的区域”画成**黄色**（增益 0 时只画不填）——这是确认
   “深度 -> clip 约定 / `DepthFlipY`”是否正确的那只眼睛。

### Z.2 首次实机的判据（一次性可验三件事）
* 勾 `latewarp takeover: running`；打开 **Show static elements** 看**黄带位置**：应落在**转镜露出的那一侧**。
  若上下颠倒或整体错位 => 改 `DepthFlipY`（0/1）或“深度 -> clip”的约定（在 `LatewarpUi.hlsl` 的 `clipCur` 构造处，一行）。
* `latewarp hole fill (x)` 0.5 -> 1.0：黄带是否被真实内容填上、边缘是否更干净。
* `latewarp pose gain (frames)` 1.0：跟手性是否变好、有无过冲；日志的 `target fwd` 与 `game` 两个前向向量能直接判断方向与量级。
* `latewarp lead fill (x)` 1.0 / 1.5：边缘撕裂。
* 采集裁定：`p2\collect_p2_run.ps1 -Log <game>\OptiScaler.log`。

### Z.3 还没做的（按优先级）
1. **P3-2 C 段 GPU**：把已经单测过的金字塔机制搬到 GPU（多层 color+depth，深层 1/4 分辨率；空槽占用 / 更近者顶替并把被顶掉的推下一层 /
   从最深一层取色回填），再加亮度局部匹配。**前提**：先用地板/天空对照把 Z.2 里的约定确认掉。
2. **P3-4b 超渲染裁切**：游戏侧抬 FOV（用户做）+ 我们在 Present 做中心裁切（`CropScale`，默认 1.0 = 关）；只裁**世界类**图层（warped base + 深度切出的武器），
   **屏幕空间 UI 保持原坐标**。量化：显示空洞 ≈ (delta − m)×(H/FOV)，代价是余量占比的线性糊化；demo 的 `EnableBorderFix` = 引擎侧同一件事（见 §0.3/§0.4）。

### Z.4 纪律与踩坑（照着做能省一整轮）
* 改补丁脚本：**整行锚点**（用语句结尾的 note 字符串或现成整行变量），**绝不用行首前缀**；改完先跑
  `apply_to_optiscaler.ps1 -DryRun -Tree <原始交付树>` 验证**全部锚点**，再 revert+apply。
* 运行单测要用 `& .\test\build_and_run_test.cmd`（**不能用** `powershell -File` 跑 .cmd）。
* 改着色器必须同时改**运行期孪生**（`LatewarpUi_Common.h`）并重编 cso；门禁 L3.5 会验证两者逐行一致。
* 不要用 `Get-Content/Add-Content` 读写 UTF-8 中文文档（PS 5.1 默认 ANSI 会写坏）；用 `[IO.File]::ReadAllText/WriteAllText` 加 UTF8 编码。
* 装机/卸载：`install_p2_into_game.ps1 -GameDir ... -ProxyName dxgi.dll`（`-Uninstall` 逐字节还原）；装机前必须先 `-Uninstall`。
* 构建产物哈希每次重建都会变（PE 时间戳/PDB GUID），源码未变时不必重新装机，但要保持 installed==built 的记录。
* 目标 resume/pause **必须由人类直接发话**（自动回合里调用会被工具策略拒绝）——要跑游戏前请让使用者说一句“暂停目标”。


## 附录 Z2 —— 第 78 轮更新（实机首测结果 + 一个真 bug 的修复；与 Z.1–Z.3 冲突处以本节为准）

### Z2.1 本轮修掉的一个真 bug（我引入的）
* **现象**：`latewarp pose gain` 非零 => 画面出现诡异虚像 / 像整体转了 90 度。
* **根因（有日志铁证）**：`latewarp-pose` 那行把宿主的 "Forward" 槽打成 **`(0.6397, -0.7686, -0.0009)`** —— 它**不是水平的相机前向**。
  旧实现**只用这一根槽 + 世界 up 去重建整个基底** => 重建基与真实基相差约 90 度 => 画面转了 90 度。
* **修法**：`BuildExtrapolatedWorldToView(curR/U/F, pos, prevR/U/F, gain, out)` —— **三根槽各自线性外推 + Gram-Schmidt 重新正交化**，不解释任何单根槽的语义。
* **回归测试**：一个**相对世界 up 带滚转的正交基**在零位移下必须**原样保留**（旧实现会把它滚掉）=> 实测总偏差 **0.000171** ✓。
* **教训（写给下一个我）**：`_cameraRight / _cameraUp / _cameraForward` **三个槽的语义未经证实**（作为一组是正交基，但名字不可信）。
  任何只取一根槽做解释的代码都会翻车；要外推就**三根一起外推**。

### Z2.2 使用者首测的三条反馈与结论
1. `pose gain` 非零 => 90 度怪像：**已修**（Z2.1），需用新构建复测 0.5 / 1.0。
2. `lead fill (x)` 怎么调都不减轻边缘撕裂：**它 = 增益 × 该帧自身位移，站着不动就是 0 px**（日志实测 `L/R/T/B 0.0 px` 那次正在菜单里拖）。
   要**一边快速转镜头一边调**（1.0 → 2.0 → 3.0）；若撕裂主要在**枪的轮廓**上，那不是它的职责（那是补洞）。
3. `hole fill (x)` 的黄色从不出现：黄色只画在"重投影**越出上一帧**"的像素上，**慢转时只有最边缘几像素宽**，肉眼几乎看不见；
   **快速甩镜**（猛地转 90 度）才会出现几十像素宽。若甩镜仍无黄色 => 那才是真信息（"深度 -> clip"约定不对），下一步诊断专门查它。
4. 使用者总体观感：**除 UI 遮罩外其它都不明显** => 三个旋钮的判据都依赖"肉眼在运动中捕捉"，**这正是下一步要先做更强诊断的原因**。

### Z2.3 下一步（按优先级；除最后一项外都不需要跑游戏）
1. **更强诊断（建议先做）**：把回填判据的**偏移量画成热图**，并每帧把 `max|偏移|` 与越界像素数写进日志。
2. **P3-2 C 段 GPU**：把已单测过的多层金字塔搬到 GPU（深层 1/4 分辨率、逐层下推、从最深一层取色）+ 亮度局部匹配。前提是先由 1 确认取样位置可信。
3. **P3-4b 超渲染裁切**：游戏侧抬 FOV + 我们在 Present 做中心裁切（`CropScale` 默认 1.0 = 关）；只裁**世界类**图层，**屏幕空间 UI 保持原坐标**。
4. **实机复测**（需使用者，且**先让他说“暂停目标”**）：`pose gain 0.5/1.0` 复测 + 甩镜看黄带 + lead fill 边转边调。

### Z2.4 本轮交付
* 装机 `dxgi.dll` sha256 `FC1096522BB0643CF844C12C812C75A0F33E0D705BE07E8BED78606DE0795D3E`（installed==built）。
* `verify_p2.ps1 -Full` = PASS（含新增的滚转回归测试）；manifest 96 文件；本轮包 sha 见 `LOG.md` 第 78 轮。


## 附录 Z3 —— 第 79 轮更新（P3-3 更强诊断落地 + 抓出两个“隐形”真 bug；与 Z/Z2 冲突处以本节为准）

### Z3.0 一句话
诊断做完了，而且**顺手证明前几轮的两处 0 效果不是“设计如此”，是真 bug**：常量缓冲里那张蓝噪声表的步长写错，
导致 `InvVPCur / VPPPrev / HoleFillGain / DepthFlipY` 全部被着色器按 **0** 读——**P3-2 的回填块从来没执行过**；
而 `LeadFillPx` 少了一个 16 字节对齐，导致**只要 lead fill > 0 整屏都会退回未扭曲帧**。两个都已修，并用 10 条 `static_assert` 钉死。

### Z3.1 P3-3 诊断（新旋钮 + 新日志）
* **面板 `latewarp diag offset map`**（ini `[Latewarp] DiagMap`，**默认 0 = 关**，与其它旋钮一致）。
* 打开后画面 = **重投影偏移量热图**（**P3-3b 起还要同时打开 `Show static elements`**，见 Z3.6；只开 diag 时画面保持正常，只记录数字）：黑(0 px) → 绿 → 黄 → 红 → 白(32 px 及以上)；
  落在**上一帧之外**的像素画**纯黄**（与旧诊断黄一致，所以“空洞必须在转向那一侧”的读法不变）。
  建议**一边快速转镜头**一边看：约定正确时它是一片**连贯的场**（纯偏航时应近似水平梯度）；约定错时是噪声/整体乱掉。
* 同时每 30 帧（前 3 帧必打）一行日志：

  ```
  latewarp-diag: frame N shift max X peak P px | outside C (c%) max W px behind B
                 | mismatch M outside Mo | centre S px ndc (cx,cy)->(px,py) depth D
                 | reference R px | pass 2560x1600 depth 2560x1600
  ```

  * `shift/peak`：每像素偏移的**当前帧最大值 / 30 帧窗口峰值**；
  * `outside`：会**越出上一帧**的像素数（这才是“真的没内容可填”的部分）及占屏比；
  * `behind`：`clipPrev.w <= 0` 的像素数。**非零 = 约定错**（点被投到上一帧相机背后），不是补洞弱；
  * `mismatch`：把 history 采在“数学上它该来自的位置”，与当前像素比；全屏均值**大 = 查表镜像/错位**，
    越界像素那一个 `outside` 才是**回填质量**本身；
  * `centre` / `reference`：着色器测的**中心像素**偏移 vs 宿主预测的 `focal*tan(姿态角)`（远点近似）。两者量级必须一致；
  * `depth WxH`：**深度纹理自身尺寸**。若与 `pass` 不同 => 深度取样读错像素，后面一切免谈。
* 成本：诊断开着时每帧一次 80 字节回读（Map 拿到的是**上一帧**的块，所以不卡渲染线程）。

### Z3.2 ★真 bug #1：常量缓冲数组步长（P3-2 为什么“完全没效果”）
* **证据**（cso 自己的反射，`LatewarpUi_Shader.h` 头部）：`uint BlueNoiseWords[256]; Offset: 48` 之后是
  `float4x4 InvVPCur; Offset: 4144` —— HLSL 在 cbuffer 里**数组每个元素占一个 16 字节寄存器**，
  所以那张表占 **4096** 字节，不是 1024。
* C++ 侧当时是紧凑写法（`uint32_t[256]`，1024 字节）=> 结构体总长 1216，而着色器寻址到 4288 =>
  **视图之外一律读 0**（D3D 规定）=> `InvVPCur/VPPPrev` 全 0 => `clipPrev.w == 0` => `if (clipPrev.w > 1e-6f)` **永不成立**
  => **P3-2 的回填与黄色诊断从来没执行过**。这就是使用者说的“hole fill 的黄色从不出现、也看不出效果”。
* 修法：C++ 侧按 16 字节步长镜像（`struct BlueNoiseSlot { uint32_t word; uint32_t pad[3]; }`），
  并在 `LatewarpUi_Dx12` 构造函数里放 **10 条 `static_assert`**（`LeadFillPx` 32 / `BlueNoiseWords` 48 / 4096 字节 /
  `InvVPCur` 4144 / `VPPPrev` 4208 / `HoleFillGain` 4272 / `DepthFlipY` 4276 / `DiagMap` 4280 / `DiagRefPx` 4284）。
  这组断言是照着 cso 反射的数字写的，**以后谁改结构体都会在编译期炸**。

### Z3.3 ★真 bug #2（被上面第一条断言当场抓住）：`LeadFillPx` 少 16 字节对齐
* 断言第一次运行就报 `LeadFillPx must sit at 32`：C++ 的 `float[4]` **只有 4 字节对齐**，所以它落在 **28**；
  HLSL 的 `float4` 在 **32**。于是着色器读到的 `LeadFillPx` **整体错位一个 word**：
  `.x` = 宿主的 `right`、`.y` = `top`、`.z` = `bottom`、`.w` = **蓝噪声表第一个 word**（约 1e9）。
  底边那条 ramp 于是恒等于 1 => **只要 `lead fill` > 0，整屏都退回未扭曲的 `present`**。
  （使用者上次“调了没变化”是因为他站在菜单里没转镜头，宽度 = 增益 × 该帧位移 = 0，正好绕过了这个 bug。）
* 修法：`alignas(16)` 显式加在 `LeadFillPx` / `InvVPCur` / `VPPPrev` / `BlueNoiseSlot` 上——**对齐是承重的，不是装饰**。
* 顺带修：蓝噪声表进常量缓冲也按“表 word k -> 元素 k”写（以前紧凑 memcpy，着色器实际拿到 `table[4k]`，
  仍是合法噪声所以肉眼看不出来，但**不是**我们验证过的那张表）。

### Z3.4 新增的离线可验证件（单测 + 门禁）
* `p2::ForwardAngleDeg(cur,prev)`：只给**角度大小**，不解释是哪个轴（宿主槽名不可信这条教训继续生效）；
* `p2::PredictCentreShiftPx(cur,prev,focal)`：`focal*tan(角度)`，作为日志里的 **reference**（>=80° 直接拒绝，不给天文数字）；
* `p2::DecodeDiagStats(words, w, h)`：解回读块（位转浮点、NDC->px、两个 mismatch 均值、越界百分比、中心样本有效位、深度尺寸）；
* 单测新增 20 条（全绿）：含“从未写过的块 -> invalid”“NaN/负值不污染日志”“深度尺寸与 pass 不一致可读”“85° 拒绝”。
* 门禁：`L2` 干跑 **55** 补丁 / 16 新文件；`L3.5` 孪生一致 **327** 行（运行期副本因 MSVC **C2026**（单个字面量 >16384 字节被截断）
  拆成两段相邻 raw literal，门禁已同步学会忽略拼接标记，且拼接结果与 `.hlsl` 逐行相等）；`L4` 新增“诊断不得自开”。
* `make_patch_review.ps1` 的 blast radius：**8 改 / 16 增 / 0 删**；`build_verify.ps1` = PASS。

### Z3.5 交付与下一步
* 装机 `dxgi.dll` sha256 `1EC3728173B1813ECFAAA24ECAF0E22A714AF2A13B544ADADDC55E2932183F87`（installed==built，26001408 字节）。
* 包 48 文件（0 个 NVIDIA 二进制）；本轮包 sha 见 `LOG.md` 第 79 轮。ini 未动：`[Latewarp] Rewrite=true`、
  `[Reprojection] UseNvidiaLatewarp=true`，三个 P3 旋钮仍是 `auto`/缺省（即**下次进游戏默认什么都不生效**，必须自己开）。
* **下一步（需要使用者跑一次游戏；按规则请先说“暂停目标”）**：
  1. 勾 `latewarp diag offset map`，**一边转镜头**一边看热图和日志；把 `reference` 与 `shift max/centre` 对一下量级，
     顺便看 `depth WxH` 是否等于 `pass`、`behind` 是否非零 —— 这三件事一次性判定“深度->clip 约定 / DepthFlipY / 深度分辨率”。
  2. 有了上面的判定，再打开 `latewarp hole fill (x)` 0.5/1.0（现在它是**真的在跑**了），对比 `mismatch outside` 与画面。
  3. 顺带复测 `pose gain 0.5/1.0`（90 度 bug 已修的那版）与 `lead fill` 边转边调（现在它的宽度是真的了）。
* 然后才轮到 **P3-2 C 段 GPU**（多层金字塔 + 亮度匹配）与 **P3-4b 超渲染裁切**。


## 附录 Z3.6 —— 第 80 轮更新（第一次带诊断的实机：**诊断根本没开**，于是把它做成“开机即自述”）

### Z3.6.1 使用者那次运行到底发生了什么（读完日志的事实，不做猜测）
* `OptiScaler.log`（22:46–22:51，166465 行/15.4 MB）:
  * `latewarp: eval #1/#3/#4/#1000…#5000`，`keys written 23, refused 0`，**无任何 device-removed** => 扭曲一直在跑，内核正常。
  * **`latewarp-diag-on` 出现 0 次 => `DiagMap` 整场都是 0** => 热图没画、**逐帧数字一条也没有**。
  * `latewarp-lead-fill: gain 0.12/0.14/0.31 -> L/R/T/B 0.0 px`（5 条，全在菜单里拖滑块、相机不动 => 宽度按定义就是 0）；
    `latewarp-pose: gain 0.05/0.08/0.14 target fwd == game`（同样是在菜单里拖，两帧相机相同 => 外推等于原值）；
    `latewarp-hole-fill: gain 0.00 ready true`（前 5 帧的一次性日志，看不到之后改成了多少）。
  * 结论：那次运行**唯一可用的信息**是使用者的一句话——“智能武器瞄准框内的物体也算作 UI 被遮罩”。
* 结构性原因（我的）：所有 P3 日志都是**一次性前 5 帧**，而旋钮是在几分钟后才被拖动的 => 日志永远记录不到**实际在用的值**。

### Z3.6.2 本轮改了什么（都不需要跑游戏即可验证）
1. **掩码定量**（`kDiagMaskCount/Cutout/DiffQ` = 17/18/19，凑满 20 词）:每个像素若 `uiMask=1` 则计数，并区分它是不是**深度谓词**选中的，
   以及那处的 `|present-hudless|` 强度。日志新列：`mask {:.2f}% (cutout {:.2f}%) diff {:.3f}`。
   * 判读: `cutout%` 占掩码比例大 => **深度谓词/`InvertedDepth`/`DepthCutoff` 选错了区域**（这正好能解释“一大片远处建筑被涂成品红”）；
   * `diff` 很小(≈0.02) => 掩码抓住的是**一层很淡的屏幕空间着色**（智能武器准星那类），本该跟着世界一起被扭曲。
2. **诊断不再强制改画面**:`DiagMap=1` 现在**只记录数字**，画面保持正常（要**看**热图就再开 `Show static elements`）。
   之前的设计会让诊断模式整屏被热图盖住 => 既飞不了也瞄不了，等于没法用。
3. **旋钮变更日志** `latewarp-knob: lead .. hole .. pose .. diag .. | depth cutoff .. expand .. inverted ..`:
   任何一个 P3 旋钮变化就打一行，**并带上深度谓词的三个输入**（那正是掩码的嫌疑对象）。
   => 从此每次运行的日志都能自述“当时用的是多少”，不再出现“无法描述”的空转。
4. `InvertedDepth` 也是**首次**被记录（`(int) lwUiParams.InvertedDepth`）。

### Z3.6.3 部署变更（只影响使用者机器上的 ini，不影响交付包默认值）
* 在游戏的 `OptiScaler.ini` 的 `[Latewarp]` 下加了一行 **`DiagMap = 1`** => 下次进游戏**自动开始记录数字**（画面不变）。
  想关掉就在面板把 `latewarp diag offset map` 拖回 0；交付包里的默认仍是 0（门禁 L4 强制）。

### Z3.6.4 下次请这样跑（60 秒，一次拿全）
1. 进游戏后打开面板，勾 **`latewarp takeover: running`**（每次启动都要勾一次，它是运行时开关）。
2. 直接在游戏里**正常玩 30–60 秒**，中途**故意快速转几次镜头**（左右甩各两三次，再上下抬压）。
3. 想要肉眼看位置就再打开 `Show static elements`（那时会出现热图 + 粉/青），**看一眼就关掉**继续玩。
4. 退出后把 `OptiScaler.log` 交给我（`p2\collect_p2_run.ps1 -Log <game>\OptiScaler.log`）。
我要从那几行 `latewarp-diag:` 里读三件事:（a）`reference` 与 `shift max/centre` 是否同量级（深度->clip 约定）；
（b）`behind` 是否为 0、`depth WxH` 是否等于 `pass WxH`；（c）`mask %` / `cutout %` / `diff` —— 这决定“UI 遮罩该改哪一处”。


## 附录 Z3.7 —— 第 81 轮更新（中文面板：P3-4a）

### Z3.7.1 需求与约束（先说清楚为什么不是“整个面板都翻译”）
* 使用者原话：**“我要中文版的面板英文看不懂”**。
* OptiScaler **没有任何本地化层**（菜单字符串全是硬编码英文，几千行），全量翻译既不是本项目的职责、也不可行；
  但**这个项目需要的每一行**都可以是中文 —— 这才是使用者真正要的东西。
* 第二个约束（关键）：OPTISCALER 的菜单字体默认是**内置 HQ 字体**，字形只有 Latin-1；**中文会渲染成空白**。
  所以“翻译字符串”必须配“字体里有这些字形”，两件事缺一不可。

### Z3.7.2 做法（T39，全部离线可验证）
1. **字形**：菜单建字体图集时用 `ImFontGlyphRangesBuilder`，在默认 Latin 范围之外**只加这些标签用到的 57 个汉字码点**
   （全中文范围要 ~2 万个字形、几 MB 纹理；57 个只多几 KB）。同时补了一个真实缺陷：
   **自定义字体加载失败时原来会把 `io.FontDefault` 留成 NULL（整个面板会瞎）**，现在会 LOUD WARN 并回退到内置字体。
2. **标签**：本项目相关的 7 行改为“**中文 + 原英文令牌**”，英文令牌保持在**最后**，因为门禁的 marker、日志和文档都按英文匹配；
   例如 `让位强度 latewarp lead fill (x)`、`接管开关 latewarp takeover: running`、`深度阈值 Depth cutoff`、
   `静态元素可视化 Show static elements`、`诊断记录 latewarp diag offset map`。
3. **中文速控开关**：在 Advanced Settings 页**最上方**加一个自己的小块（标题 `latewarp 中文速控面板`），
   只有一个复选框 `接管开关（先勾这个）`（等价于英文行的 `latewarp takeover: running`，同一运行时标志），
   旁边显示 `（已装配）/（未装配）`（读 `[Reprojection] UseNvidiaLatewarp`），下面两行中文提示。
4. **源码编码**：所有中文一律写成 **UTF-8 字节转义**（如 `\xE8\xAE\xA9`）而不是字面中文 —— 
   MSVC 在没有 `/utf-8` 时按系统 ANSI 码页解释窄字符串字面量，而 ImGui 按 UTF-8 解码；转义是唯一与码页无关的写法。
   补丁脚本里也全部是 ASCII（`$cnLead` 等变量在应用时展开），所以 `apply_to_optiscaler.ps1` 本身仍是纯 ASCII。

### Z3.7.3 使用者机器上的部署（ini，非交付包默认）
* `[Menu] TTFFontPath = C:\Windows\Fonts\simhei.ttf`（黑体，单面 TTF；同一台机器也有 msyh.ttc/msyh/simsun 可选）
* `[Menu] FontSize = 16`、`[Menu] UseHQFont = true`
* `[Latewarp] DiagMap = 1`（上一轮加的，保持开着：下次跑就直接有数字）
* 交付包里的默认仍是“英文标签 + 内置字体”可用状态（门禁 L4 只强制我们自己的旋钮默认关；字体键属于 ini 部署）。

### Z3.7.4 中文 ↔ 英文对照（未来查日志/marker 用）
| 面板中文 | 英文令牌（日志/门禁用） | ini 键 |
|---|---|---|
| 接管开关（先勾这个） | `latewarp takeover: running` | 运行时标志（不写 ini） |
| 静态元素可视化 | `Show static elements` | `State::fgHudlessCompare` |
| 诊断记录 | `latewarp diag offset map` | `[Latewarp] DiagMap` |
| 让位强度 | `latewarp lead fill (x)` | `[Latewarp] EdgeFillPx` |
| 补洞强度 | `latewarp hole fill (x)` | `[Latewarp] HoleFillGain` |
| 姿态超前 | `latewarp pose gain (frames)` | `[Latewarp] PoseGain` |
| 深度阈值 | `Depth cutoff` | `[Reprojection] DepthCutoff` |

### Z3.7.5 门禁
* 补丁集 **65** 处（新增 T39a/T39b×7/T39c）；L3.5 孪生一致 **366** 行；L4 仍全绿；“只允许菜单写 ini”的不变量未动
  （中文速控开关只写**运行时标志**，不碰 ini 开关）；本轮的 3 处 marker count 漂移（`latewarp takeover: running`、
  `p2GlyphRanges.Data`、`latewarp quick panel` 各 +1）都已按实际语义改为 n=2 并写明原因。
* 构建 `build_verify.ps1` = PASS；装机与包哈希见 `LOG.md` 第 81 轮。


## 附录 Z3.8 —— 第 82 轮更新（**闪退**：诊断路径第一次真正执行就被它自己打死；已修）

### Z3.8.1 使用者报告与日志事实
* 使用者：**“直接闪退喽”**。日志（23:31:08 启动 → 23:32:40 结束，36606 行）显示：游戏跑了约 **94 秒**，
  在**接管刚启动的第 2 帧**（`latewarp: eval #2`）崩掉：
  * `Latewarp.DiagMap: 1` 启动即读入（是我上一轮写进 ini 的）；`latewarp-diag-on` 出现 ⇒ 诊断开关是开的；
  * `LatewarpUi start!` → 第 1528 帧创建 `_buffer`/`_history` → 第 1529 帧创建两个掩码纹理 → 紧接着
    **`Device removed reason: DXGI_ERROR_INVALID_CALL`** → `Failed to create a constants buffer` → 设备移除、游戏退出；
  * `latewarp-diag: frame` **0 条** ⇒ 逐帧数字一次都没输出，说明死在“第一次执行诊断路径”的那一刻。
* 顺带确认：**中文字体/中文面板没有崩**（`Menu.TTFFontPath: C:\Windows\Fonts\simhei.ttf` 正常读入，菜单正常挂载 94 秒）。

### Z3.8.2 根因（我的 bug）
* 诊断缓冲 `_diag` 是用 `CD3DX12_RESOURCE_DESC::Buffer(...)` 建的，而它的 flags **默认是 `D3D12_RESOURCE_FLAG_NONE`**；
  给一个**没有** `ALLOW_UNORDERED_ACCESS` 的 buffer 创建 UAV，**不是**让调用失败，而是**直接把设备移除**（`DXGI_ERROR_INVALID_CALL`）。
  它在 `CreateUnorderedAccessView(u2)` 那一刻命中，正好在日志里“掩码创建之后、常量缓冲之前”的位置。
* 为什么从没被抓到：**诊断路径在此前从未被开启过**（`DiagMap` 一直是 0），着色器里的诊断代码也从没执行；
  这类 D3D12 标志/状态错误**只能在真机上暴露**，离线单测与门禁都看不见。

### Z3.8.3 修法（T39 之外，属 P3-3c）
1. `_diag` 改用**带 UAV 标志**的描述符（`ALLOW_UNORDERED_ACCESS`）；
2. READBACK / UPLOAD 那两个伴生缓冲改用**单独的无标志描述符** `copyDesc` —— 反过来，给 READBACK/UPLOAD 资源加 UAV 标志也是非法的；
3. 加兜底：资源建好后**检查 flag**，缺了就 `LOG_ERROR` 并把诊断关掉（绝不去绑那个 UAV）；
4. 门禁新增两条 marker 钉住（`copyDesc` 的存在 + flag 检查），防止回归。

### Z3.8.4 纪律教训（写死在这里）
* **新的 GPU 路径必须单独开一次**，不能和别的变更一起上：本轮把“中文面板 + 诊断开启”同时推给使用者，
  结果崩了之后仍需要靠日志区分是谁的锅（这次是诊断）。下次：先只上不带诊断的版本，稳定后再单独开诊断。
* 这也正是“诊断默认关、要用时在面板单独打开”的价值：**默认关就是崩溃半径控制**。

### Z3.8.5 部署变更
* 使用者机器 ini：**`[Latewarp] DiagMap = 0`**（这一版先让它稳定）。
  要做测量时，把中文行的 **`诊断记录`** 拖到 1（同一个 ini 键），**这一步就是唯一变量**：若再崩，就是诊断本身，立刻拖回 0 即可。
* 装机/包哈希见 `LOG.md` 第 82 轮。


## 附录 Z3.9 —— 第 83 轮：**方向纠正**（补洞与内核机制重叠 / 姿态超前不能用预测）+ 研究出处

### Z3.9.1 使用者给的两条纠正（都成立，本文件据此改写）
1. **补洞（P3-2）不该做**：Reflex 2 内核**自带**撕裂修补（那是它算法的一部分）。我们再叠一层基于 history 的回填，
   会和内核抢同一件事 → 功能重叠、结果互相打架。**这一模块要撤掉**（含黄/热图那套回填可视化的默认行为）。
   我们合成层**真正该解决的**是使用者原话：**“武器遮罩不干净”**。
2. **姿态超前（P3-0a）方向错**：不能用“从过去两帧外推”的**预测**。Reflex 2 的机制是 **late input sampling**：
   CPU 用**最新的输入采样**算出最新视角，GPU 把**已经渲染好的那一帧**在**最接近显示的时刻**扭到该视角；
   收益来自“采样更晚 + 对已渲染帧重投影”，不是来自预测未来。
   ⇒ **撤掉 pose gain**。我们这条链路里“最晚可得的姿态”就是 Present 钩子里游戏当帧的相机（这已经是 late-sample 点）；
   在它之上再加外推只会注入误差（实测：非零即整屏倒置）。

### Z3.9.2 研究出处（使用者要求先找到）
* **论文**：*Post-Render Warp with Late Input Sampling Improves Aiming Under High Latency Conditions*
  作者 Joohwan Kim, Pyarelal Knowles, Josef Spjut, Ben Boudaoud, Morgan McGuire（NVIDIA），
  **High Performance Graphics 2020**，DOI **10.1145/3406187**
  <https://research.nvidia.com/publication/2020-07_post-render-warp-late-input-sampling-improves-aiming-under-high-latency>
  摘要要点：把 VR 的图像/模拟 warp 技术改造后用于降低端到端延迟，**最多消除“额外 80 ms 延迟”所造成惩罚的 80%**（原文 “eliminating up to 80% of the penalty from 80 ms of added latency”）。
* **NVIDIA 技术博客**：*Warp Drive Gaming – Eliminate More than 80% of the Latency Performance Penalty*（2020-07-14）
  <https://developer.nvidia.com/blog/nvidia-research-warp-drive-gaming-eliminate-more-than-80-of-the-latency-Performance-penalty/>
  要点：受试者在 105 ms 模拟延迟下，**所有 late-warp 条件（连最简实现）都能打出 25 ms 延迟时的水平**，
  即消除 80–90% 的延迟惩罚；**采样“更晚”是关键**。
* **后续（含工程实现）**：*Gaming at Warp Speed: Improving Aiming with Late Warp*，ACM DOI **10.1145/3450550.3465347**。
* **产品化描述（2025 年 Reflex 2）**：官方博客 *NVIDIA Reflex 2 With New Frame Warp Technology Reduces Latency In Games By Up To 75%*
  <https://www.nvidia.com/en-us/geforce/news/reflex-2-even-lower-latency-gameplay-with-frame-warp/>
  —— 其中“撕裂用前几帧的视角/颜色/深度做**图像修复**”这一句，正是内核自带补洞的证据（也是 Z3.9.1 第 1 条）。

### Z3.9.3 我们自己的 RE 早就写过“官方路径不用 NoWarpMask”（`_re\demo_re\FRAMEWARP_demo_拆解.md`）
* 官方 demo：`Latewarp.NoWarpMask = nullptr`；`HudlessColor` / `UIColorAlpha` / `Backbuffer` **都是同一张 `inputColor`**；
  也就是**驱动自己用 HudlessColor + Backbuffer(+UIColorAlpha 的 alpha) 处理 UI/武器**，不需要外部遮罩。
* 我们这条路：喂 **UI-free 帧** + **自造 1-bit、蓝噪声抖动、且晚一帧**的 `NoWarpMask`，再自己把 UI 贴回去。
  ⇒ “武器遮罩不干净”的来源是**设计**，不是参数：抖动边界 + 晚一帧 + 只有 0/1 两档。

### Z3.9.4 按纠正后重排的下一步（待使用者裁定）
1. **删** P3-2（history 回填 + 黄/热图默认行为）与 P3-0a（pose gain 及其 CB/面板/接线）；
2. **攻“武器遮罩不干净”**，从干净到彻底三个档：
   a. **同帧遮罩**：mask 只需要 depth+present+hudless，完全可以在 `Evaluate` **之前**算好并写进本帧要交给内核的那张 mask
      （现在是合成阶段算、给内核的是上一帧的）→ 去掉一帧错位；
   b. **视模型半边不做抖动**：深度裁出的武器/手应给**硬边界 + 1~2 px 膨胀**，蓝噪声只保留给“UI 差异”那半边；
   c. **回到官方接口**：给内核 `Latewarp.UIColorAlpha`（内核用它的 alpha 自己合成 UI/武器），`NoWarpMask` 传 nullptr。
      前提：先确认 CP2077 present 的 alpha 通道是否有意义（需要一次实机采样或 RE 确认）。
3. 完成后 **P3-4b 超渲染裁切**（使用者自己定义的“正确解法”：抬 FOV + 中心裁切）才是有意义的抗撕裂方向。


## 附录 Z4 —— 第 84 轮：**压缩前交接**（计划 + 文件地图 + 已定结论 + 红线）

### Z4.0 速览（新会话先读这 8 行）
* 目标 `goal-b6bc3412-d701-4ea7-8321-099d0948ef7d` **paused/disarmed**；**模型不能自己 resume**（实测被拒），要续跑须使用者发话。
* 现状：latewarp 已出画（`latewarp: eval #N ... keys written 23`）、不崩；补丁集 **65 处 / 16 新文件**；装机 `dxgi.dll` sha256 `19D4CE13…`（installed==built）。
* 使用者已判定两条方向：**删 P3-2 补洞**（与内核自带补洞重叠）、**删 P3-0a 姿态超前**（预测 ≠ Reflex 2 机制）。
* 本轮（Z3.9/Z4）已确立：内核两种模式、`NoWarpMask` 是硬门控、UI 分离应走 `UIColorAlpha`、MFG 晚 warp 的正确形态、路径 B 的硬约束。
* **下一步第一刀**：离线台架探测内核模式（Z4.3 的 P3-A），不需要使用者跑游戏。
* 面板已中文化（`[Menu] TTFFontPath=simhei.ttf`、`FontSize=16`）；中文速控块在 Advanced Settings 页最上方。

### Z4.1 文件地图（★ 分五类，别混淆）

**① 唯一真源 —— 只有这一处描述我们的改动**
| 路径 | 说明 |
|---|---|
| `_re\reflex2_mod\p2\apply_to_optiscaler.ps1` | **补丁集唯一真源**（65 处，T5…T39）。改补丁只改这里；先 `-DryRun -Tree <交付源树>` 验证全部锚点，再 `-Action Revert` + 应用 |
| `_re\reflex2_mod\p2\files\**` | **我们新增的 16 个源文件**（应用时被复制进工作区）：`upscalers\latewarp\*`、`shaders\latewarp\*` |
| `_re\reflex2_mod\p2\verify_p2.ps1` | 门禁（L1…L7）；marker 数量漂移要按语义改，不许删 |
| `_re\reflex2_mod\p2\build_verify.ps1` | **唯一可信构建判据** |
| `_re\reflex2_mod\p2\make_p2_release.ps1` / `make_patch_review.ps1` / `install_p2_into_game.ps1` / `collect_p2_run.ps1` | 打包 / diff 审查 / 装机 / 采日志 |
| `_re\reflex2_mod\p2\test\*` | 离线单测 `LatewarpParams_test.cpp` + `build_and_run_test.cmd` + 离线内核验收 `test_offline_warp.ps1` |

**② 生成物 —— 不要手改（会被覆盖）**
| 路径 | 谁生成 |
|---|---|
| `_re\repro_src\OptiScaler\**` | **构建工作区**：由 `apply_to_optiscaler.ps1` 从交付源树 + `p2\files` 生成；每次 revert/apply 重建 |
| `_re\repro_src\OptiScaler\shaders\latewarp\LatewarpUi_Shader.h` | **fxc 产物**（cso）；改了 `.hlsl` 必须重编（见 Z4.4） |
| `_re\reflex2_mod\p2\APPLIED_DIFF.txt` / `APPLY_STATE.txt` / `PATCH_REVIEW.md` / `PATCH_REVIEW.diff` | 应用/审查产物（随 apply、make_patch_review 重写） |
| `_re\reflex2_mod\dist\Reflex2-P2-OptiScaler-1.0.0(.zip)` | 交付包（48 文件；含 `docs\HANDOFF_P3_NEXT.md` 的副本） |
| `_re\demo_re\harness\*`（`fwtest.exe`、`*.raw`、`fwtest.*.log`、各探针子目录） | 台架的输入/输出/日志 |

**③ 只读参考 —— 不要改**
| 路径 | 是什么 |
|---|---|
| `OptiScaler_20260923_154112\OptiScaler_source_5b6bc822\OptiScaler\` | **交付源树（pristine）**：门禁 L1/L6 的基准，绝不直接改 |
| `_re\nvngx_latewarp_re\docs\*` | 内核逆向：`PARAM_ABI.md`（键↔偏移）、`GAP_MATRIX_PATH.md`（irf≠0 跳过矩阵）、`ABI_LEAD.md`（三个 kernel）、`PARAM_FILL.md` |
| `_re\demo_re\FRAMEWARP_demo_拆解.md` | 官方样例拆解（参数表、EnableBorderFix、调用点） |
| `_re\demo_re\src_public\*` | 官方 Streamline_Sample FrameWarp 公开源码 |
| `_re\routeA\audit\*`、`_re\bluenoise32\`、`_re\reflex2_mod\spec\*` | Route A 审计、蓝噪声表、键表/ABI |

**④ 使用者自备 —— 绝不入库/绝不打包**
* 游戏目录里的 `nvngx.dll`（1,411,224 B）与 `nvngx_latewarp.dll`（907,296 B）；`dxgi.dll.specialk_bak`（SpecialK 被让位）。
* 交付包卫生检查就钉这三条：**0 个 NVIDIA 二进制、0 个构建产物、单文件 < 2 MB**。

**⑤ 被装机改动的（游戏侧）**：`<game>\bin\x64\dxgi.dll`（我们装机）、`OptiScaler.ini`（键值）、`_p2_state.txt`（装机状态）、`OptiScaler.log`（日志）。`install_p2_into_game.ps1 -Uninstall` 可逐字节还原。

### Z4.2 已定结论（避免重犯）
1. **内核结构**：fb0 主重投影 / **fb1 补洞** / fb2 **UI 合成**；`IsRenderedFrame != 0` ⇒ **整段矩阵合成被跳过**，只走 fb2（UI 合成）；`NoWarpMask` 是**硬门控（>0 即跳过扭曲）**；`FrameID` **内核不读**（不认识生成帧）；`DepthInverted` 只喂 fb1；`EvalFlags != 0` 让 fb2 早退 ⇒ (irf, evalflags) 是**模式开关**。
2. **我们踩过的三个真 bug**：① cbuffer 数组每元素占 16 字节（蓝噪声表 4096 而非 1024）⇒ 后面所有成员被按 0 读；② `LeadFillPx` 缺 `alignas(16)` ⇒ 错位一个 word；③ 诊断缓冲缺 `ALLOW_UNORDERED_ACCESS` ⇒ **设备移除、游戏闪退**（新 GPU 路径必须单独开一次验证）。
3. **深度分辨率坑**：`pass 2560x1600` 而 `depth 1280x800` ⇒ 回填块读深度必须用 `uv × depthDim`（该块已被判定删除）。
4. **两条方向判定（使用者）**：删 P3-2（与内核补洞重叠）、删 P3-0a（预测非机制）。
5. **延迟框架（方法论）**：两笔账（渲染 / 呈现）；**late latch** 在 scanout 前 1–2 ms、与**显示刷新率**对齐；**逐生成帧 Slerp**（DLSS-G 两端姿态都已知，无需预估）；**纯旋转 2D warp**（生成帧无深度，`H≈K·R·K⁻¹`）；**M+1 次/渲染帧**；UI/武器分离用内核 **`irf≠0` 的 `UIColorAlpha` 路径**；**路径 B 无法回传引擎状态** ⇒ late delta 必须**限幅**。
6. **研究出处**：HPG 2020 *Post-Render Warp with Late Input Sampling…*（DOI 10.1145/3406187，额外 80 ms 延迟的惩罚最多消除 80%）；NVIDIA 博客 *Warp Drive Gaming*（105 ms 模拟下打出 25 ms 水平，80–90% 惩罚被消除）；*Gaming at Warp Speed: Improving Aiming with Late Warp*（10.1145/3450550.3465347）；官方 Reflex 2 博客；专利 **US 20210106912A1**。

### Z4.3 计划（阶段 / 验收 / 门禁）
| 阶段 | 内容 | 验收 | 需要使用者? |
|---|---|---|---|
| **P3-A** | 离线台架探测内核模式：`--irf 0/1` × `--inflags` × `--uialpha color/zero` × `--premul` × `--nomats` × `--evalsperframe N`；回答：irf≠0 是否只做 UI 合成；UI×alpha 能否给**干净边界**；一帧内多次不同目标姿态是否稳定（=MFG 晚 warp 原型） | 台架日志（`fwtest.*.log`）+ 结论写进 Z4/Z5 | 否 |
| **P3-B** | **Late latch 打点**（纯日志）：`姿态年龄 = 记录时刻 − 相机采样时刻` + 该窗口鼠标增量 + **下一帧游戏相机实际增量**（判定是否重复计入） | 一次运行日志即可判定“还有没有可榨” | 是（60 秒） |
| **P3-C** | **掩码重做**：同帧 mask（在 `Evaluate` 前算）+ 视模型硬边界不抖动 + 走 `Latewarp.UIColorAlpha`（`NoWarpMask=nullptr`）；顺带清理 P3-2/P3-0a 的面板项、CB 字段、白名单 | 门禁全绿 + 实机边界干净 | 是（验收观感） |
| **P3-D** | **我们的旋转 2D 晚 warp**：先只对渲染帧（与内核结果对照），再加限幅的 late delta；落点 = `LatewarpUi` 那一遍（我们已持有 present 拷贝） | 离线单测 + 实机 + 姿态年龄下降 | 是 |
| **P3-E** | **MFG 共存**：把 latewarp 从“替换 FG 后端”改成“呈现链上的过滤器”，挂在 FG 后端之后；每个上呈帧一次（M+1 次/渲染帧） | 需要真 FG 环境（DLSS-G/FSR3） | 是 |
| **P3-F** | **P3-4b 超渲染裁切**（使用者定义的抗撕裂正解）：抬 FOV + 中心裁切，只裁世界层、UI 保持原坐标 | 实机观感 | 是（使用者抬 FOV） |

**每阶段固定门禁链**（缺一不可）：
`apply_to_optiscaler.ps1 -DryRun -Tree <交付源树>` → `-Action Revert` → 应用 → `build_verify.ps1` → `verify_p2.ps1 -Full` → `make_patch_review.ps1` → `make_p2_release.ps1` → （需要时）`install_p2_into_game.ps1`。

### Z4.4 命令速查（都在 `_re\reflex2_mod\p2`）
```
.\apply_to_optiscaler.ps1 -DryRun -Tree <交付源树>   # 改补丁后先验证锚点
.\apply_to_optiscaler.ps1 -Action Revert ; .\apply_to_optiscaler.ps1
.\build_verify.ps1                                  # 唯一可信构建判据
.\verify_p2.ps1 -Full                               # 门禁（含回退往返 + 构建）
& .\test\build_and_run_test.cmd                      # 单测（不能用 powershell -File 跑 .cmd）
.\make_p2_release.ps1 ; .\make_patch_review.ps1
.\install_p2_into_game.ps1 -GameDir <game>\bin\x64 -ProxyName dxgi.dll   # 先 -Uninstall
.\collect_p2_run.ps1 -Log <game>\bin\x64\OptiScaler.log
# 改 .hlsl 后重编 cso（两份副本必须一致，门禁 L3.5 会查）：
#   C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\x64\fxc.exe /nologo /T cs_5_0 /E CSMain /Vn LatewarpUi_cso /Fh LatewarpUi_Shader.h LatewarpUi.hlsl
```
**坑（照做省一整轮）**：补丁锚点必须**整行独占**；改完先 DryRun；着色器改了要同步运行期孪生（`LatewarpUi_Common.h`；MSVC 单字面量 >16384 字节会 C2026，故拆成两段相邻 raw literal，门禁已学会忽略拼接标记）；PS 5.1 读写 UTF-8 中文文档用 `[IO.File]::ReadAllText/WriteAllText`；面板中文一律写 **UTF-8 字节转义**；`_re\repro_src` 是生成物不要手改；台架 `--matseq` 是**每行一个矩阵**（每帧 4 行）。

### Z4.5 面板中文 ↔ 英文 ↔ ini 对照
| 面板（中文） | 英文令牌（日志/门禁用） | ini 键 |
|---|---|---|
| 接管开关（先勾这个） | `latewarp takeover: running` | 运行时标志，不写 ini |
| 静态元素可视化 | `Show static elements` | `State::fgHudlessCompare` |
| 诊断记录 | `latewarp diag offset map` | `[Latewarp] DiagMap`（当前部署 **0**） |
| 让位强度（**待撤**） | `latewarp lead fill (x)` | `[Latewarp] EdgeFillPx` |
| 补洞强度（**待撤**） | `latewarp hole fill (x)` | `[Latewarp] HoleFillGain` |
| 姿态超前（**待撤**） | `latewarp pose gain (frames)` | `[Latewarp] PoseGain` |
| 深度阈值 | `Depth cutoff` | `[Reprojection] DepthCutoff`（0.014） |

### Z4.6 红线（使用者裁定过）
* **不改 OptiScaler 源码树**（交付源树只读；一切走补丁集）；包内 **0 个 NVIDIA 二进制**；新代码 **GPL-3**；
* **一次只改一个变量并追加日志**；**新的 GPU/驱动路径必须单独开一次验证**（闪退教训）；
* 反作弊游戏不注入不调试；跑游戏一律由使用者做，我们只读日志；**要他跑之前先请他暂停目标**；
* 上下文紧张先更新本文件；`verify_p2.ps1` 的 marker 数漂移要**按语义改并写明原因**，不许绕过。

### Z4.7 下一步第一刀（已具体到动作）
在 `_re\demo_re\harness\` 用现成 `fwtest.exe` 跑 P3-A 的模式矩阵（先用已有的 `irfchk0/1`、`pv_ua_*`、`uimask` 结果做起点），产出三条硬结论：
① `irf≠0` 是否只做 UI 合成（不扭）；② `UIColorAlpha` 路能否给出**无抖动边界**（武器遮罩正解）；③ `--evalsperframe N` + 每帧不同目标姿态是否稳定（MFG 晚 warp 原型）。
三条都有结论后，再进入 P3-B（late latch 打点）——那时才需要使用者跑 60 秒。

## 附录 Z5 —— 第 85 轮：**P3-A 离线内核模式探测完成**（三条硬结论 + 一个新台架开关）

### Z5.0 速览（三问三答）
| 问题 | 结论 | 证据 |
|---|---|---|
| ① `IsRenderedFrame != 0` 到底是什么 | **纯 UI 合成模式**：整段矩阵/扭曲被跳过；**连四个矩阵键都不需要**；没有 UI 覆盖时输出 = 输入（逐字节） | `irf1_uianull` = 0.000000%；`irf1+--nomats` 仍 Success；反向对照 `irf0+--nomats` = 0xBAD00005（且输出没被写） |
| ② `UIColorAlpha` 能否给**无抖动**边界 | **能。是逐像素 8 位覆盖率的线性交叉淡化：`out = warp + (源 − warp) × alpha/255`**。alpha=0 → 纯扭曲；alpha=255 → **逐字节等于源**；中间单调。**UI 纹理的 RGB 被忽略**；`UsePremultiplyUIAlpha`（台架 `--premul`）实测无任何差别 | 硬切：1231 列全扭曲 / 1232 列全源，**过渡只有 1 列**；alpha 斜坡：`mean|o−源|` 21.2→0.0、`mean|o−warp|` 0.0→12.4 单调；UI 纹理填成纯红 a=255 时输出仍等于源（RGB 不参与） |
| ③ 一帧内多次不同目标姿态（MFG 晚 warp 原型）稳不稳 | **机制成立，但不可逐字节复现**：3 次 eval 全部 Success 且每次新姿态都生效（开/不开 `--pass2newest` 差 93%）；**同一命令连跑 3 次输出每次都不一样**（±30 px 级，93.313% 上下浮动）；多遍结果与“只用最后一个姿态的单遍”差约 0.01% 像素 ⇒ 内核在同一帧的多次 eval 之间**带状态** | 见 Z5.1 表 C |

### Z5.1 证据（全部在 `_re\demo_re\harness\p3a\*`，可原样复跑）
输入固定为 `..\..\routeA\demo_run\cap1\demo_in_f4042.raw`（2880x1620 BGRA8）+ `..\..\routeA\frame_4042.txt` + `--ngxdir cubintest`。

**表 A —— 模式矩阵（`--irf` × `--uialpha`，`diffPixels` 是“输出 vs 输入”）**
| 变体 | diffPixels |
|---|---|
| `--irf 0 --uialpha null` | 81.086034%（出画基线） |
| `--irf 1 --uialpha null` | **0.000000%**（逐字节 = 输入） |
| `--irf 0 --uialpha color` | **0.000000%**（见陷阱） |
| `--irf 1 --uialpha color` | 0.000000% |
| `--irf 0 --uialpha zero` | 81.086077%（≈ null） |
| `--irf 1 --uialpha zero` | 0.000000% |
| `--irf 0 --uialpha hud --uihud 50` | 38.712899%（下半屏不扭、上半屏扭） |
| `--irf 1 --uialpha hud --uihud 50` | 0.000000% |
| 上面 hud50 加 `--premul 0` | 38.712899%（与 premul 1 **完全一致**） |
| `--irf 1 --uialpha null --nomats 1` | CreateFeature/Evaluate **Success**（矩阵键用不到） |
| `--irf 0 --uialpha null --nomats 1` | Evaluate = **0xBAD00005**（缺矩阵） |

**表 B —— `UIColorAlpha` 语义（新开关 `--uialpha file --uialphafile <raw>`，UI 与帧是两张独立纹理）**
| UI 纹理（RGB / alpha） | 结果 |
|---|---|
| 源图 / a=255 | 输出 **RGB 逐字节 = 源**（无扭曲） |
| 源图 / a=0 | 纯扭曲 81.090706% |
| 纯红 / a=255 | 同“源图/a=255”：**输出 = 源**（不是红）⇒ **RGB 被忽略** |
| 纯红 / a=0 | 纯扭曲 81.090664% |
| 全黑 / a=255 | 输出 RGB = 源（全屏当作 UI） |
| 全黑 / a=0 | 纯扭曲 |
| 源图 / a=0→255 横条 | **线性交叉淡化** |
| 源图×alpha / a=0→255（预乘） | 与“源图直传”**逐位相同** ⇒ 内核只读 alpha |
| 源图 / 硬切（x<1232 a=0，否则 255） | 1231 列**全扭曲**、1232 列**全等于源**，过渡 1 列 |

**表 C —— 一帧多次 eval（`p3a\seq3.txt`：4 个姿态，w2v=1°/2°/3°，pw2v 固定 = 源姿态）**
| 变体 | eval 返回 | diffPixels | 结论 |
|---|---|---|---|
| `--evalsperframe 1`（姿态 0/0） | Success | 0.000000% | 恒等 → 输出 = 输入（sha `B3F131C4…`） |
| `--evalsperframe 3`（不开 pass2newest） | 3×Success | 0.000000% | **sha 与单遍完全相同** ⇒ 多遍但同矩阵 = 无变化 |
| `--evalsperframe 3 --pass2newest` | 3×Success | 93.313550% | **每次 eval 都换新目标姿态**（M+1 微 warp 形态成立） |
| 上一条原样重跑 | 3×Success | 93.313507% | **sha 不同**（差 2 px）⇒ 不可逐字节复现 |
| 上一条 + `--postwait 400` 连跑 3 次 | 3×Success | 93.313293 / 93.312950 / 93.313936% | 三次 sha **互不相同** |
| `--matrixring 5` 加上述参数连跑 2 次 | 3×Success | 93.314322 / 93.311514% | 同样每次不同 |
| 只用“最后一个姿态”的单遍（`pose2.txt`） | Success | 93.302212% | 与多遍结果 **sha 不同、差约 500 px** ⇒ 多次 eval 之间**带状态**（历史缓冲） |
| `--loops 3`（3 个帧令牌，每帧 3 遍） | 9×Success | 91.311321% | 连续多帧多重 eval 不崩、不出错 |

**表 D —— 边界剖面（`p3a_fine.py`，列号 vs `mean|o−源|` / `mean|o−warp|`）**
```
硬切 (alpha 在 1232 换挡)          斜坡 (alpha 1200→1263 线性)
  x   |o-in|  |o-warp|               x   |o-in|  |o-warp|
1228  18.30   0.00                1196  21.11   0.00
1231  17.14   0.00                1216  14.22   4.89
1232   0.00  16.89                1232   8.26   8.66
1240   0.00  16.86                1248   3.88  12.36
                                  1263   0.00  11.71
```
⇒ 内核在这条路上做的是 **8 位 alpha 的逐像素混合**，不是 0/1 门控、也没有抖动（硬切处 1 列就完成过渡，两侧都“恰好等于”其中之一）。

### Z5.2 对 P3-C（掩码重做）的直接影响
1. **武器/UI 边界改走 `Latewarp.UIColorAlpha` 的软 alpha 覆盖率**，`NoWarpMask` 可以退场 —— 它是**硬门控（>0 即整像素跳过扭曲）**，我们之前只能给 1 bit（蓝噪声抖动），这正是“武器遮罩不干净”的机制来源。换成 alpha 后：内核给出 256 档、逐像素、单调的淡化，**没有双曝光也没有抖动**。
2. 交叉淡化的另一端是**未扭曲的源（HudlessColor）**，**不是** UI 纹理的颜色（RGB 被忽略）。所以流程仍是：内核把场景扭好（武器区按 alpha 保持不动）→ 我们的 `LatewarpUi` 那一遍再把武器/UI 画回去。要让两边对得上，我们自己的遮罩也必须变成**羽化的 alpha（1–2 px）**，而不是现在这版硬边 1 bit。
3. **陷阱（必须写进代码注释）**：当 `UIColorAlpha` 与 `Backbuffer`/`HudlessColor` 是**同一个指针**时，整帧被当成 UI ⇒ **完全不出画**（表 A 的 `--uialpha color` 三条全是 0.000000%）。我们必须给它一张**独立纹理**；这同时解释了台架早期“绑定 color 就没扭曲”的怪现象。
4. **alpha 位深**：CP2077 后台缓冲是 R10G10B10A2（alpha 只有 **2 位 ⇒ 4 档**），所以软边界**必须放在独立纹理里**（BGRA8/R8 的 8 位 alpha）。台架实测 256 档线性。
5. `UsePremultiplyUIAlpha`（我们的 `--premul` / cbuffer 里那一项）实测**无任何差别**；不要为它写代码，也别把它当开关。

### Z5.3 对 P3-E（MFG 共存）的直接影响
* “一帧内 N 次 eval、每次新目标姿态、谁最后写谁上呈”这条形态**在 API 层成立**：没有硬件 FG 也能验证（表 C）。
* **不要用 sha256 做回归判据**：同命令连跑三次输出都不同（±30 px）。判据用 **`diffPixels` 落在窄带内** + “两次运行差异 < 0.02%”这种**容忍度断言**；恒等域（`--evalsperframe 1` / 不开 pass2newest）仍可逐字节判定。
* 多次 eval **带状态**（与“最后一个姿态的单遍”差约 500 px）。在真 FG 环境里这意味着：**上呈链上每次 warp 都要从同一张已渲染帧、用当次最新姿态重算**，而不是在上一遍输出上叠；P3-E 必须按这个前提设计。
* 2 位 alpha 的合成路径（生成帧没有深度、只有旋转）见 Z4.2 第 5 条，不受本轮影响。

### Z5.4 本轮新增的台架能力 + 复现命令
* `fwtest.cpp` 新增一个**只读输入**开关（老开关行为不变）：
  `--uialpha file --uialphafile <FWDMP1 raw>`：把 `Latewarp.UIColorAlpha` 绑到一张**独立**纹理，用来把“UI 的 RGB / alpha / 覆盖来源”三者解耦。`--uialpha hud --uihud N` 只能做一条水平硬切，回答不了“软边还是 0/1”。
* 改完必须重建（台架是自用仪器，不属于交付物）：`cmd /c build.cmd` → `fwtest.exe`（本轮已重建，`BUILD_EXIT=0`）。
* 复现：`& .\p3a_matrix.ps1`（表 A）、`& .\p3a_uifile.ps1`（表 B）、`& .\p3a_mfg.ps1` / `p3a_mfg2.ps1`（表 C）、`python .\p3a_fine.py`（表 D）；输入构造脚本 `p3a_mkui.py` / `p3a_mkseq.py`，输入/输出都在 `_re\demo_re\harness\p3a\*`。

### Z5.5 下一步
* **P3-A 完成**（三问都有结论，全程不需要使用者跑游戏）。
* 下一刀 **P3-B late latch 打点（纯日志）**：`姿态年龄 = 记录时刻 − 相机采样时刻`、该窗口内的鼠标原始增量、**下一帧游戏相机的实际增量**。**需要使用者跑 60 秒** —— 按红线，开跑前请使用者先说一句 **「暂停目标」**，跑完只收 `OptiScaler.log`。
* P3-C 的设计按 Z5.2 改（同帧软 alpha 遮罩 + `UIColorAlpha` 独立纹理 + 撤掉 1 bit 抖动），等 P3-B 的姿态年龄数据出来后一起排优先级。

## 附录 Z6 —— 第 86 轮：P3-1/P3-2/P3-0a **已撤回**（面板只剩 4 行）+ 新装机哈希 + 一个坑

### Z6.1 面板现在是什么样
Advanced Settings 页只保留：**接管开关（先勾这个）/ 静态元素可视化 / 诊断记录 / 深度阈值**。
`让位强度`、`补洞强度`、`姿态超前` 三行**连同配置项、ini 键、cbuffer 字段、着色器代码、GPU 调用点一起删除**，
门禁 L4 新增断言「这三个名字在应用后的树里出现 0 次」（实测 `mentions=0`）。

### Z6.2 为什么删（使用者裁定，不要再造）
* 撕裂 → **超渲染裁切**（抬 FOV + 中心裁切，P3-F），不是把边缘 ramp 回未扭曲帧；
* 补洞 → **内核自带**，我们的 history 回填与它重叠；
* 姿态超前 → **预测 ≠ 机制**，Reflex 2 = late input sampling。

### Z6.3 保留了什么
P3-3 诊断**全部保留**（`BuildReprojectionMatrices` / history 纹理 / 热图 / 掩码统计；`DiagMap` 默认 **0**），
`NoWarpMask` 合成路径保留（P3-C 才会换）。`ComputeLeadFill` / `BuildExtrapolatedWorldToView` 两个纯数学函数
与其单测**保留但已无调用者**，头文件按“已撤回”标注 —— 下一轮做 P3-C 时顺手删掉。

### Z6.4 哈希（取代 Z4/Z5 里的一切旧值）
* 装机 `dxgi.dll` sha256 = `D5781664F6D519F9793B33840FC6150AEC7541F67FFFE9617C921125D10622B0`（installed==built）
* 交付包 sha256 **故意不写进包内文档**（包里的 `docs\HANDOFF_P3_NEXT.md` 自己也是包的一部分，重打包即失效）——记在 `LOG.md` 第 86 轮，48 文件
* 补丁集 = **48 处 / 10 文件（8 改 + 16 增）**；`verify_p2.ps1 -Full` = PASS。

### Z6.5 工具链坑（照做省一整轮）
**不要再对 `apply_to_optiscaler.ps1` 用 `[IO.File]::WriteAllLines`**：它写成 CRLF，脚本里的 here-string 会把 `\r\n`
带进 LF 的目标文件，随后所有 literal 锚点静默失配（报的是后面那条补丁 matched 0 times）。脚本必须保持 **LF**。

### Z6.6 下一步的硬前提
使用者第 85 轮那次运行里 `Latewarp.UIColorAlpha` 查询返回 `0xBAD00010`，而 Z5 的软-alpha 结论全部来自台架。
**P3-C 动 `UIColorAlpha` 之前，先弄清真机里这条参数到底是“查不到”还是“不存在”**；
在此之前不要把 Z5 的 `UIColorAlpha` 方案当成已在游戏里可用。

## 附录 Z7 —— 第 87–88 轮：`0xBAD00010` 已解释 + **P3-B 打点已装机**（下次运行就能采数据）

### Z7.1 `0xBAD00010` 不是坏消息
真机里六条 plane 查询**全部**返回它，包括 `Depth`/`Output`/`MotionVectors`（内核确实在用）⇒ 是我们调用的
`Get(key, void**)` 没落在 GetPtr 上。台架 RE：**GetPtr = vtable 槽 8**。探针已按槽 8 改写并新增身份判定行：
`latewarp: plane probe: uialpha{+/-} hudless{+/-} backbuffer{+/-} sameAsHudless={0|1} sameAsBackbuffer={0|1}`。
Z6.6 里那个「P3-C 前必须弄清」的硬前提**解除**：下次运行就能看到真机里 `UIColorAlpha` 是否存在、是否与帧同指针。

### Z7.2 P3-B 采什么（下次运行的有效数据）
`latewarp-latelatch: pose age X ms | present gap Y ms | age/gap Z | camera turn T deg | sampled frame F | fps P`
* `age/gap → 1`：我们交出去的姿态几乎整整一帧旧，**晚采样有空间**（P3-D/E 值得做）；
* `age/gap → 0`：采样已经贴着 Present，这层没有剩余窗口，瓶颈在呈现链（该往 MFG/呈现时序上找）；
* `camera turn`：`age` 大且 `turn` 大才是有效样本。**跑的时候请持续转视角/压枪 30–60 秒**，别站着不动。
* 我们没有读游戏原始鼠标增量（要 hook 游戏输入系统）；`camera turn` 是包含同一份输入的等效观测量。

### Z7.3 当前交付物哈希
* 装机 `dxgi.dll` sha256 = `E34433FC930B2750F8C8934CB4834965B1A1A3C375FB5294FF8EB121E0353185`（installed==built）
* 补丁集 = **49 处 / 10 文件（8 改 + 16 增）**；`verify_p2.ps1 -Full` = **PASS**；`make_patch_review.ps1` = PASS
* 交付包 sha256 记在 `LOG.md` 第 88 轮末尾（**故意不写进包内文档**：包里的本文件自己也是包的一部分）

### Z7.4 下一步（我的清单，无需使用者决策）
1. 使用者跑一次（30–60 秒，持续动视角）→ 采 `latewarp-latelatch` 与新的 plane probe；
2. 依据 `age/gap` 判定 P3-D/E 的优先级；依据 plane probe 决定 P3-C 走 `UIColorAlpha` 还是先在 `NoWarpMask` 上做软边；
3. 清理 `ComputeLeadFill` / `BuildExtrapolatedWorldToView` 及其单测（已无调用者）。
* 跑游戏一律由使用者执行；**开跑前先让他说「暂停目标」**。

## 附录 Z8 —— 第 89 轮：死代码清理完成 + P3-B 分析器 + 交接注意

### Z8.1 已完成（本轮）
* P3-1/P3-2/P3-0a 的**死数学与单测全部删除**（`ComputeLeadFill` / `BuildExtrapolatedWorldToView` / `BackgroundPyramid` /
  `UpdateBackgroundPixel` / `ReprojectClip` / `ClipToWorld` / `RowTimesMat`）；`LatewarpParams_test.cpp` 676→483 行。
  保留 `BuildReprojectionMatrices`（诊断）与 `BuildWorldToView`（P2 矩阵路径）。
* 新增 `p2\analyze_latelatch.ps1`（`-SelfTest` 通过）：一条命令把下一份日志变成三个数字 + 一个 VERDICT + plane probe 判定。
* 门禁全绿：`verify_p2.ps1 -Full` PASS / `make_patch_review.ps1` PASS / 48 文件包 / 装机。

### Z8.2 还没做（按优先级，都不需要我再猜方向）
1. **P3-B 采集**（等使用者跑一次，30–60 秒持续动视角）：`& .\analyze_latelatch.ps1 -Log <game>\bin\x64\OptiScaler.log -MinTurnDeg 0.05`
   → 看 VERDICT 与 plane probe 两行。
2. **P3-C 掩码重做**：路线由 plane probe 决定（独立指针→走 `UIColorAlpha` 软 alpha；没给→在 `NoWarpMask` 上把我们的 alpha 羽化）。
3. **P3-D 纯旋转 2D 晚 warp**：只在第 1 步给出 HEADROOM 时才值得做。
4. 台架上给 P3-C 补一条离线验证（软 alpha 的 256 档 vs 1-bit 抖动的边界对比已由 Z5 的表 D 覆盖，可直接引用）。

### Z8.3 交接注意
* **目标 `goal-c246feb9-9df9-4ab5-9bcb-231024fddb88` 现在是使用者主动暂停（paused/disarmed）**；模型不能自己 resume，
  要续跑必须由使用者发话。要跑游戏仍然先请使用者说「暂停目标」。
* `apply_to_optiscaler.ps1` **必须保持 LF**（用 `WriteAllLines` 重写会把 here-string 变成 CRLF，锚点会静默失配——Z6.5）。
* 每次 apply 会重写 `resource_build_date.h` ⇒ **dll 不是逐字节可复现的**；`installed==built` 只对同一次 apply→build→install 成立。

## 附录 Z9 —— 第 90 轮：**P3-B 实测结论（20 fps 锁帧）** + 探针站点标签修正

### Z9.1 P3-B 的答案：晚采样最多值 ~6.5 ms
使用者锁 **20 fps** 跑了一次（约 5800 帧，66 个 `latewarp-latelatch` 样本，其中 52 个 `camera turn ≥ 0.05°`）：
```
pose age    : mean 6.47 ms   max 7.28 ms        (5.9–7.3 ms，极稳定)
present gap : mean 49.42 ms  (20.3 fps，与锁帧一致)
age/gap     : 0.13
camera turn : mean 2.10 deg   max 14.75 deg     (样本有效，人在动)
```
⇒ **我们交给内核的姿态只旧约 6.5 ms**。晚采样（P3-D）的绝对收益上限就是这 6.5 ms；
帧率越高这个数字占一帧的比例越大（60 fps 下约 39%），但**绝对值不变**。
与 HPG 2020「消除 80 ms 额外延迟惩罚的 80%」不是一个量级 ⇒ **P3-D 暂缓**，
延迟的大头是 present gap（锁 20 fps 时 50 ms），即呈现链 / MFG 时序（P3-E）与帧率本身。
**待补**：一次**不锁帧**的同长度复跑，确认 pose age 是否恒定 ~6.5 ms（若是，则它是渲染→呈现链上的固定量，与帧率无关）。

### Z9.2 探针的站点标签（修掉一个自欺缺陷）
第 89 轮把 `Get(key, void**)` 改成 vtable 槽 8 时，我删掉了**原始返回码**和**调用点**信息；
于是第 90 轮日志里六条全 MISSING 被误读成「游戏不给 UIColorAlpha」。真因是：
唯一触发的探针在 `LatewarpFeature_Dx12.cpp` 的 `p2::Fill` **之前**，对象还是空的。
现在：`LogPlaneProbe(params, site)` 必带站点标签 + 恢复原始返回码，三个站点分别是
`fresh-params/before-fill`（空对象，无意义）、`app-params/before-rewrite`（应用给的；**本部署不会触发**，
因为 OptiScaler 跑在 dxgi.dll，游戏的 NGX 调用进的是自备真 `nvngx.dll`）、`after-fill`（**我们**绑的，用来证明槽 8 可读）。
`analyze_latelatch.ps1` 的 plane 判读按站点重写（`-SelfTest` 通过）。

### Z9.3 对 P3-C 的影响（结论：更简单了）
自建路**自己拥有全部 49 个参数**，所以 P3-C **不需要**游戏给什么：直接给内核一张**我们自己的** `UIColorAlpha`
（8 位 alpha 覆盖，独立纹理）→ 内核做逐像素软淡化（Z5 表 D），`NoWarpMask` 退场。
落地前先在台架确认一件事：**内核是否接受与帧不同格式的 UI 纹理**（R8 vs BGRA8/R10G10B10A2），这决定实现形态。

### Z9.4 本轮门禁
`verify_p2.ps1 -Full` = **PASS**（补丁 49 / 16 新文件）；期间抓到我自己的一个陈旧 marker：
改了 `GetPtrSlot` 的返回行文本后忘了同步门禁 marker（`return ((PFN_NgxGetPtr) vt[8])…`），已改为新文本。

## 附录 Z10 —— 第 91 轮：pose age 与帧率无关（86 fps 下占 0.61 帧）+ 晚输入源事实修正

### Z10.1 P3-B 最终答案（两次运行）
| 运行 | 帧率 | pose age (mean) | present gap | age/gap |
|---|---|---|---|---|
| 锁 20 fps | 20.3 | 6.47 ms (max 7.28) | 49.42 ms | 0.13 |
| 不锁帧 | 86.2 | 7.18 ms (max 15.14) | 12.14 ms | **0.61** |
⇒ **pose age 与帧率无关（~6.5–7.2 ms）**；比值随帧率变化，玩家实际帧率下约 **0.6 帧**。
晚采样的绝对收益上限 = ~7 ms；相对收益 = 一帧的六成。**P3-D 值得做，但前提是有晚输入源。**

### Z10.2 晚输入源：我们目前没有（修正旧记录）
`menu\input\input_system_raw.cpp` 等文件属于 **OptiScaler 的输入层**，不是游戏；其累加有门控
`!ExternalTargetProcess || InputHwnd != nullptr || !Focused` ⇒ 那是「外部目标进程虚拟鼠标」功能，正常游玩不累积。
可用的两条路：**(a) 我们自建 `RIDEV_INPUTSINK` raw-input 接收端（只读）+ 灵敏度标定**（推荐）；(b) RE 游戏输入系统（重）。

### Z10.3 下一步（按建议顺序）
1. **P3-C**：给内核一张**我们自己的** `UIColorAlpha`（8 位 alpha、独立纹理）→ 软界面边界，`NoWarpMask` 退场。
   落地前先在台架确认内核接受**与帧不同格式**的 UI 纹理（R8 vs BGRA8）。
2. **P3-D-0 探针**：自建 raw-input sink + 日志（每帧原始鼠标计数 + 相机转角），一次运行完成标定。
3. 再决定 P3-D 的微 warp（旋转-only、限幅）。

### Z10.4 实测附带确认
`plane probe [after-fill]: depth+ output+ uialpha- hudless+ backbuffer+`：第 90 轮修的**槽 8 读回在真机工作**；
`UIColorAlpha` 当前绑 null（P3-C 之前的预期）。

## 附录 Z11 —— 第 92 轮：存档位置 + `UIColorAlpha` 格式定案（P3-C 实现前必读）

### Z11.1 存档（NoWarpMask 版，独立可取）
`_re\reflex2_mod\versions\P3C-pre_noWarpMask_20260928\` —— 内含 `p2\**`（49 补丁那版工具链+源码）、
`OptiScaler_preP3C_noWarpMask.dll`（`5F9ED4D3…`）、`dist\..._preP3C.zip`（`64546D1C…`）、文档快照与 `MANIFEST.md`。
取用方式（MANIFEST 里有详细命令）：只取 dll / 并存一套源码 / 整体覆盖回 `p2\`。**这不是 git 回退，当前补丁集不受影响。**

### Z11.2 `UIColorAlpha` 的格式要求（实测，别猜）
| UI 纹理格式 | 结果 |
|---|---|
| BGRA8（帧的格式） | 软交叉淡化，单调 ✔ |
| R8G8B8A8_UNORM | **与 BGRA8 逐位相当** ✔（格式不必等于帧格式） |
| R8_UNORM | **整屏当 UI，全帧原样返回（0% 变化）** ✘ |
⇒ P3-C 必须**新分配一张 4 通道纹理**（alpha 8 位）来装覆盖；R8 掩码纹理与 `NoWarpMask` 一起退场。
⇒ 也意味着不能用后台缓冲当 UI 纹理（R10G10B10A2 只有 2 位 alpha）。

### Z11.3 P3-C 的落地清单（下一轮直接照着做）
1. `LatewarpUi` 计算着色器：把 `uiMask` 的**软值**写进新纹理 alpha，**去掉蓝噪声量化**（抖动只属于旧的 NoWarpMask 路径）；
2. 新纹理：4 通道、present 尺寸、UAV；`NoWarpMask` 的 R8 纹理随之删除；
3. 绑定：`Latewarp.UIColorAlpha = 新纹理`、`Latewarp.NoWarpMask = nullptr`（`nullOutUIColorAlpha` 改 false）；
4. 覆盖在 `Evaluate` **之前**产生（同帧）；
5. 门禁链（DryRun→Revert→apply→build→verify -Full→review→release→install），marker 按语义更新；
6. 实机验收：武器/UI 边界不再抖动（这是使用者最初的抱怨），且 `plane probe [after-fill]` 应显示 `uialpha+`。

### Z11.4 其它仍然有效
* P3-D（晚采样）：pose age ~7 ms、86 fps 下占 0.61 帧 ⇒ 值得做；但**缺晚输入源**（见 Z10.2），需先做 P3-D-0 探针（自建 `RIDEV_INPUTSINK`）。
* 目标由使用者暂停；给他数据/口令后才继续。

## 附录 Z12 —— 第 93 轮：P3-C 已装机（软 alpha 走 UIColorAlpha，NoWarpMask 退场）

### Z12.1 现状（改完并已装机）
| 项 | 内容 |
|---|---|
| 掩码机制 | **软 8-bit alpha 覆盖率**（内核逐像素交叉淡化），旧的 **1-bit 蓝噪声 NoWarpMask 硬门控已退场** |
| 纹理 | 两条 **RGBA8** UI-alpha（轮转，覆盖是**上一帧**算的）；`u1` 槽位不变，根签名不变（5 SRV / 3 UAV / 1 CBV） |
| 绑定 | `Latewarp.UIColorAlpha = 我们的 UI 纹理`（必须 4 通道、必须与 Hudless/Backbuffer 不同指针）；`Latewarp.NoWarpMask` 不再写 |
| 着色器 | `RWTexture2D<float4> UiAlpha : register(u1)`，写出 `float4(0,0,0,uiMask)`；量化逻辑删除；cso 已重编 |
| 装机 | `dxgi.dll = EB4663C48CC28C8A3EEC7C94C6CBE3F2ECB8C4CD17BAB614A7838C92D27904AD` |

### Z12.2 下一轮（按优先级）
1. **同帧覆盖**：把覆盖计算拆成 `Evaluate` 之前的一次 dispatch（当前是上一帧），这是 Z3.9.4a 的 a；
2. **清死代码**：`LatewarpBlueNoise32.h`、cbuffer 里的 `BlueNoiseWords`（cso 已标 unused）、`Bayer4x4`；清它们要重钉 static_assert 偏移；
3. **过渡带**：视实机观感决定是否去掉我们自己的那一次 `lerp`（让内核独占）；
4. **P3-D-0**：自建 `RIDEV_INPUTSINK` 只读探针 + 灵敏度标定（服务帧生成延迟这个大头）。

### Z12.3 存档仍在
`versions\P3C-pre_noWarpMask_20260928\`（NoWarpMask 版：dll `5F9ED4D3…`、包 `64546D1C…`、MANIFEST 说明三种取用方式）——
本次 P3-C 改动**没有**动它，随时可以拉出来与软 alpha 版并行对比。

## 附录 Z13 —— 第 94 轮：P3-C **完成**（同帧覆盖已落地）

### Z13.1 现状
| 项 | 内容 |
|---|---|
| 覆盖的产生 | **`DispatchCoverage` 在 `Evaluate` 之前**跑（T41），只写 UI-alpha 环纹理；合成那一遍（`Dispatch`）不再写它 |
| 环的推进 | 由 `DispatchCoverage` 负责（谁写谁推进），合成不再 flip |
| 常量缓冲 | 覆盖遍用独立的 `_coverageConstantBuffer`（避免与合成共用导致 GPU 读到错的那组） |
| cbuffer 布局 | `DiagMap 4260 / DiagRefPx 4264 / CoverageOnly 4268`（与 C++ `static_assert` 逐条对齐，已看 fxc reflection） |
| 补丁 | **50 处 / 10 文件 / 16 新文件**；孪生 HLSL 348 行一致 |
| 装机 | `dxgi.dll = 78D080A6066AA12E6B0A8A93BD01D041DD9AE0C5CB831FFE3766E1E4881498B6` |

### Z13.2 必须记住的教训
**加/移 cbuffer 字段后要看 fxc 的 reflection 偏移**（`LatewarpUi_Shader.h` 顶部注释里就有），不能只信 C++ 侧的 `static_assert`：
本轮 `CoverageOnly` 错位 8 字节，会让覆盖遍静默失效（alpha 全 0 → 武器/UI 被扭），且**没有任何运行时报错**。

### Z13.3 下一步
1. **P3-D-0**：自建 `RIDEV_INPUTSINK` 只读接收端 + 日志（每帧原始鼠标计数 + 相机转角）→ 灵敏度标定，服务帧生成延迟（~7 ms 姿态年龄）；
2. 清死代码：`LatewarpBlueNoise32.h`、cbuffer 的 `BlueNoiseWords`（fxc 已标 unused）、`Bayer4x4`；清 cbuffer 字段时**务必按 Z13.2 复核偏移**；
3. 实机验收 P3-C：武器/UI 边界不再抖动，且 `plane probe [after-fill]` 显示 `uialpha+`。

## 附录 Z14 —— 第 95 轮：P3-D-0 探针已装机（自建 raw mouse sink）

### Z14.1 现状
| 项 | 内容 |
|---|---|
| 接收端 | 我们自己的 `RIDEV_INPUTSINK` + 隐藏窗口（独立线程消息循环），原子累加 `WM_INPUT` 增量；**不改游戏鼠标**、不消费、不影响行为 |
| 位置 | 实现 `LatewarpFeature_Dx12.cpp`（游戏专用 TU；离线单测编译的 `LatewarpFrameData.cpp` 不能含 Windows 代码），声明 `LatewarpFrameData.h` |
| 打点 | `latewarp-latelatch: ... | rawMouse dx dy | sink 0xNN`（T40 扩展，补丁数不变=50） |
| sink 位 | bit0 started / bit1 registered / bit2 deltas-seen / bit3 window-failed / bit4 register-failed |
| 分析器 | `analyze_latelatch.ps1` 输出 sink 解释 + 标定样本的 counts/frame、deg/frame 与 **deg per count** |
| 装机 | `dxgi.dll = 149881BC2790457A080B40AD24B47A3E5B863EE90644116D393B0CF0FB2D265C` |

### Z14.2 需要的运行方式
**整场持续移动鼠标/转视角 30–60 秒**（标定要求同一批帧里既有原始增量、又有相机转角）。
跑完即可得灵敏度与姿态年龄复核；**没有任何画面行为依赖这些数据**，所以这次运行是纯采集。

### Z14.3 之后
1. 灵敏度到手 → 设计 P3-D 微 warp：`angle = counts_since_camera_sample x sensitivity`，**限幅 + 死区**，只做旋转；
2. 清死代码（`LatewarpBlueNoise32.h` / cbuffer `BlueNoiseWords` / `Bayer4x4`），改 cbuffer 字段务必复核 fxc reflection（Z13.2）；
3. P3-C 的实机观感验收（边界不抖、`uialpha+`）。

## 附录 Z15 —— 第 96 轮：无死代码版（偏移表已更新，务必按此对表）

### Z15.1 cbuffer 偏移（fxc reflection 实测，`static_assert` 已对齐）
`DiffThreshold 0 / ShowMask 4 / DepthCutoff 8 / CutoffExpandPx 12 / InvertedDepth 16 / InvScreenWidth 20 /
InvScreenHeight 24 / **InvVPCur 32 / VPPPrev 96 / DepthFlipY 160 / DiagMap 164 / DiagRefPx 168 / CoverageOnly 172**`
（那 4096 字节的蓝噪声数组已删除——以后若有人想再加“大数组”，**先看 Z13.2 与这段**。）

### Z15.2 交付物变化
| 项 | 值 |
|---|---|
| 新增源文件 | **15**（原 16，删了 `LatewarpBlueNoise32.h`） |
| 交付包 | **47 文件**，sha256 `A1FC89D4A95C28DE8D83FC61F50925C61A148BA877B79C017BC4BBAE4ABAECD9` |
| 补丁集 | 50 处 / 10 文件 |
| 孪生 HLSL | 336 显著行一致 |
| 装机 | `dxgi.dll = A9D48E6327E4E9CF1D8CA59A848CFF1C5D5DD4104B24C9155319037AEFA7AAA4` |

### Z15.3 下一步（数据驱动）
1. 使用者跑一次（**整场持续动鼠标/转视角** 30–60 秒）：同时验收 P3-C 边界观感与 `plane probe [after-fill]=uialpha+`，并采 `rawMouse`；
2. `analyze_latelatch.ps1` 给出 **deg/count 灵敏度** → 设计 P3-D 微 warp（限幅 + 死区，仅旋转）；
3. 若灵敏度噪声大（同帧 counts↔turn 相关性差），退一步只做「按姿态年龄限幅的固定小角度补足」，也仍然是真实收益。

## 附录 Z16 —— 第 97 轮：同帧覆盖遍**引发实机崩溃，已撤销**

### Z16.1 结论（一句话）
第 94 轮加的 `DispatchCoverage`（在 `Evaluate` **之前**跑）对后台缓冲硬套 `D3D12_RESOURCE_STATE_PRESENT` 做状态转换，
而那一刻它还不是 PRESENT ⇒ 第 1 帧设备移除、进程硬崩（日志最后两行就是它新建的两张覆盖纹理，`latewarp: eval` 全程 0 次）。
**该路径已整体撤销**（补丁 T41 / `DispatchCoverage` / `CoverageOnly` / `_coverageConstantBuffer` 全部删除，环轮转还给 `Dispatch`）。

### Z16.2 当前装机（撤销后）
* `dxgi.dll` = `62C5D222F449BDD9BBE5B59DCB73A47D000032076363BC9C1E3F006CB51F747F`（installed==built）
* 交付包 = `5A360A5743F6DE30D08877E86F5227FDEE07AE1AD87B0107050371E2B813B8B3`（47 文件）
* 补丁 **49** 处 / 10 文件 / 15 新增；孪生 327 显著行；`verify_p2.ps1 -Full` = PASS
* 含：软 alpha（`UIColorAlpha`）+ P3-D-0 探针 + 死代码清理；**不含**同帧覆盖（覆盖=上一帧）
* 安全网：`versions\P3C-pre_noWarpMask_20260928\OptiScaler_preP3C_noWarpMask.dll`（sha `5F9ED4D3…`）可一键换回

### Z16.3 同帧覆盖重做的前置条件（下次照此做）
1. 不硬编码任何输入资源的当前状态；2. 优先只用 `hudless`+`depth`（或有跟踪状态的副本）；
3. 转换前先打日志；4. **一张新 GPU 路径单独一个构建**（使用者的红线，本轮就是没做到）。

## 附录 Z17 —— 第 98 轮：原始鼠标探针已撤销（抢输入），晚输入源改路线

### Z17.1 结论
**在游戏进程内二次注册鼠标原始输入 = 抢走游戏的 `WM_INPUT`**（同用途最后一次注册决定投递窗口）⇒ 鼠标全废。
探针已整条撤销；`verify_p2.ps1 -Full` = PASS。当前装机 `dxgi.dll = F324883AC1CAC5D3DF01BA4E569A946D3E131A15693931B292BD76D921A213E0`。

### Z17.2 晚输入源的三条可行路线（择一，单独构建）
1. **WndProc 子类化 + 只旁听**（最贴近真实输入；注意链式转交原 proc）；
2. **`WH_MOUSE_LL` + 回中剔除**（OptiScaler 自带外部路径的判据可借）；
3. **无输入源路线**：按姿态年龄的固定小角度限幅补偿（先易后难、风险最低）。

### Z17.3 仍需使用者验的两件事
1. 鼠标恢复后：**武器/UI 边界是否不再抖动**（P3-C 的主验收，一直还没拿到）；
2. 若边界仍不满意，按 Z12 的取舍调整（过渡带二次混合 / 掩码软硬）。

### Z17.4 工具纪律（本轮血的教训）
脚本化删代码：**先打印将要删除的行区间、确认后再执行**；生成物树（`_re\repro_src`）是我的最后一道备份。

## 附录 Z18 —— 第 99 轮：覆盖率二值化 + 可观测性（双影=软 alpha 的必然结果）

### Z18.1 一句话
**软 alpha 在分数覆盖率处就是“按比例混合两张图”= 双影**；抖动当年正是防这个。
现在覆盖率二值化（仅 5% 阈值宽的羽化）⇒ 无抖动、无重影带。装机 `dxgi.dll = 7302B7D09319B57995DE9806AC3588E90184581667E70A84CBB55C8698315DD0`。

### Z18.2 新增日志（下次运行的关键证据）
| 行 | 含义 |
|---|---|
| `latewarp-uialpha: bound ptr …` | 内核这一帧**确实拿到**了我们的 UI-alpha 纹理 |
| `latewarp-uialpha: NOT bound …` | 环没准备好（此时内核完全无遮罩，武器会被扭） |
| `latewarp-diag: frame … mask …% (cutout …%) diff …` | 自动打开前 600 帧：掩码占比 / 其中来自**深度裁出**的比例 / 颜色差强度 |

### Z18.3 判断树（下轮直接用）
1. `NOT bound` → 修 ring 生命周期（合成→绑定的时序）；
2. `bound` 但 `cutout ≈ 0%` → **深度谓词没选中武器**：查 `InvertedDepth` 语义 / 深度格式 / cutoff 方向；
3. `bound` 且 `cutout` 正常但仍有双影 → 覆盖率在某些区域仍是分数（再看 `mask%` 与 `diff`），或我们的合成与内核双重混合。

### Z18.4 备份与回退
NoWarpMask 版存档仍在 `versions\P3C-pre_noWarpMask_20260928\`（dll `5F9ED4D3…`），一条 copy 即可回退。
