# SPEC: LATEWARP 的真实 API 路径 (PDB 证据) — 对 harness "不 warp" 的解释

证据来源: demo(StreamlineSample.exe) 的 PDB 符号导出产物, 在 `_re\demo_re\` 下:
  sym_publics.tsv / sym_types_latewarp.tsv / sym_locals_latewarp.tsv / sym_lines_latewarp.tsv / asm_*.txt
  (符号来自 NVIDIA 的 Streamline 示例 Debug 构建: F:\GithubMods\DLSS\Streamline_Sample\...\StreamlineSample.obj)
等级: [T1] 直接从 PDB 读出; [T0] 二进制导出表; [INFERRED] 标注推理。

## 1. 关键新事实: latewarp 有**专用结构体 API**, 不是只靠 43 个字符串键 [T1]

`NVSDK_NGX_D3D12_Latewarp_Eval_Params` (216 字节):
```
+0    void* InBackbuffer            +8   void* InHudlessColor        +16  void* InUIColorAlpha
+24   void* InDepth                 +32  void* InMotionVectors       +40  void* OutColor
+48   void* InNoWarpMask
+56   Coordinates InBackbufferSubrectBase      +64  Coordinates InHudlessColorSubrectBase
+72   Coordinates InUIColorAlphaSubrectBase    +80  Coordinates InDepthSubrectBase
+88   Coordinates InMVSubrectBase              +96  Coordinates InNoWarpMaskSubrectBase
+104  Coordinates InOutputSubrectBase
+112  Dimensions InBackbufferSubrectDimensions +120 InHudlessColorSubrectDimensions
+128  InUIColorAlphaSubrectDimensions          +136 InDepthSubrectDimensions
+144  InMVSubrectDimensions                    +152 InNoWarpMaskSubrectDimensions
+160  InOutputSubrectDimensions
+168  uint  FrameID        +172 bool DepthInverted    +173 bool UsePremultiplyUIAlpha
+176  float InJitterOffsetX  +180 float InJitterOffsetY
+184  void* WorldToViewMatrix                 +192 void* ViewToClipMatrix
+200  void* PrevRenderedWorldToViewMatrix      +208 void* PrevRenderedViewToClipMatrix
```
`NVSDK_NGX_Latewarp_Create_Params` (8 字节): `+0 uint InOutputWidth`, `+4 uint InOutputHeight`。
`sl::LatewarpOptions` (2 字节): `+0 bool latewarpActive`, `+1 bool predictiveRenderActive`。

## 2. demo 侧调用链 [T1, 符号名+长度一致]
```
StreamlineSample::SetLatewarpOptions   rva 0x8B130  len 1322   局部变量: sl::ReflexCameraData cameraData / sl::LatewarpOptions lwOptions
  -> NGXWrapper::SetLatewarpOptions    rva 0x71D40  len 13     入参 sl::LatewarpOptions const&
  -> NGXWrapper::EvaluateLatewarp      rva 0x71D60  len 7081   组装 NVSDK_NGX_D3D12_Latewarp_Eval_Params 并调用
       (函数内有 __l6/__l17/__l19 三个 ETW _tlgEvent 块 => 三段独立事件路径)
TResources: NGXWrapper::TagResources_Latewarp rva 0x7BC90 len 23 (一个转发桩)
                                参数: (nvrhi::ICommandList*, donut::engine::IView const**, ITexture*, ITexture*, sl::Extent)
可用性: NVWrapper::GetLatewarpAvailable rva 0xB2180 len 20 ; NVWrapper::Get_Latewarp_SwapChainRecreation rva 0x7BB30
相机:   NGXWrapper::SetReflexCameraData(sl::FrameToken&, sl::ReflexCameraData const&) ;
        NGXWrapper::ReflexCallback_RenderStart/Sleep/SimStart ; ReflexTriggerPcPing/Flash ; QueryReflexStats
```

## 3. 谁是 216 字节结构体的消费者 (没有专用导出) [T0+T1+INFERRED]
- `bin\nvngx_latewarp.dll` 40 个导出**无**任何 Latewarp/Tag/Resource 专用函数 (标准 D3D11/D3D12/Vulkan 集合)。[T0]
- `bin\realdir\nvngx.dll` (核心) 71 个导出同样**无** latewarp 专用函数。[T0]
- 游戏里 NGX 的 Init 被 **Streamline 自己的代理劫持**: 驱动日志 `appExeName = 190_E658700.dll`(Streamline), `drsProfileName = Cyberpunk 2077`, `cmsId = 100152211`。[T1, 来自 harness 记录]
- demo 的 `SetLatewarpOptions` 用的是 **`sl::`** 命名空间结构体。[T1]
=> [INFERRED] latewarp 的评测路径是 **App -> Streamline(选项/相机数据) -> NGX/驱动**, 而那 216 字节结构体是这条路径上的中间 ABI,
   不是 NGX 的公开导出参数。**仅靠设置 43 个 `Latewarp.*` 字符串键不足以让它真正发生 warp。**

## 4. 这解释了 harness "NOT A WARP" [T1 + 推断]
`_re\demo_re\harness\RESULTS.md`: 自建 exe(fwtest.exe) 用 demo 的同样 49 个参数得到 `PSNR(OUT,IN)=99.00dB`(逐比特拷贝),
并已逐项排除: 颜色/输出/深度格式、纹理 flags、IsRenderedFrame、FrameID 推进、MV 大小、Init sdkVersion、app id(4 个值)、exe 名。
**未做的正是资源标记/专用结构体这条路径** -> 载荷 `[0,0x40)` 的 7 个句柄没有资源可绑 -> 内核读到"未绑定"(0) -> 输出=input。
与我们在真机上实测到的"demo 进程里 `[0,0x40)` 是**非 0** 的 0xC020C8xx"完全自洽:
  那些句柄来自**资源绑定侧**(驱动/Streamline/NGX 标记路径), 而不是 feature DLL 或我们的参数设置。

## 5. 对 mod 架构的硬性影响 (必须写进 ADR-001)
1. **纯 P1(只做 `nvngx.dll` 代理 + 设 43 键) 只能"跑起来", 不会真 warp** —— 因为缺资源标记与选项路径。
2. 要真 warp, 必须走 **Streamline 侧接入**: 让进程里的 Streamline 认为 "latewarpActive=1" 并提供相机数据,
   或者由我们直接构造 216 字节 eval params 并交给正确的消费者。
3. 可用性闸门 `GetLatewarpAvailable` 与 `Get_Latewarp_SwapChainRecreation` 是 demo 的判定入口, 需要在我们的实现里做等价判断。
4. 目标游戏里 Streamline 代理(190_E658700.dll / sl.interposer 等)已经存在 —— 这给了我们天然的**注入点**(OptiScaler 已经在 hook Streamline 相关路径)。

## 6. 下一步要回答的问题 (S5/S6 前置)
Q-A 216 字节结构体由哪个模块的函数消费? (候选: sl.interposer / sl.reflex / 190_E658700.dll / NGX 参数对象的扩展键)
    —— 手段: 在 demo 进程里对 `NGXWrapper::EvaluateLatewarp` 的间接调用点(如 0x72515/0x72A4 处的 `call rdx`)下断/取目标;
       或用我们的探针脚本对 demo 进程内存里该函数体的 call 目标做解析。
Q-B `sl::ReflexCameraData` 的字段布局 (决定我们要喂什么相机数据)。
Q-C OptiScaler 是否已有 Streamline/Reflex 侧的 hook 可复用 (S3 的问题清单里加进去)。

## 7. 更正 (2026-09-26, T2 自测) —— §3/§4/§5 的结论写错了

**§5.1 "纯 P1(只做 nvngx.dll 代理 + 设 43 键)只能'跑起来', 不会真 warp" 是错的。**
本机亲手复现(命令与原始日志: `_re\reflex2_mod\verify\warp\fwtest.vfy_{ctl,ref}.log`):

| 跑法 | 差分像素 | 判定 |
|---|---|---|
| `fwtest --irf 1 --uialpha color` | 0 / 4665600 = **0.000000%** (逐位拷贝) | 不 warp |
| `fwtest --irf 0 --uialpha null` | 3783280 / 4665600 = **81.088820%**, PSNR 24.30 dB | **真 warp** |

与 `_re\routeA\evidence\routea_hook_proof\PROOF.md` §1 的 `ra_ref = 81.088799%` 一致(同一输入 dump、同一真核)。

**结论修正**:
1. 决定 warp 与否的不是"资源有没有被标记", 而是**两个 app 侧输入**: `Latewarp.IsRenderedFrame`(门控四个矩阵的读取)
   和 `Latewarp.UIColorAlpha`(整屏不透明时把重投影完全盖掉)。这两者都在 43 键白名单内, 因此**参数侧代理足以产生真 warp**。
2. 载荷 `[0,0x40)` 在 demo 进程里本来就是**非 0**(0xC020C8xx), 资源绑定侧一直在正常工作 —— 它从来不是 demo 不 warp 的原因。
   (§4 把"未做资源标记"当成原因是误判; §5.1/§5.2 据此推出的架构结论也随之作废。)
3. §3 关于"216 字节结构体是唯一真路径"的推断**仍未证实**(Q-A 未答), 但**已不再是让游戏 warp 的必要条件**。

**另一条新测得的 ABI 事实(重要, 会让人写出假失败)**:
`NVSDK_NGX_Parameter::Set` 的槽位 0/3/4/6 **不返回任何值(void)** —— 读它的 EAX 只会拿到残留垃圾
(实测被误读成 `0x972732A0`/`0x97273760`)。`_re\demo_re\harness\ngxproxy.cpp` 自己的 thunk 也是按 `void(*)(...)` 调用这些槽位的。
**只有槽位 8 的 `Get` 会返回 result**。因此:
* 指针型写入(`Latewarp.UIColorAlpha`)**可以**用 `Get` 回读来验证(回读 null 且 ret=1 即成功);
* int 型写入(`Latewarp.IsRenderedFrame`)**无法回读**, 只能记录我们写入的值。
