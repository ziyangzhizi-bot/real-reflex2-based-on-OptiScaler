# ---------------------------------------------------------------------------
#  install_latewarp_dll.ps1 -- provide the NGX latewarp FEATURE dll to a target.
#
#  WHY THIS IS A SEPARATE STEP
#    The feature dll (nvngx_latewarp.dll, NGX feature 15) is NOT shipped by the display
#    driver on this machine (verified: 0 hits anywhere under DriverStore) and NGX hard-fails
#    with 0xBAD0000B when the feature dll is not next to the core. So the file has to come
#    from the USER; this script locates their own copy, VERIFIES it, and places it.
#
#  WHAT THIS SCRIPT DELIBERATELY DOES NOT DO (INV-P2, user decision on record)
#    It never downloads anything and never ships, embeds or reconstructs NVIDIA code.
#    If the file is not on the machine, it FAILS with a clear message.
#
#  usage:
#    .\install_latewarp_dll.ps1 -GameDir <dir> -DryRun
#    .\install_latewarp_dll.ps1 -GameDir <dir> -LatewarpDll <path to user's copy>
#    .\install_latewarp_dll.ps1 -GameDir <dir> -SearchRoots <dir1>,<dir2>
#    .\install_latewarp_dll.ps1 -GameDir <dir> -AllowOtherVersion   # loud warning
#    .\install_latewarp_dll.ps1 -GameDir <dir> -CoreDll <path>      # the CORE that knows latewarp
#    .\install_latewarp_dll.ps1 -GameDir <dir> -SkipCore            # feature dll only (latewarp then cannot work)
# ---------------------------------------------------------------------------
param(
    [Parameter(Mandatory = $true)][string]$GameDir,
    [string]$LatewarpDll = '',
    [string[]]$SearchRoots = @(),
    [int]$MaxDepth = 3,
    [switch]$AllowOtherVersion,
    [string]$CoreDll = '',
    [switch]$SkipCore,
    [switch]$AllowCoreWithoutLatewarp,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'

# The build this integration was developed and verified against, taken from
# _re\optiscaler_verify\latewarp_facts.json (a PE fingerprint of the working file):
#   FileVersion 310,2,0,0 / "NVIDIA Latewarp - DVS PRODUCTION" / 907296 bytes
$KnownSha256   = '81E63B4A9DCFB99B2B71C3DDFD3EA4A0E9780B778BD47E9A6F7F010A7A6C0F20'
$KnownSize     = 907296
$FeatureName   = 'nvngx_latewarp.dll'

# The NGX CORE has to know feature 15 as well. The core that ships with the display driver on the
# development machine (30.0.14.9516, 488824 bytes) contains ZERO "Latewarp." strings, so placing
# only the feature dll still ends in 0xBAD0000B. Verified capable core = the user's own package:
#   version 32.0.15.7652 / 1411224 bytes / sha256 9E5C1F46...
# OptiScaler loads "_nvngx.dll" BEFORE "nvngx.dll" (proxies/NVNGX_Proxy.h:447), so the capable core
# is placed AS _nvngx.dll while OptiScaler itself is installed as nvngx.dll.
$KnownCoreSha256 = '9E5C1F46EA88E21716BB1F3579E58FD0AD8531B179BBE5E86B768B5686E69E5C'
$KnownCoreSize   = 1411224
$CoreFileName    = 'nvngx.dll'
$CorePlaceName   = '_nvngx.dll'

if (-not (Test-Path -LiteralPath $GameDir)) { throw "game dir not found: $GameDir" }
$GameDir = (Resolve-Path -LiteralPath $GameDir).Path

function Get-Sha([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash }

function Test-Candidate([string]$p) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return $null }
    if ((Split-Path $p -Leaf) -ne $FeatureName) { return $null }
    $len = (Get-Item -LiteralPath $p).Length
    $sha = Get-Sha $p
    return [pscustomobject]@{ path = $p; size = $len; sha256 = $sha; exact = ($sha -eq $KnownSha256) }
}

# A core is only usable if it can actually do latewarp, so capability is checked by CONTENT
# (the parameter names it carries), not by trusting the file name.
function Test-CoreCapable([string]$p) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return $null }
    if ((Split-Path $p -Leaf) -ne $CoreFileName) { return $null }
    $item = Get-Item -LiteralPath $p
    if ($item.Length -lt 500000) { return $null }                       # the driver core is 488 KB
    if (('' + $item.VersionInfo.ProductName) -notmatch 'NGX') { return $null }
    $text = [System.Text.Encoding]::ASCII.GetString([System.IO.File]::ReadAllBytes($p))
    $keys = @([regex]::Matches($text, 'Latewarp\.[A-Za-z0-9_.]+') | ForEach-Object { $_.Value } | Sort-Object -Unique)
    $sha = Get-Sha $p
    return [pscustomobject]@{ path = $p; size = $item.Length; sha256 = $sha; keys = $keys.Count; exact = ($sha -eq $KnownCoreSha256) }
}

# --- 1. explicit path wins --------------------------------------------------
$found = $null
$searched = New-Object System.Collections.Generic.List[string]

if ($LatewarpDll) {
    if (-not (Test-Path -LiteralPath $LatewarpDll)) { throw ("-LatewarpDll not found: " + $LatewarpDll) }
    $found = Test-Candidate (Resolve-Path -LiteralPath $LatewarpDll).Path
    if ($null -eq $found) { throw ("-LatewarpDll must point at a file named " + $FeatureName + ", got: " + (Split-Path $LatewarpDll -Leaf)) }
}

# --- 2. the obvious places inside the target -------------------------------
if ($null -eq $found) {
    foreach ($p in @((Join-Path $GameDir $FeatureName), (Join-Path $GameDir ('realdir\' + $FeatureName)))) {
        $searched.Add($p)
        $c = Test-Candidate $p
        if ($null -ne $c) { $found = $c; break }
    }
}

# --- 3. bounded search of user-supplied roots ------------------------------
if (($null -eq $found) -and ($SearchRoots.Count -gt 0)) {
    foreach ($root in $SearchRoots) {
        if (-not (Test-Path -LiteralPath $root)) { Write-Host ("[skip] search root not found: " + $root); continue }
        Write-Host ("[search] " + $root + "  (depth " + $MaxDepth + ")")
        $stack = @([pscustomobject]@{ d = (Resolve-Path -LiteralPath $root).Path; depth = 0 })
        while ($stack.Count -gt 0) {
            $cur = $stack[0]; $stack = $stack[1..($stack.Count - 1)]
            $searched.Add($cur.d)
            $c = Test-Candidate (Join-Path $cur.d $FeatureName)
            if ($null -ne $c) { $found = $c; break }
            if ($cur.depth -lt $MaxDepth) {
                foreach ($sub in (Get-ChildItem -LiteralPath $cur.d -Directory -ErrorAction SilentlyContinue)) {
                    $stack += [pscustomobject]@{ d = $sub.FullName; depth = ($cur.depth + 1) }
                }
            }
        }
        if ($null -ne $found) { break }
    }
}

# --- 4. verdict -------------------------------------------------------------
if ($null -eq $found) {
    Write-Host ""
    Write-Host "PROVISIONING FAILED: no usable copy of $FeatureName was found."
    Write-Host "  looked at: " + $searched.Count + " location(s), e.g."
    foreach ($s in ($searched | Select-Object -First 6)) { Write-Host ("    - " + $s) }
    Write-Host "  This build does NOT ship NVIDIA binaries. Provide your own copy with:"
    Write-Host ("    -LatewarpDll <path>   or   -SearchRoots <dir>[,<dir>]")
    Write-Host "  Expected file: " + $FeatureName + "  (" + $KnownSize + " bytes, sha256 " + $KnownSha256.Substring(0,16) + "...)"
    exit 2
}

Write-Host ("[found] " + $found.path)
Write-Host ("         size=" + $found.size + "  sha256=" + $found.sha256)
if (-not $found.exact) {
    if (-not $AllowOtherVersion) {
        Write-Host ""
        Write-Host "PROVISIONING REFUSED: the file does not match the verified build."
        Write-Host ("  expected sha256: " + $KnownSha256)
        Write-Host ("  actual   sha256: " + $found.sha256)
        Write-Host ("  expected size  : " + $KnownSize + "   actual: " + $found.size)
        Write-Host "  A latewarp feature dll is version-coupled to the NGX core; a mismatch tends to"
        Write-Host "  fail in ways that are hard to diagnose. Pass -AllowOtherVersion to override, or"
        Write-Host "  supply the verified build."
        exit 3
    }
    Write-Host "[warn] VERSION MISMATCH ACCEPTED via -AllowOtherVersion -- behaviour is unverified."
}

# --- 4b. the CORE must know feature 15 (or the feature dll is useless) ------
if (-not $SkipCore) {
    $core = $null

    if ($CoreDll) {
        if (-not (Test-Path -LiteralPath $CoreDll)) { throw ("-CoreDll not found: " + $CoreDll) }
        $core = Test-CoreCapable (Resolve-Path -LiteralPath $CoreDll).Path
        if ($null -eq $core) {
            throw ("-CoreDll must point at a real, latewarp-capable " + $CoreFileName +
                   " (>=500 KB, ProductName contains NGX, and it must carry Latewarp.* names)")
        }
    } else {
        foreach ($p in @((Join-Path $GameDir $CoreFileName), (Join-Path $GameDir $CorePlaceName))) {
            $c = Test-CoreCapable $p
            if ($null -ne $c) { $core = $c; break }
        }
        if ($null -eq $core) {
            foreach ($root in $SearchRoots) {
                if (-not (Test-Path -LiteralPath $root)) { continue }
                $stack = @([pscustomobject]@{ d = (Resolve-Path -LiteralPath $root).Path; depth = 0 })
                while ($stack.Count -gt 0) {
                    $cur = $stack[0]; $stack = $stack[1..($stack.Count - 1)]
                    $c = Test-CoreCapable (Join-Path $cur.d $CoreFileName)
                    if ($null -ne $c) { $core = $c; break }
                    if ($cur.depth -lt $MaxDepth) {
                        foreach ($sub in (Get-ChildItem -LiteralPath $cur.d -Directory -ErrorAction SilentlyContinue)) {
                            $stack += [pscustomobject]@{ d = $sub.FullName; depth = ($cur.depth + 1) }
                        }
                    }
                }
                if ($null -ne $core) { break }
            }
        }
    }

    if ($null -eq $core) {
        Write-Host ""
        Write-Host "CORE PROVISIONING FAILED: no latewarp-capable NGX core was found."
        Write-Host "  The core that comes with the display driver does NOT know feature 15 (verified: the"
        Write-Host "  one on this machine carries zero Latewarp.* names), so the feature dll alone is not"
        Write-Host "  enough -- CreateFeature(15) would come back as 0xBAD0000B."
        Write-Host "  Provide your own copy with:   -CoreDll <path to nvngx.dll>"
        Write-Host ("  Verified build: " + $CoreFileName + "  " + $KnownCoreSize + " bytes  sha256 " + $KnownCoreSha256.Substring(0,16) + "...")
        Write-Host "  Pass -SkipCore to place only the feature dll (latewarp will then NOT work)."
        exit 4
    }

    Write-Host ("[core] " + $core.path)
    Write-Host ("       size=" + $core.size + "  sha256=" + $core.sha256 + "  Latewarp.* names=" + $core.keys)

    if (-not $core.exact) {
        if (($core.keys -eq 0) -and (-not $AllowCoreWithoutLatewarp)) {
            Write-Host ""
            Write-Host "CORE PROVISIONING REFUSED: that core carries no Latewarp.* parameter names,"
            Write-Host "so it cannot create feature 15. Pass -AllowCoreWithoutLatewarp to override."
            exit 5
        }
        Write-Host "[warn] core is not the verified build -- capability was checked by content, behaviour is unverified."
    }

    $coreDst = Join-Path $GameDir $CorePlaceName
    # Test-Path FIRST: Get-FileHash throws on a missing file (the feature-dll branch below has the
    # same guard, and forgetting it here cost a test run).
    if ((Test-Path -LiteralPath $coreDst) -and ((Get-Sha $coreDst) -eq $core.sha256)) {
        Write-Host ("[ok] core already in place: " + $coreDst)
    } elseif ($DryRun) {
        Write-Host ("[dry] copy core -> " + $coreDst)
    } else {
        Copy-Item -LiteralPath $core.path -Destination $coreDst -Force
        if ((Get-Sha $coreDst) -ne $core.sha256) { throw ("core copy verification failed for " + $coreDst) }
        Write-Host ("[ok] capable core placed as " + $CorePlaceName + " (OptiScaler looks for this name first)")
    }
}

# --- 5. place it next to the core and beside the exe ------------------------
$destinations = @()
if (Test-Path -LiteralPath (Join-Path $GameDir 'realdir')) { $destinations += (Join-Path $GameDir ('realdir\' + $FeatureName)) }
$destinations += (Join-Path $GameDir $FeatureName)

foreach ($dst in $destinations) {
    if ((Test-Path -LiteralPath $dst) -and ((Get-Sha $dst) -eq $found.sha256)) {
        Write-Host ("[ok] already in place: " + $dst)
        continue
    }
    if ($DryRun) { Write-Host ("[dry] copy -> " + $dst); continue }
    Copy-Item -LiteralPath $found.path -Destination $dst -Force
    $after = Get-Sha $dst
    if ($after -ne $found.sha256) { throw ("copy verification failed for " + $dst) }
    Write-Host ("[ok] placed: " + $dst)
}

if ($DryRun) { Write-Host "[dry] nothing written" } else { Write-Host "PROVISIONING OK" }
exit 0
