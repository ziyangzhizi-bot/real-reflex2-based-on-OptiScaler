# ---------------------------------------------------------------------------
#  test_game_install.ps1 -- positive + NEGATIVE tests for install_p2_into_game.ps1,
#  run entirely against a FAKE game directory. No game, no GUI, no real files touched.
# ---------------------------------------------------------------------------
$ErrorActionPreference = 'Continue'
$P2 = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Script = Join-Path $P2 'install_p2_into_game.ps1'
$tmp = Join-Path $env:TEMP ('p2game_' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
$fails = 0
function Check([string]$n, [bool]$ok, [string]$d) {
    if ($ok) { Write-Host ("  [PASS] " + $n + "  " + $d) } else { Write-Host ("  [FAIL] " + $n + "  " + $d) -ForegroundColor Red; $script:fails++ }
}
function Run([string[]]$a) {
    $prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $o = & powershell -NoProfile -ExecutionPolicy Bypass -File $Script @a 2>&1 | Out-String; $c = $LASTEXITCODE }
    finally { $ErrorActionPreference = $prev }
    return @{ text = $o; code = $c }
}
function Sha([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash }

# a fake patched build: 64 KB of deterministic bytes
$build = Join-Path $tmp 'OptiScaler.dll'
$bytes = New-Object byte[] 65536
for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [byte](($i * 7) % 251) }
[System.IO.File]::WriteAllBytes($build, $bytes)
$buildSha = Sha $build

# a fake game dir: an exe + an existing dxgi.dll we must preserve
$game = Join-Path $tmp 'game'; New-Item -ItemType Directory -Force -Path $game | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $game 'SomeGame.exe'), (New-Object byte[] 128))
$origDxgi = Join-Path $game 'dxgi.dll'
[System.IO.File]::WriteAllBytes($origDxgi, (New-Object byte[] 4096))
$origSha = Sha $origDxgi

Write-Host "=== game install tests ==="

# --- negative: not a game dir -----------------------------------------------
$notGame = Join-Path $tmp 'notgame'; New-Item -ItemType Directory -Force -Path $notGame | Out-Null
$r = Run @('-GameDir', $notGame, '-OptiScalerDll', $build)
Check "no .exe -> refused" ($r.code -ne 0) ("exit=" + $r.code)
Check "no .exe -> explains why" ($r.text -match 'does not look like a game directory') ""

# --- negative: missing build ------------------------------------------------
$r = Run @('-GameDir', $game, '-OptiScalerDll', (Join-Path $tmp 'nope.dll'))
Check "missing build -> refused" ($r.code -ne 0) ("exit=" + $r.code)
Check "missing build -> tells you to build first" ($r.text -match 'build it first') ""

# --- dry run ----------------------------------------------------------------
$r = Run @('-GameDir', $game, '-OptiScalerDll', $build, '-DryRun')
Check "dry run -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "dry run -> wrote nothing" ((Sha $origDxgi) -eq $origSha) "original dxgi.dll untouched"

# --- install ----------------------------------------------------------------
$r = Run @('-GameDir', $game, '-OptiScalerDll', $build, '-ProxyName', 'dxgi.dll')
Check "install -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "install -> slot now holds our build" ((Sha $origDxgi) -eq $buildSha) ""
Check "install -> original was backed up" ((Get-ChildItem -Recurse (Join-Path $game '_p2backup_*') -Filter 'dxgi.dll' | Measure-Object).Count -eq 1) ""
Check "install -> state file written" (Test-Path (Join-Path $game '_p2_state.txt')) ""
$r2 = Run @('-GameDir', $game, '-OptiScalerDll', $build, '-ProxyName', 'dxgi.dll')
Check "second install -> refused (state exists)" ($r2.code -ne 0) ("exit=" + $r2.code)

# --- uninstall restores byte-identically ------------------------------------
$r = Run @('-GameDir', $game, '-Uninstall')
Check "uninstall -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "uninstall -> original dxgi.dll restored BYTE-IDENTICALLY" ((Sha $origDxgi) -eq $origSha) ""
Check "uninstall -> state file removed" (-not (Test-Path (Join-Path $game '_p2_state.txt'))) ""
$r = Run @('-GameDir', $game, '-Uninstall')
Check "uninstall twice -> refused" ($r.code -ne 0) ("exit=" + $r.code)

# --- install where nothing exists, then uninstall deletes what we added ------
$game2 = Join-Path $tmp 'game2'; New-Item -ItemType Directory -Force -Path $game2 | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $game2 'G.exe'), (New-Object byte[] 64))
$r = Run @('-GameDir', $game2, '-OptiScalerDll', $build, '-ProxyName', 'winmm.dll')
Check "fresh install -> exit 0" ($r.code -eq 0) ("exit=" + $r.code)
$r = Run @('-GameDir', $game2, '-Uninstall')
Check "uninstall removes the file we added" (-not (Test-Path (Join-Path $game2 'winmm.dll'))) ""


# --- AC-P2-008: the anti-cheat scope is a CONTROL, not a sentence -----------
$acGame = Join-Path $tmp 'ac_game'; New-Item -ItemType Directory -Force -Path $acGame | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $acGame 'AcGame.exe'), (New-Object byte[] 64))
[System.IO.File]::WriteAllBytes((Join-Path $acGame 'EasyAntiCheat.exe'), (New-Object byte[] 64))
$r = Run @('-GameDir', $acGame, '-OptiScalerDll', $build, '-ProxyName', 'dxgi.dll')
Check 'anti-cheat game -> REFUSED' ($r.code -ne 0) ('exit=' + $r.code)
Check 'anti-cheat refusal names the policy and the marker' (($r.text -match 'AC-P2-008') -and ($r.text -match 'EasyAntiCheat')) ''
Check 'anti-cheat refusal wrote nothing' (-not (Test-Path (Join-Path $acGame 'dxgi.dll'))) ''
$r = Run @('-GameDir', $acGame, '-OptiScalerDll', $build, '-Force')
Check 'no -Force escape hatch exists (behavioral proof)' ($r.code -ne 0) ('exit=' + $r.code)
$r = Run @('-GameDir', $acGame, '-OptiScalerDll', $build, '-DryRun')
Check 'anti-cheat + -DryRun -> still refused' ($r.code -ne 0) ('exit=' + $r.code)

$sysGame = Join-Path $tmp 'sys_game'; New-Item -ItemType Directory -Force -Path $sysGame | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $sysGame 'SysGame.exe'), (New-Object byte[] 64))
[System.IO.File]::WriteAllBytes((Join-Path $sysGame 'someguard.sys'), (New-Object byte[] 64))
$r = Run @('-GameDir', $sysGame, '-OptiScalerDll', $build)
Check 'any kernel .sys in the tree -> REFUSED' ($r.code -ne 0) ('exit=' + $r.code)
Check 'kernel refusal explains itself' ($r.text -match 'kernel driver') ''

# --- nvngx.dll deployment guard --------------------------------------------
$game4 = Join-Path $tmp 'game4'; New-Item -ItemType Directory -Force -Path $game4 | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $game4 'G.exe'), (New-Object byte[] 64))
$r = Run @('-GameDir', $game4, '-OptiScalerDll', $build, '-ProxyName', 'nvngx.dll')
Check "nvngx.dll without _nvngx.dll -> REFUSED" ($r.code -ne 0) ("exit=" + $r.code)
Check "nvngx refusal names the missing core and the fix" (($r.text -match '_nvngx.dll') -and ($r.text -match 'install_latewarp_dll')) ""
Check "nvngx refusal wrote nothing" (-not (Test-Path (Join-Path $game4 'nvngx.dll'))) ""

[System.IO.File]::WriteAllBytes((Join-Path $game4 '_nvngx.dll'), (New-Object byte[] 600000))
$r = Run @('-GameDir', $game4, '-OptiScalerDll', $build, '-ProxyName', 'nvngx.dll')
Check "core present -> install exit 0" ($r.code -eq 0) ("exit=" + $r.code)
Check "core present -> guard reported" ($r.text -match '\[guard\] _nvngx.dll present') ""
Check "core present -> nvngx.dll placed" (Test-Path (Join-Path $game4 'nvngx.dll')) ""
$r = Run @('-GameDir', $game4, '-Uninstall')
Check "uninstall removes the nvngx.dll we added" (-not (Test-Path (Join-Path $game4 'nvngx.dll'))) ""

# a stub masquerading as the core must also be refused
$game5 = Join-Path $tmp 'game5'; New-Item -ItemType Directory -Force -Path $game5 | Out-Null
[System.IO.File]::WriteAllBytes((Join-Path $game5 'G.exe'), (New-Object byte[] 64))
[System.IO.File]::WriteAllBytes((Join-Path $game5 '_nvngx.dll'), (New-Object byte[] 1024))
$r = Run @('-GameDir', $game5, '-OptiScalerDll', $build, '-ProxyName', 'nvngx.dll')
Check "tiny _nvngx.dll -> REFUSED (not a core)" ($r.code -ne 0) ("exit=" + $r.code)
Check "tiny core refusal explains itself" ($r.text -match 'is not an NGX core') ""

Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
Write-Host ("=== " + $(if ($script:fails -eq 0) { 'PASS' } else { 'FAIL' }) + " (" + $script:fails + " failure(s)) ===")
exit $(if ($script:fails -eq 0) { 0 } else { 1 })
