// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#include "LatewarpFrameData.h"

#include <chrono>
#include <math.h>
#include <mutex>
#include <string.h>

namespace p2
{

// S10 F-03: written from the Streamline constants hook, read from the render thread.
static std::mutex g_mutex;
static FrameData g_frameData;

// P3-4a: the CJK glyphs of the Chinese panel labels (see the header). Written as UTF-8 byte escapes on
// purpose: a literal Chinese string would be encoded with whatever code page the compiler assumes
// (without /utf-8 that is the ANSI code page), and ImGui expects UTF-8.
const char kChinesePanelGlyphs[] =
    "\xE4\xB8\xAD\xE6\x96\x87\xE9\x80\x9F\xE6\x8E\xA7\xE9\x9D\xA2\xE6\x9D\xBF\xE6\x8E\xA5\xE7\xAE\xA1\xE5\xBC\x80\xE5\x85\xB3\xE5\x85\x88"
    "\xE5\x8B\xBE\xE8\xBF\x99\xE4\xB8\xAA\xE5\xB7\xB2\xE8\xA3\x85\xE9\x85\x8D\xE6\x9C\xAA\xE9\x9D\x99\xE6\x80\x81\xE5\x85\x83\xE7\xB4\xA0\xE5\x8F\xAF"
    "\xE8\xA7\x86\xE5\x8C\x96\xE8\xAF\x8A\xE6\x96\xAD\xE8\xAE\xB0\xE5\xBD\x95\xE8\xAE\xA9\xE4\xBD\x8D\xE5\xBC\xBA\xE5\xBA\xA6\xE8\xA1\xA5\xE6\xB4\x9E"
    "\xE5\xA7\xBF\xE6\x80\x81\xE8\xB6\x85\xE5\x89\x8D\xE6\xB7\xB1\xE5\xBA\xA6\xE9\x98\x88\xE5\x80\xBC\xE9\x80\x89\xE5\x90\x8E\xE7\xAB\x8B"
    "\xE5\x8D\xB3\xE7\x94\x9F\xE6\x95\x88\xE6\x94\xB9\xE5\xAE\x8C\xE6\x8C\x89\xE4\xBF\x9D\xE5\xAD\x98\xE7\xAD\x89\xE4\xBA\x8E\xE4\xB8\x8B\xE5\x8C\xBA"
    "\xE7\x9A\x84"
    // P3-E2c4: the mask-threshold slider -- 遮罩阈值 + its hint 拉到0就全屏都扯越大冻住的越多.
    // Duplicates of earlier code points are harmless (ImFontGlyphRangesBuilder deduplicates).
    "\xE9\x81\xAE\xE7\xBD\xA9"
    "\xE6\x8B\x89\xE5\x88\xB0\xE5\xB0\xB1\xE5\x85\xA8\xE5\xB1\x8F\xE9\x83\xBD\xE6\x89\xAF\xEF\xBC\x9B\xE8\xB6\x8A\xE5\xA4\xA7\xE5\x86\xBB\xE4\xBD\x8F\xE7\x9A\x84\xE5\xA4\x9A"
    // P3-E2c6: 修正强度 (warp strength)
    "\xE4\xBF\xAE\xE6\xAD\xA3\xE5\xBC\xBA\xE5\xBA\xA6";

static void Copy16(float* dst, const float* src)
{
    for (int i = 0; i < 16; ++i) dst[i] = src[i];
}

void SetStreamlineViewToClip(const float* m16, uint32_t frameIndex)
{
    if (m16 == nullptr) return;

    std::lock_guard<std::mutex> lock(g_mutex);

    if (g_frameData.hasCurrent && frameIndex != g_frameData.frameIndex)
    {
        // a new frame: the matrix we already hold becomes the "previous" one
        Copy16(g_frameData.prevViewToClip, g_frameData.viewToClip);
        g_frameData.hasPrevious = true;
        // P3-5b: the jitter rotates with it, because it belongs to the same rendered frame.
        g_frameData.prevJitter[0] = g_frameData.jitter[0];
        g_frameData.prevJitter[1] = g_frameData.jitter[1];
        g_frameData.hasPrevJitter = true;
        // P3-B: the SAMPLE TIME rotates the same way. Only a frame-index CHANGE moves it, so extra
        // calls inside one frame (Streamline calls once per viewport) keep the FIRST sample time --
        // the earliest moment we could have known this camera.
        g_frameData.prevSampleMs = g_frameData.sampleMs;
        g_frameData.prevSampleFrameIndex = g_frameData.frameIndex;
        g_frameData.sampleMs = NowMs();
    }
    else if (!g_frameData.hasCurrent)
    {
        g_frameData.hasPrevious = false;   // nothing to rotate to yet
        g_frameData.sampleMs = NowMs();
    }

    Copy16(g_frameData.viewToClip, m16);
    g_frameData.frameIndex = frameIndex;
    g_frameData.hasCurrent = true;
    ++g_frameData.updateCount;
}

void SetStreamlineJitter(float x, float y)
{
    // NaN or an absurd value: keep whatever we had. A bad jitter is worse than none.
    const bool bad = (x != x) || (y != y) || (x < -4.f) || (x > 4.f) || (y < -4.f) || (y > 4.f);
    if (bad) return;

    std::lock_guard<std::mutex> lock(g_mutex);
    g_frameData.jitter[0] = x;
    g_frameData.jitter[1] = y;
}

FrameData GetFrameData()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_frameData;
}

// ---- P3-B: late-latch timing (logging only) ------------------------------------------------
// The epoch is a namespace-scope static so the very first sample is already > 0 (0 doubles as
// "nothing sampled yet"), and std::chrono -- not QueryPerformanceCounter -- on purpose: this TU is
// also compiled by the offline unit test WITHOUT the Windows headers.
static const std::chrono::steady_clock::time_point g_clockEpoch = std::chrono::steady_clock::now();

double NowMs()
{
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - g_clockEpoch).count();
}

double NewestSampleAgeMs(double nowMs)
{
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_frameData.hasCurrent || g_frameData.sampleMs <= 0.0 || nowMs <= 0.0)
        return -1.0;
    return nowMs - g_frameData.sampleMs;
}

static float WrapPi(float a)
{
    while (a > 3.14159265f) a -= 6.28318531f;
    while (a < -3.14159265f) a += 6.28318531f;
    return a;
}

static bool Finite(float a) { return (a == a) && (a > -1.0e30f) && (a < 1.0e30f); }

// ---- P2/E2c9 (P0): the present-boundary camera double buffer ---------------------------------
// The writer is Streamline's slSetConstants thread, the reader is the present/render thread, so
// every transfer goes through g_mutex and hands out COPIES. Nothing here allocates or blocks; the
// presenter only takes the lock once per frame.
static LwCameraPose g_camNow;      // newest sample
static LwCameraPose g_camCur;      // what the last present consumed
static LwCameraPose g_camPrev;     // what the present before that consumed
static uint32_t g_camSerial = 0;   // bumped on every accepted sample
static uint32_t g_camConsumed = 0; // last serial the presenter adopted

static void Copy3(float* dst, const float* src)
{
    dst[0] = src[0];
    dst[1] = src[1];
    dst[2] = src[2];
}

void SetStreamlineCameraPose(const float pos[3], const float up[3], const float right[3], const float fwd[3],
                             const float viewToClip[16])
{
    if (pos == nullptr || up == nullptr || right == nullptr || fwd == nullptr)
        return;

    for (int i = 0; i < 3; ++i)
    {
        if (!Finite(pos[i]) || !Finite(up[i]) || !Finite(right[i]) || !Finite(fwd[i]))
            return;   // a half-written sample is worse than the previous one: keep what we have
    }

    std::lock_guard<std::mutex> lock(g_mutex);
    Copy3(g_camNow.pos, pos);
    Copy3(g_camNow.up, up);
    Copy3(g_camNow.right, right);
    Copy3(g_camNow.fwd, fwd);
    if (viewToClip != nullptr)
        Copy16(g_camNow.viewToClip, viewToClip);
    g_camNow.valid = true;
    ++g_camSerial;
}

bool AdvanceStreamlineCameraPose(LwCameraPose& outCur, LwCameraPose& outPrev)
{
    std::lock_guard<std::mutex> lock(g_mutex);

    if (!g_camNow.valid)
        return false;

    // Rotate ONLY when a sample arrived since the previous call: repeated presents of the same
    // rendered frame (MFG presents one rendered frame 3-4 times) must NOT advance the pair, or the
    // delta would collapse to zero again -- the exact bug this replaces.
    if (g_camSerial != g_camConsumed)
    {
        g_camPrev = g_camCur.valid ? g_camCur : g_camNow;
        g_camCur = g_camNow;
        g_camConsumed = g_camSerial;
    }

    outCur = g_camCur;
    outPrev = g_camPrev;
    return g_camCur.valid;
}

uint32_t CameraPoseSerial()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_camSerial;
}

uint32_t CameraPoseConsumed()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_camConsumed;
}

// P2/E2c11b: the tag drive point (see the header). All three calls happen on the render thread, the
// same thread that drives Present(), so a plain flag plus a timestamp is enough.
static bool g_lwAtTag = false;
static double g_lwTagDriveMs = -1.0e9;

// P2/E2c12: the pinned pose pair (see the header). Same thread as the tag and the present.
static double g_posePinMs = -1.0e9;

void PinLatewarpPosePair()
{
    g_posePinMs = NowMs();
}

bool LatewarpPosePinned()
{
    return (NowMs() - g_posePinMs) < 12.0;
}

bool CurrentLatewarpPosePair(LwCameraPose& outCur, LwCameraPose& outPrev)
{
    std::lock_guard<std::mutex> lock(g_mutex);

    if (!g_camCur.valid)
        return false;

    outCur = g_camCur;
    outPrev = g_camPrev;
    return true;
}

void SetLatewarpAtTag(bool on)
{
    g_lwAtTag = on;
}

bool LatewarpAtTag()
{
    return g_lwAtTag;
}

void SetLatewarpTagDriveOk()
{
    g_lwTagDriveMs = NowMs();
}

bool LatewarpTagDriveRecent()
{
    // P2/E2c17 (round 15): the window is per PRESENT, not per tag. In the in-place mode the warp is
    // written at the ScalingOutputColor tag, which can be a good part of a frame before the present;
    // a 2 ms window would let the present chain warp the frame a SECOND time -- and that second warp
    // also warps the UI (the generator keeps the UI crisp via its own path), leaving a residual HUD
    // ghost. 40 ms covers a frame down to 25 fps and is still far below any two-frame gap at 60 fps.
    return (NowMs() - g_lwTagDriveMs) < 40.0;
}

// ---- P3-2: 4x4 helpers (row-major, column-vector) ------------------------------------------
static void Mul16(const float* a, const float* b, float* out)   // out = a * b
{
    for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c)
        {
            float s = 0.f;
            for (int k = 0; k < 4; ++k) s += a[r * 4 + k] * b[k * 4 + c];
            out[r * 4 + c] = s;
        }
}

// Gauss-Jordan with partial pivoting: small, dependency-free, and easy to test.
static bool Invert16(const float* m, float* out)
{
    float a[4][8];
    for (int r = 0; r < 4; ++r)
    {
        for (int c = 0; c < 4; ++c) { a[r][c] = m[r * 4 + c]; a[r][4 + c] = (r == c) ? 1.f : 0.f; }
    }
    for (int col = 0; col < 4; ++col)
    {
        int piv = col;
        for (int r = col + 1; r < 4; ++r) if (fabsf(a[r][col]) > fabsf(a[piv][col])) piv = r;
        if (fabsf(a[piv][col]) < 1.0e-12f) return false;
        if (piv != col) for (int c = 0; c < 8; ++c) { float t = a[col][c]; a[col][c] = a[piv][c]; a[piv][c] = t; }
        const float inv = 1.f / a[col][col];
        for (int c = 0; c < 8; ++c) a[col][c] *= inv;
        for (int r = 0; r < 4; ++r)
        {
            if (r == col) continue;
            const float f = a[r][col];
            if (f == 0.f) continue;
            for (int c = 0; c < 8; ++c) a[r][c] -= f * a[col][c];
        }
    }
    for (int r = 0; r < 4; ++r) for (int c = 0; c < 4; ++c) out[r * 4 + c] = a[r][4 + c];
    return true;
}







bool BuildReprojectionMatrices(const float curWorldToView[16], const float curViewToClip[16],
                               const float prevWorldToView[16], const float prevViewToClip[16],
                               float outInvVPCur[16], float outVPPPrev[16])
{
    if (curWorldToView == nullptr || curViewToClip == nullptr || prevWorldToView == nullptr ||
        prevViewToClip == nullptr || outInvVPCur == nullptr || outVPPPrev == nullptr)
        return false;

    float vpCur[16];
    Mul16(curWorldToView, curViewToClip, vpCur);     // row-vector order: world -> clip
    if (!Invert16(vpCur, outInvVPCur)) return false;
    Mul16(prevWorldToView, prevViewToClip, outVPPPrev);
    return true;
}





// ---- P3-3: the diagnostic readback -------------------------------------------------------------
// The GPU accumulates one 16-word block per frame (see the kDiag* table in the header); these two
// functions are the half of that pipeline which has no D3D12 in it, so the unit test can pin the
// decoding without a device.
static float BitsToFloat(uint32_t bits, bool allowNegative)
{
    float f = 0.f;
    memcpy(&f, &bits, sizeof(f));

    if (!Finite(f))
        return 0.f;
    if (!allowNegative && f < 0.f)
        return 0.f;

    return f;
}

bool ForwardAngleDeg(const float curFwd[3], const float prevFwd[3], float* outDeg)
{
    if (curFwd == nullptr || prevFwd == nullptr || outDeg == nullptr)
        return false;

    *outDeg = 0.f;

    float lenA = 0.f, lenB = 0.f, dot = 0.f;
    for (int i = 0; i < 3; ++i)
    {
        if (!Finite(curFwd[i]) || !Finite(prevFwd[i]))
            return false;

        lenA += curFwd[i] * curFwd[i];
        lenB += prevFwd[i] * prevFwd[i];
        dot += curFwd[i] * prevFwd[i];
    }

    if (lenA < 1e-12f || lenB < 1e-12f)
        return false;

    float c = dot / sqrtf(lenA * lenB);
    if (c > 1.f) c = 1.f;
    if (c < -1.f) c = -1.f;

    *outDeg = acosf(c) * 57.2957795f;
    return true;
}

bool PredictCentreShiftPx(const float curFwd[3], const float prevFwd[3], float focalPx, float* outPx)
{
    if (outPx == nullptr)
        return false;

    *outPx = 0.f;

    if (!(focalPx > 0.f) || !Finite(focalPx))
        return false;

    float deg = 0.f;
    if (!ForwardAngleDeg(curFwd, prevFwd, &deg))
        return false;

    // tan blows up at 90 deg; a pose delta anywhere near that is not a frame delta, so refuse it
    // rather than publish a nonsense reference.
    if (deg >= 80.f)
        return false;

    const float px = focalPx * tanf(deg * 3.14159265f / 180.0f);
    if (!Finite(px))
        return false;

    *outPx = px;
    return true;
}

bool DecodeDiagStats(const uint32_t words[kDiagWords], int screenWidth, int screenHeight,
                     DiagReadout* out)
{
    if (words == nullptr || out == nullptr)
        return false;
    if (screenWidth <= 0 || screenHeight <= 0)
        return false;

    DiagReadout r {};

    r.pixels        = words[kDiagPixels];
    r.outsideCount  = words[kDiagOutsideCount];
    r.behindCount   = words[kDiagBehindCount];
    r.depthWidth    = (int) words[kDiagDepthW];
    r.depthHeight   = (int) words[kDiagDepthH];

    r.maxShiftPx    = BitsToFloat(words[kDiagMaxShiftPx], false);
    r.maxOutsidePx  = BitsToFloat(words[kDiagMaxOutsidePx], false);

    r.centreCur[0]  = BitsToFloat(words[kDiagCentreCurX], true);
    r.centreCur[1]  = BitsToFloat(words[kDiagCentreCurY], true);
    r.centrePrev[0] = BitsToFloat(words[kDiagCentrePrevX], true);
    r.centrePrev[1] = BitsToFloat(words[kDiagCentrePrevY], true);
    r.centreDepth   = BitsToFloat(words[kDiagCentreDepth], true);
    r.centreValid   = (words[kDiagCentreValid] != 0u);

    // the centre pixel's own displacement, in pixels -- the number the log compares against the
    // pose angle: a distant point under a pure rotation moves by about focal * tan(angle).
    const float dx = (r.centrePrev[0] - r.centreCur[0]) * 0.5f * (float) screenWidth;
    const float dy = (r.centrePrev[1] - r.centreCur[1]) * 0.5f * (float) screenHeight;
    r.centreShiftPx = sqrtf(dx * dx + dy * dy);

    if (r.pixels > 0)
        r.outsidePercent = 100.f * (float) r.outsideCount / (float) r.pixels;

    // P3-3b: the mask block. The cutout share is relative to the MASK (not to the frame): it says
    // how much of what we are freezing was selected by the depth predicate instead of the colour diff.
    r.maskCount       = words[kDiagMaskCount];
    r.maskCutoutCount = words[kDiagMaskCutout];
    if (r.pixels > 0)
        r.maskPercent = 100.f * (float) r.maskCount / (float) r.pixels;
    if (r.maskCount > 0)
    {
        r.maskCutoutPercent = 100.f * (float) r.maskCutoutCount / (float) r.maskCount;
        r.meanMaskDiff = ((float) words[kDiagMaskDiffQ] / 1024.f) / (float) r.maskCount;

    // P2/E2c25 (T82): the bright-content bins and the frame max luminance.
    for (int b = 0; b < 4; ++b)
    {
        r.binInQ[b]  = words[kDiagBin0InQ + 2 * b];
        r.binOutQ[b] = words[kDiagBin0OutQ + 2 * b];
    }
    r.maxLum = (float) words[kDiagMaxLumQ] / 32.f;
    }

    const uint32_t mmN = words[kDiagMmCount];
    if (mmN > 0)
        r.meanMismatch = ((float) words[kDiagMmSumQ] / 1024.f) / (float) mmN;

    const uint32_t mmOutN = words[kDiagMmOutCount];
    if (mmOutN > 0)
        r.meanMismatchOutside = ((float) words[kDiagMmOutSumQ] / 1024.f) / (float) mmOutN;

    r.valid = (r.pixels > 0);
    *out = r;
    return true;
}

bool BuildWorldToView(const float right[3], const float up[3], const float fwd[3], const float pos[3],
                      float out[16])
{
    if (right == nullptr || up == nullptr || fwd == nullptr || pos == nullptr || out == nullptr)
        return false;

    const bool degenerate = (right[0] == 0.f && right[1] == 0.f && right[2] == 0.f) &&
                            (up[0] == 0.f && up[1] == 0.f && up[2] == 0.f) &&
                            (fwd[0] == 0.f && fwd[1] == 0.f && fwd[2] == 0.f);
    if (degenerate)
    {
        for (int i = 0; i < 16; ++i) out[i] = 0.f;
        return false;
    }

    out[0] = right[0]; out[1] = up[0]; out[2] = fwd[0]; out[3] = 0.f;
    out[4] = right[1]; out[5] = up[1]; out[6] = fwd[1]; out[7] = 0.f;
    out[8] = right[2]; out[9] = up[2]; out[10] = fwd[2]; out[11] = 0.f;
    out[12] = -(right[0] * pos[0] + right[1] * pos[1] + right[2] * pos[2]);
    out[13] = -(up[0] * pos[0] + up[1] * pos[1] + up[2] * pos[2]);
    out[14] = -(fwd[0] * pos[0] + fwd[1] * pos[1] + fwd[2] * pos[2]);
    out[15] = 1.f;
    return true;
}

namespace
{
    // Normalises one axis. Returns false for a zero-length input so the caller can refuse instead of
    // binding a broken basis.
    static bool LwScaleNormalize3(float v[3])
    {
        const float len2 = (v[0] * v[0]) + (v[1] * v[1]) + (v[2] * v[2]);
        if (!(len2 > 1e-12f))
            return false;
        const float inv = 1.0f / sqrtf(len2);
        v[0] *= inv; v[1] *= inv; v[2] *= inv;
        return true;
    }
}

bool ScaleLatewarpWarpDelta(const LwCameraPose& prev, const LwCameraPose& cur, float alpha, LwCameraPose* out)
{
    if (out == nullptr || !prev.valid || !cur.valid)
        return false;
    // !(x >= 0) also catches NaN: a poisoned config must not silently produce a half-scaled pair.
    if (!(alpha >= 0.0f) || !(alpha <= 1.0f))
        return false;

    if (alpha >= 1.0f)
    {
        *out = cur;
        return true;
    }
    if (alpha <= 0.0f)
    {
        *out = prev;
        out->valid = cur.valid;
        return true;
    }

    // Linear interpolation of the basis and the position, then normalise each axis INDEPENDENTLY.
    // No cross products on purpose: the handedness of `right` belongs to the game, and deriving it
    // here could flip the basis. The per-frame delta is a fraction of a degree and a few cm, so the
    // linear interpolation stays orthonormal far below the kernel's precision.
    float fwd[3], up[3], right[3], pos[3];
    for (int i = 0; i < 3; ++i)
    {
        fwd[i]   = prev.fwd[i]   + alpha * (cur.fwd[i]   - prev.fwd[i]);
        up[i]    = prev.up[i]    + alpha * (cur.up[i]    - prev.up[i]);
        right[i] = prev.right[i] + alpha * (cur.right[i] - prev.right[i]);
        pos[i]   = prev.pos[i]   + alpha * (cur.pos[i]   - prev.pos[i]);
    }
    if (!LwScaleNormalize3(fwd) || !LwScaleNormalize3(up) || !LwScaleNormalize3(right))
        return false;

    *out = cur;
    for (int i = 0; i < 3; ++i)
    {
        out->fwd[i] = fwd[i];
        out->up[i] = up[i];
        out->right[i] = right[i];
        out->pos[i] = pos[i];
    }
    return true;
}

namespace
{
    // Rodrigues rotation of v about the given axis by deg, in place. The axes handed in are
    // camera basis vectors, so they are unit length by construction -- normalise anyway so a
    // denormalised basis cannot silently scale the result.
    void RotateAbout(float axis[3], float v[3], float deg)
    {
        const float rad = deg * 3.14159265358979323846f / 180.0f;
        const float c = cosf(rad);
        const float s = sinf(rad);

        float a[3] = { axis[0], axis[1], axis[2] };
        const float len = sqrtf(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (len > 1e-12f) { a[0] /= len; a[1] /= len; a[2] /= len; }

        const float dot = a[0] * v[0] + a[1] * v[1] + a[2] * v[2];
        const float cross[3] = { a[1] * v[2] - a[2] * v[1], a[2] * v[0] - a[0] * v[2],
                                 a[0] * v[1] - a[1] * v[0] };

        for (int i = 0; i < 3; ++i)
            v[i] = v[i] * c + cross[i] * s + a[i] * dot * (1.0f - c);
    }
}

void LateInputYawPitchDeg(int32_t dx, int32_t dy, float yawDegPerCount, float pitchDegPerCount,
                          float deadZoneCounts, float gain, float maxDeg, float* yawDeg, float* pitchDeg)
{
    float y = 0.f;
    float p = 0.f;

    if (gain > 0.f)
    {
        const float fx = static_cast<float>(dx);
        const float fy = static_cast<float>(dy);
        const float ax = fabsf(fx);
        const float ay = fabsf(fy);

        // The dead zone is SUBTRACTED from the magnitude: a hand resting on the mouse produces
        // nothing, and the motion beyond the dead zone is not rescaled by it.
        if (ax > deadZoneCounts) y = ((fx > 0.f) ? (ax - deadZoneCounts) : -(ax - deadZoneCounts)) * yawDegPerCount;
        if (ay > deadZoneCounts) p = ((fy > 0.f) ? -(ay - deadZoneCounts) : (ay - deadZoneCounts)) * pitchDegPerCount;

        y *= gain;
        p *= gain;

        if (y > maxDeg) y = maxDeg; else if (y < -maxDeg) y = -maxDeg;
        if (p > maxDeg) p = maxDeg; else if (p < -maxDeg) p = -maxDeg;
    }

    if (yawDeg != nullptr) *yawDeg = y;
    if (pitchDeg != nullptr) *pitchDeg = p;
}

void ApplyYawPitchToWorldToViewDeg(float w2v[16], float yawDeg, float pitchDeg)
{
    if (w2v == nullptr || (yawDeg == 0.f && pitchDeg == 0.f))
        return;

    // BuildWorldToView puts the basis vectors in the COLUMNS of the 3x3 block
    // (row0 = (right.x, up.x, fwd.x, 0), row1 = (right.y, ...), row2 = (right.z, ...)),
    // so read them column-wise -- reading them row-wise silently transposes the rotation.
    float right[3] = { w2v[0], w2v[4], w2v[8] };
    float up[3] = { w2v[1], w2v[5], w2v[9] };
    float forward[3] = { w2v[2], w2v[6], w2v[10] };

    // Recover the camera position from row 3. The basis is orthonormal, so pos = -R^T * t.
    const float pos[3] = { -(right[0] * w2v[12] + right[1] * w2v[13] + right[2] * w2v[14]),
                           -(up[0] * w2v[12] + up[1] * w2v[13] + up[2] * w2v[14]),
                           -(forward[0] * w2v[12] + forward[1] * w2v[13] + forward[2] * w2v[14]) };

    if (yawDeg != 0.f)
    {
        RotateAbout(up, right, yawDeg);
        RotateAbout(up, forward, yawDeg);
    }

    if (pitchDeg != 0.f)
    {
        // Negated: the rotation that looks UP takes forward toward +up, i.e. about -right.
        RotateAbout(right, up, -pitchDeg);
        RotateAbout(right, forward, -pitchDeg);
    }

    w2v[0] = right[0];   w2v[4] = right[1];   w2v[8] = right[2];
    w2v[1] = up[0];      w2v[5] = up[1];      w2v[9] = up[2];
    w2v[2] = forward[0]; w2v[6] = forward[1]; w2v[10] = forward[2];

    // Re-encode the SAME camera position with the rotated basis: a pure in-place rotation.
    w2v[12] = -(right[0] * pos[0] + right[1] * pos[1] + right[2] * pos[2]);
    w2v[13] = -(up[0] * pos[0] + up[1] * pos[1] + up[2] * pos[2]);
    w2v[14] = -(forward[0] * pos[0] + forward[1] * pos[1] + forward[2] * pos[2]);
    w2v[15] = 1.f;
}


static void Put16(float* dst, const float* src)
{
    if (src == nullptr)
    {
        for (int i = 0; i < 16; ++i) dst[i] = 0.f;
        return;
    }
    for (int i = 0; i < 16; ++i) dst[i] = src[i];
}

const float* MatrixRing::Bind(const float* worldToView, const float* viewToClip,
                              const float* prevWorldToView, const float* prevViewToClip)
{
    const uint32_t index = next % (uint32_t) kSlots;
    next = (index + 1u) % (uint32_t) kSlots;
    ++binds;

    float* base = slot[index];
    Put16(base + 0, worldToView);
    Put16(base + 16, viewToClip);
    Put16(base + 32, prevWorldToView);
    Put16(base + 48, prevViewToClip);
    return base;
}

static bool g_runtimeEnabled = false;   // STOPPED until the hotkey says otherwise

void SetRuntimeEnabled(bool on) { g_runtimeEnabled = on; }
bool IsRuntimeEnabled() { return g_runtimeEnabled; }

void ResetFrameData()
{
    std::lock_guard<std::mutex> lock(g_mutex);
    g_frameData = FrameData {};
}

int BuildPresentedFramePlan(int framesToGenerate, int slots, PresentedFrame* plan, int planCapacity)
{
    if (plan == nullptr || framesToGenerate < 1 || slots < 1)
        return 0;

    const int count = framesToGenerate + 1;   // the rendered frame plus M generated ones
    if (planCapacity < count)
        return 0;

    const float step = 1.0f / static_cast<float>(count);   // generated frame k sits at k/(M+1)

    for (int k = 0; k < count; ++k)
    {
        PresentedFrame& p = plan[k];
        p.presentedIndex = k;
        p.outputSlot = k % slots;
        p.interpolationT = (k == 0) ? 0.f : (static_cast<float>(k) * step);
        p.isRenderedFrame = (k == 0);
    }

    return count;
}

}   // namespace p2
