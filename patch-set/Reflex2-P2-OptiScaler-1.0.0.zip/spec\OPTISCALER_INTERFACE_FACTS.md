# SPEC: OptiScaler 接口事实 (P2-S1 定稿)

> 证据分级 **T1** = 直接读源码(文件:行号)。**未知** = 未查证, 不许推断。
> 源码树: `OptiScaler_20260923_154112\OptiScaler_source_5b6bc822` (v10.0.0-dev, 5b6bc822)。
> 本文件只记**事实**, 结论/方案见 `spec\OPTISCALER_INTEGRATION.md` 与 `plans\p2-optiscaler-latewarp.md`。

## ① hudfix 的无 UI 帧能否当 `Latewarp.HudlessColor`/`UIColorAlpha` —— **结论: 可以 (待确认格式)** [T1]

| 事实 | 位置 |
|---|---|
| 它有**自己的**捕获纹理数组 `_captureBuffer[fIndex]` | `hudfix\Hudfix_Dx12.cpp` |
| 捕获 = 把候选资源**整张拷进**自己的纹理: `cmdList->CopyResource(_captureBuffer[fIndex], resource->buffer);` | `Hudfix_Dx12.cpp:832` |
| 捕获纹理按**交换链尺寸**创建: `..., _captureBuffer[fIndex], scWidth, scHeight)` | `Hudfix_Dx12.cpp:849` |
| 捕获后还会跑一次 **FormatTransfer** 规范化格式 | `Hudfix_Dx12.cpp:923,941` |
| 结束状态被置为 **`D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE`**(即可作 SRV 读取) | `Hudfix_Dx12.cpp:943` |
| 它对外发布"抓到无 UI 帧"这件事 | `Hudfix_Dx11.cpp:269 HudlessFound()`(Dx11 侧同构) |

⇒ 交换链尺寸 + 可作 SRV + 有自己的生命周期 ⇒ **结构上正是 latewarp 要的输入平面**。
**待确认**: 规范化后的具体 DXGI 格式是否落在 latewarp 内核认的那组(路线 A 实测内核认 **87/10**)。

## ② `sl::Constants` 是否能提供 latewarp 要的四个矩阵 + jitter —— **结论: 数据在手上, 只差推导** [T1]

**Hook 点**: `hooks\Streamline_Hooks.cpp:1044`
```
sl::Result StreamlineHooks::hkslSetConstants(const sl::Constants& values, const sl::FrameToken& frame, ...)
    -> return o_slSetConstants(values, frame, viewport);   // 目前原样透传, 不取字段
```
(GDI SL1 版本: `:622 hkslSetConstants_sl1(const sl1::Constants& values, ...)`; reflex 版本: `:1462`)

**`sl::Constants` 的字段**(`_re\probe\sdk\sl\sl_consts.h`, `SL_STRUCT_BEGIN(Constants, ...)` at L182):

| 字段 | 行 | 对 latewarp 的意义 |
|---|---|---|
| `float4x4 cameraViewToClip` | L188 | = `Latewarp.ViewToClipMatrix` |
| `float4x4 clipToCameraView` | L190 | V2C 的逆 |
| `float4x4 clipToPrevClip` | L196 | 当前 clip → 上一帧 clip(注释: `= clipToView * viewToViewPrev * viewToClipPrev`) |
| `float4x4 prevClipToClip` | L199 | 上帧 clip → 当前 clip |
| `float2 jitterOffset` | L202 | = `Latewarp.Jitter.Offset` |
| `float2 mvecScale` | L204 | MV 缩放 |
| `float2 cameraPinholeOffset` | L206 | — |
| `float3 cameraPos/cameraUp/cameraRight/cameraFwd` | L208-214 | 相机基(可构造 WorldToView) |
| `float cameraNear/Far` | L217+ | 深度线性化 |

⇒ **四个矩阵中 `ViewToClip` 直接有; jitter 直接有; MV 缩放有; 相机构造基有**。
`PrevRenderedViewToClip` / `PrevRenderedWorldToView` 需要**推导**(用 `clipToPrevClip`/`prevClipToClip` 或缓存上一帧的值)。
**注意**: P1 实测发现 demo 传的结构是"**位姿差一帧 + 投影两帧相同**" ⇒ 简单做法是**缓存上一帧的 `cameraViewToClip`**。
**待验证**: 推导式要与内核实际读法对上(P1 离线 harness 可做差分验证)。

## ③ 深度/MV 的格式·极性·缩放约定是否与内核一致 —— **部分已知, 仍需查** [T1 + 未知]

| 已知 | 位置 |
|---|---|
| `InitFlags.DepthInverted` / `.LowResMV` / `.JitteredMV` 已有 | `upscalers\IFeature.h:18,20,21` |
| `_depthLinear`(线性深度标记) 已有 | `IFeature.h:85`; `virtual bool DepthLinear()` L153; `DepthInverted()` L156 |
| latewarp 侧同样有 `Latewarp.DepthInverted` 键 | `_re\reflex2_mod\spec\LATEWARP_KEYS.tsv` |

**结论(T1)**: 深度/MV 是**从 NGX 参数对象里取的**, 与 latewarp 同一机制 —— 证据:
`framegen\nvngx\Nvngx_FFX.cpp:256` = `InParameters->Get("DLSSG.MVecs", &motionVectors);`
(同族键还有 `DLSSG.MvecScaleX/Y` `:564,565`, `DLSSG.CameraNear/Far` `inputs\NVNGX_DLSS_Dx12.cpp:1119,1122`)。
即: OptiScaler 已习惯"从参数对象拿平面句柄", 这正是 latewarp 的 43 键工作方式。
格式方面: `hudfix\Hudfix_Dx12.cpp:21 GetFormatGroup()` 已有格式族分类, 且捕获后跑 FormatTransfer 规范化。

**仍然未知(只能在运行期确定)**: 目标现场的实际深度/MV DXGI 格式与极性值。
⇒ 不作为静态阻塞项; 由 P2-S3/S5 在运行期断言(P1 已证明内核认 **87/10**)。

## ④ 自建实例时命令列表/资源状态是否安全 —— **未知 (推迟到 P2-S4 处理)** [未知]

已知先例(本项目自身教训, 非 OptiScaler): 路线 A 曾在**游戏热路径**上装钩子导致 4 秒内两次崩溃;
OptiScaler 的规格文档记录它自己"**从设备创建那一刻接管**"并给资源/命令列表注册 `ID3DDestructionNotifier`
(见 `_re\routeA\SPEC_B_TAKEOVER.md`)。⇒ S4 必须走"冷路径安装 + 自建实例", 不得在热路径装钩子。

## ⑤ latewarp 的输出接到呈现链哪一步 —— **结论: 有一条现成的 reproject 通道** [T1]

| 事实 | 位置 |
|---|---|
| OptiScaler **已有 reproject 着色器模块** | `shaders\reproject\Reproject_Dx12.{h,cpp}` + `Reproject_Common.h` |
| 其派发签名已带 latewarp 需要的两个输入 | `Reproject_Dx12.h:57`: `bool Dispatch(IDXGISwapChain3* sc, ID3D12GraphicsCommandList* cmdList, ReprojectionParams& params, ID3D12Resource* hudless, D3D12_RESOURCE_STATES state, ID3D12Resource* depth, D3D12_RESOURCE_STATES depthState);` |

⇒ latewarp 可以**接在这条通道上**(同输入: hudless + depth + params), 或作为它的等价替代实现。
这大幅降低了"输出接到哪"的风险。

## 结论: 5 项的状态

| 项 | 状态 |
|---|---|
| ① hudless 可作输入 | **可行**(待确认格式 87/10) |
| ② 矩阵 + jitter | **数据在手上**(待做推导式 + 差分验证) |
| ③ 深度/MV 约定 | **部分已知, 需补一处查证** |
| ④ 自建实例安全性 | **未知** → 推迟到 P2-S4(有本项目崩溃先例, 必须冷路径) |
| ⑤ 输出接法 | **有现成 reproject 通道** |

⇒ **没有发现"不可行"的阻塞项**; 计划可以按 `plans\p2-optiscaler-latewarp.md` 推进。
**S1 完成**: 5 项全部有结论(① 可行 / ② 数据在手上 / ③ 同机制取参, 运行期断言格式 / ④ 推迟 S4 / ⑤ 有现成通道)。

## ⑥ [重大前提] 本机**已存在** OptiScaler 的可复现构建链 [T2]

这直接决定 S2 的"编译通过"验收能立刻验证:

| 项 | 状态 |
|---|---|
| 构建工作区 | `_re\repro_src\`(源码 + `OptiScaler.sln` + `OptiScaler.vcxproj`) |
| 固定版本头(否则版本串会变) | `OptiScaler\resource_build_date.h` = `"20260923_154018"`; `resource_build_commit.h` = `"5b6bc822"` —— **已就位** |
| **已构建产物** | `_re\repro_src\x64\ReleaseDebug\OptiScaler.dll` = **25,897,984 B**(与 `BUILD_FROM_SOURCE.md` §4 预期一致) + `OptiScaler.map`(14 MB) |
| 增量构建脚本 | `_re\optiscaler_verify\repro_build2.ps1`; 全量 `repro_build.ps1`; 重链接出 map `repro_map2.ps1` |
| 校验脚本 | `_re\optiscaler_verify\norm_compare.py`(与发布 DLL 做函数级比对; 预期 947/947 导出等) |
| MSBuild | `C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe` ✓ |
| 构建命令 | `msbuild /m /p:Configuration=ReleaseDebug /p:Platform=x64 OptiScaler.sln` |

⇒ **S2 的验证方式**: 把 `p2\` 的文件应用到 `_re\repro_src`(**构建工作区, 不是交付的源码树** ⇒ 满足 INV-P4)
→ 跑 `repro_build2.ps1` 增量编译 → 必须产出新的 `OptiScaler.dll`。这正是 AC-P2-001 的一半。

## ⑦ 特征 DLL 指纹(供 P2-S6 安装器做哈希校验) [T1]

取自 `_re\optiscaler_verify\latewarp_facts.json`(该文件即对 `bin\nvngx_latewarp.dll` 的 PE 指纹):

| 项 | 值 |
|---|---|
| 整文件 SHA-256 | `81E63B4A9DCFB99B2B71C3DDFD3EA4A0E9780B778BD47E9A6F7F010A7A6C0F20` |
| 大小 | 907,296 B |
| Version | 310,2,0,0 ("NVIDIA Latewarp - DVS PRODUCTION") |
| 链接器 / 时间戳 | 14.30 / 2025-04-10T22:48:22Z |
| `.text` SHA-256 | `64716487C1C6DBC5450C0DBF1E19249BAB16D4BE29FB8878D8490B99DDD4FFE1` |

⇒ 安装器在"就地取用使用者自备的那份"时可以核对整文件 SHA-256; 版本不符时**明确报错**(不静默)。
