// ---------------------------------------------------------------------------
//  Part of the P2 latewarp integration for OptiScaler.
//  SPDX-License-Identifier: GPL-3.0-or-later   (OptiScaler itself is GPL-3)
// ---------------------------------------------------------------------------
#include <pch.h>

#include "LatewarpFeature.h"

LatewarpFeature::LatewarpFeature() {}

// The NGX feature handle is released by LatewarpFeatureDx12::Release(); doing it here would
// run during static teardown, when the NGX module may already be gone.
LatewarpFeature::~LatewarpFeature() {}
